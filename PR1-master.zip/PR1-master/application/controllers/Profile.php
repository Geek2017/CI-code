<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profile extends CI_Controller {

	function __construct() {
        parent::__construct();
    }
    
    public function validate_profile()
    {

    	    $lname = $this->input->post("lname");
            $fname = $this->input->post("fname");
            $bday = $this->input->post("bday");
            $contact = $this->input->post("contact");
            $email= $this->input->post("email");
            $address = $this->input->post("address");
            $zip = $this->input->post("zip");
            $city = $this->input->post("city");
            $country = $this->input->post("country");
            $password = $this->input->post("password");
            $c_password = $this->input->post("c_password");
            $current_position = $this->input->post("current_position");
            $number_years_position = $this->input->post("number_years_position");
            $started_date = $this->input->post("started_date");


            if( $lname == null ){
	        	echo json_encode(array( 
						'mcontent' => 'error', 
						'id' => "lname" ,
						'message' => "Nom obligatoire",
					));
            }else if($fname == null ){
            	echo json_encode(array( 
					'mcontent' => 'error', 
					'id' => "fname",
					'message' => "Prénom obligatoire",
				));
            }else if($bday == null){
            	echo json_encode(array( 
					'mcontent' => 'error', 
					'id' => "bday",
					'message' => "Date de naissance obligatoire",
				));
            }else if( $this->session_checker->check_date("/", $bday ) == "true" ){
            	echo json_encode(array( 
					'mcontent' => 'error', 
					'id' => "bday",
					'message' => "veuillez entrer une date valide",
				));
            }else if( $contact == null ){
            	echo json_encode(array( 
					'mcontent' => 'error', 
					'id' => "contact" ,
					'message' => "Contact obligatoire",
				));
			}else if( trim($contact) == null ){
            	echo json_encode(array( 
					'mcontent' => 'error', 
					'id' => "contact" ,
					'message' => "Invalid Contact Numéro",
				));
            }else if( $address == null ){
            	echo json_encode(array( 
					'mcontent' => 'error', 
					'id' => "address",
					'message' => "Adresse obligatoire",
				));
            }else if( $zip == null ){
            	echo json_encode(array( 
					'mcontent' => 'error', 
					'id' => "zip" ,
					'message' => "Code postal obligatoire",
				));
            }else if( !is_numeric( $zip ) ){
            	echo json_encode(array( 
					'mcontent' => 'error', 
					'id' => "zip" ,
					'message' => "Code postal doit être au format numérique",
				));
            }else if( $city == null ){
            	echo json_encode(array( 
					'mcontent' => 'error', 
					'id' => "city" ,
					'message' => "Ville obligatoire",
				));
            }else if( $country == null ){
            	echo json_encode(array( 
					'mcontent' => 'error', 
					'id' => "country" ,
					'message' => "Pays obligatoire",
				));
            }else if($password == null) {
				echo json_encode(array(
					'mcontent' => 'error',
					'id' => "passwords" ,
					'message' => "Mot de passe obligatoire",
				));
			}else if($this->password_required( $c_password, $password )){
				echo json_encode(array(
					'mcontent' => 'error',
					'id' => "c_password" ,
					'message' => "Les mots de passe ne correspondent pas!",
				));
			}else if( $current_position == null ){
            	echo json_encode(array( 
					'mcontent' => 'error', 
					'id' => "current_position" ,
					'message' => "Métier ou Poste actuel obligatoire",
				));
            }else if( $number_years_position == null ){
            	echo json_encode(array( 
					'mcontent' => 'error', 
					'id' => "number_years_position",
					'message' => "Nombre d'années est obligatoire",
				));
			}else if( !is_numeric($number_years_position) ){
            	echo json_encode(array( 
					'mcontent' => 'error', 
					'id' => "number_years_position",
					'message' => "Nombre Seulement",
				));
            }else if( $started_date == null){
            	echo json_encode(array( 
					'mcontent' => 'error', 
					'id' => "started_date" ,
					'message' => "Date création obligatoire",
				));
            }else if( $this->profiles->email_required($email) )
    		{
    			echo json_encode(array( 
					'mcontent' => 'error', 
					'id' => "email" ,
					'message' => "Format d'email invalide",
				));
    		}else{
    			$this->profiles->save_profile();
    		}
    }
    public function password_required( $c_password, $password )
	{
		    if( $password != null )
		    {
		    	if( $c_password != $password )
		    	{
	            	return true;
            	}
		    }
	}
	public function sections_profile()
	{
		$secid = $this->input->post('secid');
		$Percent_Done = $this->questions->getPercentage_($secid);
		$data = $this->globalmodel->is_section_allow((int)$secid, 2);

		if($Percent_Done >= 100)
		{
			echo json_encode( array( 'msg' => 'results page' , 'redirect' => 'yes' ) );
		}
		else if($secid == 1 && $Percent_Done == 0) {
			echo json_encode( array( 'msg' => 'incomplete', 'redirect' => 'no', 'section_param'=>1, 'last_answered'=>'' ) );
		}
		else if($secid == 6 || $secid == 7 && $this->users->with_referent() == 0 ) 
		{
			if(floor($data['section_param']) == 7 || floor($data['section_param']) == 6  )
				echo json_encode( array( 'msg' => 'incomplete', 'redirect' => 'no', 'section_param'=>$data['section_param'], 'last_answered'=>$data['last_answered'] ) );
			else
				echo json_encode( array( 'msg' => 'incomplete', 'redirect' => 'no', 'section_param'=>7, 'last_answered'=>'' ) );
		}
		else
		{
			//$data = $this->globalmodel->is_section_allow((int)$secid, 2);
			if(floor($data['section_param']) == $secid)
				echo json_encode( array( 'msg' => 'incomplete', 'redirect' => 'no', 'section_param'=>$data['section_param'], 'last_answered'=>$data['last_answered'] ) );
			else if($this->globalmodel->get_setting('allow_skip_question') == 1)
				echo json_encode( array( 'msg' => 'incomplete', 'redirect' => 'no', 'section_param'=>$secid, 'last_answered'=> '' ));
			else
				echo json_encode( array( 'msg' => 'incomplete', 'redirect' => 'inc' ) );
		}
//		if( $this->questionaires_length($secid) ==  $this->steps_length($secid) )
//		{
//			if( $this->check_percentages($secid) ){
//
//				echo json_encode( array( 'msg' => 'incomplete', 'redirect' => 'no' ) );
//
//			}else{
//
//				echo json_encode( array( 'msg' => 'results page' , 'redirect' => 'yes' ) );
//			}
//
//		}else{
//
//			echo json_encode( array( 'msg' => 'incomplete' , 'redirect' => 'no' ) );
//		}

	}
	public function questionaires_length($secid)
	{
	    $user_id = $this->session->userdata('id');
	    $concat = "";
	    $count = "";
	    //switch ($secid) 
	    //{
	    	//case '1':
	    	//	$concat = "q_section = '$secid' ";//no decimal point
	    	//	break;
	    	
	    	//default:
	    		$concat = "q_section LIKE '$secid%' "; //others with point 0.0 or 0.0.0
	    		//break;
	    //}

		foreach ($this->db->query(" SELECT DISTINCT( q_section ) as q_section FROM `questionaires` 
			WHERE $concat ")->result() as $key => $value) 
		{
			$count += count( $value->q_section ) ;
		}
		return $count;
	}
	public function steps_length($secid)
	{
		$user_id = $this->session->userdata('id');
		$concat = "";
		$count = "";

		//switch ($secid) 
	   // {
	    //	case '1':
	    //		$concat = "section_id= '$secid' ";//no decimal point
	    //		break;
	    	
	    //	default:
	    		$concat = "section_id LIKE '$secid%' "; //others with point 0.0 or 0.0.0
	    //		break;
	    //}

	    foreach ( $this->db->query("  SELECT * FROM `step` WHERE $concat AND user_id = '$user_id' ")->result() as $key => $value) 
		{
		$count += count( $value->section_id ) ;
		}
		return $count;
	}
	public function check_percentages($secid)
	{
		$user_id = $this->session->userdata('id');
	    $concat = "";
	  
	    //switch ($secid) 
	    //{
	    //	case '1':
	    //		$concat = "q_section = '$secid' ";//no decimal point
	    ///		break;
	    	
	    //	default:
	    		$concat = "q_section LIKE '$secid%' "; //others with point 0.0 or 0.0.0
	    //		break;
	   // }

		foreach ($this->db->query(" SELECT DISTINCT( q_section ) as q_section FROM `questionaires` 
			WHERE $concat ")->result() as $key => $value) 
		{
			foreach ( $this->db->query(" SELECT * FROM `step` WHERE section_id = '$value->q_section' AND user_id='$user_id' ")->result() as $key => $value) 
			{
				if( $value->percentage < 100){
					return true;
				}
			}
		}

	}
}
