<?php
	$sub = explode('/', $this->uri->uri_string());
	switch($sub[0]){
	  case 'sections':
	     if(count($sub) > 1){
	       switch ( $sub ) {
	       	case is_numeric( $sub[1] ):
	       			$active =  floor($sub[1]);
						//substr_replace($sub[1], '', 1 , 2);
	       		break;
	       	
	       	case is_numeric( $sub[2] ):
	       			$active =  floor($sub[2]);
						//substr_replace( $sub[2] , '', 1 , 2);
	       		break;
	       }
	     }
     break;
	}

	if(isset($dat)){
		$data = (json_decode($dat));
		$rows = $data->total_rows;
		$answered = $data->answered;
	}else{
		$rows = 0;
		$answered = 0;
	} 
 
	if ($rows == 0) {
		$s_last = $this->uri->total_segments();
	}else{
		$s_last = $this->uri->total_segments()-1;
	}
	$section_num = $this->uri->segment($s_last);

  
?>
<div class="progress-state">
	<ul class="list-inline global-progress">
        <?php
		$lp = [];
		for($i=1; $i <= 10; $i++) {

        	$this->db->select('*');
		    $this->db->from('section');

		    $this->db->where('section_id',$i);
		    $query = $this->db->get();
		    $sec = $query->result();
		    $sec = $sec[0];

			$r_last = $this->uri->total_segments()-1;
			$result = $this->uri->segment($r_last);
			if($i) 
			{
				$Percent_Done = $this->questions->getPercentage_($i);
				$Percent_Done_Prev = $i != 1 ? $this->questions->getPercentage_($i - 1) : 100;
				$lp[] = $Percent_Done;
			}
        	?>
                <li>
                    <a href="#" onclick='	sections_progress(event,"<?php echo $i;?>","<?php echo $Percent_Done; ?>","<?php echo $Percent_Done_Prev; ?>");'><p><?php echo $i > 9 ? $i : '&nbsp'.$i.'' ?></p>
                	<img src="<?php echo base_url('assets/img/progress.png'); ?>" alt="progress" 
                	class="img-responsive <?php if($i == $active){ echo "active"; } ?>" 
                	/>
                	</a>
                </li>
                 
        <?php } $filter_lp = array_keys(array_filter($lp));   ?>

    </ul>
	<input type="hidden" id="lowest_p" value="<?php echo count(array_filter($lp)) > 0 && min(array_filter($lp)) == 100  ?  end($filter_lp) + 2 : ( count(array_filter($lp))> 0 ? (array_keys($lp,min(array_filter($lp)))[0]) + 1 : 1) ?>">

</div>

<div></div>
