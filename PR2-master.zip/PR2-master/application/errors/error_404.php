<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta Http-Equiv="Cache-Control" Content="no-cache">
    <meta Http-Equiv="Pragma" Content="no-cache">
    <meta Http-Equiv="Expires" Content="0">
    <title>404 - Page non trouvée</title>
    <!-- Bootstrap CSS -->
    <link href="<?=plugins_bundle();?>template/css/bootstrap.min.css" rel="stylesheet">
    <!-- Notify Me CSS -->
    <link href="<?=plugins_bundle();?>bootstrap/notify_3.3.1/animate.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="<?=plugins_bundle();?>template/css/sb-admin.css" rel="stylesheet">
    <!-- Favicon -->
    <link href="<?=images_bundle();?>fav-icon.ico" rel="icon" sizes="32x32">
    <!-- Custom Fonts -->
    <link href="<?=plugins_bundle();?>template/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!--     <style type="text/css">

        ::selection{ background-color: #E13300; color: white; }
        ::moz-selection{ background-color: #E13300; color: white; }
        ::webkit-selection{ background-color: #E13300; color: white; }

        body {
            background-color: #fff;
            margin: 40px;
            font: 13px/20px normal Helvetica, Arial, sans-serif;
            color: #4F5155;
        }

        a {
            color: #003399;
            background-color: transparent;
            font-weight: normal;
        }

        h1 {
            color: #444;
            background-color: transparent;
            border-bottom: 1px solid #D0D0D0;
            font-size: 19px;
            font-weight: normal;
            margin: 0 0 14px 0;
            padding: 14px 15px 10px 15px;
        }

        code {
            font-family: Consolas, Monaco, Courier New, Courier, monospace;
            font-size: 12px;
            background-color: #f9f9f9;
            border: 1px solid #D0D0D0;
            color: #002166;
            display: block;
            margin: 14px 0 14px 0;
            padding: 12px 10px 12px 10px;
        }

        #container {
            margin: 10px;
            border: 1px solid #D0D0D0;
            -webkit-box-shadow: 0 0 8px #D0D0D0;
        }

        p {
            margin: 12px 15px 12px 15px;
        }
    </style> -->
</head>
<body>
<div id="error_404" class="container-fluid">
    <div class="row text-center">
        <div class="col-md-12">
            <img class="logo center-block" src="<?=base_url('resources/images/logo_black.png')?>" width="320">
            <h1><?="404 - Page non trouvée"?></h1>
            <p><?="La page que vous avez demandée ne peut pas être trouvée"?></p>
        </div>
    </div>
    <div class="row text-center">
        <div class="col-md-12">
            <div class="form-inline">
                <form class="form-group">
                    <input type="text" class="form-control" id="text" placeholder="Qu'est-ce que vous cherchez ?">
                </form>
                <form class="form-group">
                    <button type="submit" class="btn btn-defaul btn-sm pull-right">Rechercher</button>
                </form>
            </div>
        </div>
    </div>
</div>
</body>
</html>