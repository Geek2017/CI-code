<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class City_location extends MY_Controller {
    public function __construct()
    {
        //parent::__construct();
        $this->my_controller_parent_construct();
        $this->check_session_timed_out("bo");
        //load language files
        $this->load_language_backoffice();
        $this->lang->load('backoffice/system_config', 'fr');
        //load models
        $this->load->model("event_city_location_model");
        $this->load->model("user_activity_log_model");
    }

    public function add_city(){
        if($this->input->post()) {
            if($this->event_city_location_model->check_city($this->input->post('city'), "")){
                output_to_json($this, array(
                    "mtype" => "error",
                    "message" => $this->lang->line("city_name_exist"),
                    "mdetail" => array(array("field" => "city", "message" => $this->lang->line("city_name_exist")))
                ));
            } else {
                $insert_new_city = $this->event_city_location_model->add_city($this->input->post('city'));
                if($insert_new_city) {

                    $act_log = $this->user_activity_log_model->add_activity_log(array(
                        "description" => $this->lang->line("added_new_city_loc")." - ".$this->input->post('city'),
                        "user_id"   =>  $this->data["logged_in"]["user_id"],
                        "action"    =>  "ADD",
                        "table_origin" => "event_city_location",
                        "reference_id" => $insert_new_city
                    ));

                    if($act_log){
                        output_to_json($this, array(
                            "mtype" => "success",
                            "message" => $this->lang->line("new_city_added")
                        ));
                    } else {
                        output_to_json($this, array(
                            "mtype" => "warning",
                            "message" => $this->lang->line("unknown_error")
                        ));
                    }
                } else {
                    output_to_json($this, array(
                        "mtype" => "error",
                        "message" =>  $this->lang->line("unknown_error_on_saving")
                    ));
                }
            }
        } else {
            show_404();
        }
    }

    public function edit_city($city_location_id){
        if($this->input->post()) {
            if($this->event_city_location_model->check_city($this->input->post('city'), $city_location_id)) {
                output_to_json($this, array(
                    "mtype" => "error",
                    "message" => $this->lang->line("city_name_exist"),
                    "mdetail" => array(array("field" => "city", "message" => $this->lang->line("city_name_exist")))
                ));
            } else {
                $update_city = $this->event_city_location_model->edit_city($city_location_id, $this->input->post('city'));

                if($update_city) {

                    $act_log = $this->user_activity_log_model->add_activity_log(array(
                        "description" => $this->lang->line("updated_city_logs")." - ".$this->input->post('city'),
                        "user_id"   =>  $this->data["logged_in"]["user_id"],
                        "action"    =>  "EDIT",
                        "table_origin" => "event_city_location",
                        "reference_id" => $city_location_id
                    ));

                    if($act_log) {
                        output_to_json($this, array(
                            "mtype" => "success",
                            "message" => $this->lang->line("update_city_name")
                        ));
                    } else {
                        output_to_json($this, array(
                            "mtype" => "warning",
                            "message" => $this->lang->line("unknown_error")
                        ));
                    }
                } else {
                    output_to_json($this, array(
                        "mtype" => "error",
                        "message" => $this->lang->line("unknown_error_on_updates")
                    ));
                }
            }
        } else {
            show_404();
        }
    }

    public function delete_city($city_location_id){
        if($this->input->post() && $city_location_id) {
            $delete_city = $this->event_city_location_model->delete_city($city_location_id);
            if($delete_city) {
                $act_log = $this->user_activity_log_model->add_activity_log(array(
                    "description" => $this->lang->line("deleted_city_name")." - ".$city_location_id,
                    "user_id" => $this->data["logged_in"]["user_id"],
                    "action" => "DELETE",
                    "table_origin" => "event_city_location",
                    "reference_id" => $city_location_id
                ));

                if ($act_log) {
                    output_to_json($this, array(
                        "mtype" => "success",
                        "message" => $this->lang->line("deleted_city_name")
                    ));
                } else {
                    output_to_json($this, array(
                        "mtype" => "warning",
                        "message" => $this->lang->line("unknown_error")
                    ));
                }
            }
        } else {
            show_404();
        }
    }

    public function get_city_location_list(){
        $list = $this->event_city_location_model->get_datatables($this->input->post());
        $data = array();
        $row = array();
        $x = $this->input->post("start");

        foreach ($list as $cityloc) {
            $row["city_order"] = ++$x;
            $row["city"] = $cityloc->city;
            $row["action"] = $cityloc->city_location_id;
            array_push($data, $row);
        }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->event_city_location_model->count_all($this->input->post()),
            "recordsFiltered" => $this->event_city_location_model->count_filtered($this->input->post()),
            "data" => $data,
        );
        //output to json format
        output_to_json($this, $output);
    }
}