<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Background_service extends MY_Controller {
    protected $_servers_;
    public function __construct()
    {
        $this->my_controller_parent_construct();
        $this->load->library("mailjet_libr");
        $this->load->model("event_email_recipient_model");
        $this->load->model("event_email_template_model");
    }

    public function run_service_011($limit, $service_type, $server){
        if ((isset($service_type) && !empty($service_type)) || (isset($this->_servers_[$server]) && !empty($this->_servers_[$server]))) {
            if (isset($limit) && !empty($limit)) {
                $maildata = $this->get_mail_recipes($limit, $service_type);
                if ($maildata["status"]) {
                    $maildata["addVars"] = $this->definedVars(strtoupper($server));
                    $mjmailer_response = $this->mailjet_libr->send($maildata, $service_type);

                    if (isset($mjmailer_response["success"]) && !empty($mjmailer_response["success"])) {
                        if(sizeof($mjmailer_response["sent_emails"]) > 0 || sizeof($mjmailer_response["failed_emails"]) > 0) {
                            $response = $this->event_email_recipient_model->update_recipient_email_status($mjmailer_response, $service_type);
                            if ($response) {
                                echo $mjmailer_response["logs"] . PHP_EOL;
                                //echo "Log (" . date("Y-m-d H:i:s A") . ") : Sent Email : ".sizeof($mjmailer_response["sent_emails"]) ."  Failed Email : ".sizeof($mjmailer_response["failed_emails"]) . PHP_EOL;
                            } else {
                                echo "Log (" . date("Y-m-d H:i:s A") . ") : Server connection error." . PHP_EOL;
                            }
                        } else {
                            echo "Log (" . date("Y-m-d H:i:s A") . ") : Err code : ".$mjmailer_response["logs"]." Message : Cannot send emails." . PHP_EOL;
                        }
                    } else {
                        if (isset($mjmailer_response["logs"]) && !empty($mjmailer_response["logs"])) {
                            echo "Log (" . date("Y-m-d H:i:s A") . ") : " . print_r($mjmailer_response["logs"]) . PHP_EOL;
                        } else {
                            echo "Log (" . date("Y-m-d H:i:s A") . ") : Unknown error occurred" . PHP_EOL;
                        }
                    }
                } else {
                    echo $maildata["message"];
                }
            } else {
                echo "Log (" . date("Y-m-d H:i:s A") . ") : Specify the number of items to process." . PHP_EOL;
            }
        } else {
            echo "Log (" . date("Y-m-d H:i:s A") . ") : Undefined service type." . PHP_EOL;
        }
    }

    private function get_mail_recipes($limit, $type){
        switch($type){
            case 1 :
                return $this->get_reminder_emails($limit);
                break;
            case 2 :
                return $this->get_waitlist_emails($limit);
                break;
            case 3 :
                return $this->get_push_event_emails($limit);
                break;
            default :
                echo "No action has been specified.";
                exit(0);
                break;
        };
    }

    public function auto_close_and_open_event($service_code){
        if (isset($service_code) && !empty($service_code)) {
            if($service_code == "lemodeFRWlogx0d@2016") {
                //open events
                $this->load->model("event_model");
                $openevent_feedback = $this->event_model->open_events();
                $closeevent_feedback = $this->event_model->close_events();
                if($openevent_feedback || $closeevent_feedback) {
                    echo "System (" . date("Y-m-d H:i:s A") . ") : Unlock processes : " . $openevent_feedback . "\n" .
                        "System (" . date("Y-m-d H:i:s A") . ") : Events Closed : " . $closeevent_feedback . PHP_EOL;
                }
            } else {
                echo "System (" . date("Y-m-d H:i:s A") . ") : Unknown service code." . PHP_EOL;
            }
        } else {
            echo "System (" . date("Y-m-d H:i:s A") . ") : Undefined service. Please specify the service code to run upon calling this function." . PHP_EOL;
        }
    }

    public function auto_unlock_fo_actions($service_code){
        if (isset($service_code) && !empty($service_code)) {
            if($service_code == "lemodeFRWlogx0d@2016") {
                $this->load->model("event_concurrent_process_model");
                $unlock_processes = $this->event_concurrent_process_model->cron_unlock_fo_actions();
                if($unlock_processes) {
                    echo "System (" . date("Y-m-d H:i:s A") . ") : Unlock processes : " . $unlock_processes . "\n" . PHP_EOL;
                }
            } else {
                echo "System (" . date("Y-m-d H:i:s A") . ") : Unknown service code." . PHP_EOL;
            }
        } else {
            echo "System (" . date("Y-m-d H:i:s A") . ") : Undefined service. Please specify the service code to run upon calling this function." . PHP_EOL;
        }
    }

    public function get_reminder_emails($limit=1){
        if($limit>0) {
            $this->load->model("event_registration_model");
            $published_events = $this->event_registration_model->get_data_reminder_email_list();
            // print_r($published_events);
            if ($published_events) {
                $mj_mailer_data = array();
                foreach ($published_events as $value) {
                    $event_email_tpl = $this->event_email_template_model->get_current_event_email_template($value->event_id, $value->event_schedule_id, 1, true);
                    // print_r($event_email_tpl);                    
                    if(sizeof($event_email_tpl) > 0) {
                        $event_email_tpl->email_tpl_detail = urldecode($event_email_tpl->email_tpl_detail);

                        $subscribers = $this->event_registration_model->get_event_subscribers_list($value->event_start_date_time, $value->event_schedule_id, $limit);
                        $total_result = sizeof($subscribers);
                        // print_r($subscribers);
                        if ($total_result > 0) {
                            if ($total_result < $limit) {
                                $limit = $limit - $total_result;
                                array_push($mj_mailer_data, array(
                                    "event" => $value,
                                    "event_email_tpl" => $event_email_tpl,
                                    "subscribers" => $subscribers
                                ));
                            } else {
                                array_push($mj_mailer_data, array(
                                    "event" => $value,
                                    "event_email_tpl" => $event_email_tpl,
                                    "subscribers" => $subscribers
                                ));
                                break;
                            }
                        }
                    }
                }

                if(sizeof($mj_mailer_data) > 0){
                    return array("status" => true, "maildata" => $mj_mailer_data);
                } else {
                    return array(
                        "status" => false,
                        "message" =>  ""
                    );
                }
            } else {
                return array(
                    "status" => false,
                    "message" => ""
                );
            }
        } else {
            return array(
                "status" => false,
                "message" => "Log (" . date("Y-m-d H:i:s A") . ") : Please specify the number of mails to send per process.".PHP_EOL
            );
        }
    }

    public function get_waitlist_emails($limit=1){
        if($limit>0) {
            $this->load->model("event_wait_list_model");
            $published_events = $this->event_wait_list_model->get_data_waitlists();
            // print_r($published_events);
            if ($published_events) {
                $swift_mailer_data = array();
                foreach ($published_events as $value) {
                    $event_email_tpl = $this->event_email_template_model->get_current_event_email_template($value->event_id, $value->event_schedule_id, 2, true);
                    // print_r($event_email_tpl);
                    if(sizeof($event_email_tpl) > 0) {
                        $event_email_tpl->email_tpl_detail = urldecode($event_email_tpl->email_tpl_detail);

                        $subscribers = $this->event_wait_list_model->get_waitlists_subscribers($value->event_schedule_id, $limit);
                        $total_result = sizeof($subscribers);                        
                        if ($total_result > 0) {
                            if ($total_result < $limit) {
                                $limit = $limit - $total_result;
                                array_push($swift_mailer_data, array(
                                    "event" => $value,
                                    "event_email_tpl" => $event_email_tpl,
                                    "subscribers" => $subscribers
                                ));
                            } else {
                                array_push($swift_mailer_data, array(
                                    "event" => $value,
                                    "event_email_tpl" => $event_email_tpl,
                                    "subscribers" => $subscribers
                                ));
                                break;
                            }
                        }
                    }
                }
                if(sizeof($swift_mailer_data) > 0){
                    return array("status" => true, "maildata" => $swift_mailer_data);
                } else {
                    return array(
                        "status" => false,
                        "message" =>  ""
                    );
                }
            } else {
                return array(
                    "status" => false,
                    "message" => ""
                );
            }
        } else {
            return array(
                "status" => false,
                "message" => "Log (" . date("Y-m-d H:i:s A") . ") : Please specify the number of mails to send per process.".PHP_EOL
            );
        }
    }

    public function get_push_event_emails($limit=1){
        if($limit>0) {
            $this->load->model("event_email_custom_model");
            $published_events = $this->event_email_custom_model->get_data_push_event_email();
            // print_r($published_events);
            if ($published_events) {
                $mj_mailer_data = array();
                foreach ($published_events as $value) {
                    $event_email_tpl = $this->event_email_template_model->get_current_event_email_template($value->event_id, $value->event_schedule_id, 4, true);
                    // print_r($event_email_tpl);
                    if(sizeof($event_email_tpl) > 0) {
                        $event_email_tpl->email_tpl_detail = urldecode($event_email_tpl->email_tpl_detail);

                        $subscribers = $this->event_email_custom_model->get_push_event_recipients($value->email_custom_id, $limit);
                        $total_result = sizeof($subscribers);
                        // print_r($subscribers);
                        if ($total_result > 0) {
                            if ($total_result < $limit) {
                                $limit = $limit - $total_result;
                                array_push($mj_mailer_data, array(
                                    "event" => $value,
                                    "event_email_tpl" => $event_email_tpl,
                                    "subscribers" => $subscribers
                                ));
                            } else {
                                array_push($mj_mailer_data, array(
                                    "event" => $value,
                                    "event_email_tpl" => $event_email_tpl,
                                    "subscribers" => $subscribers
                                ));
                                break;
                            }
                        }
                    }
                }
                if(sizeof($mj_mailer_data) > 0){
                    return array("status" => true, "maildata" => $mj_mailer_data);
                } else {
                    return array(
                        "status" => false,
                        "message" =>  ""
                    );
                }
            } else {
                return array(
                    "status" => false,
                    "message" => ""
                );
            }
        } else {
            return array(
                "status" => false,
                "message" => "Log (" . date("Y-m-d H:i:s A") . ") : Please specify the number of mails to send per process.".PHP_EOL
            );
        }
    }

    public function reminder_email_management_service($service_code){
        if (isset($service_code) && !empty($service_code)) {
            if($service_code == "lemodeFRWlogx0d@2016") {
                $this->load->model("event_model");
                $this->load->model("event_email_schedule_model");
                $result = $this->event_model->get_events_for_reminder_email();
                $msg_log = "";
                // print_r($result);
                if(sizeof($result) > 0) {
                    foreach ($result as $row) {
                        $email_schedule = $this->event_email_schedule_model->get_email_sending_schedule($row);
                        // print_r($email_schedule);
                        if(sizeof($email_schedule) > 0){
                            $msg_log .=$this->reminder_subscribers($email_schedule, $row);
                        }
                    }
                }
                echo $msg_log;
            } else {
                echo "System (" . date("Y-m-d H:i:s A") . ") : Unknown service code." . PHP_EOL;
            }
        } else {
            echo "System (" . date("Y-m-d H:i:s A") . ") : Undefined service. Please specify the service code to run upon calling this function." . PHP_EOL;
        }
    }

    private function reminder_subscribers($email_schedule, $event){
        $count = 0; $events="";
        $this->load->model("event_registration_model");
        if(sizeof($email_schedule) > 0)
        {
            foreach($email_schedule as $row){
                $events .="Event_id : ".$event->event_id.", Event_schedule_id : ".$event->event_schedule_id." Email schedule_id : ".$row->email_schedule_id.", Email sched. type : ".$row->email_sched_reference." \n";
                $count += $this->event_registration_model->prepare_list_for_reimnder_email($row, $event);
            }
        } else{
            $events .="Event_id : ".$event->event_id.", Event_schedule_id : ".$event->event_schedule_id.", Email schedule_id : ".$email_schedule->email_schedule_id.", Email sched. type : ".$email_schedule->email_sched_reference." \n";
            $count += $this->event_registration_model->prepare_list_for_reimnder_email($email_schedule, $event);
        }

        if($count > 0) {
            return "System (" . date("Y-m-d H:i:s A") . ") : Count : ".$count.", Record : \n".$events. PHP_EOL;
        }
    }

    public function waitlist_management_service($service_code){
        if (isset($service_code) && !empty($service_code)) {
            if($service_code == "lemodeFRWlogx0d@2016") {
                $this->load->model("event_model");
                $this->load->model("event_wait_list_model");
                $this->load->model("event_email_schedule_model");
                $this->load->model("event_email_default_setting_model");
                $result = $this->event_model->get_events_for_waitinglist_email();

                // print_r($result);
                $parameters = $this->event_email_default_setting_model->get_default_email_schedule(2);
                $msg_log = "";

                //only process data when parameters are all set
                // if(sizeof($parameters) > 0) {
                    //only process events with waitlisted
                    if (sizeof($result) > 0) {
                        foreach ($result as $row) {

                            //check the date to reset, check from table "event_template_email"
                            if($row->email_schedule_id > 0) {

                                $check_reset_date = $this->event_email_template_model->check_reset_time($row->email_schedule_id);
                                //reset date is now
                                if($check_reset_date) {
                                    //if there are parameters already, immediately add them to "event_email_template"
                                    $msg_log .= $this->prepare_waitlist_tobe_emailed($row);
                                } else {
                                    //$msg_log .= "Log (" . date("Y-m-d H:i:s A") . ") : ";
                                }
                            } else {
                                //if there are parameters already, immediately add them to "event_email_template"
                                $msg_log .= $this->prepare_waitlist_tobe_emailed($row);
                            }
                        }
                    } else {
                        $msg_log .= "";
                    }
                // } else {
                //     $msg_log .= "System (" . date("Y-m-d H:i:s A") . ") : No default configuration for Waiting list Re-invitation." . PHP_EOL;
                // }
                echo $msg_log;
            } else {
                echo "System (" . date("Y-m-d H:i:s A") . ") : Unknown service code." . PHP_EOL;
            }
        } else {
            echo "System (" . date("Y-m-d H:i:s A") . ") : Undefined service. Please specify the service code to run upon calling this function." . PHP_EOL;
        }
    }

    private function prepare_waitlist_tobe_emailed($event){
        $result = $this->event_email_schedule_model->add_email_schedule_for_waitlist($event->event_id, $event->event_schedule_id);
        if($result["success"]) {
            $this->event_wait_list_model->prepare_list_for_reinvitation_email($result["email_schedule_id"], $event->event_schedule_id, $result["schedule"]->email_tpl_number_of_recipients);
        } else {
            return "Log (" . date("Y-m-d H:i:s A") . ") : " ."Cannot add email_template".PHP_EOL;
        }
    }

    private function add_to_waitlist_for_email($event_id){
        $this->load->model("event_deregistration_model");

        $this->event_deregistration_model->add_to_waitlist_for_email($event_id);
    }

    public function email_waiting_list_reinvitation() {
        $this->mailjet_libr->email_waiting_list_reinvitation();
    }

    public function definedVars($server){
        //BACKGROUND SERVICE FOR CRON
        if($server === "LOCAL"){
            return array(
                "base_url" => "http://localhost/weblemonde_test/",
                "lemonde_logo" => "http://localhost/weblemonde_test/resources/images/logo-lemonde.png",
                "event_picture" => "http://localhost/weblemonde_test/resources/images/frontoffice/events/",
                "event_url" => "http://localhost/weblemonde_test/frontoffice/event_details?event_id="
            );
        }
        else if($server === "DEV") {
            return array(
                "base_url" => "http://dev.wylog.com/lemonde/",
                "lemonde_logo" => "/web/lemonde/resources/images/logo-lemonde.png",
                "event_picture" => "http://dev.wylog.com/lemonde/resources/images/frontoffice/events/",
                "event_url" => "http://dev.wylog.com/lemonde/frontoffice/event_details?event_id="
            );
        } else if($server === "PRE_PROD") {
            return array(
                "base_url" => "http://dev.wylog.com/lemonde_pre_prod/",
                "lemonde_logo" => "http://dev.wylog.com/lemonde_pre_prod/resources/images/logo-lemonde.png",
                "event_picture" => "http://dev.wylog.com/lemonde_pre_prod/resources/images/frontoffice/events/",
                "event_url" => "http://dev.wylog.com/lemonde_pre_prod/frontoffice/event_details?event_id="
            );
        } else {
            return array(
                "base_url" => "http://evenements-abonnes.lemonde.fr/",
                "lemonde_logo" => "http://evenements-abonnes.lemonde.fr/resources/images/logo-lemonde.png",
                "event_picture" => "http://evenements-abonnes.lemonde.fr/resources/images/frontoffice/events/",
                "event_url" => "http://evenements-abonnes.lemonde.fr/frontoffice/event_details?event_id="
            );
        }
    }
}