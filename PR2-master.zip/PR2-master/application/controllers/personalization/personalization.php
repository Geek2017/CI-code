<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Personalization extends MY_Controller {

    public function __construct()
    {
         $this->my_controller_parent_construct();
         $this->load->model('personalization_model');

         $this->check_session_timed_out("bo");

          //$this->load_language_backoffice();
          $this->lang->load('backoffice/personalization', 'fr');

          //origin folders
          $this->hstroke_origin = origin_folders('hstroke');
          $this->banner_origin = origin_folders('banner');

          //banner and heartstroke folder
          $this->banner_folder = banner_bundle();
          $this->hstroke_folder = hstroke_bundle();
    }
    public function create_reg_form_rules()
    {

       $arr = [];
       foreach ($this->personalization_model->get_user_subscriber_reg_form()  as $key => $value) {
            array_push($arr, array(
                 "name" => $value->name,
                 "length" => 3,
                 "required" => ( $value->is_required > 0 ? true : false ),
                 "status" => ( $value->display_status > 0 ? "display" : "hidden" )
            ) );
        }

        output_to_json($this,$arr);
    }
    public function get_reg_form()
    {
    	$this->arr = [];
    	foreach ($this->personalization_model->get_user_subscriber_reg_form(1)  as $key => $value) {
    		$arr[] = $value;
    	}

    	output_to_json($this, $arr);
    }
    public function update_reg_form()
    {
         $this->arr = [];
         $this->arr['affected_rows'] = $this->personalization_model->update_user_subscriber_reg_form() >= 0 ? $this->lang->line("update_successful") : $this->lang->line("update_error");
         output_to_json($this, $this->arr);
    }
    public function upload_banner()
    {
        $data = $_POST['imagebase64'];
        $description = $_POST['description'];

        list($type, $data) = explode(';', $data);
        list(, $data)      = explode(',', $data);

        $data = base64_decode($data);
        $imageName = time().'.png';
        $origin = $this->banner_origin;
     
        if( (is_dir($origin) && is_writable($origin)) ){
          file_put_contents($origin.$imageName, $data);
            $this->arr['message'] = "success";
            $this->arr['banner'] = $imageName;
            $this->arr['description'] = $description;
            
            $this->personalization_model->upload_new_banner(
                array(
                    'image' => $imageName,
                    'description' => $description
                )
            );
            output_to_json($this,$this->arr);
        }else{
            $this->arr['message'] = "error";
            $this->arr['banner'] = $data;

            output_to_json($this,$this->arr);
        }
    }
    public function get_banner()
    {
        output_to_json($this,$this->personalization_model->upload_get_banner());
    }
    public function append_mentions_legales()
    {
        output_to_json($this,$this->personalization_model->append_mentions_legales());
    }
    public function update_mentions_legales()
    {
        if(  $this->personalization_model->update_mentions_legales() >= 0 )
        {
             $arr['message'] = $this->lang->line("update_successful");
             $arr['mtype'] = "success";
        }
        else
        {
             $arr['message'] =  $this->lang->line("update_error");
             $arr['mtype'] = "error";
        }

        output_to_json($this, $arr );
    }
    public function upload_logo()
    {
        $origin = $this->hstroke_origin;
        if( (is_dir($origin) && is_writable($origin)) ){
            $name = $_FILES['logo']['name'];
            $tmp = $_FILES['logo']['tmp_name'];
            $error = $_FILES['logo']['error'] ;
            $info = getimagesize($tmp);
            $rename = round(microtime(true)).'.'.end( explode(".", $_FILES["logo"]["name"]) );
            $store = $this->hstroke_origin.$rename;

            if ($error !== UPLOAD_ERR_OK) {
               output_to_json($this, array( 
                    "mtype" => "error" , 
                    "message" => $this->lang->line("upload_error_code") .$error
               ));
            }
            if ($info === FALSE) {
                output_to_json($this, array( 
                    "mtype" => "error" , 
                    "message" => $this->lang->line("unable_determine_image_type") 
                ));
            }
            if (($info[2] !== IMAGETYPE_GIF) && ($info[2] !== IMAGETYPE_JPEG) && ($info[2] !== IMAGETYPE_PNG)) {
                output_to_json($this, array( 
                    "mtype" => "error" , 
                    "message" => $this->lang->line("upload_extensions_like") 
                ));
            }
            else if( move_uploaded_file($tmp, $store) ){
                $this->personalization_model->insert_logo( array(
                        'image' => $rename,
                        'status' => 1
                ));
                output_to_json($this, array( 
                    'image' => $this->hstroke_folder.$rename,
                    "mtype" => "success" , 
                    "message" => $this->lang->line("success_upload") 
                ));
            }
        }
    }
    public function upload_get_logo()
    {
       output_to_json($this, 
          $this->hstroke_folder.$this->personalization_model->get_logo()['image']
       ); 
    }
}