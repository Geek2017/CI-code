<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Satisfaction_curves extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }

    public function get_satisfactions()
    {
         $id = $this->session->userdata('id');
         $sid = $this->input->post('sid');
         $table = $this->input->post('table');

         $results = $this->db->query("SELECT *, DATE_FORMAT(date,'%d/%m/%Y') AS date_evt  FROM satisfaction_curve WHERE user_id='$id' AND table_no ='$table' AND id ='$sid' ")->result_array();
         echo json_encode( $results  );
    }
    public function tables()
    {
        $id = $this->session->userdata('id');
        $table = $this->input->post('table');

         $results = $this->db->query("SELECT *, DATE_FORMAT(date,'%d/%m/%Y') AS date_evt  FROM satisfaction_curve WHERE user_id='$id' AND table_no ='$table' order by date DESC")->result_array();
         echo json_encode( $results  );
    }
    public function deletes()
    {
        $this->db->where('id', $this->input->post('sid') );
        $this->db->delete('satisfaction_curve');

        if( $this->input->post('table') == 1 )
        {
             echo json_encode( array(
                'message' => 'Supprimé avec succès'
            ) );
         }
         else if(  $this->input->post('table') == 2  )
         {
             echo json_encode( array(
                'message' => 'Supprimé avec succès'
            ) );
         }
    }
    public function updates()
    {
       $id =$this->session->userdata('id');
       $sid = $this->input->post('sid');
       $table =  $this->input->post('table_no');
       $dates = str_replace('/', '-', $this->input->post('date') );

       $data = array(
            'date' =>date("Y-m-d", strtotime( $dates )) ,
            'event' => $this->input->post('event'),
            'satisfaction_rate' => $this->input->post('satisfaction_rate'),
            'reason' => $this->input->post('reasons')
            );
        
        if( $this->input->post('date') == null )
        {
             echo json_encode( array(
                    'message' => 'Sélectionnez une date',
                    'focus' => 'date',
                    'redirect' => 'false'
                ) );
        }
        else if( $this->input->post('event') == null )
        {
            echo json_encode( array(
                    'message' => 'Evènement obligatoire',
                    'focus' => 'event',
                    'redirect' => 'false'
                ) );
        }
        else if( $this->input->post('satisfaction_rate') == null )
        {
            echo json_encode( array(
                    'message' => 'Satisfaction obligatoire',
                    'focus' => 'satisfaction_rate',
                    'redirect' => 'false'
                ) );
        }
        else if( $this->input->post('satisfaction_rate') > 5 || $this->input->post('satisfaction_rate') < -5)
        {
            echo json_encode( array(
                'message' => "Votre satisfaction doit être comprise entre -5 et +5", 
               'focus' => 'satisfaction_rate',
                'redirect' => 'false'
                ) );
        }
        else if( $this->input->post('reasons') == null )
        {
              echo json_encode( array(
                    'message' => 'Raison obligatoire',
                    'focus' => 'reasons',
                    'redirect' => 'false'
                ) );
        }
        else
        {
             $this->db->where('user_id', $id);
             $this->db->where('id', $sid);
             $this->db->where('table_no', $table);
             $update = $this->db->update('satisfaction_curve', $data);

             if($update){
                if( $this->input->post('table_no') == 1 )
                {
                     echo json_encode( array(
                        'message' => 'Enregistrement des modifications',
                        'redirect' => 'true'
                    ) );
                 }
                 else if(  $this->input->post('table_no') == 2  )
                 {
                     echo json_encode( array(
                        'message' => 'Enregistrement des modifications',
                        'redirect' => 'true'
                    ) );
                 }
               
            }
        }
    }
    public function adds()
    {
       $dates = str_replace('/', '-', $this->input->post('date') );
       $data = array(
            'user_id' => $this->session->userdata('id'),
            'table_no' => $this->input->post('table_no'),
            'date' => date("Y-m-d", strtotime( $dates )) ,
            'event' => $this->input->post('event'),
            'satisfaction_rate' => $this->input->post('satisfaction_rate'),
            'reason' => $this->input->post('reasons')
            );
        
        if( $this->input->post('date') == null )
        {
             echo json_encode( array(
                    'message' => 'Sélectionnez une date',
                    'focus' => 'date',
                    'redirect' => 'false'
                ) );
        }
        else if( $this->input->post('event') == null )
        {
            echo json_encode( array(
                    'message' => 'Evènement obligatoire',
                    'focus' => 'event',
                    'redirect' => 'false'
                ) );
        }
        else if( $this->input->post('satisfaction_rate') == null )
        {
            echo json_encode( array(
                    'message' => 'Satisfaction obligatoire',
                    'focus' => 'satisfaction_rate',
                    'redirect' => 'false'
                ) );
        }
        else if( $this->input->post('satisfaction_rate') > 5 || $this->input->post('satisfaction_rate') < -5 )
        {
            echo json_encode( array(
                'message' => "Votre satisfaction doit être comprise entre -5 et +5", 
               'focus' => 'satisfaction_rate',
                'redirect' => 'false'
                ) );
        }
        else if( $this->input->post('reasons') == null )
        {
              echo json_encode( array(
                    'message' => 'Raison obligatoire',
                    'focus' => 'reasons',
                    'redirect' => 'false'
                ) );
        }
        else
        {

             if($this->db->insert('satisfaction_curve', $data)){
                if( $this->input->post('table_no') == 1 )
                {
                     echo json_encode( array(
                        'message' => 'Enregistré avec succès',
                        'redirect' => 'true'
                    ) );
                 }
                 else if(  $this->input->post('table_no') == 2  )
                 {
                     echo json_encode( array(
                        'message' => 'Enregistré avec succès',
                        'redirect' => 'true'
                    ) );
                 }
               
            }
        }
    }
    public function count_scurves()
    {
        $this->db->where('table_no', $this->input->post('table_no') );
        $this->db->where('user_id', $this->session->userdata('id'));
        $query = $this->db->get("satisfaction_curve");
       
        echo json_encode( array(
             'count' => $query->num_rows()
            ) );
    }
}

   
  