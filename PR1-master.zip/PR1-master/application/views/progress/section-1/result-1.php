<?php

$this->db->select('*');
$this->db->from('section');
$this->db->where('section_id', $this->uri->segment(3));
$query = $this->db->get();
$sec = $query->result();
$sec = $sec[0];

$print_section = $this->uri->segment(3);

?>
<style>
    <?php
    if(stripos(current_url(),"myprofile_result")) : ?>
    @media print {
        body {
            overflow: visible !important;
        }

        .sec-content {
            height: auto !important;
        }
        #training_table_res thead{
           background-color: #285a89 !important;
            color: #fff;
            border-color: #fff !important;
        } 
        #keyword td.thead{ 
            background-color: #285A89; 
            color : #FFFFFF; 
        }
    }
    @media print and (color) {
       * {
          -webkit-print-color-adjust: exact;
          print-color-adjust: exact;
       }
       #print_btn_now{
          display: none !important;
       }
       #keyword td.thead{ 
            background-color: #285A89; 
            color : #FFFFFF; 
        }
    }
    @media print {
        iframe {
            width: 100%;
            overflow: visible !important;
        }
        body * {
            visibility: hidden;
            overflow: visible !important;
        }
        * { float: none !important; }
        #sec-content, #sec-content * {
            visibility: visible;
        }
        #sec-content {
            overflow: visible !important;
            float:none !important;
            /* position: fixed; */
        }
        #graphTest{
            width: 1000px !important;
        }
        #view-job td:nth-child(1),
        #training_table_res th,
        #table_ref_list th,
        #plan_tbl_d th,
        .piste-table th{
            background-color: #285a89 !important;
            color: #fff;
            border-color: #fff !important;
        }
        .job-tables table th,
        #v_tab_2 thead{
            background-color: #285a89 !important;
            color: #fff;
            border-color: #fff !important;
        }
        #training_table_res thead{
            background-color: #285a89 !important;
            color: #fff;
            border-color: #fff !important;
             -webkit-print-color-adjust: exact; 
        }.
        .sec-content thead {
            background-color: #285a89 !important;
        }
        #keyword td.thead{ 
            background-color: #285A89; 
            color : #FFFFFF; 
        }
        body {
          -webkit-print-color-adjust: exact;
        }

        /*p {
            page-break-before: always;
        }*/
    }
    @media print and (color) {
       * {
          -webkit-print-color-adjust: exact;
          print-color-adjust: exact;
       }
       #print_btn_now{
          display: none !important;
       }
        #keyword td.thead{ 
            background-color: #285A89; 
            color : #FFFFFF; 
        }
    }
    <?php endif; ?>
</style>
<div class="container-fluid sec-bg">
    <div class="s_section">
        <input type="hidden" id="section_id" value="<?php echo $this->uri->segment(3); ?>">
    	<h1 class="text-center"><?php echo $sec->section_title; ?></h1>
    	<hr>
        <div id="s_result">
             
           <?php
           if($questions) {

            $q_number = 1;
               $section_title_ = "";
               $section_number = "";
               foreach ($questions as $question) {
                   if($this->session->userdata('org') > 0 && $question_data = $this->questions->get_question_org_with_section($question->q_id)->row()) {
                       if($question_data->status == '1')
                           $question = $question_data;
                   }
                   ?>                
                   <div class="result-container <?php echo 'section-'.ceil($question->q_section).' q'.$q_number; ?> question_id_<?php echo $question->q_id; ?>">
                       <?php
                       echo '<input type="hidden" class="sectionID" value="'.$question->q_section.'">';
                       echo '<input type="hidden" class="qID" name="q_id" value="' . $question->q_id . '">';
                       $section_title = $question->section_title;
                       $section_number = $question->q_section;
                       $section_query = $this->questions->getSection($question->sec_id)->row();
                       if($question->fetch_description != 0 )
                           $section_title = $section_query->section_title;

//                       if($section_number != $question->q_section ){
//                           echo $section_number;
//                       }
                       if($section_title_ != $section_title ) {
                           $section_title_ = $question->section_title;
                           if($question->fetch_description != 0 )
                               $section_title_ = $section_query->section_title;
                           $q_number = 1;
//                           //echo "<h3 data-id='".$section_number."' class='result_".$key."_".str_replace(".","_",$section_number)."'>".$section_number." ".$section_title."</h3>";
                           echo "<h3>".$section_number." ".$section_title."</h3>";
                       }
                       if($question->q_id != 57) { // FIXME: FIX THIS PIECE OF SHIT [ACE]
//                           echo "<h3>Q" . $q_number . " : </h3>";
                           $content = str_replace(['\n','\r'], "", $question->q_content);
                           echo "<div class='question_q_content'>". $content ."</div>";
                       }
                       ?>
                   </div>
                   <?php
                   $q_number++;
               }
           }else{
               echo '<h1>Aucun résultat trouvé</h1>';
           }
           ?>
        </div>
        <br>
        <div class="pull-right">
            <?php if($next_item > 0): ?>
                <a target="_blank" href="<?php echo ak_url().'main/myprofile_result/'.$print_section.'?print=true'; ?>">
                    <button type="button" class="btn btn-primary btn-lg glyphicon glyphicon-print" id="section1-continue">&nbsp;<span>Imprimer</span></button>
                </a>
                <a href="<?php echo ak_url().'sections/'.($next_item == 6 && $this->users->with_referent() == 0 ? 7 : $next_item ) ?>">
                    <button type="button" class="btn btn-primary btn-lg" id="section1-continue">Suivant</button>
                </a>
            <?php elseif($this->uri->segment(3) == 10) : ?>
                <a target="_blank" href="<?php echo ak_url().'main/myprofile_result/'.$print_section.'?print=true'; ?>">
                    <button type="button" class="btn btn-primary btn-lg glyphicon glyphicon-print" id="section1-continue">&nbsp;<span>Imprimer</span></button>
                </a>
                <a href="<?php echo ak_url().'sections/fin' ?>">
                    <button type="button" class="btn btn-primary btn-lg" id="section1-continue">Suivant</button>
                </a>
            <?php endif; ?>
        </div>
 	</div>
</div>
<style>
    #s_result input,
    #s_result textarea{
        font-weight: bold;
        background-color: #fff;
    }
    .glyphicon-plus{
      display: none;
    }
    .none{
      display: none;
    }
    .section-1.q11{
      display: none;
    }
    #job_table, #add_job{
      display: none;
    }
    #qualifiers{ /*.question_id_108*/
      display: none;
    }
     #keyword td.thead{ 
        background-color: #285A89; 
        color : #FFFFFF; 
    }

</style>
<script>
     $('.result-container input, .result-container textarea').attr('disabled', true);
//     var script = document.createElement( 'script' );
//     script.type = 'text/javascript';
//     script.src = "<?php //echo base_url()."assets/js/chart_s2.js"; ?>//";
     $('#s3_graph').html('<canvas id="graphTest" width="400" height="190" style="padding-left:10px; padding-right:10px;"></canvas>');
//         .append(script);
//    $('#remove_res').remove();
    $('.result-container > div#remove_res').parent().remove();
     $('.cv_result').parent().parent().remove();
</script>