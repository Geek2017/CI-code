<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 
	
class Event_speaker_model extends CI_Model {

    function __construct(){
        parent::__construct();
    }

    public function add_event_speaker($data, $event_id){
        return $this->check_event_speaker("add", $data, $event_id, $data["added_by"]);
    }

    public function update_event_speaker($speaker_assignee_id, $data, $user_id){

        $speaker_id = $this->check_event_speaker("update", $data, $data["event_id"], $user_id);
        if($speaker_id){
            if($speaker_id != $data["speaker_id"]){
                /*
                    found speaker but with different speaker id. so, we will get the
                    speaker id for reassignment
                */
                $this->db->where("speaker_assignee_id", $speaker_assignee_id);
                $this->db->update("event_speaker_assignee", array("speaker_id" => $check->speaker_id));
                return $speaker_id;
            }            
        }
        return $speaker_id;
    }

    public function delete_event_speaker($speaker_assignee_id, $speaker_id){
        //check if other events are using the speaker
        $this->db->select("speaker_assignee_id");
        $this->db->where("speaker_id", $speaker_id);
        $this->db->where("status", 1);
        $this->db->where("speaker_assignee_id !=", $speaker_assignee_id);
        $count = $this->db->get("event_speaker_assignee")->num_rows();

        if($count > 0){
            //some other events are using the speaker so just delete itself
            $this->db->where("speaker_assignee_id", $speaker_assignee_id);
            $this->db->update("event_speaker_assignee", array("status" => 0));
        } else{
            $this->db->where("speaker_assignee_id", $speaker_assignee_id);
            $this->db->update("event_speaker_assignee", array("status" => 0));

            $this->db->where("speaker_id", $speaker_id);
            $this->db->update("event_speaker", array("status" => 0));
        }
        return true;
    }

    private function check_event_speaker($action, $data, $event_id, $user_id){
        $this->db->select("speaker_id, status");
        if(isset($data["speaker_id"]) && !empty($data["speaker_id"])){

            $this->db->where("speaker_id !=", $data["speaker_id"]);
        }
        $this->db->where("speaker", $data["speaker"]);
        $this->db->from("event_speaker");
        $this->db->limit(1);
        $result = $this->db->get();
        //if found a record
        if($result->num_rows() > 0) {

            $row =  $result->row();
            if( $row->status == 0 ) {
                //set to active, and just do not allow duplicate entry
                $this->db->where("speaker_id", $row->speaker_id);
                $this->db->update("event_speaker", array("status" => 1));
                return $row->speaker_id;
            }
            //found one then, just return the row
            return $row->speaker_id;
        } else {

            if( $action == "udpate" ) {
                //just update the exisiting one then return the speaker id
                $this->db->where("speaker_id", $data["speaker_id"]);
                $this->db->update("event_speaker", array("speaker" => $data["speaker"]));
                return $data["speaker_id"];
            } else if( $action == "add" ) {
                //must add one
                $this->db->insert("event_speaker", array(
                    "speaker" => $data["speaker"],
                    "added_by"  =>  $user_id,
                    "status"    =>  1
                ));
                return $this->db->insert_id();
            }
            return false;
        }
    }
}