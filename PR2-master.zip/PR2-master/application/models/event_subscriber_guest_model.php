<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Event_subscriber_guest_model extends CI_Model {

	public function __construct() {
        parent::__construct();
    }

    public function register($user_id, $event_schedule_id, $guest_info)
    {
    	foreach ($guest_info as $info) {
    		$this->db->insert('event_subscriber_guest', array(
    				'inviter_id' => $user_id,
    				'event_schedule_id' => $event_schedule_id,
    				'first_name' => $info['first_name'],
    				'last_name' => $info['last_name']
    			)
    		);
    	}
    }

    public function cancel_current_event_registration($user_id, $event_schedule_id)
    {
        $query = $this->db->select('*')
            ->from('event_subscriber_guest')
            ->where('event_schedule_id', $event_schedule_id)
            ->where('inviter_id', $user_id)
            ->where('status', 1)
            ->get()
            ->result();

        return $query;
    }

    public function cancel_current_waitlist_registration($user_id, $event_schedule_id)
    {
        $query = $this->db->select('*')
            ->from('event_subscriber_guest')
            ->where('event_schedule_id', $event_schedule_id)
            ->where('inviter_id', $user_id)
            ->where('status', 1)
            ->get()
            ->result();

        return $query;
    }

    public function deregister_guest($event_schedule_id, $user_id, $user_agent, $cancelled_guest, $seats_cancelled)
    {
        $subscriber_details = $this->db->select('registration_id, number_of_guest')
            ->from('event_registration')
            ->where('event_schedule_id', $event_schedule_id)
            ->where('subscriber', $user_id)
            ->where('status', 1)
            ->get()
            ->row();

        // Cancel Guest
        $this->db->where('inviter_id', $user_id);
        $this->db->where('event_schedule_id', $event_schedule_id);
        $this->db->where('status', 1);
        $this->db->where_in('email_address', $cancelled_guest);
        $this->db->update('event_subscriber_guest', array('status'=>0));

        // Enter cancel record
        $this->db->insert('event_deregistration',
            array(
                'registration_id' => $subscriber_details->registration_id,
                'event_schedule_id' => $event_schedule_id,
                'subscriber' => $user_id,
                'seats_reserve' => $subscriber_details->number_of_guest + 1,
                'number_of_place' => $seats_cancelled, 
                'user_agent' => $user_agent
            )
        );

        // Reduce number of guest
        $guest = 'number_of_guest-'.$seats_cancelled;
        $this->db->set('number_of_guest', $guest, FALSE);
        $this->db->where('event_schedule_id', $event_schedule_id);
        $this->db->where('subscriber', $user_id);
        $this->db->where('status', 1);
        $this->db->update('event_registration');

        // Free seats taken up by canceled guest
        $reserved_seats = 'remaining_seat+'.$seats_cancelled;
        $this->db->set('remaining_seat', $reserved_seats, FALSE);
        $this->db->where('event_schedule_id', $event_schedule_id);
        $this->db->update('event_schedule');
    }

    public function deregister_waitlist_guest($event_schedule_id, $user_id, $user_agent, $cancelled_guest, $seats_cancelled)
    {
        $subscriber_details = $this->db->select('wait_list_id, number_of_places')
            ->from('event_wait_list')
            ->where('event_schedule_id', $event_schedule_id)
            ->where('wait_list_subscriber', $user_id)
            ->where('status', 1)
            ->get()
            ->row();

        // Cancel Guest
        $this->db->where('inviter_id', $user_id);
        $this->db->where('event_schedule_id', $event_schedule_id);
        $this->db->where('status', 1);
        $this->db->where_in('email_address', $cancelled_guest);
        $this->db->update('event_subscriber_guest', array('status'=>0));

        // Enter cancel record
        $this->db->insert('event_wait_list_deregistration',
            array(
                'wait_list_id' => $subscriber_details->wait_list_id,
                'event_schedule_id' => $event_schedule_id,
                'wait_list_subscriber' => $user_id,
                'seats_reserve' => $subscriber_details->number_of_places,
                'number_of_place' => $seats_cancelled,
                'user_agent' => $user_agent
            )
        );

        // Reduce number of guest
        $guest = 'number_of_places-'.$seats_cancelled;
        $this->db->set('number_of_places', $guest, FALSE);
        $this->db->where('event_schedule_id', $event_schedule_id);
        $this->db->where('wait_list_subscriber', $user_id);
        $this->db->where('status', 1);
        $this->db->update('event_wait_list');

        // Free seats taken up by canceled guest
        $reserved_seats = 'quota_waiting_list_seat+'.$seats_cancelled;
        $this->db->set('quota_waiting_list_seat', $reserved_seats, FALSE);
        $this->db->where('event_schedule_id', $event_schedule_id);
        $this->db->update('event_schedule');
    }

}