<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Page_error_handler extends MY_Controller {

    public function __construct()
    {
        //parent::__construct();
        $this->my_controller_parent_construct();
    }

	public function index()
	{
        // Whoops, we don't have a page for that!
        //show_404();
        $this->output->set_status_header('404');
        $data['content'] = 'error_404'; // View name
        $data['heading'] = 'Page Not Found'; // View name
        $data['message'] = 'The page you requested was not found on this site.'; // View name
        $this->load->view('error_404',$data);//loading in my template
	}

}