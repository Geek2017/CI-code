<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Event_concurrent_process_model extends CI_Model {

	public function __construct() {
        parent::__construct();
    }

    public function check_action($user_id, $login_id, $event_id, $process_type){

    	$process_date = date_modify(new DateTime(), "+" . 10 . "minutes");   // change (seconds||minutes||hours||days)
    	$process_date_expiration = $process_date->format("Y-m-d H:i:s");

    	$query = "SELECT ecp.*, ulh.user_id, ulh.status
	    	FROM event_concurrent_process ecp 
	    	LEFT JOIN user_login_history ulh
	    		ON  ulh.history_id = ecp.login_id
	    	WHERE ulh.user_id = ".$user_id;
	    $query .= " AND ecp.process_reference = ".$event_id;
	    $query .= " AND ecp.process_type = ".$process_type;
	    $record = $this->db->query($query);
	    $row = $record->row();

	    if($row){
	    	if($row->login_id == $login_id){
    			if($row->process_status == 0){
    				$update_record = "UPDATE event_concurrent_process ecp
						JOIN user_login_history ulh
							ON  ulh.history_id = ecp.login_id
					    SET ecp.process_status = 1, ecp.process_date = CURRENT_TIMESTAMP, ecp.process_expiration = '".$process_date_expiration;
					$update_record .= "' WHERE ulh.user_id = ".$user_id;
					$update_record .= " AND ecp.process_reference = ".$event_id;
					$update_record .= " AND ecp.process_type = ".$process_type;
					$this->db->query($update_record);
    			}
				return false; // action open
	    	}
	    	else {
	    		if($row->process_status == 0) {
	    			$update_record = "UPDATE event_concurrent_process ecp
						JOIN user_login_history ulh
							ON  ulh.history_id = ecp.login_id
					    SET ecp.login_id = " .$login_id. ", ecp.process_status = 1, ecp.process_date = CURRENT_TIMESTAMP, ecp.process_expiration = '".$process_date_expiration;
					$update_record .= "' WHERE ulh.user_id = ".$user_id;
					$update_record .= " AND ecp.process_reference = ".$event_id;
					$update_record .= " AND ecp.process_type = ".$process_type;
					$this->db->query($update_record);
	    		}
	    		else return true; // action locked
	    	}
	    } else {
	    	$this->db->insert("event_concurrent_process", array(
	    		'login_id' => $login_id,
	    		'process_reference' => $event_id,
	    		'process_type' => $process_type,
	    		'process_expiration' => $process_date_expiration,
	    		'process_status' => 1
	    	));
	    	return false;
	    }
    }

    public function profile_check_action($user_id, $login_id, $process_type){
    	$process_date = date_modify(new DateTime(), "+" . 10 . "minutes");   // change (seconds||minutes||hours||days)
    	$process_date_expiration = $process_date->format("Y-m-d H:i:s");

    	$query = "SELECT ecp.*, ulh.user_id, ulh.status
	    	FROM event_concurrent_process ecp 
	    	LEFT JOIN user_login_history ulh
	    		ON  ulh.history_id = ecp.login_id
	    	WHERE ulh.user_id = ".$user_id;
	    $query .= " AND ecp.process_type = ".$process_type;
	    $record = $this->db->query($query);
	    $row = $record->row();

	    if($row){
	    	if($row->login_id == $login_id){
    			if($row->process_status == 0){
    				$update_record = "UPDATE event_concurrent_process ecp
						JOIN user_login_history ulh
							ON  ulh.history_id = ecp.login_id
					    SET ecp.process_status = 1, ecp.process_date = CURRENT_TIMESTAMP, ecp.process_expiration = '".$process_date_expiration;
					$update_record .= "' WHERE ulh.user_id = ".$user_id;
					$update_record .= " AND ecp.process_type = ".$process_type;
					$this->db->query($update_record);
    			}
				return false; // action open
	    	}
	    	else {
	    		if($row->process_status == 0) {
	    			$update_record = "UPDATE event_concurrent_process ecp
						JOIN user_login_history ulh
							ON  ulh.history_id = ecp.login_id
					    SET ecp.login_id = " .$login_id. ", ecp.process_status = 1, ecp.process_date = CURRENT_TIMESTAMP, ecp.process_expiration = '".$process_date_expiration;
					$update_record .= "' WHERE ulh.user_id = ".$user_id;
					$update_record .= " AND ecp.process_type = ".$process_type;
					$this->db->query($update_record);
	    		}
	    		else return true; // action locked
	    	}
	    } else {
	    	$this->db->insert("event_concurrent_process", array(
	    		'login_id' => $login_id,
	    		'process_type' => $process_type,
	    		'process_expiration' => $process_date_expiration,
	    		'process_status' => 1
	    	));
	    	return false;
	    }
    }

    public function unlock_action($user_id, $login_id, $event_id, $process_type){
    	$this->db->where('login_id', $login_id)
    		->where('process_reference', $event_id)
        	->where('process_type', $process_type)
        	->update('event_concurrent_process', array('process_status' => 0));
    }

    public function profile_unlock_action($login_id, $process_type){
    	$this->db->where('login_id', $login_id)
        	->where('process_type', $process_type)
        	->update('event_concurrent_process', array('process_status' => 0));
    }

    public function cron_unlock_fo_actions(){
        //then, unlock process status
        $this->db->where("process_expiration <= CURRENT_TIMESTAMP");
        $this->db->where("process_status", 1);
        $this->db->update("event_concurrent_process", array("process_status" => 0));
        return $this->db->affected_rows();
    }

}