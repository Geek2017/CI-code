<style type="text/css">
@media print and (color) {
       * {
          -webkit-print-color-adjust: exact;
          print-color-adjust: exact;
       }
       #print_btn_now{
          display: none !important;
       }
    }
</style>
<?php $MAX_SECTION = $this->questions->count_this('allsection_floor');  ?>
<div class="home">
	<div class="row profile_container" >
	   <div class="col-md-12" id="profile_container">
		   <input type="hidden" id="baseURL" name="baseURL" value="<?php echo base_url(); ?>">
		   <?php
		   		$x = 0;
		   		$q_a = [];
		   		for($i = 1; $i <= $MAX_SECTION; $i++):
					if($this->questions->count_this('question',$i) != $this->questions->count_this('answer',$i)):
						$x++;
					endif;
				endfor;
		   ?>
		   	<?php if($x == $MAX_SECTION): ?>
				<p class="profile_title">Cette partie se complétera au fur et à mesure de l'avancement de votre parcours</p>
			<?php else: ?>
				<style>
					.sec-content {
						height: 100%%;
						margin-left: 0px;
					}
				</style>
		   		<div class="panel-group sec-content" id="result_q">
				<?php
				for($i = 1; $i <= $MAX_SECTION; $i++):
					$question = $this->questions->count_this('question',$i);
					$q_a[] = [$this->questions->count_this('question',$i),$this->questions->count_this('answer',$i)];
					if($i == 4 && $this->questions->count_this('answer',$i) == 9 || $this->questions->count_this('answer',$i) >= $this->questions->count_this('question',$i)):
						$question_ = $this->questions->getAllQuestionsBySection($i);
					?>
						<div class="panel panel-default">
							<div class="panel-heading">
								<h3 class="panel-title">
									<a data-toggle="collapse" data-parent="#result_q" href="#result_<?php echo $i ?>">
										Résultats Section <?php echo $i; ?></a>
								</h3>
								<a target="_blank" href="<?php echo ak_url()."/main/myprofile_result/".$i."?print=true" ?>"><button type="button" class="res-btn btn btn-primary glyphicon glyphicon-print" id="btn-print" ></button></a>
							</div>
							<div id="result_<?php echo $i ?>" class="panel-collapse collapse in">
								<div class="panel-body">
										<iframe src="<?php echo ak_url()."/main/myprofile_result/".$i ?>"></iframe>
								</div>
							</div>
						</div>
		   <?php	endif;
				endfor;
				?>
				</div>
		   <?php endif ?>
		   <?php 
		   $file = $this->uploads->cvlist();
		   ?>
		   <div class="panel panel-default">
							<div class="panel-heading">
								<h3 class="panel-title">
									<a data-toggle="collapse" data-parent="#result_q" href="#cv">
										CV

								</h3>
								<center class="preview">Prévisualiser</center></a>
								<a type="button" href="<?php echo ak_url()."upload/newcv"; ?>" class="cv-btn btn btn-primary glyphicon glyphicon-upload " id="btn-upload"></a>
							</div>
							<div id="cv" class="panel-collapse collapse">
								<div class="panel-body">
									<embed width="999" height="500" src="<?php echo $file['filename']; ?>" type="application/pdf"></embed>
								</div>
							</div>
							 
			</div>
		   <div class="panel panel-default">
			   <div class="panel-heading">
				   <h3 class="panel-title">
					   <a data-toggle="collapse" data-parent="#result_q" href="#profile_piste">
						   Pistes Professionnelles Réalistes
				   </h3>
				   <a ></a>
			   </div>
			   <div id="profile_piste" class="panel-collapse collapse">
				   <div class="panel-body">
					   <table id="piste_list" class="table table-striped table-hover" border="1" cellpadding="1" cellspacing="1">
						   <thead>
						   <tr class="thead"><th>Titre de la piste</th>
							   <th>Secteur</th>
							   <th>Métier (choisir parmi la liste entreprise)</th>
							   <th>Titre / fonction</th>
							   <th>Missions / Objectifs</th>
							   <th>Activités principales</th>
							   <th class="modification">Modifications</th>
						   </tr>
						   </thead>
						   <tbody id="body_piste">
						   </tbody>
					   </table>
					   <button onclick="piste.add();" type="button" id="piste_btn" class="btn btn-primary glyphicon glyphicon-plus"></button>
				   </div>
			   </div>
		   </div>
	   </div>
		<div class="clearfix"></div>
	</div>
		<div class="print_con">
			<div class="download_pdf btn_d_all">
				<a href="<?php echo base_url()."index.php/main/m_result/1"; ?>" target="_blank">
					<button id="r_download_pdf" class="btn btn-primary glyphicon glyphicon-search"></button>
				</a>
			</div>
			<div class="print_all btn_d_all">
				<a href="<?php echo base_url()."index.php/main/m_result/1"; ?>" target="_blank">
					<button id="r_print_all" class="btn btn-primary glyphicon glyphicon-print" ></button>
				</a>
			</div>
		</div>
 
</div>
