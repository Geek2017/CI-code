<?php
defined('BASEPATH') OR exit('No direct script access allowed');
//$this->session_checker->is_authorize();
?>
<html>
<head>

    <?php $this->load->view($header);?>
    
</head>
<body>
	<?php
	    $this->load->view($nav_menu);
		$this->load->view($content); 
    ?>

    </div>
	 <?php $this->load->view($footer); ?>
    <script>
	function openNav() 
    {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
	}

	function closeNav() {
	    document.getElementById("mySidenav").style.width = "0";
	    document.getElementById("main").style.marginLeft= "0";
	}
	</script>

</body>

</html>