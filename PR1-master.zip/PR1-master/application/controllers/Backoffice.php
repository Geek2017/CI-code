<?php
defined('BASEPATH') OR exit('No direct script access allowed');
include_once (dirname(__FILE__) . "/Main.php");
class BackOffice extends CI_Controller {

    function __construct()
    {
        parent::__construct();
    }
    public function makequestion()
    {
        if( $this->session->userdata('role') != null )
        {
            $op = $this->questions->getSections();
            $options[0] = "Select Section";
            foreach($op->result() as $res){
                $options[$res->section_id] = $res->section_title;
            }
            $data = array(
                'content' => 'backoffice/makequestion',
                'nav_menu' => 'page-nav',
                'user_role' => $this->session->userdata('role'),
                'options'   =>  $options
            );
            $this->load->view('backoffice/backoffice_template', $data);
        }
        else
        {
            redirect('/', 'refresh');
        }
    }

    public function postquestion()
    {
        try{
            $editQuestion = $this->input->post('question_id') ? $this->input->post() : null;
            $this->backoffices->postquestion($this->input->post("section"), $this->input->post("question"), $editQuestion);
            $res = 'true';
        }catch(Exception $ex){
            $res = 'false';
        }
        echo $res;
    }

    public function getquestion($question = null)
    {
        echo $this->backoffices->getquestion($question);
    }

    public function editquestion($id)
    {
        if( $this->session->userdata('role') != null )
        {
            $op = $this->questions->getSections();
            $options[0] = "Select Section";
            foreach($op->result() as $res){
                $options[$res->section_id] = $res->section_title;
            }

            $s_question = $this->questions->getQuestion();
            $config['base_url']     = site_url('editquestion/');
            $config['total_rows']   = $s_question->num_rows();
            $config['first_url']    = '1';
            $config['per_page']     = 1;
            $config['use_page_numbers'] = TRUE;
            $config['num_links']    = $s_question->num_rows();
            $config['next_link']    = '<button type="button" class="btn btn-primary next">Suivant</button>';
            $config['prev_link']    = '<button type="button" class="btn btn-primary prev">Précédent</button>';
            $this->pagination->initialize($config);
            $page = $this->uri->segment(2) ? ($this->uri->segment(2)) : 1;
            $str_links = $this->pagination->create_links();
            $last_page = $this->uri->segment(2) >= ceil($config['total_rows'] / $config['per_page']) ? true : false;

            $dat = json_encode([
                'question' => true,
                'pagination' => explode('&nbsp;', $str_links),
                'last_page' => $last_page,
                'total_rows' => $s_question->num_rows(),
                'content' => $this->backoffices->fetch_data($config["per_page"], $page),
            ]);

            $data = array(
                'content' => 'backoffice/editquestion',
                'nav_menu' => 'page-nav',
                'user_role' => $this->session->userdata('role'),
                'options'   =>  $options,
                'data'      =>  $dat
            );
            $this->load->view('backoffice/backoffice_template', $data);
        }
        else
        {
            redirect('/', 'refresh');
        }
    }

    public function ajax()
    {
        $type = $this->input->get("type");
        switch($type){
            case 'get_section':
            {
                if($id = $this->input->get('id') ) {
                    if($section = $this->questions->getSectionByID($id, 1)->row()){
                        echo json_encode($section);
                    }
                }
                break;
            }
            case 'get_question':
            {
                if($id = $this->input->get('id') ) {
                    if($this->session->userdata('role') == ADMIN){
                        if($question = $this->questions->getQuestionByAdmin($id)->row() )
                            echo json_encode($question);
                        else if($question = $this->questions->getQuestionByID($id)->row() )
                            echo json_encode($question);
                    }
                    else if($question = $this->questions->getQuestionByID($id)->row() )
                        echo json_encode($question);

                }
                break;
            }
            case 'get_setting':
            {
                if($id = $this->input->get('id') ) {
                    if($setting = $this->globalmodel->get_setting_info($id)->row()){
                        echo json_encode($setting);
                    }
                }
                break;
            }
            case 'submit_edit_section':
            {
                echo $this->backoffices->update_section();
                break;
            }
            case 'submit_edit_question':
            {
                echo $this->backoffices->update_question();
                break;
            }
            case 'submit_edit_setting':
            {
                echo $this->backoffices->update_setting();
                break;
            }
            case 'get_all_users_graph':
            {
                $active_admin   =   $this->users->get_user_info(["role_id" => ADMIN,"active"=>"1"])->num_rows();
                $inactive_admin =   $this->users->get_user_info(["role_id" => ADMIN,"active"=>"0"])->num_rows();
                $active_user    =   $this->users->get_user_info(["role_id" => USERS,"active"=>"1"])->num_rows();
                $inactive_user  =   $this->users->get_user_info(["role_id" => USERS,"active"=>"0"])->num_rows();
                $all_users      =   $active_admin + $inactive_admin + $active_user + $inactive_user;
                $all_admin =($active_admin + $inactive_admin);

                echo json_encode(
                    [
                        number_format((($active_admin  ) ), 1, '.', ''),
                        number_format((($inactive_admin ) ), 1, '.', '')
//                        round(($active_admin     * 100) / $all_users),
//                        round(($inactive_admin   * 100) / $all_users),
//                        round(($active_user      * 100) / $all_users),
//                        round(($inactive_user    * 100) / $all_users)
                    ] );
                break;
            }
            case 'get_all_users_graph_label':
            {
                echo json_encode(
                    [
                        'active_admin'   =>   $this->users->get_user_info(["role_id" => ADMIN,"active"=>"1"])->num_rows(),
                        'inactive_admin' =>   $this->users->get_user_info(["role_id" => ADMIN,"active"=>"0"])->num_rows(),
                        'active_user'    =>   $this->users->get_user_info(["role_id" => USERS,"active"=>"1"])->num_rows(),
                        'inactive_user'  =>   $this->users->get_user_info(["role_id" => USERS,"active"=>"0"])->num_rows()
                    ] );
                break;
            }
            case 'get_section_stat':
            {
                echo $this->backoffices->get_section_stat();
                break;
            }
            case 'get_section_stat_superadmin':
            {
                $this->backoffices->get_section_stat_superadmin() ;
                break;
            }
        }
    }
    public function index()
    {
        if( $this->session->userdata('role') == 1 || $this->session->userdata('role') == 2 || empty(  $this->session->userdata('role') )  )
            {
                  $data = array(
                    'header' => 'backoffice/header',
                    'footer' => 'backoffice/footer',
                    );

                $this->load->view('backoffice/login' , $data );
            }
            else
            {
                redirect( 'main', 'refresh' );
            }

       
    }
   
    public function dashboard()
    {
        
        $this->session_checker->session_filled();

        switch($this->session->userdata('role')){
            case SUPERADMIN:
                $content = 'backoffice/index';
                break;
            case ADMIN:
                $content = 'backoffice/admin/dashboard';
                break;
            default:
                $content = 'backoffice/index';
                break;
        }

         $data = array(
            'content' => $content,
            'nav_menu' => 'backoffice/nav-menu',
            'header' => 'backoffice/header',
            'footer' => 'backoffice/footer',
            'role'    => $this->session->userdata('role')
            );
        $this->load->view('backoffice/template', $data);
        
    }
    public function accounts()
    {
        
        $this->session_checker->session_filled();
         $data = array(
            'content' => 'backoffice/accounts',
            'nav_menu' => 'backoffice/nav-menu',
            'header' => 'backoffice/header',
            'footer' => 'backoffice/footer',
            'role'    => $this->session->userdata('role'),
            'controller' => $this
            );
        $this->load->view('backoffice/template', $data);
        
    }
    public function organizations()
    {
        
        $this->session_checker->session_filled();
         $data = array(
            'content' => 'backoffice/organizations',
            'nav_menu' => 'backoffice/nav-menu',
            'header' => 'backoffice/header',
            'footer' => 'backoffice/footer',
            'orgs' => $this->backoffices->get_organizations(),
            'role'    => $this->session->userdata('role'),
            'controller' => $this
            );
        $this->load->view('backoffice/template', $data);
        
    }
    public function roles($role_id)
    {
         $role_name ="";

          switch ($role_id) 
          {
              case '1':
                  $role_name = $this->languages->lang('superadmin');
                  break;
              
              case '2' : 
                $role_name = $this->languages->lang('admin');
              break;

              case '3' : 
               $role_name = $this->languages->lang('user');
              break;
          }

          return $role_name;
    }
    public function get_organization_by_id($id)
    {
        return $this->backoffices->get_organization_by_id($id);
    }
    /*Sadmin -> admin*/
    public function add_admin(){
        $this->backoffices->add_update_admins();

    }
    public function delete_admin(){
        $this->backoffices->delete_admins();

        echo json_encode( array( 'message' => ($this->input->post('status') == 1 ? "L'entreprise a été désactivée avec succès" : "L'entreprise a été activée avec succès") ) );
    }
    public function get_admin(){
        echo json_encode( $this->backoffices->get_admin_org($_POST['id']) );
    }
    public function update_admin(){
        $this->backoffices->add_update_admins();

//         echo json_encode( array( 'msg' => 'Admin successfull updated' ) );
    }

    /* Sadmin -> guest  */
    public function control_guest()
    {

    }
    public function delete_guest(){
        if($this->backoffices->delete_guests())
            echo json_encode( array( 'message' => ($this->input->post('status_guest') == "1" ? "L'utilisateur a été désactivé" : "L'utilisateur a été activé") ) );
        else
            echo json_encode( array( 'message' => 'Error') );
    }
    public function edit_guest(){
       echo json_encode(  $this->backoffices->edit_guests() );
    }
    public function update_guest()
    {
         $this->backoffices->update_guests();
    }

    public function view_sections()
    {
        $this->session_checker->session_filled();
        $data = array(
            'content' => 'backoffice/super/sections',
            'nav_menu' => 'backoffice/nav-menu',
            'header' => 'backoffice/header',
            'footer' => 'backoffice/footer'
        );
        $this->load->view('backoffice/template', $data);
    }
    public function view_settings()
    {
        $this->session_checker->session_filled();
        $data = array(
            'content' => 'backoffice/super/settings',
            'nav_menu' => 'backoffice/nav-menu',
            'header' => 'backoffice/header',
            'footer' => 'backoffice/footer'
        );
        $this->load->view('backoffice/template', $data);
    }
    public function users_progresions_and_done()
    {
        $this->backoffices->section_graphs();
    }
    public function most_users_graph()
    {
        $max = [];
        $sub = [];
        foreach ($this->backoffices->most_user_graphs() as $key => $value) 
        {
            $max[] = $value['max_u'];
            $sub[] = $value['subsidiary'];
        }
         echo json_encode( array( 
            "hover" => "#36A2EB",
            "background_c" => "#36A2EB",
            "max_u"=> $max, 
            "sub" => $sub 
        ));

    }
    public function get_all_accounts()
    {
        $dtQuery = $this->session->userdata('role') == SUPERADMIN ? $this->backoffices->guest_accounts() : $this->backoffices->guest_account_by_org($this->session->userdata('org'));
        $dtResult = $dtQuery->get()->result();
        $dtHtml = '';
        foreach ($dtResult as $aRow) {
            $icon = $aRow->active == "1" ? "glyphicon-remove" : "glyphicon-ok";
           
            //$created_date = $aRow->date_created > 0 ?  date("Y-F-jS", strtotime($aRow->date_created)) : "";
            //$starting_date = $aRow->started_date > 0 ? date("Y-F-jS", strtotime(DateTime::createFromFormat('d/m/Y', $aRow->started_date)->format('Y-m-d'))) : "N/A";

            if( $aRow->started_date > 0 ){
                // $date_s =  explode(' ',date("j F Y", strtotime(DateTime::createFromFormat('d/m/Y',$aRow->started_date)->format('Y-m-d'))));
                // $starting_date =  $date_s[0]." ".$this->french_calendar->month($date_s[1])." ".$date_s[2] ;
                $date_s =  explode(' ',date("j m Y", strtotime(DateTime::createFromFormat('d/m/Y',$aRow->started_date)->format('Y-m-d'))));
                $starting_date =  $date_s[0]."/".$date_s[1]."/".$date_s[2] ;
            }else{
                $starting_date = "N / A";
            }

            if( $aRow->date_created > 0 ){
                //$date_c = explode(' ',  date("j F Y", strtotime($aRow->date_created)) );
                //$created_date =  $date_c[0]." ".$this->french_calendar->month($date_c[1])." ".$date_c[2] ;
                $date_c = explode(' ',  date("j m Y", strtotime($aRow->date_created)) );
                $created_date =  $date_c[0]."/".$date_c[1]."/".$date_c[2] ;
            }else{
                $created_date = "N / A";
            }


            $color = "";
            $glyphicon = "";

            switch ( $aRow->active ) :

                case '0':
                    $glyphicon = "glyphicon-remove" ;
                    $color = "grey";

                break;

                case '1':

                    $glyphicon = "glyphicon-ok";

                    $color =  $this->logs->last_activity( $aRow->user_id )
                           ?  $this->logs->status_color(  date("Y-m-d", strtotime(  $this->logs->last_activity( $aRow->user_id )->date_time  )) , $aRow->user_id)
                           :  "green" ;

                break;

            endswitch ;

            $dtHtml .=
                '<tr>'.
                '<td>'.$aRow->username.'</td>'.
                '<td>'.$aRow->firstname.'</td>'.
                '<td>'.$aRow->lastname.'</td>'.
                '<td>'.$aRow->company.'</td>'.
                '<td>'.$created_date.'</td>'.
                '<td>'.$starting_date.'</td>'.
                '<td>'.( $this->questions->my_last_answered("",$aRow->user_id) ? $this->questions->my_last_answered("",$aRow->user_id)->q_section : null).'</td>'.
                '<td>'.$this->user_time_accumulated($aRow->user_id).'</td>'.
                "<td><span class='glyphicon {$glyphicon}' style='color: white; padding: 10px; background-color:{$color};'></span>".'</td>'.
                '<td><button onclick="Guests.preview_guest('.$aRow->user_id.');" id="preview_user" class="btn btn-primary glyphicon glyphicon-user"></button><button onclick="Guests.edit_guest('.$aRow->user_id.');" class="btn btn-primary glyphicon glyphicon-pencil"></button> <button class="del_ref btn btn-primary glyphicon '.$icon.'" data-user_id="'.$aRow->user_id.'" data-status="'.$aRow->active.'" id="account_status" ></button></td>'.
            '</tr>';
        }
        echo json_encode($dtHtml);
    }
    public function user_time_accumulated($user_id)
    {
        $time_accumulated = 0;
        foreach($this->logs->group_startlog($user_id)->result() as $log){
            $last_answered = $this->questions->get_question_by_session($log->loginlog_id,$user_id)->row();
            if($last_answered) {
                $time_accumulated += strtotime($last_answered->date_created) - strtotime($log->date_time);
            }
        }
        return $this->second_to_time($time_accumulated);
    }
    public function second_to_time($seconds)
    {
        $hours = floor($seconds / 3600);
        $mins = floor($seconds / 60 % 60);
        $secs = floor($seconds % 60);
        return ($hours ? $hours. 'hour'.($hours > 1 ? "s " : " ") : '' ). ($mins ? $mins. 'minute'.($mins > 1 ? "s " : " ") : ''). ($secs ? $secs. 'second'.($secs > 1 ? "s " : " ") : '' );
    }
    public function get_all_sections()
    {
        $dtResult = GlobalModel::setDatatable($this->db->from('section')->order_by('section_id','asc'), array(
            'section_id',
            'section_title',
            'sec_status',
        ),
            'id');
        foreach ($dtResult['objResult'] as $aRow) {
            $status = $aRow->sec_status == "1" ? "<span class=\"ref_validate glyphicon glyphicon-ok-sign\"></span>" : "<span class=\"ref_validate glyphicon glyphicon-remove-sign\"></span>";
            $data = array(
                $aRow->section_id,
                $aRow->section_title,
                $status,
                '<button class="edit_ref btn btn-primary glyphicon glyphicon-pencil" onclick="sections.edit_section('.$aRow->id.')" ></button>'
            );
            $dtResult['aaData'][] = $data;
        }
        unset($dtResult['objResult']);
        echo json_encode($dtResult);
    }
    public function get_all_settings()
    {
        $translated_codes = "";
        
        $dtResult = GlobalModel::setDatatable($this->db->from('system_settings')->order_by('id','asc'), array(
            'id',
            'setting_fieldcode',
            'setting_fieldvalue',
            'setting_description',
            'setting_status',
        ),
            'id');
        foreach ($dtResult['objResult'] as $aRow) {
            $status = $aRow->setting_status == "1" ? "<span class=\"ref_validate glyphicon glyphicon-ok-sign\"></span>" : "<span class=\"ref_validate glyphicon glyphicon-remove-sign\"></span>";
            
            switch( $aRow->setting_fieldcode ){
                    case 'allow_skip_question' :
                    $translated_codes = "saut_de_question";
                    break;

                    case 'akeen_email' :
                    $translated_codes = "e-mail_akeen";
                    break;

                    case 'account_days_expire' :
                    $translated_codes = "expiration_de_compte";
                    break;

                    case 'time_out_session' :
                    $translated_codes = "expiration_de_session";
                    break;


            }

            $data = array(
                $aRow->id,
                $translated_codes,
                $aRow->setting_fieldvalue,
                $aRow->setting_description,
                $status,
                '<button class="edit_ref btn btn-primary glyphicon glyphicon-pencil" onclick="settings.edit_setting('.$aRow->id.')" ></button>'
            );
            $dtResult['aaData'][] = $data;
        }
        unset($dtResult['objResult']);
        echo json_encode($dtResult);
    }
    public function get_all_questions()
    {
        $this->get_all_q();
        $dtResult = GlobalModel::setDatatable($this->questions->get_all_questions_org(), array(
            'q_id',
            'q_section',
            'q_order',
            'status'
        ),
            'q_id');
        foreach ($dtResult['objResult'] as $aRow) {
            $q_id = $aRow->q_id;
            $q_section = $aRow->q_section;
            $q_order = $aRow->q_order;
            $q_status = $aRow->status;
            if($question_admin = $this->questions->get_question_org($aRow->q_id)->row()){
                $q_id = $question_admin->id;
                $q_section = $question_admin->section_number;
                $q_order = $question_admin->question_order;
                $q_status = $question_admin->q_status;
            }
            $status = $q_status == "1" ? "<span class=\"ref_validate glyphicon glyphicon-ok-sign\"></span>" : "<span class=\"ref_validate glyphicon glyphicon-remove-sign\"></span>";
            $data = array(
                $aRow->q_id,
                $q_section,
                $q_order,
                $status,
                '<button class="btn btn-primary glyphicon glyphicon-pencil" onclick="questions.edit_question('.$q_id.')" ></button>'
            );
            $dtResult['aaData'][] = $data;
        }
        unset($dtResult['objResult']);
        echo json_encode($dtResult);
    }
    public function get_all_q()
    {
        $dtQuery = $this->questions->get_all_questions_org()->get()->result();
        $dtHtml = '';
        foreach ($dtQuery as $aRow) {
            $q_id = $aRow->q_id;
            $q_section = $aRow->q_section;
            $q_order = $aRow->q_order;
            $q_status = $aRow->status;
            if($this->session->userdata('role') == ADMIN && $question_admin = $this->questions->get_question_org($aRow->q_id)->row()){
                $q_id = $question_admin->id;
                $q_section = $question_admin->q_section;
                $q_order = $question_admin->q_order;
                $q_status = $question_admin->status;
            }
            $status = $q_status == "1" ? "<span class=\"ref_validate glyphicon glyphicon-ok-sign\"></span>" : "<span class=\"ref_validate glyphicon glyphicon-remove-sign\"></span>";
            $dtHtml .= '<tr>
                <td>'.$q_section.' '. $this->questions->get_section_title($aRow->sec_id)['section_title'].'</td>
                <td>'.$q_order.'</td>
                <td>'.$status.'</td>
                <td><button class="btn btn-primary glyphicon glyphicon-pencil" onclick="questions.edit_question('.$q_id.')" ></button></td>
            </tr>';
            //<td>'.$aRow->q_id.'</td>
        }
        echo json_encode($dtHtml);
    }
    public function view_questions()
    {
        $this->session_checker->session_filled();
        $data = array(
            'content' => 'backoffice/super/questions',
            'nav_menu' => 'backoffice/nav-menu',
            'header' => 'backoffice/header',
            'footer' => 'backoffice/footer',
            'sections'  =>  $this->questions->getSections()
        );
        $this->load->view('backoffice/template', $data);
    }
    /*Profile super admin*/
    public function profile()
    {
        $this->session_checker->session_filled();
        $data = array(
            'content' => 'backoffice/super/profile',
            'nav_menu' => 'backoffice/nav-menu',
            'header' => 'backoffice/header',
            'footer' => 'backoffice/footer',
            'profile_lists'  =>  $this->backoffices->get_super_profile()
        );
        $this->load->view('backoffice/template', $data);
    }
    /*Get profile of superadmin*/
    public function get_super_profile()
    {
        echo json_encode( $this->backoffices->get_super_profile() );
    }
    /*Update superadmin profile*/
    public function update_super_profile()
    {
          $this->backoffices->update_super_profile();
    }
    /*Super admin and admin user management status */
    public function user_status()
    {
         $this->session_checker->session_filled();
        $data = array(
            'content' => 'backoffice/super/user_status',
            'nav_menu' => 'backoffice/nav-menu',
            'header' => 'backoffice/header',
            'footer' => 'backoffice/footer',
            'users_lists'  =>  $this->backoffices->get_user_status()
        );
        $this->load->view('backoffice/template', $data);
    }
    public function list_user_status(){
        $dtResult = $this->backoffices->get_user_status()->result();
        $dtHtml = '';
        foreach ($dtResult as $aRow) {
            $complete_name = $aRow->firstname.' '.$aRow->lastname;
            // $created_date = $aRow->date_created > 0 ? date("Y-F-jS", strtotime($aRow->date_created)) : "";
             $last_login = $aRow->date_time > 0 ? date("Y-F-jS", strtotime($aRow->date_time)) : "";
            // $starting_date = $aRow->started_date > 0 ?   date("Y-F-jS", strtotime(DateTime::createFromFormat('d/m/Y', $aRow->started_date)->format('Y-m-d'))) : "N/A";
            // $color = "green";
            // $glyphicon = "glyphicon-ok";
            // if($aRow->active == 0) {
            //     $color = "black";
            //     $glyphicon = "glyphicon-remove";
            //     if($aRow->started_date > 0)
            //         $color = "grey";
            // }else if( $aRow->date_time > 0 )
            //     $color =  $this->logs->status_color( date("Y-m-d", strtotime($aRow->date_time))  );
            
            $last_answer = $this->questions->fetch_last_answered("",$aRow->user_id);

            $icon = $aRow->active == "1" ? "glyphicon-remove" : "glyphicon-ok";
            $created_date = $aRow->date_created > 0 ?  date("Y-F-jS", strtotime($aRow->date_created)) : "";
            $starting_date = $aRow->started_date > 0 ? date("Y-F-jS", strtotime(DateTime::createFromFormat('d/m/Y', $aRow->started_date)->format('Y-m-d'))) : "N/A";
            $color = "";
            $glyphicon = "";

            switch ( $aRow->active ) :

                case '0':
                    $glyphicon = "glyphicon-remove" ;
                    $color = "grey";

                break;

                case '1':

                    $glyphicon = "glyphicon-ok";

                    $color =  $this->logs->last_activity( $aRow->user_id )
                           ?  $this->logs->status_color(  date("Y-m-d", strtotime(  $this->logs->last_activity( $aRow->user_id )->date_time  )) , $aRow->user_id)
                           :  "green" ;

                break;

            endswitch ;

            if( $last_answer->q_section < 10.4 )
            {
                 $dtHtml .= "<tr>".
                "<td>".$complete_name."</td>".
                "<td>".$created_date."</td>".
                "<td>".$starting_date."</td>".
                "<td>".$last_login ."</td>".
                "<td>".($last_answer ? $last_answer->q_section : null)."</td>".
                "<td><span class='glyphicon {$glyphicon}' style='color: white; padding: 10px; background-color:{$color};'></span></td>".
                "</tr>";
            }
        }
        echo json_encode($dtHtml);
    }
    // public function dump()
    // {
    //    $this->backoffices->users_progresions_and_dones("","true") ;
    // }
    public function super_profile()
    {
        $this->session_checker->session_filled();
        $data = array(
            'content' => 'backoffice/super/superprofile',
            'nav_menu' => 'backoffice/nav-menu',
            'header' => 'backoffice/header',
            'footer' => 'backoffice/footer'
        );
        $this->load->view('backoffice/template', $data);
    }
    public function get_profile()
    {
        echo json_encode( $this->backoffices->get_profiles() );
    }
    public function get_sadmin_profile()
    {
        echo json_encode( $this->backoffices->get_sadmin_profiles() );
    }
    public function post_sadmin_profile()
    {
        $user =  $this->users->get_user_info(['id'=> $this->session->userdata('id')  ])->row();

        if( $this->input->post('username') == null ){
             echo json_encode(array( 
                'type' => 'required',
                'message' => 'Username is required!' , 
                'focus' => '#username'
            ));
        }else if( $this->input->post('password') == null ){
             echo json_encode(array( 
                'type' => 'required',
                'message' => '*Mot de passe requis*!' , 
                'focus' => '#password'
            ));
        }else if( $this->input->post('npass') != null && $this->input->post('cpass') == null ){
            echo json_encode(array( 
                'type' => 'required',
                'message' => 'Confirm password is required!' , 
                'focus' => '#cpass'
            ));
        }else if(  $this->input->post('cpass') != null && $this->input->post('npass') == null ){
             echo json_encode(array( 
                'type' => 'required',
                'message' => 'New password is required!' , 
                'focus' => '#npass'
            ));
        }else if(  ($this->input->post('cpass') != null && $this->input->post('npass') != null ) && ( $this->input->post('cpass') != $this->input->post('npass')  ) ){
             echo json_encode(array( 
                'type' => 'required',
                'message' => 'Password is mismatch!' , 
                'focus' => '#npass'
            ));
        }else{
            if( sha1( $this->input->post('password') ) != $user->password  ){
                echo json_encode(array( 
                    'type' => 'required',
                    'message' => 'Invalid password!' , 
                    'focus' => '#password'
                ));
            }else{
                if( $this->backoffices->post_sadmin_profiles()  >= 0 ){
                    echo json_encode(array( 
                        'close_modal' => true,
                        'message' => '*Mise à jour réussie*' , 
                    ));
                } 
            }
        }

        //echo json_encode( $this->backoffices->post_sadmin_profiles() );
    }
    public function spersonalize()
    {
        $this->session_checker->session_filled();
        $data = array(
            'content' => 'backoffice/super/superpersonalize',
            'nav_menu' => 'backoffice/nav-menu',
            'header' => 'backoffice/header',
            'footer' => 'backoffice/footer'
        );
        $this->load->view('backoffice/template', $data);
    }
    public function get_sadmin_personalize($type = null)
    {
        echo json_encode( $this->backoffices->get_sadmin_personalizes( $type ) );
    }
    public function post_sadmin_personalize()
    {
        $this->backoffices->post_sadmin_personalizes( $this->input->post('type'), ['content' => $this->input->post('content')] );
        echo json_encode( array( "message" => "Successfully Updated" ) );
    }
}


