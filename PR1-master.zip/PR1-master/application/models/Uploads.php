<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Uploads extends CI_Model {

	function __construct() 
	{
        parent::__construct();
    }
	public function save_csv()
	{
		if ( !$this->upload->do_upload('userfile'))
        {
             //print_r($this->upload->display_errors());
             return false;
        }
        else
        {
              //echo json_encode(  array('msg' => $this->upload->data()) );
			$uid = $this->session->userdata('id');
			$upload_data = $this->upload->data();
			$filename = $upload_data['file_name'];
			$path = $upload_data['full_path'];

			$this->db->insert('uploads', array(
				'user_id' => $uid,
				'path' =>  $path,
				'filename' => $filename,
				'type' => "resume"
			));

			return true;
        }
	}
	public function view_file(){
		$query = $this->db->get_where('uploads', array('user_id' => $this->session->userdata('id')));
		return $query->result();
	}
	public function has_resume($user_id = null)
	{
		$user_id = $user_id ? $user_id : $this->session->userdata('id');
		$query = $this->db->order_by('id','DESC')->get_where('uploads', array('type' => 'resume' ,'user_id' => $user_id));
		$found = $query->result();

		if( $query->num_rows() > 0)
		{
			  return array( 
	            'filename' => $found[0]->filename,
	            'path' => $found[0]->path,
	            'uploadedCsV' => 0
	          ) ;
	          
		}else{
			  return  array( 
	            'filename' => "",
	            'path' => "",
	            'uploadedCsV' => 1
	          );
		}
	}
	public function cvlist($user_id = null)
    {
       
       $found = $this->has_resume($user_id);
        return array( 
            'filename' =>$found['filename'] !="" ? '../../uploads/'.$found['filename'] : "", 
            'path' =>$found['path'],
            'uploadedCsV'  => $found['uploadedCsV'],
			'filename_orig'	=>	$found['filename']
            ) ;
    
    }

	public function save_video($id, $type)
	{
		$new_filename = $type."_".$id;
		$error = "";
		try {
			$found_video = $this->has_video($id, $type);
			if($found_video["video"] == 1 && $_FILES['video_file']['error'] > 0){
				return json_encode(array(
					'type' => 'success',
					'msg' => ""
				));
			}
			if (
				!isset($_FILES['video_file']['error']) ||
				is_array($_FILES['video_file']['error'])
			) {
				$error = 'Invalid parameters.';
			}

			switch ($_FILES['video_file']['error']) {
				case UPLOAD_ERR_OK:
					break;
				case UPLOAD_ERR_NO_FILE:
					$error ='No file sent.';
					break;
				case UPLOAD_ERR_INI_SIZE:
				case UPLOAD_ERR_FORM_SIZE:
					$error = 'Exceeded filesize limit.';
					break;
				default:
					$error = 'Unknown errors.';
					break;
			}

			if ($_FILES['video_file']['size'] > 300000000) {
				$error = 'Exceeded filesize limit.';
			}
			$file_type = array(
				'mp4' => 'video/mp4',
				'webm'=> 'video/webm',
				'ogg' => 'video/ogg',
			);
			if (!$ext = array_search($_FILES['video_file']['type'],$file_type))
				$error = 'Invalid file format. Accepted format: mp4, webm & ogg';

			$filename = "./uploads/video/".$type."/";

			if (!file_exists($filename)) {
				mkdir($filename, 0777);
			}

			if (!move_uploaded_file(
				$_FILES['video_file']['tmp_name'],
				sprintf('./uploads/video/%s/%s.%s',
					$type,
					$new_filename,
					$ext
				)
			)) {
				$error = 'Film non téléchargé';
			}
			$return = json_encode(array(
				'type' => 'success',
				'msg' => "Téléchargement vidéo avec succès"
			));
			if($error){
				$return = json_encode(array(
					'type' => 'error',
					'msg' => $error
				));
			}
			$data = array(
				'user_id' => $id,
				'path' =>  '',
				'filename' => $new_filename.".".$ext,
				'type' => "$type"
			);

			if($found_video["video"] == 1){
				$this->db->where('user_id', $id);
				$this->db->update('uploads', $data);
			}else
				$this->db->insert('uploads',$data);

			return $return;

		} catch (RuntimeException $e) {
			return $return = json_encode(array(
				'type' => 'error',
				'msg' => $e->getMessage()
			));

		}
	}
	public function has_video($id, $type)
	{
		$query = $this->db->order_by('id','DESC')->get_where('uploads', array('type' => $type ,'user_id' => $id));
		$found = $query->result();
		if( $query->num_rows() > 0)
		{
			return array(
				'filename' => $found[0]->filename,
				'path' => $found[0]->path,
				'id' => $found[0]->id,
				'video' => 1
			) ;

		}else{
			return array(
				'filename' => "",
				'path' => "",
				'id' => "",
				'video' => 0
			);
		}
	}
	public function get_video($id = null, $type = null)
	{
		$vid_data =  $this->has_video($id ? $id : $this->session->userdata('id'), $type) ;
		$file = explode(".",$vid_data["filename"]);
		$ext = $file[key(array_slice( $file, -1, 1, TRUE ))];
		$vid_data['ext'] = $ext;
		if($id)
			return json_encode( $vid_data );
		else
			echo json_encode( $vid_data );
	}
	public function get_default_section_video($sec_id = null)
	{
		$query = $this->db->order_by('id','DESC')->get_where('video', array('section_id' => $sec_id));
		$found = $query->result();
		if( $query->num_rows() > 0)
		{
			return array(
				'filename' => $found[0]->file,
				'section_id' => $found[0]->section_id
			) ;

		}
	}
	public function delete_video_exists()
	{
		$this->db->where('id', $this->input->post('upload_id') );
        $this->db->delete('uploads');

         echo json_encode( array(
                'message' => 'Supprimé avec succès',
                'success' => "true"
         ) );
	}
}
