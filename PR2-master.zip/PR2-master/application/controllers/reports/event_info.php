<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Event_info extends MY_Controller {
    
    public function __construct()
    {
        //parent::__construct();
        $this->my_controller_parent_construct();
//        $this->check_session_timed_out("bo_redirect_now");
        //load language files
        $this->load_language_backoffice();
        $this->lang->load('backoffice/reports', 'fr');
        $this->lang->load('backoffice/events', 'fr');
        //load model
        $this->load->model("user_model");
        $this->load->model("event_model");
        $this->load->model("event_registration_model");
    }

    public function export_events_list($event_schedule_id)
    {
        ini_set('memory_limit', '1024M');
        ini_set('max_execution_time', (60*3));

        $reports = array("event", "subscriber", "unsubscribe", "waitlist");
        $event_title = "";

        /** Include PHPExcel */
        require_once APPPATH  . 'libraries/Classes/PHPExcel.php';

        // Create new PHPExcel object
        $objPHPExcel = new PHPExcel();

        // Set document properties
        $objPHPExcel->getProperties()->setCreator("Le Monde Event Management System")
            ->setLastModifiedBy("Le Monde Event Management System")
            ->setTitle("Office 2007 XLSX Document")
            ->setSubject("Office 2007 XLSX  Document")
            ->setDescription("Test document for Office 2007 XLSX, generated using PHP classes.")
            ->setKeywords("office 2007 openxml php")
            ->setCategory("Export file");

        foreach($reports as $sheet=>$value) {
            $options = $this->get_report($value, $event_schedule_id);
            $row = 1;
            $row_value = 2;

            if($sheet > 0){
                $objPHPExcel->createSheet();
                $objPHPExcel->setActiveSheetIndex($sheet)->setTitle($this->lang->line("reports")[$value][$value."_file_name"]);
            }else {
                $objPHPExcel->setActiveSheetIndex($sheet)->setTitle($this->lang->line("reports")[$value][$value."_file_name"]);
            }

            $col = 0;
            //this code fragment is to set title header on every sheet except for the 1st sheet
            if($value != "event"){
                $this->event_header_title($objPHPExcel, $event_title, $options["column_names"]);
                $row= 2;
                $row_value = 3;
            }

            if (count($options["column_names"]) > 0) {
                foreach ($options["column_names"] as $colKey => $name) {
                    $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col, $row, $this->lang->line($name));
                    $objPHPExcel->getActiveSheet()->getStyleByColumnAndRow($col++, $row)->applyFromArray(
                        array
                        (
                            'fill' => array
                            (
                                'type' => PHPExcel_Style_Fill::FILL_SOLID,
                                'color' => array('rgb' => '428bca')
                            )
                        )
                    )->getBorders()->getAllBorders()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
                }
            }

            $col = 0;

            if (count($options["data"]) > 0) {
                foreach ($options["data"] as $data) {
                    foreach ($options["column_names"] as $colKey => $name) {
                        if (trim($name) != "") {
                            $cell_value = $data->{$name};
                            if ($name == "price_rate") {
                                $cell_value = str_replace(",00", "", number_format($data->{$name}, 2, ",", " ")) . " €";
                            } else if($name == "event_title") {
                                $event_title = $data->{$name};
                            } else if($name == "total_booked"){
                                $cell_value = $data->{"total_booked"};
                                if(isset($data->{"type"})) {
                                    if($data->{"type"} == 0) {
                                        $cell_value = $data->{"total_booked_ws"};
                                    }
                                }
                            }
                            $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col++, $row_value, $cell_value);
                        } else {
                            $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col++, $row_value, "");
                        }
                    }
                    $col = 0;
                    $row_value++;
                }
            }
        } //end of for loop

        // Auto size columns for each worksheet
        foreach ($objPHPExcel->getWorksheetIterator() as $worksheet) {

            $objPHPExcel->setActiveSheetIndex($objPHPExcel->getIndex($worksheet));

            $sheet = $objPHPExcel->getActiveSheet();
            $cellIterator = $sheet->getRowIterator()->current()->getCellIterator();
            $cellIterator->setIterateOnlyExistingCells(true);
            /** @var PHPExcel_Cell $cell */
            foreach ($cellIterator as $cell) {
                $sheet->getColumnDimension($cell->getColumn())->setAutoSize(true);
            }
        }
        //set file name
        $filename = $event_title." (".date('d-m-Y H\hi').")";

        // Set active sheet index to the first sheet, so Excel opens this as the first sheet
        $objPHPExcel->setActiveSheetIndex(0);

        // Redirect output to a client’s web browser (Excel2007)
        header('Content-Type: application/vnd.ms-excel; charset=utf-8');
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="'.$filename.'.xlsx"');
        header('Cache-Control: max-age=0');

        // If you're serving to IE 9, then the following may be needed
        header('Cache-Control: max-age=1');

        // If you're serving to IE over SSL, then the following may be needed
        header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
        header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
        header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
        header ('Pragma: public'); // HTTP/1.0

        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        $objWriter->save('php://output');
        exit();
    }

    private function get_report($type, $event_schedule_id, $event_id=null){
        switch($type){

            case "event" : return $this->event_data($event_schedule_id);
                break;

            case "subscriber" : return $this->export_subscribers_merge($event_schedule_id);
                break;

            case "unsubscribe" : return $this->export_unsubscription($event_schedule_id);
                break;

            case "waitlist" : return $this->export_waitlist($event_schedule_id);
                break;

            default : return array();
            break;
        };
    }

    public function export_subscribers_merge($event_schedule_id)
    {
        /*BASIC SUBCRIBERS LIST EXPORT TEMPLATE*/
        $column_names = array("last_name", "first_name", "total_booked", "email_address", "mobile_number", "city", "reservation_date", "reservation_time", "navigator", "reservation_status");
        $subscribers = $this->event_registration_model->get_event_subscribers_with_waitlist($event_schedule_id);

        return array(
            "column_names" => $column_names,
            "data" => $subscribers
        );
    }

    public function export_unsubscription($event_schedule_id)
    {
        /*BASIC SUBCRIBERS LIST EXPORT TEMPLATE*/
        $column_names = array("last_name", "first_name", "total_booked", "number_of_place_cancelled", "email_address", "mobile_number", "city", "reservation_date", "reservation_time", "date_of_cancellation", "time_of_cancellation", "navigator");
        $subscribers = $this->event_registration_model->get_event_unsubscription($event_schedule_id);

        return array(
            "column_names" => $column_names,
            "data" => $subscribers
        );
    }

    public function export_waitlist($event_schedule_id)
    {
        /*BASIC SUBCRIBERS LIST EXPORT TEMPLATE*/
        $column_names = array("last_name", "first_name", "total_booked", "email_address", "mobile_number", "city", "reservation_date", "reservation_time", "navigator");
        $subscribers = $this->event_registration_model->get_event_waitlist($event_schedule_id);

        return array(
            "column_names" => $column_names,
            "data" => $subscribers
        );
    }

    private function event_header_title($objPHPExcel, $event_title, $columns){
        $objPHPExcelSheet = $objPHPExcel->getActiveSheet(0);
        $first_letter = PHPExcel_Cell::stringFromColumnIndex(0);
        $last_letter = PHPExcel_Cell::stringFromColumnIndex(count($columns)-1);
        $header_range = "{$first_letter}1:{$last_letter}1";
        $objPHPExcelSheet->setCellValueByColumnAndRow(0, 1, mb_strtoupper($event_title));
        $objPHPExcelSheet->mergeCells($header_range);
        $objPHPExcelSheet->getStyle($header_range)->getFont()->setBold(true);
        $objPHPExcelSheet->getStyle($header_range)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $objPHPExcelSheet->getStyleByColumnAndRow(0, 1)->applyFromArray(
            array
            (
                'fill' => array
                (
                    'type' => PHPExcel_Style_Fill::FILL_SOLID,
                    'color' => array('rgb' => '428bca')
                )
            )
        )->getBorders()->getAllBorders()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcelSheet->getRowDimension('1')->setRowHeight(40);
    }

    public function event_data($event_schedule_id){
        /*BASIC SUBCRIBERS LIST EXPORT TEMPLATE*/
        $column_names = array("event_title", "event_type", "place_town", "date_month", "hour",
            "total_places_avl", "num_remaining_places", "price_rate","event_statuses");

        $events = $this->event_model->get_events_list_export($this->input->get(), 1, $event_schedule_id);

        return array(
            "column_names" => $column_names,
            "data" => $events
        );
    }


}