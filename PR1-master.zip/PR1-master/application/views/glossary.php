<!-- Page Content -->
<div class="container static">
  <a class="align-left" href="<?php echo site_url('main/progress'); ?>"><img src="<?php echo base_url('assets/img/return.png'); ?>"/>Retour</a>
  <div class="home" id="lien">
     <?php echo $this->backoffices->get_sadmin_personalizes(1); ?>
  </div>
</div>