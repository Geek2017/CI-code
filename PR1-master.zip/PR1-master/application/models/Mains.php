<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mains extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }

    public function accounts() 
    {
        $this->db->select('*');
        $this->db->from('accounts');
        $this->db->where('id',$this->session->userdata('id'));
        $query = $this->db->get();
        $user = $query->result(); 
        $user = $user[0];

        return array(
            'user_email' => $user->username
        );
    }
    public function get_my_referentinfo($token)
    {
        $query = $this->db->query("SELECT * FROM referents WHERE token_id='$token' "); 
        return $query->result_array();
    }
    public function check_token_confirm($token)
    {
        $check = $this->db->query(" SELECT * FROM referents WHERE token_id='$token' AND validation = 0 ");
      
        if($check->num_rows() > 0)
        {
           return  true;
        }else{
           return false;
        }
        
    }

    public function getProgressClass($section_id)
    {
        $Percent_Done = $this->questions->getPercentage_($section_id);

        if($Percent_Done >= 100 || ($this->users->with_referent() == 0 && $section_id == 6 ))
        {
            $class = 'gray-circle';
            $class2 = 'gray-chart-title gray-chart-title-border gray-top';
            $class3 = 'gray-chart-description-border desc-cont';
        }else if($Percent_Done >= 1){
            $class = 'green-circle';
            $class2 = 'green-chart-title green-chart-title-border green-top';
            $class3 = 'green-chart-description-border desc-cont';
        }else{
            $class = 'blue-circle';
            $class2 = 'blue-chart-title blue-chart-title-border blue-top';
            $class3 = 'blue-chart-description-border desc-cont';
        }
        return [
            'circle'    =>  $class,
            'title'     =>  $class2,
            'desc'      =>  $class3
        ];
    }
}