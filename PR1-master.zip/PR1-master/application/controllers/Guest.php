<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Guest extends CI_Controller {

    function __construct()
    {
        parent::__construct();
        $this->load->helper('form');
        $this->load->library('form_validation');
    }

    public function add_update_guest()
    {
        $user_id = $this->input->post('user_update_id');
        $user_email = $user_id ? $this->users->get_user_info(['id'=>$user_id])->row()->username : null;
        $input = array(
            'email'                 =>  $this->input->post('email')
        );
        $rules = array(
            'email'                 =>  'required|valid_email|Adresse e-mail invalide'
        );
        $validator = $this->globalmodel->akeenValidator($input, $rules);
        if($validator){
            $error = $validator[0];
            $return = json_encode(
                array(
                    'result'    =>  'error',
                    'message'   =>  $error['error']
                )
            );
        }else if($this->users->check_email_existing($this->input->post('email'), $user_email))
            $return = json_encode(['result'=>'error','message'=>'Adresse e-mail déjà existant']);
        else{
            if($result = $this->users->add_update_guest_user($user_id ? $user_id : null)) {
                $return = json_encode(['result' => 'success', 'message' => $result == 1 ? 'Utilisateur ajouté avec succès' : 'Mise à jour effectuée']);
                if($result == 3)
                    $return = json_encode(['result' => 'error', 'message' => 'Nombre d\'utilisateur atteint']);
            }else
                $return = json_encode(['result'=>'error','message'=>'Quelque chose a mal tourné']);
        }
        echo $return;
    }

    public function edit_guest()
    {
        $user_id = $this->input->post('id');
        if($account_data = $this->users->get_user_info(['id'=>$user_id])){
            if($user_data = $this->users->get_table_user(['user_id'=>$user_id])){
                $first_name = $user_data->row()->firstname;
                $lastname   = $user_data->row()->lastname;
                $company    = $user_data->row()->company;
                $position   = $user_data->row()->position;
            }
            echo json_encode([
                'email'     =>  $account_data->row()->username,
                'firstname' =>  isset($first_name)  ? $first_name   : '',
                'lastname'  =>  isset($lastname)    ? $lastname     : '',
                'company'   =>  isset($company)     ? $company      : '',
                'position'  =>  isset($position)    ? $position     : '',
            ]);
        }
    }

    public function get_user()
    {
        if($account_data = $this->users->get_user_info_data(['user_id'=>$this->session->userdata('id')])->row()){
            unset($account_data->password);
            unset($account_data->token_id);
            $subsidiary = null;
            if($org = $this->backoffices->get_organization_by_id($this->session->userdata('org')))
                $subsidiary = $org->subsidiary;
            $account_data = (array) $account_data;
            $account_data['subsidiary'] = $subsidiary;
            $account_data = (object)$account_data;
            echo json_encode($account_data);
        }
    }

    public function with_referent()
    {
        if($account_data = $this->users->get_user_info(['id'=>$this->session->userdata('id')])->row()){
            $this->users->update_user_info(['with_referent'=>"0"]);
        }
    }

    public function check_useradd_limit()
    {
        echo ak_return(true,$this->users->check_useradd_limit());
    }
}