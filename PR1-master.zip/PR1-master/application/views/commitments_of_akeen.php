<!-- Page Content -->
<div class="container static">
    <div class="row">
        <div class="col-lg-10 col-lg-offset-1">
         <?php 
            if(isset($user_role)) {
                if($this->session->userdata("lastname") != null){?>
                    <a class="align-left" href="<?php echo site_url('main/progress'); ?>"><img src="<?php echo base_url('assets/img/return.png'); ?>"/> Retour</a>
                        <?php } ?>
                             <?php
                        }else{
                            ?>
                          <a class="align-left" href="<?php echo site_url('main/'); ?>"><img src="<?php echo base_url('assets/img/return.png'); ?>"/> Retour</a>
                             <?php
                        }
                        ?>  
            <h1 class="text-center">Les engagements d&#8217;AkeeN  </h1>

        	<p><b>Les engagements d’AkeeN vis-à-vis de l’entreprise </b></p>            
            <p>AkeeN promet à l’entreprise de :</p>
            <ul class="static-bullet">
                <li><span>Aider &#224; la d&#233;cision pour orienter professionnellement un collaborateur </span></li>
                <li><span>Motiver ses salari&#233;s et d&#233;velopper la performance</span></li>
                <li><span>Faire gagner du temps aux RH en g&#233;rant un grand nombre de mobilit&#233;s internes tout en assurant l&#8217;&#233;galit&#233; de traitement et la confidentialit&#233;</span></li>
                <li><span>Garder la maîtrise de la d&#233;cision finale de l&#8217;attribution de poste au niveau DRH et manager op&#233;rationnel</span></li>
                <li><span>Capitaliser le processus de gestion de mobilit&#233; interne existant au sein de l&#8217;entreprise</span></li>
                <li><span>Disposer d&#8217;un processus pré-structuré mais adaptable rapidement &#224; ses besoins </span></li>
                <li><span>Acqu&#233;rir un dispositif de mobilit&#233; interne innovant correspondant aux enjeux actuels</span></li>
                <li><span>Structurer le projet de mobilit&#233; de fa&#231;on professionnelle (bilan &#224; date, &#233;quipe projet interne, flash report, indicateurs &#8230;.) </span></li>
            </ul><br><br>

             <p><b>Les engagements d&#8217;AkeeN vis-&#224;-vis du collaborateur</b> </p>
             <p>AkeeN promet au collaborateur de :</p>
            <ul class="static-bullet">
                <li><span> Rester maître du cadre et du processus en construisant son projet professionnel r&#233;aliste au regard du march&#233; interne,  &#224; son rythme, accompagn&#233; par une m&#233;thode rigoureuse, test&#233;e, et des conseillers ext&#233;rieurs. </span></li>
                <li><span>Garder sa motivation par une &#171; gamification &#187; du profil et une frise d&#8217;avancement </span></li>
                <li><span>Se regarder avec objectivit&#233; et sinc&#233;rit&#233; comme dans un miroir, sans regard ext&#233;rieur critique ou bienveillant. </span></li>
                <li><span> Construire un projet motiv&#233; et r&#233;aliste en passant en trois phases:</span></li>
                    <ul class="static-dashed">
                        <li>r&#233;aliser un bilan professionnel et personnel, gr&#226;ce &#224; des exercices, des tests, des questionnaires, et des conseils </li>
                        <li>construire son projet professionnel en le confrontant aux besoins internes et un pitch motiv&#233; en accord avec son actualit&#233;</li>
                        <li>se  mettre en relation avec un r&#233;seau de r&#233;f&#233;rents op&#233;rationnels et de DRH internes</li>
                    </ul>

                <li><span> Avoir acc&#232;s &#224; une hotline dans un mode (mail, t&#233;l&#233;phone, coach) et un  temps d&#233;cid&#233;s par l&#8217;entreprise</span></li>
            </ul>
        </div>        
    </div>
</div>
