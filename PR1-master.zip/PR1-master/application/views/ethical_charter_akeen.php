<!-- Page Content -->
<div class="container static">
    <div class="row">
        <div class="col-lg-10 col-lg-offset-1">
         <?php 
            if(isset($user_role)) {
                if($this->session->userdata("lastname") != null){?>
                    <a class="align-left" href="<?php echo site_url('main/progress'); ?>"><img src="<?php echo base_url('assets/img/return.png'); ?>"/> Retour</a>
                        <?php } ?>
                             <?php
                        }else{
                            ?>
                          <a class="align-left" href="<?php echo site_url('main/'); ?>"><img src="<?php echo base_url('assets/img/return.png'); ?>"/> Retour</a>
                             <?php
                        }
                        ?>  
            <h1 class="text-center">Charte d&#233;ontologique AkeeN</h1>
            <p>Notre charte est partag&#233;e par notre r&#233;seau de coachs r&#233;f&#233;rents</p>
            
            <p><b>Obligations et devoirs du coach r&#233;f&#233;rent AkeeN</b></p>
           	<ul class="static-bullet">
                <li><span>Le coach s'astreint <b>au secret professionnel</b> que ce soit au niveau de l&#8217;organisation ou de l&#8217;accompagn&#233;.</span></li>
                <li><span>L'exercice professionnel du coach AkeeN n&#233;cessite <b>une formation, une exp&#233;rience et une supervision.</b> </span></li>
                <li><span>Conscient de sa position, le coach <b>s'interdit d'exercer tout abus d'influence.</b></span></li>
                <li><span>Le coach prend tous les moyens propres &#224; permettre, dans le cadre du parcours AkeeN, <b>le d&#233;veloppement professionnel et personnel de l&#8217;accompagn&#233;.</b></span></li>
                <li><span><b>L&#8217;accompagnant</b> est garant du <b>cadre et des moyens</b></span></li>
                <li><span>Le coach est attentif <b>au m&#233;tier, aux usages, &#224; la culture, au contexte et aux contraintes de l&#8216;organisation.</b></span></li>
            </ul><br>
            
            <p><b>Engagements de l&#8217;accompagn&#233;</b></p>
            <ul class="static-bullet">
                <li><span>L&#8217;accompagn&#233; est responsable <b>du contenu et des sujets &#224; aborder. </b></span></li>
                <li><span>L'exercice professionnel du coach AkeeN n&#233;cessite une formation, une exp&#233;rience et une supervision. </span></li>
                <li><span>L&#8217;accompagn&#233; <b>s&#8217;engage &#224; participer &#224; toutes les &#233;tapes du parcours</b> AkeeN,</span></li>
                <li><span>L&#8217;accompagn&#233; s&#8217;astreint &#224;:</span></li>
                    <ul class="circle-list">
                        <li><b>garder strictement confidentielles</b> les informations du parcours et, &#224; cet effet, &#224; les prot&#233;ger dans des conditions de protection applicables &#224; leurs propres informations et documents confidentiels;</li>
                        <li><b>ne pas divulguer les Informations communiqu&#233;es par AkeeN,</b> &#224; une personne, entreprise, soci&#233;t&#233; ou Tiers quelconque d&#8217;aucune mani&#232;re que ce soit, ni par transfert de mail, ni de vive voix&#8230;.</li>
                        <li><b>compl&#233;ter un formulaire d&#8217;&#233;valuation</b> en fin de parcours.</li>
                    </ul>
               
            </ul>

        </div>        
    </div>
</div>
