<!-- jQuery -->
    <script src="<?php echo base_url();?>assets/js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>

    <script src="<?php echo base_url();?>assets/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/dataTables.bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/dataTables.responsive.js"></script>

    <script src="<?php echo base_url();?>assets/js/jquery.maskedinput.min.js"></script> 
    <script src="<?php echo base_url(); ?>assets/js/jquery.flip.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets/plugins/toast/script/showToast.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/head.min.js"></script> 
    <script src="<?php echo base_url(); ?>assets/js/bootbox.min.js"></script> 
    <script src="<?php echo base_url(); ?>assets/js/validator/app.js"></script>
    <script src="<?php echo base_url(); ?>assets/plugins/smoke/js/smoke.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/plugins/smoke/lang/fr.js"></script>
    <script src="<?php echo base_url(); ?>assets/ckeditor/ckeditor.js"></script>
    <script src="<?php echo base_url();?>assets/js/jquery.chosen.js"></script>
    <script src="<?php echo base_url();?>assets/js/jscolor.js"></script>
    <script src="<?php echo base_url();?>assets/js/ak_chosen.js"></script>
    <script src="<?php echo base_url();?>assets/js/global.js"></script>
    <!-- Geocode css-->
    <link href="<?php echo base_url();?>assets/css/geocode.css" rel="stylesheet">
    <!-- Load geonames -->
    <script type="text/javascript" src="http://api.geonames.org/export/geonamesData.js?username=akeen.12345"></script>
    <script type="text/javascript" src="http://api.geonames.org/export/jsr_class.js"></script>

    <!-- Script to Activate the Carousel --> 
    <script type="text/javascript">
    var url = "<?php echo base_url(); ?>";

        $(document).ready(function()
        {
            head.ready(function()
            {
                <?php
                if($this->session->userdata('role') != 0 && $this->session->userdata('role') < USERS):
                ?>
                head.js(
                    [
                        url+'assets/js/validator/reload.js',
                        url+'assets/js/validator/login.js',
                        url+'assets/js/validator/enterkey.js',
                        url+'assets/js/super/superprofile.js',
                        url+'assets/js/super/superpersonalize.js',
                        url+'assets/js/validator/accounts.js',
                        url+'assets/js/validator/organizations.js',
                        url+'assets/js/admin/company_users.js',
                        url+'assets/js/super/sections.js',
                        url+'assets/js/super/questionnaires.js',
                        url+'assets/js/super/dashboard_graph.js',
                        url+'assets/js/super/settings.js',
                        url+'assets/js/super/profile.js',
                        url+'assets/js/super/user_status.js',
                        url+'assets/js/super/personalize.js',
                        url+'assets/js/geocode.js'
                    ],
                    function ()
                    {
                        //console.log("loaded validators");
                    }
                );
                <?php else : ?>
             head.js(
                [
                    url+'assets/js/validator/reload.js',
                    url+'assets/js/validator/login.js',
                    url+'assets/js/validator/enterkey.js'
                ],
                function () 
                {
                   //console.log("loaded validators");
                }
             );

                <?php endif; ?>
            });

        });
    </script>

     <script>
    function openNav() 
    {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
    }

    function closeNav() {
        document.getElementById("mySidenav").style.width = "0";
        document.getElementById("main").style.marginLeft= "0";
    }
    function update_preview_color(e_class,type,jscolor) {
        var elements = ["header-preview","left-m-preview","right-m-preview","footer-preview"];
        var css = type == 1 ? 'background' : 'color';
        $('#'+elements[e_class]).css(css, '#'+jscolor.valueElement.value);
    }
    </script>
