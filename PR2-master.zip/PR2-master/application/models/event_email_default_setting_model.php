<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Event_email_default_setting_model extends CI_Model {

    var $column_order = array(null,'eett.email_type','email_tpl_setting_sched','eeds.email_tpl_number_of_recipients', 'email_tpl_sched_author', 'eeds.email_tpl_sched_date_added', null); //set column field database for datatable orderable
    var $column_search = array('CONCAT(u.first_name, " ", u.last_name)','eett.email_type'); //set column field database for datatable searchable just firstname , lastname , address are searchable
    var $order = array('eeds.email_tpl_sched_date_added' => 'desc'); // default order

    public function __construct() {
        parent::__construct();
    }

    private function _get_datatables_query($data_source){
        $this->db->select("
            eeds.email_tpl_setting_id,
            eett.email_type,
            eeds.email_type_id,
            eeds.email_tpl_setting_sched_by,
            eeds.email_tpl_setting_sched as email_tpl_setting_sched_q,
            eeds.email_tpl_number_of_recipients")
            ->select("CONCAT(u.first_name, ' ', u.last_name) as email_tpl_sched_author", FALSE)
            ->select("CONCAT(eeds.email_tpl_setting_sched, ' ', eeds.email_tpl_setting_sched_by) as email_tpl_setting_sched", FALSE)
            ->select("DATE_FORMAT(eeds.email_tpl_sched_date_added, '%d/%m/%Y %Hh%i') AS email_tpl_sched_date_added", FALSE)
            ->from("event_email_default_setting eeds")
            ->join('event_email_template_type eett', 'eett.email_type_id = eeds.email_type_id', 'left')
            ->join('user u', 'u.user_id = eeds.email_tpl_sched_author', 'left')
            ->where_in("eeds.email_tpl_setting_status", array(1));

        $i = 0;
//        if(isset($data_source["custom_filter_search"]) && !empty($data_source["custom_filter_search"]) && $data_source["custom_filter_search"] != "all"){
//            if($data_source["custom_filter_search"] == "start_date_time"){
//                $splitte = explode("/", $data_source['search']['value']);
//                $this->db->like("e.start_date_time", $splitte[1]."-".$splitte[0]);
//
//            } else {
//                if (isset($data_source["keyname"]) && !empty($data_source["keyname"])) {
//                    if($data_source[$data_source["keyname"]] != "") {
//                        $this->db->where("e." . $data_source["custom_filter_search"], $data_source[$data_source["keyname"]]);
//                    }
//                    $this->db->like("e.title", $data_source['search']['value']);
//                } else {
//                    $this->db->like("e." . $data_source["custom_filter_search"], $data_source['search']['value']);
//                }
//            }
//        } else {
            foreach ($this->column_search as $item) {// loop column
                if ($data_source['search']['value']) {  // if datatable send POST for search
                    if ($i === 0) { // first loop
                        $this->db->like($item, $data_source['search']['value']);
                    } else {
                        $this->db->or_like($item, $data_source['search']['value']);
                    }
                }
                $i++;
            }
//        }

        if(isset($data_source['order'])) { // here order processing
            if(isset($data_source['order']['0']['dir'])) {
                $this->db->order_by($this->column_order[$data_source['order']['0']['column']], $data_source['order']['0']['dir']);
            }
        } else if(isset($this->order)) {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    public function get_events_list_export($data_source){
        $this->_get_datatables_query($data_source);
        $query = $this->db->get();
        $res = $query->result();
        return $res;
    }

    public function get_datatables($data_source){
        $this->_get_datatables_query($data_source);
        if($data_source['length'] != -1)
            $this->db->limit($data_source['length'], $data_source['start']);
        $query = $this->db->get();
        return $query->result();
    }

    public function count_filtered($data_source){
        $this->_get_datatables_query($data_source);
        $query = $this->db->get();
        return $query->num_rows();
    }

    public function count_all($data_source){
        $this->_get_datatables_query($data_source);
        return $this->db->count_all_results();
    }

    public function save_default_configuration($data){
        //get last default schedule
        $default_sched = $this->get_default_email_schedule(1);
        $default_sched_wl = $this->get_default_email_schedule(2);

        //unset default config
        $this->db->where("email_type_id", $data["email_type_id"]);
        $this->db->where("email_tpl_setting_status", 1);
        $this->db->update("event_email_default_setting", array("email_tpl_setting_status" => 0));

        $this->db->insert("event_email_default_setting", $data);
        if ($this->db->affected_rows()) {
            $email_tpl_setting_id = $this->db->insert_id();
            if($data["email_type_id"] == 1) {//reminder email only

                //update the previous default setting id and populate the new one, this is to get the latest
                //default email schedule namely the default schedule and the custom schedule

                $this->db->query("UPDATE event_email_schedule ees
                SET ees.reference = '" . $email_tpl_setting_id . "', ees.email_schedule_date = NOW()
                WHERE ( ees.email_schedule_status = 1 "
                    . (isset($default_sched->email_tpl_setting_id) && !empty($default_sched->email_tpl_setting_id) ? "AND ees.reference = '" . $default_sched->email_tpl_setting_id . "'" : "") . "
                AND ees.email_type_id = 1 AND ees.email_schedule_id )
                OR (SELECT email_sched_reference_id
                    FROM event_email_recipient
                    WHERE email_sched_reference = 1
                    AND email_sched_reference_id = ees.email_schedule_id
                    AND email_status IN(0,2,3)
                    AND email_type_id = 1)
                ");

                $this->db->query("UPDATE event_email_recipient eer
                SET eer.email_sched_reference_id = " . $email_tpl_setting_id . "
                WHERE eer.email_status IN(0,2,3) AND eer.email_sched_reference = 2
                AND eer.email_type_id = 1 "
                    . (isset($default_sched->email_tpl_setting_id) && !empty($default_sched->email_tpl_setting_id) ? " AND eer.email_sched_reference_id = '" . $default_sched->email_tpl_setting_id . "'" : "") . "
                AND eer.email_sched_reference_id IN(
                    SELECT email_tpl_setting_id
                    FROM event_email_default_setting
                    WHERE  email_tpl_setting_id = eer.email_sched_reference_id
                    AND email_tpl_setting_status IN(0)
                    AND email_type_id = 1
                )");

            } else if($data["email_type_id"] == 2) { //waitlist reinvitaiton
                if(!empty($default_sched_wl))
                    $this->delete_current_waitlist_reinvitation_sched($default_sched_wl->email_tpl_setting_id);
            }
            return $email_tpl_setting_id;
        }
        return false;
    }

    public function update_default_configuration($email_tpl_setting_id, $data){
        $change_waitlist_sched = false;
        if($data["email_type_id"] == 2) {
            $change_waitlist_sched = $this->check_change_in_sched($email_tpl_setting_id, $data);
        }
        $this->db->where("email_tpl_setting_id", $email_tpl_setting_id);
        $updated = $this->db->update("event_email_default_setting", $data);

        if($updated){
            if ($change_waitlist_sched == true) {
                $this->delete_current_waitlist_reinvitation_sched($email_tpl_setting_id);
            }
            return true;
        }
        return false;
    }

    public function delete_configuration_setting($email_tpl_setting_id){
        $this->db->where("email_tpl_setting_id", $email_tpl_setting_id);
        $this->db->update("event_email_default_setting", array("email_tpl_setting_status" => 0));

        //if default scheduled is deleted then defer sending the email not yet sent
        $updated = $this->db->query("UPDATE event_email_recipient eer
            SET eer.email_status = 5, eer.email_date_time = NOW()
            WHERE eer.email_status IN(0,2,3)
            AND eer.email_sched_reference = 2
            AND eer.email_sched_reference_id = '".$email_tpl_setting_id."'");

        if($updated){
            return true;
        }
        return false;
    }

    private function check_change_in_sched($email_tpl_setting_id, $data){
        $result = $this->db->query(
            "SELECT email_tpl_setting_id
             FROM event_email_default_setting
             WHERE email_tpl_setting_sched_by = ?
             AND email_tpl_setting_sched = ?
             AND email_tpl_number_of_recipients = ?
             AND email_type_id = 2
             AND email_tpl_setting_id = ?",
            array($data["email_tpl_setting_sched_by"], $data["email_tpl_setting_sched"],
                $data["email_tpl_number_of_recipients"], $email_tpl_setting_id));
        if($result->num_rows() > 0) {
            return false;
        }
        return true;
    }

    public function delete_current_waitlist_reinvitation_sched($email_tpl_setting_id){
        $emailSched = $this->get_current_wlr_email_schedule(2, $email_tpl_setting_id);
        // print_r($emailSched); exit;
        if(sizeof($emailSched) > 0) {
            $this->db->query("UPDATE event_email_recipient eer
            SET eer.email_status = 5, eer.email_date_time = NOW()
            WHERE eer.email_status IN(0,2,3)
            AND eer.email_sched_reference = 1
            AND eer.email_type_id = 2
            AND eer.email_sched_reference_id = '".$emailSched->email_schedule_id."'");
        }

        $this->db->where("reference", $email_tpl_setting_id);
        $this->db->update("event_email_schedule", array("email_schedule_status" => 0));
    }

    public function get_current_wlr_email_schedule($email_type_id, $reference){
        $this->db->select("email_schedule_id");
        $this->db->where("email_schedule_status", 1);
        $this->db->where("reference", $reference);
        $this->db->where("email_type_id", $email_type_id);
        $this->db->limit(1);
        return $this->db->get("event_email_schedule")->row();
    }

    public function get_default_email_schedule($email_type_id){
        $this->db->select("email_tpl_setting_id, email_tpl_setting_sched, email_tpl_setting_sched_by, email_tpl_number_of_recipients");
        $this->db->where("email_tpl_setting_status", 1);
        $this->db->where("email_type_id", $email_type_id);
        $this->db->where("is_default", 0);
        $this->db->limit(1);
        return $this->db->get("event_email_default_setting")->row();
    }
}