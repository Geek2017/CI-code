<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <?php $this->load->view($header);?>
    
</head>

<body id="login-page">

    <div class="container">
    	<div class="login-cont">
    		<form id="frm-login" method="POST" role="form">
    			<div class="login-title">
    				<center><img src="<?php echo base_url('assets/img/logo_blue.png'); ?>" ></center>
    			</div>
    			<div class="login-body">
	    			<div class="form-group">
		    			<div class="inner-addon left-addon">
						    <i class="glyphicon glyphicon-envelope"></i>
						    <input type="text" class="form-control nxt" id="username"  data-smk-icon="glyphicon-asterisk" value="<?php echo (  get_cookie('username') != "" ) ?  get_cookie('username') : "" ;?>" placeholder="Email"  required/>
						</div>
					</div>
					<div class="form-group">
						<div class="inner-addon left-addon">
						    <i class="glyphicon glyphicon-lock"></i>
						    <input type="password" class="form-control nxt" id="password" data-smk-icon="glyphicon-asterisk" value="<?php echo (  get_cookie('password') != "" ) ?  get_cookie('password') : "" ;?>" placeholder="Votre mot de passe" required/>
						</div>
					</div>
					<div class="form-group">
                                <input id="remember" name="remember" class="nxt"
                                 <?php echo (  get_cookie('remember') != "" ) ?  "checked='checked'" : "" ;?> 
                                 type="checkbox" /> Se souvenir de moi</label>
                                <a class="right" href="#" data-toggle="modal" data-target="#forgot_password_modal">Mot de passe oublié?</a>
                            </div>


	    			 <button type="button" id="btn-login" onclick="Auth.login();" class="btn btn-primary login nxt" >SE CONNECTER</button>
    			</div>
    		</form>
    	</div>
    </div>

	<!-- Forgot Password -->
	<div id="forgot_password_modal" class="modal fade" role="dialog">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header header-form">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<h2 class="text-center modal-title">Mot de passe oublié</h2>
				</div>
				<div class="modal-body">
					<div class="contianer">
						<form id="forgotpass_form" role="form" autocomplete="off">
							<div class="col-sm-12">
								<div class="form-group">
									<input type="email" id="email_forgot" class="form-control email nxt" required data-smk-icon="glyphicon-asterisk"

										   placeholder="Votre adresse e-mail">
								</div>

								<button type="button" id="btn_forgot" data-loading-text="ENVOYER"  class="btn btn-primary login nxt" onclick="Auth.forgot_submit();">ENVOYER</button>
							</div>
							<div class="clearfix"></div>
						</form>
					</div>
				</div>
			</div><!-- /.modal-content -->

		</div>
	</div>

    <?php $this->load->view($footer); ?>
</body>

</html>