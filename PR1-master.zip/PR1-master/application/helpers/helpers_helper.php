<?php

    function dd()
    {
        echo "<pre>";
            array_map(function($x) { var_dump($x); }, func_get_args());
        echo "</pre>";
        die;
    }

    function ak_return($mcontent, $message)
    {
        return json_encode(array(
            'mcontent'  => $mcontent,
            'message'   => $message,
        ));
    }

    function ak_url()
    {
        $actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
        $index = strpos($actual_link, "index.php") > 0 ? 'index.php/' : '';
        return base_url().$index;
    }

    function multiKeyExists(array $arr, $key) {

        // is in base array?
        if (array_key_exists($key, $arr)) {
            return true;
        }

        // check arrays contained in this array
        foreach ($arr as $element) {
            if (is_array($element)) {
                if (multiKeyExists($element, $key)) {
                    return true;
                }
            }

        }

        return false;
    }
