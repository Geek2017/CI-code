<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Accueil</title>

    <!-- Bootstrap Core CSS -->
    <link href="<?php echo base_url();?>assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/css/datepicker.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="<?php echo base_url();?>assets/css/section.css" rel="stylesheet">
     <link href="<?php echo base_url();?>assets/css/akeen-slider.css" rel="stylesheet">
     <link href="<?php echo base_url();?>assets/css/custom.css" rel="stylesheet">
     <link href="<?php echo base_url();?>assets/css/font-awesome.min.css" rel="stylesheet">
     <link href="<?php echo base_url();?>assets/css/flip.css" rel="stylesheet">
     <link href="<?php echo base_url();?>assets/css/sidebar.css" rel="stylesheet">
     
     <link href="<?php echo base_url();?>assets/css/dataTables.responsive.css" rel="stylesheet">
     
    <!-- Toast message -->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/plugins/toast/style/showToast.css" />
     <script src="<?php echo base_url(); ?>assets/js/validator/app.js"></script>
         <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    
</head>

<body>
    <?php 
    $this->load->view($nav_menu);
    ?>

    <?php
    $model = new Backoffices();
    $personalize = $model->has_logo($this->session->userdata('org')) ? $model->has_logo($this->session->userdata('org')) : null;
    $color = $personalize ? json_decode($personalize->style) : null;
    ?>
<div id="wrapper">

    <!-- Sidebar -->
    <div id="sidebar-wrapper2" style="<?php echo $color ? 'background:#'.$color->left_menu_bg : ''; ?>">
    <div class="menu">
        <ul class="sidebar-nav2">
            <li class="nav-inline">
                <a data-toggle="modal" href="<?php echo site_url(); ?>" style="<?php echo $color ? 'color:#'.$color->left_menu_text : ''; ?>">
                    <img src="<?php echo base_url('assets/img/home-icon.png'); ?>" class="nav-img">
                    <?php echo mb_strtoupper('accueil'); ?>
                </a>
            </li>

            <li class="nav-inline">
                <a data-toggle="modal" href="<?php echo site_url('main/progress') ?>" style="<?php echo $color ? 'color:#'.$color->left_menu_text : ''; ?>">
                    <img src="<?php echo base_url('assets/img/arrow-icon.png'); ?>" class="nav-img">
                    <?php echo mb_strtoupper('Mon parcours');?>
                </a>
            </li>
            
            <li class="nav-inline">
                <a data-toggle="modal" href="<?php echo site_url('main/my_profile') ?>" style="<?php echo $color ? 'color:#'.$color->left_menu_text : ''; ?>">
                    <img src="<?php echo base_url('assets/img/user-icon.png'); ?>" class="nav-img">
                    <?php echo mb_strtoupper('Mon profil');?>
                </a>
            </li>

            <li class="nav-inline">
                <a data-toggle="modal" href="<?php echo site_url('referent/lists') ?>" style="<?php echo $color ? 'color:#'.$color->left_menu_text : ''; ?>">
                    <img src="<?php echo base_url('assets/img/ref-icon.png'); ?>" class="nav-img">
                    <?php echo mb_strtoupper('Mes référents');?>
                </a>
            </li>

            <li class="nav-inline">
                <a data-toggle="modal" href="<?php echo site_url('main/glosaire') ?>" style="<?php echo $color ? 'color:#'.$color->left_menu_text : ''; ?>">
                    <img src="<?php echo base_url('assets/img/glossary-icon.png'); ?>" class="nav-img">
                    <?php echo mb_strtoupper('Le glossaire');?>
                </a>
            </li>

            <li class="nav-inline">
                <a data-toggle="modal" href="#edit_profile" style="<?php echo $color ? 'color:#'.$color->left_menu_text : ''; ?>">
                    <img src="<?php echo base_url('assets/img/account-icon.png'); ?>" class="nav-img">
                    <?php echo mb_strtoupper('Mon compte');?>
                </a>
            </li>

            <li class="nav-inline">
                <a href="#" onclick="Auth.logout();" style="<?php echo $color ? 'color:#'.$color->left_menu_text : ''; ?>">
                    <img src="<?php echo base_url('assets/img/signout.png'); ?>" class="nav-img">
                    <?php echo mb_strtoupper('Se déconnecter');?>
                </a>
            </li>
        </ul>
    </div>
    </div>
    <!-- /#sidebar-wrapper -->

    <!-- Page Content -->
    <div id="page-content-wrapper">
        <?php 
        $this->load->view($content); 
        ?>
    </div>
    <!-- /#page-content-wrapper -->

</div>
<!-- /#wrapper -->
<!-- Footer -->
    <footer style="<?php echo $color ? 'background:#'.$color->footer_bg.'; color:#'.$color->footer_text : ''; ?>">
        <div class="container c-left">
         <div class="row">
             <div class="col-lg-4">
                 <div class="widget">
                     <h4 class="widgetheading footer-h4">Pour en savoir plus</h4>
                      <hr class="footer-list">
                     <ul class="link-list">
                         <li><a href="<?php echo site_url('main/heart_of_akeen'); ?>">Le c&#339;ur d&#8217;AkeeN</a></li>
                         <li><a href="<?php echo site_url('main/ampi_course'); ?>">Le parcours AMPI</a></li>
                         <li><a href="<?php echo site_url('main/commitments_of_akeen'); ?>">Les engagements d&#8217;AkeeN</a></li>
                         <li><a href="<?php echo site_url('main/question_frequency'); ?>">Questions fr&#233;quentes</a></li>
                         <li><a href="<?php echo site_url('main/press_area'); ?>">Espace Presse</a></li>
                     </ul>
                 </div>
             </div>
             <div class="col-lg-4">
                 <div class="widget">
                     <h4 class="widgetheading footer-h4">Notre société</h4>
                     <hr class="footer-list">
                     <ul class="link-list">
                         <li><a href="<?php echo site_url('main/who_are_we'); ?>">Qui sommes-nous ? </a></li>
                         <li><a href="<?php echo site_url('main/ethical_charter_akeen'); ?>">Charte d&#233;ontologique AkeeN</a></li>
                         <li><a href="<?php echo site_url('main/legal_notice'); ?>">Mentions l&#233;gales </a></li>
                         <li><a href="<?php echo site_url('main/terms_of_service'); ?>">Conditions G&#233;n&#233;rales d&#8217;utilisation</a></li>
                         <li><a href="<?php echo site_url('main/contact_us'); ?>">Nous contacter</a></li>
                     </ul>
                 </div>
             </div>
             <div class="col-lg-4">
                 <div class="widget">
                     <h4 class="widgetheading footer-h4">Votre dispositif de Mobilit&#233; interne</h4>
                      <hr class="footer-list">
                     <ul class="link-list">
                          <li><a href="<?php echo site_url('main/issues_of_internal_mobility'); ?>">Enjeux de la mobilit&#233; interne</a></li>
                         <li><a href="#">Charte et principes de la Mobilit&#233; interne</a></li>
                         <li><a href="#">Processus de Mobilit&#233; interne</a></li>
                         <?php 
                        if(isset($user_role)) { ?>
                         <li><a href="<?php echo site_url('main/glossary'); ?>">Glossaire</a></li>
                         <?php } ?>
                     </ul>
                 </div>
             </div>
         </div>
     </div>
      <div id="sub-footer">
         <div class="container">
         <div class="partnerlogo text-center"><img src="<?php echo base_url('assets/img/hdsi-2015-bleu.svg'); ?>"></div>
             <div class="row">
                 <div  class="col-lg-12">
                    <ul class="social-network">
                         <li><a href="#"><img src="<?php echo base_url('assets/img/linkedin-footer.png'); ?>"  alt="linkedin Logo"/></a></li>
                         <li><a href="#" ><img src="<?php echo base_url('assets/img/twitter-footer.png'); ?>"  alt="twitter Logo"/></a></li>
                         <li><a href="#" ><img src="<?php echo base_url('assets/img/google-plus-footer.png'); ?>"  alt="g+ Logo"/></a></li>
                    </ul>
                </div>
                     <div class="copyright">
                     <hr class="footer-copyright ">
                         <p>
                         &copy; AKEEN 2015. Tout droits réservés par Akeen Mobilité.
                         </p>
                     </div>
                 </div>
               
             </div>
        </div>
    </footer>


    <!-- jQuery -->
    <script src="<?php echo base_url();?>assets/js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>

    <script src="<?php echo base_url();?>assets/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/dataTables.bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/dataTables.responsive.js"></script>
    <script src="<?php echo base_url();?>assets/js/jquery.maskedinput.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/jquery.flip.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets/plugins/toast/script/showToast.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/head.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/bootbox.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/validator/app.js"></script>
    <script src="<?php echo base_url(); ?>assets/plugins/smoke/js/smoke.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/plugins/smoke/lang/fr.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/bootstrap-datepicker.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/datepicker-fr.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/profesional_job.js"></script>

    <!-- Script to Activate the Carousel --> 
     <?php 
     $validated = isset( $validated  ) ? $validated  : "";
     if( $validated == true) {
        echo " <script>
        $('#token').modal('show');
        </script>";
        }else{
         echo " <script>
        $('#token').modal('hide');
        </script>";
        }
    ?>
    <script>
    $(function() {
                $("body").delegate("#bday", "focusin", function(){
                    $('#bday').datepicker({
                        //startDate : start,
                        format: 'dd/mm/yyyy',
                        endDate   : '+0d',
                        language: 'fr'
                    // update "toDate" defaults whenever "fromDate" changes
                    })
                });
            });
        $('.carousel').carousel({
            interval: 3000 //changes the speed
        })
        $(function(){
            $(".flip").flip({
                trigger: 'hover'
            });
        });
        $("#menu-toggle").click(function(e) {
        
        $("body").toggleClass("toggled");
        });
        $("#menu-close").click(function(e) {
            
            $("body").removeClass("toggled");
        });
        $("#menu-close-l").click(function(e) {
            
            $("body").removeClass("toggled");
        });
        var url = "<?php echo base_url(); ?>";



        $(document).ready(function()
        {
            head.ready(function()
            {
                head.js(
                    [
                        url+'assets/js/validator/reload.js',
                        url+'assets/js/validator/profile.js',
                        url+'assets/js/validator/login.js',
                        url+'assets/js/validator/enterkey.js',
                        url+'assets/js/validator/referent.js',
                        url+'assets/js/validator/referents_table.js',
                        url+'assets/js/validator/satisfaction_curve.js',
                        url+'assets/js/validator/training.js',
                        url+'assets/js/validator/notation.js',
                        url+'assets/js/validator/languages.js',
                        url+'assets/js/validator/success_stories.js',
                        url+'assets/js/validator/vos_deceptions.js',
                        url+'assets/js/validator/trouverez.js',
                        url+'assets/js/validator/votre.js',
                        url+'assets/js/validator/subjects.js',
                        url+'assets/js/validator/plan_development.js',
                        url+'assets/js/validator/traits_4.js',
                        url+'assets/js/validator/pitch_film.js',
                        url+'assets/js/validator/strenghts_areas.js',
                        url+'assets/js/validator/values.js',
                        url+'assets/js/validator/regards.js',
                        url+'assets/js/validator/global_results.js',
                        url+'assets/js/validator/s_10.js',
                        url+'assets/js/validator/prof_assessment.js'
                    ],
                    function ()
                    {
                        //console.log("loaded validators");
                    }
                );
            });
            $("iframe").load(function() {
                setTimeout(function(){
                        $('.panel-collapse.collapse').collapse('hide');
                    },5000);
            });
            
        });

        var lastname = '<?php echo $this->session->userdata("lastname") ?>';
        if(lastname == ""){
            $("#pre-reg-btn").click();
        }
        

        if( app.searchstr(window.location.href, 'main/my_profile')  ){
              document.write('<div id="loader" style="display:table; position: absolute; top: 0; left: 0; width: 100%; height: 100%; z-index: 10000; background-color: rgba(0, 0, 0, 0.42);">'
            + '<div style="display:table-cell; vertical-align:middle; text-align: center;">'
            + '<br /><img src="'+ url +'assets/img/loading.gif" />'
            + '</div></div>');
        }
      

        $(document).on("ajaxComplete", function(e, xhr, settings){
              setInterval(function(){
                   $('#loader').fadeOut(500);
              },9000); 
        });

    </script>
</body>

</html>