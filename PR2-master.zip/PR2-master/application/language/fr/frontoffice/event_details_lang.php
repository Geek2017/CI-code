<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/* EVENT DETAILS */

// Headers
$lang["informations"] = "Informations";
$lang["speakers"] = "Intervenants";
$lang["related_content"] = "Contenus Liés";
$lang["partners"] = "Partenaires";

// Buttons
$lang["registration"] = "INSCRIPTION";
$lang["book"] = "RÉSERVER";

// Links
$lang["back_to_all_events"] = "Retour à tous les événements";

// Informations
$lang["start_date"] = "Date de début";
$lang["end_date"] = "Date de fin";
$lang["location"] = "Location";
$lang["city"] = "Ville";
$lang["event_rate"] = "Taux d'événement";
$lang["free"] = "Gratuit";
