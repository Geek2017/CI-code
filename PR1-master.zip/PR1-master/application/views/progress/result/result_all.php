<style>
    iframe {
        width: 100%;
        overflow: visible !important;
    }
    /*body {*/
        /*overflow: visible !important;*/
    /*}*/
    #s_result input, #s_result textarea {
        font-weight: bold;
        background-color: #fff !important;
    }
    #traits_graph_76,
    #traits_graph_71 {
        height: 598px !important;
    }
    @media print {
        iframe {
            width: 100%;
            overflow: visible !important;
        }
        body * {
            visibility: hidden;
            overflow: visible !important;
        }
        * { float: none !important; }
        #sec-content, #sec-content * {
            visibility: visible;
        }
        #sec-content {
            overflow: visible !important;
            float:none !important;
            /* position: fixed; */
        }
        #graphTest{
            width: 1000px !important;
        }
        #view-job td:nth-child(1),
        #training_table_res th,
        #table_ref_list th,
        #plan_tbl_d th,
        .piste-table th{
            background-color: #285a89 !important;
            color: #fff;
            border-color: #fff !important;
        }
        .job-tables table th,
        #v_tab_2 thead{
            background-color: #285a89 !important;
            color: #fff;
            border-color: #fff !important;
        }
        #training_table_res thead{
            background-color: #285a89 !important;
            color: #fff;
            border-color: #fff !important;
             -webkit-print-color-adjust: exact; 
        }.
        .sec-content thead {
            background-color: #285a89 !important;
        }
        body {
          -webkit-print-color-adjust: exact;
        }

        /*p {
            page-break-before: always;
        }*/
    }
    @media print and (color) {
       * {
          -webkit-print-color-adjust: exact;
          print-color-adjust: exact;
       }
       #print_btn_now{
          display: none !important;
       }
    }
    .piste-table .thead{
            background-color: #285a89 !important;
            color: #fff;
            border-color: #fff !important;
        }
</style>

<script type="text/javascript">
 var frames = $('.result_all_iframe');
 frames.load(function () {
        function h(e) {
            $(e).removeAttr('rows').css({'height':'0','overflow-y':'hidden'}).height(e.scrollHeight);
        }
        $('textarea').each(function () {
            h(this);
        }).on('input', function () {
            h(this);
        });
    });
</script>

<?php $MAX_SECTION = $this->questions->count_this('allsection_floor');  ?>
            <?php
            $x = 0;
            $q_a = [];
            for($i = 1; $i <= $MAX_SECTION; $i++):
                if($this->questions->count_this('question',$i) != $this->questions->count_this('answer',$i)):
                    $x++;
                endif;
            endfor;
            ?>
            <?php if($x == $MAX_SECTION): ?>
            <?php else: ?>
                    <?php
                    for($i = 1; $i <= $MAX_SECTION; $i++):
                        $question = $this->questions->count_this('question',$i);
                        $q_a[] = [$this->questions->count_this('question',$i),$this->questions->count_this('answer',$i)];
                        if($i == 4 && $this->questions->count_this('answer',$i) == 9 || $this->questions->count_this('question',$i) == $this->questions->count_this('answer',$i)):
                            $question_ = $this->questions->getAllQuestionsBySection($i);
                            ?>
                            <iframe style="display:none;"  src="<?php echo ak_url()."/main/myprofile_result/".$i ?>" id="result_<?php echo $i; ?>" class="result_all_iframe" scrolling="no" frameborder="0"></iframe>
                        <?php
                        endif;
                    endfor;
//                    ?>
            <?php endif ?>
            <?php
//            $file = $this->uploads->cvlist();
            ?>
<!--            <embed width="999" height="500" src="--><?php //echo base_url()."uploads/".$file['filename_orig']; ?><!--" type="application/pdf"></embed>-->
<!--    <iframe id="append_result"></iframe>-->
        <div id="printer"></div>
        <div id="append_result"></div>