<?php if ( !defined('BASEPATH')) exit('No direct script access allowed');

class Preferences extends MY_Controller {

	public function __construct()
	{
		$this->my_controller_parent_construct();
        $this->load_language_frontoffice();
        $this->lang->load('frontoffice/my_account', 'fr');
		$this->load->model('user_subscriber_model', '', TRUE);
		$this->load->model('user_subscriber_event_preference_model', '', TRUE);
        $this->load->model("user_activity_log_model");
		$this->load->model("personalization_model");
	}

	public function index()
	{
		$this->load->model('event_type_model', '', TRUE);

        
		if($this->session->userdata('first_logged_in')){


            $this->load_default_language();
			$this->data['page_title'] = 'Set Your Preference';
			$this->data['content'] = 'frontoffice/home/preferences_view';
			$this->data['preferences'] = $this->event_type_model->event_types();
			$this->data['first_time'] = TRUE;            
            $this->data['load_styles'] = array
            (
                '<link href="' . plugins_bundle() . 'bootstrap/validator/bootstrapValidator.min.css" rel="stylesheet">',
                '<link href="' . plugins_bundle() . 'bootstrap/notify_3.3.1/animate.min.css" rel="stylesheet">'
            );
            $this->data['load_scripts'] = array
            (
                '<script src="'.plugins_bundle().'inputmask/min/jquery.inputmask.bundle.min.js" type="text/javascript"></script>',
                "<script src='".plugins_bundle()."bootstrap/notify_3.3.1/bootstrap-notify.min.js' type='text/javascript'></script>",                
                "<script src='" . plugins_bundle() . "bootstrap/validator/bootstrapValidator.fr.min.js' type='text/javascript'></script>",
                '<script src="'.app_bundle().'app.js" type="text/javascript"></script>',
                '<script type="text/javascript">app.setLocale([], {baseurl : "'.base_url().'"}, 2);</script>',
                "<script src='".app_bundle()."frontoffice/set_preference.js' type='text/javascript'></script>"
            );
            $this->load_extra_files(array("datetime" => true));
            $this->lang->load('frontoffice/set_preferences', 'fr');

			$this->load->view('frontoffice_view', $this->data);
		} else {
            redirect('login', 'refresh');
        }
	}

// Update Preferences - First Login -----------------------------------------------------------------------------------------------------------

	public function setPreferences()
	{

        $this->check_session_timed_out("fo");
		$this->load->model('event_type_model', '', TRUE);
		$this->load->model('user_model', '', TRUE);
        $this->load->model("user_login_history_model");

        //check duplicate user email
        $check_email = $this->user_model->check_email($this->input->post("email_address"), null, array(3));
        if($check_email) {
            output_to_json($this, array(
                "mtype" => "error",
                "message" => $this->lang->line("email_exist"),
                "mdetail" => array(array("field" => "email", "message" =>$this->lang->line("email_exist")))
            ));
        } else {
            $create_user = $this->user_model->create_new_user(array(
                "first_name" => ucfirst($this->input->post("first_name")),
                "last_name" => ucfirst($this->input->post("last_name")),
                "email_address" => $this->input->post("email_address"),
                "password" => $this->session->userdata("first_logged_in")["subid"],
                "role_id" => 3,
                "status" => 1
            ));

            if ($create_user) {
                //add activity logs for adding user
                $add_new_user = $this->user_activity_log_model->add_activity_log(array(
                    "description" => "Add new user",
                    "user_id" => $create_user,
                    "action" => "ADD",
                    "table_origin" => "user",
                    "reference_id" => $create_user
                ));

                if (!$add_new_user) {
                    output_to_json($this, array(
                        'mtype' => 'error',
                        'message' => $this->lang->line("unknown_error_on_act_logs")
                    ));
                } else {
                    $date = $this->input->post('birthday');
                    $date = str_replace('/', '-', $date);

                    $civility = (empty($this->input->post('civility')))?NULL:ucfirst($this->input->post('civility'));
                    $birthday = (empty($this->input->post('civility')))?NULL:date('Y-m-d', strtotime($date));
                    $location = (empty($this->input->post('civility')))?NULL:ucfirst($this->input->post('location'));
                    $address = (empty($this->input->post('civility')))?NULL:ucfirst($this->input->post('address'));
                    $additional_address = (empty($this->input->post('civility')))?NULL:ucfirst($this->input->post('additional_address'));
                    $postal_code = (empty($this->input->post('civility')))?NULL:ucfirst($this->input->post('postal_code'));
                    $phone = (empty($this->input->post('phone')))?NULL:$this->input->post('phone');
                    $mobile = (empty($this->input->post('mobile')))?NULL:$this->input->post('mobile');

                    $subscribe = $this->user_subscriber_model->add_subscriber_data(array(
                        'subscriber' => $create_user,
                        'civility' => $civility,
                        'birthday' => $birthday,
                        'location' => $location,
                        'address' => $address,
                        'additional_address' => $additional_address,
                        'postal_code' => $postal_code,
                        'mobile' => $mobile,
                        'phone' => $phone
                       
                    ));
                    if ($subscribe) {
                        //add activity logs for adding subscriber data
                        $add_sub_data = $this->user_activity_log_model->add_activity_log(array(
                            "description" => "Add subscriber data",
                            "user_id" => $create_user,
                            "action" => "ADD",
                            "table_origin" => "user_subscriber",
                            "reference_id" => $subscribe
                        ));

                        if (!$add_sub_data) {
                            output_to_json($this, array(
                                'mtype' => 'error',
                                'message' => $this->lang->line("unknown_error_on_act_logs")
                            ));
                        } else {
                            //insert only when preference is available
                            if ($this->input->post('preference')) {
                                $this->user_subscriber_event_preference_model->setPreferences($subscribe, $this->input->post('preference'));

                                //add activity logs for adding subscriber's event preferences
                                $add_sub_preference = $this->user_activity_log_model->add_activity_log(array(
                                    "description" => "Add subscriber event preferences",
                                    "user_id" => $create_user,
                                    "action" => "ADD",
                                    "table_origin" => "user_subscriber_event_preference",
                                    "reference_id" => $subscribe
                                ));

                                if (!$add_sub_preference) {
                                    output_to_json($this, array(
                                        'mtype' => 'error',
                                        'message' => $this->lang->line("unknown_error_on_act_logs")
                                    ));
                                    exit;
                                }
                            }
                            //TRY TO LOGGED IN SUBSCRIBER AFTER SAVING HIS INFORMATION
                            $logged_in = $this->logged_me_in($create_user);

                            if ($logged_in) {
                                output_to_json($this, array(
                                    'mtype' => 'success',
                                    'message' => $this->lang->line('preferences_set')
                                ));
                            } else {
                                output_to_json($this, array(
                                    'mtype' => 'error',
                                    'message' => $this->lang->line("unknown_error")
                                ));
                            }
                        }
                    } else {
                        output_to_json($this, array(
                            'mtype' => 'error',
                            'message' => 'Unable to save user information. Unknown error was encountered!'
                        ));
                    }
                }
            } else {
                output_to_json($this, array(
                    'mtype' => 'error',
                    'message' => 'Unable to save user information. Unknown error was encountered!'
                ));
            }
        }
	}

    private function logged_me_in($user_id){

        $this->check_session_timed_out("fo");

        //GET SESSION DATA
        $subs_session_data = $this->session->userdata("first_logged_in");

        //IMMEDIATELY DELETE SESSION DATA
        $this->session->unset_userdata("first_logged_in");
        if(!empty(get_cookie('_L3W0VB3_rememberme'))){
            delete_cookie('_L3W0VB3_rememberme');
        }
        // User ID, Session ID, IP Address
        $this->data['user_id'] = $user_id;
        $this->set_user_data();

        // Update login history
        $login_id = $this->user_login_history_model->client_checkdb($this->data, "LOGIN");

        // Create Session
        $session_data = array(
            'logged_in' => array(
                'login_id' => $login_id,
                'user_id' => (string) $user_id,
                'fullname' => $this->input->post("first_name")." ".$this->input->post("last_name"),
                'role_id' => "3",
                'LeMondeFO' =>  3,
                'remember_me' => $subs_session_data["remember_me"]
            )
        );
        $this->session->unset_userdata('remember_me');
        $this->session->unset_userdata('r_user_id');
        $this->session->unset_userdata('r_role_id');
        $this->session->unset_userdata('_l0G4wT9');
        $this->session->set_userdata($session_data);

        $client_session = $this->session->userdata('logged_in');

        //SET COOKIE WHEN REMEMBER ME IS SELECTED
        if ($subs_session_data["remember_me"]) {
            // $this->remember_me_cookie($user_id, 3, $login_id);
        } else {
            $this->delete_user_cookie();
        }

        return true;
    }

    private function remember_me_cookie($user_id, $role_id, $login_id){
        $this->load->helper('cookie');
        $this->delete_user_cookie();
        $cookie_user_id = array(
            'name'   => 'userdata',
            'value'  => json_encode(array(
                "login_id" => $login_id,
                "cookie_id" => $user_id,
                "r_cookie_id" => $role_id
            )),
            'expire' => '172800', //2days
            'prefix' => '_L3W0VB3_',
            'domain' => $_SERVER['HTTP_HOST']
        );
        set_cookie($cookie_user_id);
    }

    private function remember_me_credentials($user_id, $role_id){
        $this->load->helper('cookie');
        // $this->delete_user_cookie();
        $cookie_data = array(
            'name'   => ($role_id == 3) ? 'rememberme' : 'rememberme_bo',
            'value'  => json_encode(array(
                "cookie_id" => $user_id,
                "r_cookie_id" => $role_id
            )),
            'expire' => '172800', //2days
            'prefix' => '_L3W0VB3_',
            'domain' => 'localhost'
        );
        $this->input->set_cookie($cookie_data);
    }

    private function delete_user_cookie(){
//        delete_cookie(array(
//            'name'   => 'userdata',
//            'value'  => '',
//            'expire' => '',
//            'domain' => '',
//            'prefix' => '_L3W0VB3_'
//        ));
        delete_cookie('_L3W0VB3_userdata');
    }

    private function set_user_data()
    {
        $this->data['session_id'] = $this->session->userdata('session_id');
        $this->data['ip_address'] = $this->input->ip_address();

        // User Agent
        if ($this->agent->is_browser())
        {
            $this->data['agent'] = $this->agent->browser().' '.$this->agent->version();
        }
        elseif ($this->agent->is_robot())
        {
            $this->data['agent'] = $this->agent->robot();
        }
        elseif ($this->agent->is_mobile())
        {
            $this->data['agent'] = $this->agent->mobile();
        }
        else
        {
            $this->data['agent'] = 'Unidentified User Agent';
        }
    }
    
// Update Preferences - Profile Page -----------------------------------------------------------------------------------------------------------
    public function update_location()
    {
        $this->check_session_timed_out("fo");
        
        $client_session = $this->data['logged_in'];
        $user_id = $client_session['user_id'];
        $login_id = $client_session['login_id']; 
        // Update location
        $query = $this->user_subscriber_model->update_location($user_id, $login_id);

        $result = array(
            "mtype" => "success", //error or success or warning or info
            "message" => $this->lang->line('location_updated'),
            "mdata" => array()
        );

        output_to_json($this, $result);
    }

    public function update_mail()
    {
        $this->check_session_timed_out("fo");
        $client_session = $this->data['logged_in'];
        $user_id = $client_session['user_id'];
        $login_id = $client_session['login_id']; 
        // Update location
        $this->user_subscriber_model->update_mail($user_id, $login_id);

        $result = array(
            "mtype" => "success", //error or success or warning or info
            "message" => $this->lang->line('mail_updated'),
            "mdata" => array()
        );

        output_to_json($this, $result);
    }

    public function update_email()
    {
        $this->check_session_timed_out("fo");
        $client_session = $this->data['logged_in'];
        $user_id = $client_session['user_id'];
        $login_id = $client_session['login_id']; 
        // Update location
        $this->user_subscriber_model->update_email($user_id, $login_id);

        $result = array(
            "mtype" => "success", //error or success or warning or info
            "message" => $this->lang->line('email_updated'),
            "mdata" => array()
        );

        output_to_json($this, $result);
    }

    public function update_telephone()
    {
        $this->check_session_timed_out("fo");
        $client_session = $this->data['logged_in'];
        $user_id = $client_session['user_id'];
        $login_id = $client_session['login_id']; 
        // Update location
        $this->user_subscriber_model->update_telephone($user_id, $login_id);

        $result = array(
            "mtype" => "success", //error or success or warning or info
            "message" => $this->lang->line('telephone_updated'),
            "mdata" => array()
        );

        output_to_json($this, $result);
    }

    public function update_mobile()
    {
        $this->check_session_timed_out("fo");
        $client_session = $this->data['logged_in'];
        $user_id = $client_session['user_id'];
        $login_id = $client_session['login_id']; 
        // Update location
        $this->user_subscriber_model->update_mobile($user_id, $login_id);

        $result = array(
            "mtype" => "success", //error or success or warning or info
            "message" => $this->lang->line('mobile_updated'),
            "mdata" => array()
        );

        output_to_json($this, $result);
    }

    public function update_preferences()
    {
        $this->check_session_timed_out("fo");
        
        $client_session = $this->data['logged_in'];
        $user_id = $client_session['user_id'];
        $login_id = $client_session['login_id']; 
        $preferences = $this->input->post('checked');

        $new_preferences = $this->user_subscriber_event_preference_model->update_preferences($user_id, $login_id, $preferences);

        $result = array(
            "mtype" => "success", //error or success or warning or info
            "message" => $this->lang->line('preferences_updated'),
            "mdata" => array('updated' => implode(", ", $new_preferences))
        );

        output_to_json($this, $result);
    }

    public function check_action()
    {        
        $this->load->model('event_concurrent_process_model');
        $this->load->model('user_subscriber_model');
        $this->load->model('user_subscriber_event_preference_model');

        $client_session = $this->data['logged_in'];
        $user_id = $client_session['user_id'];
        $login_id = $client_session['login_id'];   

        $field = $this->input->post('field');
        $profile_info = $this->input->post('profile_info');

        switch($field){
            case 'location' : $process_type = 5; break;
            case 'mail' : $process_type = 6; break;
            case 'email' : $process_type = 7; break;
            case 'telephone' : $process_type = 8; break;
            case 'mobile' : $process_type = 9; break;
            case 'preferences' : $process_type = 10; break;
            default : $process_type = NULL; break;
        }
        
        if($process_type != 10) $updated = $this->user_subscriber_model->check_profile_info_update($user_id, $field, $profile_info);
        else $updated = $this->user_subscriber_event_preference_model->check_profile_info_update($user_id, $field, $profile_info);
        
        if($updated['status']){
            $result = array (
                'mtype' => "change",
                'message' => $this->lang->line('updated'),
                'mdata' => $updated['data']
            );
        } else {
            $locked = $this->event_concurrent_process_model->profile_check_action($user_id, $login_id, $process_type);
            if($locked){
                $result = array (
                    'mtype' => "block",
                    'message' => $this->lang->line('logged_on_another_device'),
                    'mdata' => array()
                );
            }
            else {
                $result = array (
                    'mtype' => "success",
                    'message' => "Vous n'êtes pas connecté",
                    'mdata' => array()
                );
            }
        }            
        output_to_json($this, $result);
    }

    public function unlock_action()
    {
        $this->load->model('event_concurrent_process_model');

        $client_session = $this->data['logged_in'];
        $user_id = $client_session['user_id'];
        $login_id = $client_session['login_id'];   
        $process_type = $this->input->post('process_type');

        $this->event_concurrent_process_model->profile_unlock_action($login_id, $process_type);
    }

    public function update_contact_email(){
    	$email = $this->input->post('contact_email_info');
    	$results = $this->personalization_model->contact_email_update($email);

    	echo json_encode($results);
    }


}