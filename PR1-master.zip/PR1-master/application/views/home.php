    <!-- Half Page Image Background Carousel Header -->
    <div id="myCarousel" class="carousel slide" data-ride="carousel" data-interval="3000">
        <!-- Indicators -->
       <!-- <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
        </ol>-->

        <!-- Wrapper for Slides -->
        <div class="carousel-inner">
            <div class="item active">
                <!-- Set the first background image using inline CSS below. -->
                <img src="<?php echo base_url('assets/img/1.png'); ?>" class="img-responsive fill" alt=""/>
                <div class="carousel-caption">
                  <h2><span class="blue">Akeen</span> Mobilité Interne Professionnelle.</h2>
                </div>
            </div>
            <div class="item">
                <!-- Set the second background image using inline CSS below. -->
               <img src="<?php echo base_url('assets/img/2.png'); ?>"  class="img-responsive fill" alt=""/>
                <div class="carousel-caption">
                   <h2><span class="blue">Akeen</span> Mobilité Interne Professionnelle.</h2>
                </div>
            </div>
            <div class="item">
                <!-- Set the third background image using inline CSS below. -->
                <img src="<?php echo base_url('assets/img/3.png'); ?>" class="img-responsive fill" alt=""/>
                <div class="carousel-caption">
                    <h2><span class="blue">Akeen</span> Mobilité Interne Professionnelle.</h2>
                </div>
            </div>
        </div>

        <!-- Controls -->
        <a class="left carousel-control" href="#myCarousel" data-slide="prev">
            <span class="icon-prev"></span>
        </a>
        <a class="right carousel-control" href="#myCarousel" data-slide="next">
            <span class="icon-next"></span>
        </a>
        <?php

        $token = isset( $token ) ? $token : "";
        if ($token != false ):
            if(count($referent_data) == 0 && $total_ref && $this->input->cookie('validated', TRUE) == NULL ):
            ?>
            <div class="modal fade in" id="token_f">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                            <h4 class="modal-title">Contact dans le cadre d’un bilan de mobilité interne</h4>
                        </div>
                        <div class="modal-body">
                            <form action="" method="POST" role="form" id="token-frm_f" class="token-form">
                                <input type="hidden" class="form-control"  name="token_id" id="token_id_f" value="<?php echo $token; ?>" >

                                <div class="row">
                                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                        <div class="form-group-sm">
                                            <label for="">Nom</label>
                                            <input type="text" class="form-control nxt"  name="nom" id="nom_f" value="<?php //echo $referent_data[0]['last_name']; ?>" placeholder="">
                                        </div>
                                        <div class="form-group-sm">
                                            <label for="">Prénom</label>
                                            <input type="text" class="form-control nxt"  name="prenom" id="prenom_f" value="<?php //echo $referent_data[0]['first_name']; ?>" placeholder="">
                                        </div>
                                        <div class="form-group-sm">
                                            <label for="">Email</label>
                                            <input type="text" class="form-control nxt"  name="email" id="email_f" value="<?php //echo $referent_data[0]['email']; ?>" >
                                        </div>
                                    </div>
                                </div>


                        </div>
                        <div class="modal-footer">
                            <button type="button" onclick="referents.validate(0);" id="ref_btn_token_f" class="btn btn-primary nxt">Suivant</button>
                        </div>
                        </form>
                    </div><!-- /.modal-content -->
                </div><!-- /.modal-dialog -->
            </div><!-- /.modal -->
            <div class="modal fade" id="token">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                            <h4 class="modal-title">Contact dans le cadre d’un bilan de mobilité interne</h4>
                        </div>
                        <div class="modal-body">
                            <form action="" method="POST" role="form" id="token-frm" class="token-form">
                             <input type="hidden" class="form-control"  name="token_id" id="token_id" value="<?php echo $token; ?>" >
                               <input type="hidden" class="form-control"  name="uid_id" id="uid_id" value="" >

                                <div class="row">
                                    <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                                        <div class="form-group-sm">
                                            <label for="">Nom</label>
                                            <input type="text" class="form-control nxt" name="nom" id="nom" value=" " placeholder="">
                                        </div>
                                        <div class="form-group-sm">
                                            <label for="">Prénom</label>
                                            <input type="text" class="form-control nxt" name="prenom" id="prenom" value=" " placeholder="">
                                        </div>
                                        <div class="form-group-sm">
                                            <label for="">Email</label>
                                            <input type="text" class="form-control nxt" name="email" id="email_ref" value=" " placeholder="Input field">
                                            <input type="hidden" class="form-control nxt" name="email_orig" id="email_orig" value=" " placeholder="Input field">
                                        </div>
                                        <div class="form-group-sm">
                                            <label for="">Secteur</label>
                                            <input type="text" class="form-control nxt" name="secteur" id="secteur" value=" " placeholder="">
                                        </div>
                                    </div>
                                    <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                                        <div class="form-group-sm">
                                            <label for="">Entreprise/Filiale</label>
                                            <input type="text" class="form-control nxt" name="enterprise" id="enterprise" value=" " placeholder="">
                                        </div>
                                            <div class="form-group-sm">
                                            <label for="">Métier</label>
                                            <input type="text" class="form-control nxt" name="metier" id="metier" value=" " placeholder="">
                                        </div>
                                        <div class="form-group-sm">
                                            <label for="">Fonction</label>
                                            <input type="text" class="form-control nxt" name="fonction" id="fonction" value=" " placeholder="">
                                        </div>
<!--                                        <div class="form-group-sm">-->
<!--                                            <label for="">Lien avec vous</label>-->
<!--                                            <input type="text" class="form-control nxt" readonly name="lien_avec_vous" id="lien_avec_vous" value="--><?php //echo $referent_data[0]['link'] ; ?><!--" placeholder="">-->
<!--                                        </div>-->
                                    </div>
                                </div>
                                
                                                           
                        </div>
                        <div class="modal-footer">
                            <button type="button" onclick="referents.validate(1);" id="ref_btn_token" class="btn btn-primary nxt">Confirmer</button>
                        </div>
                        </form>
                    </div><!-- /.modal-content -->
                </div><!-- /.modal-dialog -->
            </div><!-- /.modal -->
            <?php
                endif;
            if(count($referent_data) != 0 && $referent_data[0]['validation'] == 2) : ?>
                <?php $file = $this->uploads->cvlist($referent_data[0]['user_id']);
                      $comp = json_decode($this->competences->datas(5, $referent_data[0]['user_id'], 1));
                ?>
                <div class="modal fade in" id="referent_q" data-backdrop="false">
                    <div class="modal-dialog" style="width: 800px;">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                <h4 class="modal-title">Contact dans le cadre d’un bilan de mobilité interne</h4>
                            </div>
                            <div class="modal-body">
                                <div class="panel-group sec-content" id="result_q">
                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                            <h3 class="panel-title">
                                                <a data-toggle="collapse" data-parent="#result_q" href="#result_1" aria-expanded="false" class="collapsed">
                                                    CV</a>
                                            </h3>
                                        </div>
                                        <div id="result_1" class="panel-collapse collapse" aria-expanded="false" style="height: 0px;">
                                            <div class="panel-body">
                                                <embed width="730" height="500" src="<?php echo base_url(); ?>uploads/<?php echo $file['filename_orig']; ?>" type="application/pdf"></embed>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                            <h3 class="panel-title">
                                                <a data-toggle="collapse" data-parent="#result_q" href="#result_2" aria-expanded="false" class="collapsed">
                                                    Compétences </a>
                                            </h3>
                                        </div>
                                        <div id="result_2" class="panel-collapse collapse" aria-expanded="false" style="height: 0px;">
                                            <div class="panel-body">
                                                <table id="cmpt" class="table" style="width:730px" cellspacing="1" cellpadding="1" border="1">
                                                    <tbody>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                        <td><strong>Verbes de compétences</strong></td>
                                                        <td><strong>Notation</strong></td>
                                                    </tr>
                                                    </tbody>
                                                    <tbody>
                                                    <?php foreach($comp as $key => $cmp) : ?>
                                                        <tr>
                                                            <td><?php echo $key + 1; ?></td>
                                                            <td><?php echo $cmp->name; ?></td>
                                                            <td><?php echo $cmp->notation; ?></td>
                                                        </tr>
                                                    <?php endforeach; ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <form action="" method="POST" role="form" id="submit_form_ref" class="token-form">
                                    <input type="hidden" class="form-control"  name="token_id" id="token_id_f" value="<?php echo $token; ?>" >
                                    <input type="hidden" class="form-control"  name="uid_id" id="uid_id_f" value="<?php echo $referent_data[0]['user_id']; ?>" >
                                    <input type="hidden" name="ref_name" value="<?php echo $referent_data[0]['first_name']." ".$referent_data[0]['last_name']; ?>">
                                    <?php include('home_question.php'); ?>
                            </div>
                            <div class="modal-footer">
                                <button type="button" onclick="referents.submit_referent_answer(event);" id="ref_btn_submit" class="btn btn-primary nxt">Envoyer</button>
                            </div>
                            </form>
                        </div><!-- /.modal-content -->
                    </div><!-- /.modal-dialog -->
                </div><!-- /.modal -->
            <?php endif ?>
        <?php endif ?>

    </div>

    <!-- Page Content -->
    <div class="container home">
        <div class="row">
            <div class="col-lg-12">
                <h2>Le marché du travail est en pleine mutation :</h2>
                <ul class="home-list">
                    <li>les salariés doivent travailler plus longtemps et sont de plus en plus « opportunistes »,</li>
                    <li>le contexte économique morose incite les entreprises à préserver leur capital humain mais aussi à réduire leurs coûts administratifs,</li>
                    <li>les collaborateurs se considèrent mal accompagnés dans leur gestion de carrière malgré les entretiens professionnels qui sont désormais obligatoires.</li>
                </ul>
            </div>
        </div>
        <div class="row col-3-content">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                <h3>La mobilité interne est un excellent moyen de préserver le capital humain de l'entreprise en répondant à trois niveaux d'enjeux sociétaux</h3>
                <br>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 flip-container">
                <div class="flip"> 
                    <div class="front">
                        <h4 class="text-center">Enjeux pour l’entreprise</h4>
                    </div>
                     <div class="back">
                        <ul class="content-ul">
                            <li><span>Favoriser <b>l’engagement des salariés, leurs perspectives d’employabilité</b> et la 
                            <b>performance</b> qui en découle</span></li>
                            <li><span>S’adapter au marché en ayant des <b>salariés polyvalents, avec une réelle capacité d'adaptation et tout de suite opérationnels</b></span></li>
                            <li><span>Préserver des salariés attachés à la <b>culture de l’entreprise</b> et à ses <b>produits</b>, </span></li>
                            <li><span>Attirer, développer, et fidéliser les <b>talents</b></span></li>
                            <li><span>Contribuer au <b>retour sur investissement interne</b> </span></li>
                            <li><span><b>Réduire les coûts</b> administratifs</span></li>
                            <li><span><b>Développer sa marque employeur (QVT)</b></span></li>
                        </ul>
                    </div>
                </div>

                <!-- <div class="flipper">
                    <div class="front">
                        <h4 class="text-center">Enjeux pour l’entreprise</h4>
                    </div>
                    <div class="back">
                        <ul class="content-ul">
                            <li><span>Favoriser <b>l’engagement des salariés, leurs perspectives d’employabilité</b> et la 
                            <b>performance</b> qui en découle</span></li>
                            <li><span>S’adapter au marché en ayant des <b>salariés agiles et opérationnels rapidement</b></span></li>
                            <li><span>Préserver des salariés attachés à la <b>culture de l’entreprise</b> et à ses* produits*, </span></li>
                            <li><span>Attirer, développer, et fidéliser les <b>talents</b></span></li>
                            <li><span>Contribuer au <b>retour sur investissement interne</b> </span></li>
                            <li><span><b>Réduire les coûts</b> administratifs</span></li>
                            <li><span><b>Développer sa marque employeur (QVT)</b></span></li>
                        </ul>
                    </div>
                </div> -->
            </div>

            <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 flip-container">
                <div class="flip">
                    <div class="front">
                        <h4 class="text-center">Enjeux pour le collaborateur</h4>                   
                    </div>
                    <div class="back">
                        <ul class="content-ul">
                            <li><span><b>Diversifier son parcours professionnel en changeant de poste</b> et / ou de métier </span></li>
                            <li><span><b>Développer ses compétences techniques et comportementales</b></span></li>
                            <li><span><b>Limiter les risques professionnels</b></span></li>
                            <li><span><b>Tirer le meilleur parti des avantages</b> des grands groupes </span></li>
                            <li><span><b>Renforcer son réseau interne</b></span></li>
                            <li><span><b>S’engager pleinement</b> dans un projet professionnel en accord avec son actualité</span></li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 flip-container">
                <div class="flip">
                    <div class="front">
                        <h4 class="text-center">Enjeux sociétaux</h4>
                    </div>
                    <div class="back">
                        <ul class="content-ul">
                            <li><span><b>Etre solidaire</b> en matière de gestion de l’emploi </span></li>
                            <li><span>Faire de l’entreprise un « <b>role model</b> » dans la gestion interne du capital humain </span></li>
                            <li><span><b>Anticiper les changements d’organisation des entreprises</b> et faciliter les évolutions de carrière afin de contribuer pleinement à l'emploi</span></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>


        <div class="col-lg-12">
            <p class="content">AkeeN est une start-up où le web se met au service de la mobilité interne professionnelle de tous les collaborateurs, au moindre coût. AkeeN les accompagne au travers d’un parcours, adossé à une plateforme web, complet et structuré en dix étapes aboutissant à un projet professionnel, s’appuyant à chaque étape sur des exercices pratiques. L’objectif est de favoriser l’engagement des salariés en conciliant les évolutions et les besoins de l’entreprise avec les compétences et les aspirations individuelles de chacun.</p><br>

            <p class="content">Le processus de la plateforme AkeeN est structuré en 10 étapes et accompagné pas à pas par un coach personnel:</p><br><br>        
        </div>

        <div class="col-lg-12">
            <div class="col-lg-8 col-lg-offset-2">
                <img src="<?php echo base_url('assets/img/10steps.png'); ?>" alt="" class="img-responsive">
            </div>
        </div>
    </div>

    <input type="hidden" id="deactivated" value="<?php echo $this->session->flashdata('account_deactivated') ? 1 : 0  ?>">