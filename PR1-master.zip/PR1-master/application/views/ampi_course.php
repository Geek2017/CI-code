<!-- Page Content -->
<div class="container static">
    <div class="row">
        <div class="col-lg-10 col-lg-offset-1">
         <?php 
            if(isset($user_role)) {
                if($this->session->userdata("lastname") != null){?>
                    <a class="align-left" href="<?php echo site_url('main/progress'); ?>"><img src="<?php echo base_url('assets/img/return.png'); ?>"/> Retour</a>
                        <?php } ?>
                             <?php
                        }else{
                            ?>
                          <a class="align-left" href="<?php echo site_url('main/'); ?>"><img src="<?php echo base_url('assets/img/return.png'); ?>"/> Retour</a>
                             <?php
                        }
                        ?>  
            <h1 class="text-center">Le parcours AkeeN Mobilit&#233; Professionnelle Interne</h1>

        	<p><b>Les 10 &#233;tapes du parcours AMPI</b></p>
			<p>Le parcours AkeeN Mobilit&#233; Professionnelle Interne est structur&#233; en 10 &#233;tapes : </p>

			<img src="<?php echo base_url('assets/img/AMPI_img.png'); ?>" class="img-responsive static-image" alt="AMPI 10 Stages">

			<p>Le processus AMPI permet au collaborateur de faire un bilan confidentiel, personnel et professionnel totalement digitalisé. Accompagné pas à pas par un coach personnel, la plateforme AkeeN offre au collaborateur :</p>

			<ul class="static-dashed">
        		<li><b>une série d’exercices personnels</b>, certains demanderont de la réflexion et d’autres de la spontanéité, l'important c'est d'être « sincère » dans les réponses,</li>
        		<li><b>des retours de votre r&#233;seau professionnel,</b></li>
        		<li><b>des conseils et une aide en ligne.</b></li>
        	</ul>

        	<p>Ce parcours a &#233;t&#233; con&#231;u en entonnoir pour permettre au salari&#233; d&#8217;affiner au fur et &#224; mesure des &#233;tapes son projet professionnel en interne &#224; son entreprise.</p>
        </div>        
    </div>
</div>
