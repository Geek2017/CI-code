<!-- Navigation -->
    <div class="modal fade" id="menu-modal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <a class="close" data-dismiss="modal" aria-hidden="true"><img src="<?php echo base_url('assets/img/close.png'); ?>" alt="Close"/></a>
                    <!--<h4>SEARCH</h4>
                    <form action="index_submit" method="get" accept-charset="utf-8">
                        <input type="text" name="" id="input" class="form-control" value="" placeholder="Search . ." required="required" pattern="" title="">
                    </form>-->
                    <img src="<?php echo base_url('assets/img/logo_blue.png'); ?>"  class="modal-logo img-responsive" alt="Akeen logo"/>
                </div>
                <div class="modal-body">
                    <ul class="main-menu">
                        <li class="active"><a href="<?php echo site_url() ?>">Nothing yet</a></li>
                        <li><a href="#">Nothing yet</a></li>
                        <?php 
                        if(isset($user_role)) {
                            ?>
                             <li><a href='#' onclick='Auth.logout();' >SE DECONNECTER</a></li>
                             <?php
                        }else{
                            ?>
                             <li><a data-toggle='modal' href='#login' data-dismiss='modal' aria-hidden='true'>SE CONNECTER</a></li>
                             <?php
                        }
                        ?>
                           
                           
                    </ul>
                </div>
                <div class="modal-footer">
                    <ul class="social_media">
                        <li><a href="#"><img src="<?php echo base_url('assets/img/linkedin.png'); ?>"  class="img-responsive " alt="Linked in Logo"/></a></li>
                        <li><a href="#"><img src="<?php echo base_url('assets/img/twitter.png'); ?>"  class="img-responsive " alt="Twitter Logo"/></a></li>
                        <li><a href="#"><img src="<?php echo base_url('assets/img/google-plus.png'); ?>"  class="img-responsive " alt="g+ Logo"/></a></li>
                    </ul>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
    
    <div class="container-fluid page-nav">
        <div class="container">
        <div class="row">
            <nav class="navbar" role="navigation">
                <div class="container">
                <div class="row">
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand" href="<?php echo base_url(); ?>"><img src="<?php echo base_url('assets/img/logo_blue.png'); ?>"  class="img-responsive " alt="Akeen Logo"/></a>
                    </div>
                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <div class="nav navbar-nav navbar-right">
                        <a class="text-right" data-toggle="modal" href='#menu-modal'><img src="<?php echo base_url('assets/img/menu_black.png'); ?>" alt="Menu"/></a>
                    </div>
                    <!-- /.navbar-collapse -->
                    </div>
                </div>
                <!-- /.container -->
            </nav>
        </div>
    </div>
    </div>

  