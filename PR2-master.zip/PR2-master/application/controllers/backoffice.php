<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Backoffice extends MY_Controller {
    public function __construct()
    {
        //parent::__construct();
        $this->my_controller_parent_construct();
        $this->load_language_backoffice();
        $this->show_page_404(array(1,2), "backoffice");
        $this->clear_cache();
    }


    public function index(){
        $check_session = $this->check_cookie_and_session();
        if($check_session) {
            //load language file
            $this->lang->load('backoffice/dashboard', 'fr');
            $this->data['content'] = "backoffice/dashboard/dashboard_view";
            $this->data['page_title'] = $this->lang->line('menu_dashboard');

            $this->load_extra_files(array("moment" => true,"date_range" => true));
            array_push($this->data['load_scripts'], '<!-- Google JS -->');
            array_push($this->data['load_scripts'], '<script type="text/javascript">app.setLocale(["dashboard"], {currenturl : "' . str_replace(base_url() . "?", base_url(), current_url()) . '", baseurl : "' . base_url() . '", timeout: '.$this->check_user_session_on_load($check_session, "bo").'}, 1);</script>');
            $this->load_extra_files(array("ga_embed" => true));
            array_push($this->data['load_scripts'], '<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>');
            array_push($this->data['load_scripts'], '<script type="text/javascript" src="https://www.google.com/jsapi"></script>');
            array_push($this->data['load_scripts'], '<script src="' . app_bundle() . 'backoffice/dashboard/dashboard.js" type="text/javascript"></script>');
            $this->load->view('backoffice_view', $this->data);
        } else {
            redirect(base_url("auth"));
        }
    }

    public function user_profile() {
        $check_session = $this->check_cookie_and_session();
        if($check_session) {
            //load model
            $this->load->model("user_model");
            //load language file
            $this->lang->load('backoffice/my_profile', 'fr');

            $this->data['content'] = "backoffice/profile/user_profile_view";
            $this->data['page_title'] = $this->lang->line('page_my_profile');
            $this->data["user_data"] = $this->user_model->get_user_information_by_user_id($this->data['logged_in']['user_id'], array(1,2));

            $this->load_extra_files(array("form_validator" => true));
            array_push($this->data['load_scripts'], '<!-- Custom JS -->');
            array_push($this->data['load_scripts'], '<script src="' . app_bundle() . 'backoffice/profile/user_profile.js" type="text/javascript"></script>');
            array_push($this->data['load_scripts'], '<!-- Init JS -->');
            array_push($this->data['load_scripts'], '<script type="text/javascript">app.setLocale(["my_profile|modal"], {currenturl : "'.str_replace(base_url()."?", base_url(), current_url()).'",baseurl : "'.base_url().'", timeout: '.$this->check_user_session_on_load($check_session, "bo").'}, 1);</script>');

            $this->load->view('backoffice_view', $this->data);
        } else {
            redirect(base_url('auth'));
        }
    }

    public function users_account() {
        $check_session = $this->check_cookie_and_session();
        if($check_session) {
            //load model
            $this->load->model("user_model");
            //load language file
            $this->lang->load('backoffice/system_config', 'fr');

            $this->data['content'] = "backoffice/admin/users_account_view";
            $this->data['page_title'] = $this->lang->line('page_users_account_management');
            $this->data["users_list"] = $this->user_model->get_user_information_list($this->data["logged_in"]["user_id"], array(2));

            $this->load_extra_files(array(
                "form_validator" => true,
                "datatable" => true
            ));
            array_push($this->data['load_scripts'], '<!-- Custom JS -->');
            array_push($this->data['load_scripts'], '<script src="' . app_bundle() . 'backoffice/admin/users_account.js" type="text/javascript"></script>');
            array_push($this->data['load_scripts'], '<!-- Init JS -->');
            array_push($this->data['load_scripts'], '<script type="text/javascript">app.setLocale(["system_config|uam"], {currenturl : "'.str_replace(base_url()."?", base_url(), current_url()).'", baseurl : "'.base_url().'", timeout: '.$this->check_user_session_on_load($check_session, "bo").'}, 1);</script>');

            $this->load->view('backoffice_view', $this->data);
        }else{
            redirect(base_url('auth'));
        }
    }

    public function city_location(){
        $check_session = $this->check_cookie_and_session();
        if($check_session) {
            //load model
            $this->load->model("event_city_location_model");
            //load language file
            $this->lang->load('backoffice/system_config', 'fr');

            $this->data['content'] = "backoffice/admin/city_location_view";
            $this->data['page_title'] = $this->lang->line('page_city_location');

            $this->load_extra_files(array(
                "form_validator" => true,
                "datatable" => true
            ));
            array_push($this->data['load_scripts'], '<!-- Custom JS -->');
            array_push($this->data['load_scripts'], '<script src="' . app_bundle() . 'backoffice/admin/city_location.js" type="text/javascript"></script>');
            array_push($this->data['load_scripts'], '<!-- Init JS -->');
            array_push($this->data['load_scripts'], '<script type="text/javascript">app.setLocale(["system_config|cl"], {currenturl : "'.str_replace(base_url()."?", base_url(), current_url()).'", baseurl : "'.base_url().'", timeout: '.$this->check_user_session_on_load($check_session, "bo").'}, 1);</script>');

            $this->load->view('backoffice_view', $this->data);
        }else{
            redirect(base_url('auth'));
        }
    }

    public function event_type(){
        $check_session = $this->check_cookie_and_session();
        if($check_session) {
            //load model
            $this->load->model("event_type_model");
            //load language file
            $this->lang->load('backoffice/system_config', 'fr');

            $this->data['content'] = "backoffice/admin/event_type_view";
            $this->data['page_title'] = $this->lang->line('page_event_preference');
            $this->load_extra_files(array(
                "form_validator" => true,
                "datatable" => true
            ));
            array_push($this->data['load_scripts'], '<!-- Custom JS -->');
            array_push($this->data['load_scripts'], '<script src="' . app_bundle() . 'backoffice/admin/event_types.js" type="text/javascript"></script>');
            array_push($this->data['load_scripts'], '<!-- Init JS -->');
            array_push($this->data['load_scripts'], '<script type="text/javascript">app.setLocale(["system_config|ep"], {currenturl : "'.str_replace(base_url()."?", base_url(), current_url()).'", baseurl : "'.base_url().'", timeout: '.$this->check_user_session_on_load($check_session, "bo").'}, 1);</script>');

            $this->load->view('backoffice_view', $this->data);
        }else{
            redirect(base_url('auth'));
        }
    }
    public function contact_email(){
        $check_session = $this->check_cookie_and_session();
        if($check_session) {
            //load model
            $this->load->model("event_type_model");
            //load language file
            $this->lang->load('backoffice/system_config', 'fr');

            $this->data['content'] = "backoffice/admin/contact_email";
            $this->data['page_title'] = $this->lang->line('page_contact_email');
            $this->load_extra_files(array(
                "form_validator" => true,
                "datatable" => true
            ));
            array_push($this->data['load_scripts'], "<script src='" . app_bundle() . "frontoffice/profile.js' type='text/javascript'></script>");
            array_push($this->data['load_scripts'], '<!-- Custom JS -->');
            array_push($this->data['load_scripts'], '<script src="' . app_bundle() . 'backoffice/admin/event_types.js" type="text/javascript"></script>');
            array_push($this->data['load_scripts'], '<!-- Init JS -->');
            array_push($this->data['load_scripts'], '<script type="text/javascript">app.setLocale(["system_config|ep"], {currenturl : "'.str_replace(base_url()."?", base_url(), current_url()).'", baseurl : "'.base_url().'", timeout: '.$this->check_user_session_on_load($check_session, "bo").'}, 1);</script>');
            $this->data['load_styles'] = array(
                '<link href="'.styles_bundle().'backoffice/contact_email.css" rel="stylesheet">'
            );
            $this->load->view('backoffice_view', $this->data);
        }else{
            redirect(base_url('auth'));
        }
    }
    public function personalization(){
        
        $check_session = $this->check_cookie_and_session();
        if($check_session) {
            $this->lang->load('backoffice/system_config', 'fr');
            $this->lang->load('backoffice/dashboard', 'fr');
            $this->lang->load('backoffice/personalization', 'fr');

            $this->data['content'] = "backoffice/personalization/personalization_view";
            $this->data['page_title'] = $this->lang->line('page_personalization');
          
               $this->load_extra_files(array(
                "form_validator" => true,
                "datatable" => true,
                  "tinymce" => true,
                  "app" => true
            ));
            array_push($this->data['load_scripts'], '<!-- Custom JS -->');
            array_push($this->data['load_scripts'], '<script src="' .plugins_bundle() . 'imagepreview/imagepreview.js" type="text/javascript"></script>');
            array_push($this->data['load_scripts'], '<script src="' .plugins_bundle() . 'croppie/croppie.js" type="text/javascript"></script>');
            array_push($this->data['load_scripts'], '<link href="' .plugins_bundle() . 'croppie/croppie.css" rel="stylesheet">');
            array_push($this->data['load_scripts'], '<script src="' . app_bundle() . 'backoffice/personalization/personalization.js" type="text/javascript"></script>');
            array_push($this->data['load_scripts'], '<!-- Init JS -->');
            array_push($this->data['load_scripts'], '<script type="text/javascript">app.setLocale(["system_config|ep"], {currenturl : "'.str_replace(base_url()."?", base_url(), current_url()).'", baseurl : "'.base_url().'", timeout: '.$this->check_user_session_on_load($check_session, "bo").'}, 1);</script>');

            $this->data['load_styles'] = array(
                '<link href="'.styles_bundle().'backoffice/personalize.css" rel="stylesheet">'
            );
            
            $this->load->view('backoffice_view', $this->data);

        }else{
            redirect(base_url('auth'));
        }
    }
    public function faq(){
        
        $check_session = $this->check_cookie_and_session();
        if($check_session) {
            $this->lang->load('backoffice/system_config', 'fr');
            $this->lang->load('backoffice/dashboard', 'fr');
            $this->lang->load('backoffice/personalization', 'fr');

            $this->data['content'] = "backoffice/faq/faq";
            $this->data['page_title'] = $this->lang->line('page_personalization');
          
               $this->load_extra_files(array(
                "form_validator" => true,
                "datatable" => true,
                  "tinymce" => true,
                  "app" => true
            ));
            array_push($this->data['load_scripts'], '<!-- Custom JS -->');
            array_push($this->data['load_scripts'], '<!-- Init JS -->');
            array_push($this->data['load_scripts'], '<script type="text/javascript">app.setLocale(["system_config|ep"], {currenturl : "'.str_replace(base_url()."?", base_url(), current_url()).'", baseurl : "'.base_url().'", timeout: '.$this->check_user_session_on_load($check_session, "bo").'}, 1);</script>');

            
            
            $this->load->view('backoffice_view', $this->data);

        }else{
            redirect(base_url('auth'));
        }
    }


    public function event(){
        $check_session = $this->check_cookie_and_session();
        
        if($check_session) {
            //load model
            $this->load->model("event_type_model");
            $this->load->model("event_model");
            $this->load->model("event_city_location_model");

            //load language file for event
            $this->lang->load('backoffice/events', 'fr');

            //load language file for event schedule
            $this->lang->load('backoffice/events_template_schedule', 'fr');

            //load language for event resend email
            $this->lang->load('backoffice/event_resend_email', 'fr');

            $this->data['content'] = "backoffice/events/event_view";
            $this->data['page_title'] = $this->lang->line('event_management');
            $this->data["event_types"] = $this->event_type_model->list_event_types();
            $this->data["city_location"] = $this->event_city_location_model->list_city();

            $this->load_extra_files(array(
                "form_validator" => true,
                "datatable" => true,
                "datetime" => true,
                "tinymce" => true,
                "money_formatter" => true,
                "dropzone" => true,
                "ajax_helper" => true,
                "easycomplete" => true
            ));
            array_push($this->data['load_scripts'], '<!-- Custom JS -->');

            array_push($this->data['load_scripts'], '<script src="' . app_bundle() . 'backoffice/events/event_speaker.js" type="text/javascript"></script>');
            
            array_push($this->data['load_scripts'], '<script src="' . app_bundle() . 'backoffice/events/event_schedule.js" type="text/javascript"></script>');
            
            array_push($this->data['load_scripts'], '<script src="' . app_bundle() . 'backoffice/events/event_assign_email_template.js" type="text/javascript"></script>');

            array_push($this->data['load_scripts'], '<script src="' . app_bundle() . 'backoffice/events/event_attachment.js" type="text/javascript"></script>');

            array_push($this->data['load_scripts'], '<script src="' . app_bundle() . 'backoffice/events/event_sponsors.js" type="text/javascript"></script>');
            
            array_push($this->data['load_scripts'], '<script src="' . app_bundle() . 'backoffice/events/event.js" type="text/javascript"></script>');

            array_push($this->data['load_scripts'], '<script src="' . app_bundle() . 'backoffice/events/event_resend_email.js" type="text/javascript"></script>');

            array_push($this->data['load_scripts'], '<!-- Init JS -->');
            
            array_push($this->data['load_scripts'], '<script type="text/javascript">app.setLocale(["events"], {currenturl : "'.str_replace(base_url()."?", base_url(), current_url()).'", baseurl : "'.base_url().'", timeout: '.$this->check_user_session_on_load($check_session, "bo").'}, 1);</script>');
            
            array_push($this->data['load_styles'], '<link href="'.styles_bundle().'backoffice/event.css" rel="stylesheet">');
            
            $this->load->view('backoffice_view', $this->data);
        }else{
            redirect(base_url('auth'));
        }
    }

    // public function event_mail(){
    //     $check_session = $this->check_cookie_and_session();
    //     if($check_session) {
    //         //load model
    //         $this->load->model("event_type_model");
    //         $this->load->model("event_model");
    //         $this->load->model("event_mail_model");
    //         $this->load->model("event_city_location_model");
    //         //load language file
    //         $this->lang->load('backoffice/events', 'fr');

    //         $this->data['content'] = "backoffice/events/event_mail_view";
    //         $this->data['page_title'] = $this->lang->line('menu_events_mail');
    //         $this->data["event_types"] = $this->event_type_model->list_event_types();
    //         $this->data["city_location"] = $this->event_city_location_model->list_city();

    //         $this->load_extra_files(array(
    //             "form_validator" => true,
    //             "datatable" => true,
    //             "datetime" => true,
    //             "tinymce" => true,
    //             "typeahead" => true
    //         ));
    //         array_push($this->data['load_scripts'], '<!-- Custom JS -->');
    //         array_push($this->data['load_scripts'], '<script src="' . app_bundle() . 'backoffice/events/event_mail.js" type="text/javascript" synchronous></script>');
    //         array_push($this->data['load_scripts'], '<!-- Init JS -->');
    //         array_push($this->data['load_scripts'], '<script type="text/javascript">app.setLocale(["events"], {currenturl : "'.str_replace(base_url()."?", base_url(), current_url()).'", baseurl : "'.base_url().'", timeout: '.$this->check_user_session_on_load($check_session, "bo").'}, 1);</script>');

    //         $this->load->view('backoffice_view', $this->data);
    //     }else{
    //         redirect(base_url('auth'));
    //     }
    // }

    public function reports_subscribers_list(){
        $check_session = $this->check_cookie_and_session();
        $this->data['load_styles'] = array(
                '<link href="'.styles_bundle().'backoffice/subscriber.css" rel="stylesheet">'
            );
        if($check_session) {
            //load model
            $this->load->model("user_model");
            //load language file
            $this->lang->load('backoffice/reports', 'fr');

            $this->data['content'] = "backoffice/reports/subscribers_list_view";
            $this->data['page_title'] = $this->lang->line('menu_reports_export_client_list');

            $this->load_extra_files(array(
                "form_validator" => true,
                "datatable" => true,
                "inputmask" => true,
                "ajax_helper" => true
            ));
            array_push($this->data['load_scripts'], '<!-- Custom JS -->');
            array_push($this->data['load_scripts'], '<script src="' . app_bundle() . 'backoffice/reports/subscribers_list.js" type="text/javascript"></script>');
            array_push($this->data['load_scripts'], '<!-- Init JS -->');
            array_push($this->data['load_scripts'], '<script type="text/javascript">app.setLocale(["reports"], {currenturl : "'.str_replace(base_url()."?", base_url(), current_url()).'", baseurl : "'.base_url().'", timeout: '.$this->check_user_session_on_load($check_session, "bo").'}, 1);</script>');

            $this->load->view('backoffice_view', $this->data);
        }else{
            redirect(base_url('auth'));
        }
    }

    public function reports_events_list(){
        $check_session = $this->check_cookie_and_session();
        if($check_session) {
            //load model
            $this->load->model("user_model");
            $this->load->model("event_model");
            //load language file
            $this->lang->load('backoffice/reports', 'fr');
            $this->lang->load('backoffice/events', 'fr');

            $this->data['content'] = "backoffice/reports/events_list_view";
            $this->data['page_title'] = $this->lang->line('export_events_data');

            $this->load_extra_files(array(
                "datatable" => true
            ));
            array_push($this->data['load_scripts'], '<!-- Custom JS -->');
            array_push($this->data['load_scripts'], '<script src="' . app_bundle() . 'backoffice/reports/events_list.js" type="text/javascript"></script>');
            array_push($this->data['load_scripts'], '<!-- Init JS -->');
            array_push($this->data['load_scripts'], '<script type="text/javascript">app.setLocale(["reports"], {currenturl : "'.str_replace(base_url()."?", base_url(), current_url()).'", baseurl : "'.base_url().'", timeout: '.$this->check_user_session_on_load($check_session, "bo").'}, 1);</script>');

            $this->load->view('backoffice_view', $this->data);
        } else {
            redirect(base_url('auth'));
        }
    }

    public function event_waitlist_management() {
        $check_session = $this->check_cookie_and_session();
        if($check_session) {
            //load model
            $this->load->model("event_wait_list_reinvitation_setting_model");
            //load language file
            $this->lang->load('backoffice/events', 'fr');

            $this->data['content'] = "backoffice/events/event_waitlist_management_view";
            $this->data['page_title'] = $this->lang->line('menu_events_waitlist_management');
            $this->data["user_data"] = $this->event_wait_list_reinvitation_setting_model->get_waitlist_default_reinvitation_settings();

            $this->load_extra_files(array("form_validator" => true));
            array_push($this->data['load_scripts'], '<!-- Custom JS -->');
            array_push($this->data['load_scripts'], '<script src="' . app_bundle() . 'backoffice/events/event_wait_list_reinvitation_management.js" type="text/javascript"></script>');
            array_push($this->data['load_scripts'], '<!-- Init JS -->');
            array_push($this->data['load_scripts'], '<script type="text/javascript">app.setLocale(["events|waitlist_mgmt"], {currenturl : "'.str_replace(base_url()."?", base_url(), current_url()).'",baseurl : "'.base_url().'", timeout: '.$this->check_user_session_on_load($check_session, "bo").'}, 1);</script>');

            $this->load->view('backoffice_view', $this->data);
        } else {
            redirect(base_url('auth'));
        }
    }

    public function email_template(){
        $check_session = $this->check_cookie_and_session();
        if($check_session) {
            //load language file
            $this->lang->load('backoffice/email', 'fr');

            $this->data['content'] = "backoffice/email/email_template_view";
            $this->data['page_title'] = $this->lang->line('menu_email_template');

            $this->load_extra_files(array(
                "form_validator" => true,
                "datatable" => true,
                "tinymce" => true
            ));
            array_push($this->data['load_scripts'], '<!-- Init JS -->');
            array_push($this->data['load_scripts'], '<script type="text/javascript">app.setLocale(["email"], {currenturl : "'.str_replace(base_url()."?", base_url(), current_url()).'", baseurl : "'.base_url().'", timeout: '.$this->check_user_session_on_load($check_session, "bo").'}, 1);</script>');
            array_push($this->data['load_scripts'], '<!-- Custom JS -->');
            array_push($this->data['load_scripts'], '<script src="' . app_bundle() . 'backoffice/email/email_template.js" type="text/javascript" synchronous></script>');

            $this->load->view('backoffice_view', $this->data);
        }else{
            redirect(base_url('auth'));
        }
    }

    public function email_default_setting(){
        $check_session = $this->check_cookie_and_session();
        if($check_session) {
            //load language file
            $this->lang->load('backoffice/email', 'fr');

            $this->data['content'] = "backoffice/email/email_defaul_setting_view";
            $this->data['page_title'] = $this->lang->line('menu_email_default_setting');

            $this->load_extra_files(array(
                "form_validator" => true,
                "datatable" => true,
                "tinymce" => true
            ));
            array_push($this->data['load_scripts'], '<!-- Custom JS -->');
            array_push($this->data['load_scripts'], '<script src="' . app_bundle() . 'backoffice/email/email_default_setting.js" type="text/javascript" synchronous></script>');
            array_push($this->data['load_scripts'], '<!-- Init JS -->');
            array_push($this->data['load_scripts'], '<script type="text/javascript">app.setLocale(["email"], {currenturl : "'.str_replace(base_url()."?", base_url(), current_url()).'", baseurl : "'.base_url().'", timeout: '.$this->check_user_session_on_load($check_session, "bo").'}, 1);</script>');

            $this->load->view('backoffice_view', $this->data);
        }else{
            redirect(base_url('auth'));
        }
    }

    public function email_assign_template(){
        $check_session = $this->check_cookie_and_session();
        if($check_session) {
            //load language file
            $this->lang->load('backoffice/email', 'fr');

            $this->data['content'] = "backoffice/email/email_assign_template_view";
            $this->data['page_title'] = $this->lang->line('menu_email_assign_template');

            $this->load_extra_files(array(
                "form_validator" => true,
                "datatable" => true,
                "tinymce" => true,
                "typeahead" => true
            ));
            array_push($this->data['load_scripts'], '<!-- Custom JS -->');
            array_push($this->data['load_scripts'], '<script src="' . app_bundle() . 'backoffice/email/email_assign_template.js" type="text/javascript" synchronous></script>');
            array_push($this->data['load_scripts'], '<!-- Init JS -->');
            array_push($this->data['load_scripts'], '<script type="text/javascript">app.setLocale(["email"], {currenturl : "'.str_replace(base_url()."?", base_url(), current_url()).'", baseurl : "'.base_url().'", timeout: '.$this->check_user_session_on_load($check_session, "bo").'}, 1);</script>');

            $this->load->view('backoffice_view', $this->data);
        }else{
            redirect(base_url('auth'));
        }
    }

    public function email_reminder(){
        $check_session = $this->check_cookie_and_session();
        if($check_session) {
            //load model
            $this->load->model("event_type_model");
            $this->load->model("event_model");
            $this->load->model("event_email_template_model");
            $this->load->model("event_city_location_model");
            //load language file
            $this->lang->load('backoffice/email', 'fr');

            $this->data['content'] = "backoffice/email/email_reminder_view";
            $this->data['page_title'] = $this->lang->line('menu_events_reminder');
            $this->data["event_types"] = $this->event_type_model->list_event_types();
            $this->data["city_location"] = $this->event_city_location_model->list_city();

            $this->load_extra_files(array(
                "form_validator" => true,
                "datatable" => true,
                "datetime" => true,
                "tinymce" => true,
                "typeahead" => true
            ));
            array_push($this->data['load_scripts'], '<!-- Custom JS -->');
            array_push($this->data['load_scripts'], '<script src="' . app_bundle() . 'backoffice/email/email_reminder.js" type="text/javascript" synchronous></script>');
            array_push($this->data['load_scripts'], '<!-- Init JS -->');
            array_push($this->data['load_scripts'], '<script type="text/javascript">app.setLocale(["email"], {currenturl : "'.str_replace(base_url()."?", base_url(), current_url()).'", baseurl : "'.base_url().'", timeout: '.$this->check_user_session_on_load($check_session, "bo").'}, 1);</script>');

            $this->load->view('backoffice_view', $this->data);
        }else{
            redirect(base_url('auth'));
        }
    }

    public function push_event(){
        $check_session = $this->check_cookie_and_session();
        if($check_session) {
            //load model
            $this->load->model("event_type_model");
            $this->load->model("event_model");
            $this->load->model("event_email_filter_model");
            $this->load->model("event_email_template_model");
            $this->load->model("event_city_location_model");
            //load language file
            $this->lang->load('backoffice/email', 'fr');

            $this->data['content'] = "backoffice/email/email_push_view";
            $this->data['page_title'] = $this->lang->line('menu_email_push');
            $this->data['filter'] = $this->event_email_filter_model->get_filters();
            $this->data["event_types"] = $this->event_type_model->list_event_types();
            $this->data["city_location"] = $this->event_city_location_model->list_city();

            $this->load_extra_files(array(
                "form_validator" => true,
                "datatable" => true,
//                "tinymce" => true,
//                "typeahead" => true,
                "moment" => true,
                "date_range" => true,
                "bootstrap_select" => true
            ));
            array_push($this->data['load_scripts'], '<!-- Custom JS -->');
            array_push($this->data['load_scripts'], '<script src="' . app_bundle() . 'backoffice/email/email_push.js" type="text/javascript" synchronous></script>');
            array_push($this->data['load_scripts'], '<!-- Init JS -->');
            array_push($this->data['load_scripts'], '<script type="text/javascript">app.setLocale(["email"], {currenturl : "'.str_replace(base_url()."?", base_url(), current_url()).'", baseurl : "'.base_url().'", timeout: '.$this->check_user_session_on_load($check_session, "bo").'}, 1);</script>');

            $this->load->view('backoffice_view', $this->data);
        }else{
            redirect(base_url('auth'));
        }
    }
}