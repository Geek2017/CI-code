<br/>
<br/>
<br/>
<br/>
<form method="post" id="makeQuestion">
    <?php echo form_dropdown('section', $options, '0'); ?>
    <textarea id="question" name="question"></textarea>
    <input type="button" name="Submit" id="submitQ" value="Submit">
</form>
<script src="<?php echo base_url(); ?>assets/ckeditor/ckeditor.js"></script>
<script>
    CKEDITOR.replace( 'question' );
</script>

<script>
    $(document).ready(function() {
        var BASE_URL = $('#baseURL').val();
        $('#submitQ').on('click', function(e){
            e.preventDefault();

            for (instance in CKEDITOR.instances) {
                CKEDITOR.instances[instance].updateElement();
            }

            $.ajax({
                url: BASE_URL + "index.php/postquestion",
                type: 'post',
                data: $('#makeQuestion').serialize(),
                success: function (data) {
                    if(data=='true'){
                        alert("Success");
                        CKupdate();
                    }
                }
            });
        });
        function CKupdate(){
            for ( instance in CKEDITOR.instances ){
                CKEDITOR.instances[instance].updateElement();
                CKEDITOR.instances[instance].setData('');
            }
        }
    });
</script>