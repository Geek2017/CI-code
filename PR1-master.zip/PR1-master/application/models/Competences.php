<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Competences extends CI_Model {

    public $min = 0;
    public $max = 100;

    function __construct()
    {
        parent::__construct();

    }
    
    public function count_post($cnt = array())
    {
      
      $min = $this->min;
      $max = $this->max;

      return array_filter(
          $cnt,
          function ($value) use($min,$max) {
              return ($value >= $this->min && $value <= $this->max && $value !="" );
          }
      );
    }
    public function count_empty($cnt = array())
    {

      $min = $this->min;
      $max = $this->max;

      return array_filter(
          $cnt,
          function ($value) use($min,$max) {
              return ( $value == "" || $value == null);
          }
      );
    }
  	public function adds()
  	{

    	$id = $this->session->userdata('id');

//  		$compt = array_search( '0', $_POST );
//  		unset( $_POST[$compt] );
  		unset( $_POST[0] );
      if( count( $this->count_post($_POST) ) >= 15 && count( $this->count_empty($_POST) ) == 0 ){
        foreach ( $_POST as $key => $value ) 
        {
          $this->db->insert('competence', array( 'user_id' =>  $id , 'name' => $key, 'notation' => $value ) );
        };
        echo json_encode( array(
          'message' => 'Insertion réussie',
          'redirect' => 'true'
        ));

      }else{

        echo json_encode( array(
            'message' => 'La valeur doit être  comprise entre 0 et 100',
            'redirect' => 'false'
        ));

      }

  		
  	}
  	public function updates()
  	{
  		$id = $this->session->userdata('id');

  		$arr = array();

  	  $compt = array_search( '0', $_POST );
      unset( $_POST[$compt] );  

      if( count( $this->count_post($_POST) ) >= 15 && count( $this->count_empty($_POST) ) == 0 )
      {

        foreach ( $_POST as $key => $value ) 
        {
              $arr[] = array( 'name'=> $key, 'notation' => $value );
        }

        $this->db->where('user_id', $this->session->userdata('id'));
        $this->db->update_batch('competence', $arr , 'name' );

        echo json_encode( array(
          'message' => 'Enregistrement des modifications',
          'redirect' => 'true'
        ));

      }
      else
      {
          echo json_encode( array(
              'message' => 'La valeur doit être  comprise entre 0 et 100',
              'redirect' => 'false'
          ));
      }

    	
  	}

  	public function datas($limit = null, $id = null, $flag = null)
  	{
  		 $id = $id ? $id : $this->session->userdata('id');
		 $results = $this->db
			 		->where('user_id',$id)
			 		->get('competence')
			 		->result();
		 if($limit){
			 $results = $this->db
				 ->where('user_id',$id)
				 ->order_by('notation','DESC')
				 ->limit($limit)
				 ->get('competence')
				 ->result();
		 }

        if($flag)
            return json_encode( $results  );
        else
            echo json_encode( $results  );
  	}

}


			