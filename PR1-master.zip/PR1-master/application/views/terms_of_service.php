<!-- Page Content -->
<div class="container static">
    <div class="row">
        <div class="col-lg-10 col-lg-offset-1">
         <?php 
            if(isset($user_role)) {
            	if($this->session->userdata("lastname") != null){?>
                    <a class="align-left" href="<?php echo site_url('main/progress'); ?>"><img src="<?php echo base_url('assets/img/return.png'); ?>"/> Retour</a>
                        <?php } ?>
                             <?php
                        }else{
                            ?>
                          <a class="align-left" href="<?php echo site_url('main/'); ?>"><img src="<?php echo base_url('assets/img/return.png'); ?>"/> Retour</a>
                             <?php
                        }
                        ?>  

        		<h1 class="text-center">Conditions G&#233;n&#233;rales d&#8217;utilisation </h1>
	        	<p class="indent" style="font-size:10pt;"><i>V1 14/09/2016</i></p><br>
	        	<p class="indent"><b>PREAMBULE<br>
				EN UTILISANT LE SITE INTERNET ACCESSIBLE A l&#8217;ADRESSE WWW.AKEEN.FR, VOUS ACCEPTEZ D'&#202;TRE LI&#201;(E) PAR CES CONDITIONS G&#201;N&#201;RALES D'UTILISATION.<br>
				NOUS ATTIRONS VOTRE ATTENTION SUR CE DOCUMENT QUI CONTIENT DES DISPOSITIONS IMPORTANTES SUR VOS DROITS ET OBLIGATIONS. NOUS VOUS RECOMMANDONS D'EN IMPRIMER UNE COPIE POUR VOS ARCHIVES</b></p><br>

			
			<p><b>1. Force Obligatoire des pr&#233;sentes</b><br>
			Le Site AkeeN (ci-apr&#232;s d&#233;sign&#233; &#171; le Site &#187;) est la propri&#233;t&#233; de GARDFI, soci&#233;t&#233; par actions simplifi&#233;e de droit fran&#231;ais au capital social de 10.000 euros, dont le si&#232;ge social est situ&#233; 29 rue Bapst, 92600 Asni&#232;res sur seine (France), immatricul&#233;e au registre de commerce et des soci&#233;t&#233;s de Nanterre sous le num&#233;ro 811 180 421 RCS (ci-apr&#232;s d&#233;sign&#233;e &#171; la   Soci&#233;t&#233; &#187;).</p><br>
			<p>AkeeN est accessible &#224; l&#8217;adresse www.akeen.fr.</p><br>
			<p>AkeeN est une plateforme qui permet au collaborateur de r&#233;aliser leur bilan professionnel et personnel en ligne pour aboutir &#224; un projet professionnel interne.</p><br>
			<p>En utilisant le Site AkeeN, vous acceptez d'&#234;tre li&#233;(e) par les pr&#233;sentes conditions g&#233;n&#233;rales d'utilisation lesquelles forment un contrat conclu entre AkeeN et vous-m&#234;me (ci-apr&#232;s d&#233;sign&#233; le &#171; Contrat Cadre &#187;). Les collaborateurs sont dans ce cadre qualifi&#233;s d' &#171; Utilisateur &#187;.</p>
        </div>        
    </div>
</div>