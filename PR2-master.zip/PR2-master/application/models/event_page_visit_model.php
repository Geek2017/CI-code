<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Event_page_visit_model extends CI_Model {

	public function __construct() {
        parent::__construct();
    }

    public function page_visit($event_id, $page_visitor)
    {
    	$this->db->insert('event_page_visit',
    		array(
    			'page_visitor' => $page_visitor,
    			'event_id' => $event_id,
    			'visit_medium' => 0
    		)
    	);
    }

}