<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Frontoffice extends MY_Controller {

    public function __construct()
    {
        $this->my_controller_parent_construct();
        $this->load_language_frontoffice();
        $this->show_page_404(array(3), "frontoffice");
        $this->token_duration(); 
        // $this->is_logged_in();
        $this->load->model('event_model', '', TRUE);
        $this->load->model('event_type_model', '', TRUE);
        $this->load->model('event_city_location_model', '', TRUE);
        $this->load->model('event_sponsor_assignee_model', '', TRUE);
        $this->load->model('event_speaker_assignee_model', '', TRUE);
    }

    public function index()
    {           
        $this->home();        
    }

    public function home()
    {

         $this->load->model('personalization_model');
         $new_banner =  $this->personalization_model->upload_get_banner() ;
         $white_label =   !empty( $new_banner['description'] ) ?  $new_banner['description'] :  "<p> En remerciement de votre fidélité, <em>Le Monde</em> vous propose d'assister gratuitement aux spectacles et événements ci-dessous. </p>
                             <p> Réservez vos places en vous connectant au moyen de vos identifiants <em>LeMonde.fr</em> </p>";
         $banner  = isset( $new_banner['image']) != null ?  banner_bundle().$new_banner['image'] : images_bundle().'frontoffice/homepage/caroussel.png';
        

        $this->data['content'] = "frontoffice/home/homepage_view";
        $this->data['page_title'] = $this->lang->line('title_homepage');
        // $this->data['page_banner'] = images_bundle().'frontoffice/homepage/caroussel.png';
        $this->data['page_banner_bg'] = $banner;
        $this->data['page_banner_description'] = $white_label;
        // $this->data['page_banner_image'] = images_bundle().'';
        $this->data['event_type'] = $this->event_type_model->home();
        $this->data['event_city'] = $this->event_city_location_model->home();

        $this->load_extra_files(array(
            "bootbox" => true,
            "dotdotdot" => true,
            "notify" => true,
            "ga" => true,
            "form_validator" => true
        ));

        $check_session = $this->check_cookie_and_session();
        if($check_session){
            //load validation files
            array_push($this->data['load_scripts'], "<script src='".app_bundle()."frontoffice/init.js' type='text/javascript'></script>");
            array_push($this->data['load_scripts'], '<script type="text/javascript">_initjs.set_vars({baseurl : "'.base_url().'", currenturl : "'.str_replace(base_url()."?/", base_url(), current_url()).'"});</script>');
            array_push($this->data['load_scripts'],'<script src="'.app_bundle().'app.js" type="text/javascript"></script>');
            array_push($this->data['load_scripts'], '<script type="text/javascript">app.setLocale([], {baseurl : "'.base_url().'"}, 2);</script>');
        }
         // Changes start here
        array_push($this->data['load_scripts'], "<script src='".app_bundle()."frontoffice/events.js' type='text/javascript'></script>");
        array_push($this->data['load_scripts'], '<script type="text/javascript"> events.set_vars({baseurl : "'.base_url().'",system_lang : '.json_encode($this->lang->line('js')).'}); </script>');
        array_push($this->data['load_scripts'], "<script src='".app_bundle()."frontoffice/button_action.js' type='text/javascript'></script>");
        array_push($this->data['load_scripts'], '<script type="text/javascript"> button_action.set_vars({baseurl : "'.base_url().'",system_lang : '.json_encode($this->lang->line('js')).'}); </script>');
        
        $this->data['load_styles'] = array(
            '<link href="'.styles_bundle().'frontoffice/homepage.css" rel="stylesheet">'
        );
        $this->load->view('frontoffice_view', $this->data);
    }
    
    public function my_account()
    {
        $check_session = $this->check_cookie_and_session();
        if($check_session){
            $this->load->model('user_subscriber_model', '', TRUE);
            $this->load->model('user_subscriber_event_preference_model', '', TRUE);
            $this->load->model('event_type_model', '', TRUE);
            $this->lang->load('frontoffice/my_account', 'fr');

            $client_session = $this->data['logged_in'];
            $this->data['user_id'] = $client_session['user_id'];

            $this->data['content'] = "frontoffice/home/profile_view";
            $this->data['page_title'] = "My Account";
            $this->data['account_info'] = $this->user_subscriber_model->myaccount($this->data['user_id']);
            $this->data['preferences'] = $this->user_subscriber_event_preference_model->myaccount($this->data['user_id']);
            $this->data['event_preferences'] = $this->event_type_model->myaccount();
            $this->load_extra_files(array(
                "notify" => true,
                "form_validator" => true,
                "inputmask" => true,
                "ga" => true
            ));

            array_push($this->data['load_styles'], '<link href="' . styles_bundle() . 'frontoffice/my_account.css" rel="stylesheet">');
            array_push($this->data['load_scripts'], '<script src="' . app_bundle() . 'app.js" type="text/javascript"></script>');
            array_push($this->data['load_scripts'], "<script src='" . app_bundle() . "frontoffice/profile.js' type='text/javascript'></script>");
            array_push($this->data['load_scripts'], '<script type="text/javascript">app.setLocale([], {baseurl : "' . base_url() . '", timeout: '.$this->check_user_session_on_load($check_session, "fo").'}, 2);</script>');
            $this->load->view('frontoffice_view', $this->data);
        } else {
            redirect(base_url('login'));
        }
    }

    public function my_reservations()
    {
        $check_session = $this->check_cookie_and_session();
        if($check_session){
            $this->lang->load('frontoffice/my_reservations', 'fr');
            $this->load->model('event_type_model', '', TRUE);
            $this->data['content'] = "frontoffice/home/my_reservation";
            $this->data['page_title'] = $this->lang->line('my_reservations');
            $this->data['event_type'] = $this->event_type_model->event_types();
            $this->data['event_city'] = $this->event_city_location_model->home();

            $this->load_extra_files(array("notify" => true, "ga" => true));

            array_push($this->data['load_styles'], '<link href="' . styles_bundle() . 'frontoffice/reservations.css" rel="stylesheet">');
            array_push($this->data['load_scripts'], '<script src="'.app_bundle().'frontoffice/reservations.js" type="text/javascript"></script>');
            array_push($this->data['load_scripts'], '<script type="text/javascript"> reservations.set_vars({baseurl : "'.base_url().'",system_lang : '.json_encode($this->lang->line('js')).'}); var isalive = reservations.isalive({timeout: '.$this->check_user_session_on_load($check_session, "fo").'});</script>');
            
            $this->load->view('frontoffice_view', $this->data);
        } else {
            redirect(base_url('login'));
        }
    }

    public function in_development()
    {
        // $this->load->view('in_development_view');
        $this->data['content'] = "in_development_view";
        $this->data['page_title'] = "In Development";
        $this->load->view('frontoffice_view', $this->data);
    }

    public function event_details()
    {
        $this->lang->load('frontoffice/event_details', 'fr');
        $this->data['content'] = "frontoffice/home/event_details_view";
        $this->data['page_banner'] = images_bundle().'frontoffice/homepage/caroussel.png';
        $this->data['page_title'] = $this->lang->line('title_event_details_page');
        /*$this->data['page_banner_image'] = images_bundle().'frontoffice/event_details/logo-event-banner.png';*/
        // $this->data['page_banner_bg'] = images_bundle().'frontoffice/event_details/cover-orig\ 2350x200.jpg';
        $this->data['event_details'] = $this->event_model->event_details($this->input->get('event_id'));
        $this->data['event_timedate'] = $this->event_model->event_timedate($this->input->get('event_id'));
        $this->data['event_speakers'] = $this->event_speaker_assignee_model->event_details($this->session->userdata('user_id'), $this->input->get('event_id'));
        $this->data['event_sponsors'] = $this->event_sponsor_assignee_model->event_details($this->session->userdata('user_id'), $this->input->get('event_id'));

        $this->load_extra_files(array(
            "notify" => true,
            "datetime" => true,
            "bootbox" => true,
            "appjs" => true,
            "ga" => true
        ));

        $check_session = $this->check_cookie_and_session();
        array_push($this->data['load_styles'], '<link href="' . styles_bundle() . 'frontoffice/event_details.css" rel="stylesheet">');
        array_push($this->data['load_scripts'], '<script type="text/javascript">app.setLocale([], {baseurl : "'.base_url().'", timeout: '.$this->check_user_session_on_load($check_session, "fo").'}, 2);</script>');
        array_push($this->data['load_scripts'], "<script src='".app_bundle()."frontoffice/subscribe.js' type='text/javascript'></script>");
        array_push($this->data['load_scripts'], '<script type="text/javascript"> subscribe.set_vars({baseurl : "'.base_url().'",system_lang : '.json_encode($this->lang->line('js')).'}); </script>');
        array_push($this->data['load_scripts'], "<script src='".app_bundle()."frontoffice/button_action.js' type='text/javascript'></script>");
	    array_push($this->data['load_scripts'], '<script src="'.app_bundle().'frontoffice/date.min.js" type="text/javascript"></script>');
        array_push($this->data['load_scripts'], '<script type="text/javascript">button_action.event_pageview_counter('.$this->input->get('event_id').'); button_action.set_vars({baseurl : "'.base_url().'",system_lang : '.json_encode($this->lang->line('js')).'}); </script>');

        $this->load->view('frontoffice_view', $this->data);
    }

    public function contact()
    {
        $this->data['content'] = "frontoffice/home/contact_view";
        $this->data['page_title'] = "Contacter le Service Client";        
        $this->data['load_styles'] = array (
            '<link href="' . styles_bundle() . 'frontoffice/homepage.css" rel="stylesheet">'
        );

        $this->lang->load('frontoffice/contact', 'fr');
        $this->load->view('frontoffice_view', $this->data);
    }

    public function create_account_fo()
    {
        $this->data['content'] = "frontoffice/create_account_view";
        $this->data['page_title'] = "Create Account";
        $this->data['load_scripts'] = array
        (
            "<script src='".app_bundle()."frontoffice/authentication.js' type='text/javascript'></script>",
            "<script type='text/javascript'> authentication.set_vars({baseurl : '".base_url()."'}); </script>"
        );

        $this->lang->load('frontoffice/create_account', 'fr');
        $this->load->view('frontoffice_view', $this->data);
    }
    public function mentions_legales()
    {
        $this->data['content'] = "frontoffice/home/mentions_legales_view";
        $this->data['page_title'] = "Mentions Legales";
        $this->load->view('frontoffice_view', $this->data);
    }
}