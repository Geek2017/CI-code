<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Success_stories extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
    public function post_datas()
    {
        $action = $this->input->post('action');
         
         $data = array(
            'user_id' =>  $this->session->userdata('id') ,
            'success_text_1' => $this->input->post('context_1'),
            'success_text_2' => $this->input->post('context_2'),
            'success_text_3' => $this->input->post('context_3'),
            'success_text_4' => $this->input->post('context_4'),
            'success_text_5' => $this->input->post('context_5')
            );

        if( trim($this->input->post('context_1')) == null )
        {
             echo json_encode( array(
                    'message' => 'Veuillez remplir ce champ',
                    'focus' => 'context_1',
                    'redirect' => 'false'
                ) );
        }
        else if( trim($this->input->post('context_2')) == null )
        {
            echo json_encode( array(
                    'message' => 'Veuillez remplir ce champ',
                    'focus' => 'context_2',
                    'redirect' => 'false'
                ) );
        }
        else if( trim($this->input->post('context_3')) == null )
        {
            echo json_encode( array(
                    'message' => 'Veuillez remplir ce champ',
                    'focus' => 'context_3',
                    'redirect' => 'false'
                ) );
        }
        else if( trim($this->input->post('context_4')) == null )
        {
            echo json_encode( array(
                     'message' => 'Veuillez remplir ce champ',
                    'focus' => 'context_4',
                    'redirect' => 'false'
                ) );
        }
        else if( trim($this->input->post('context_5')) == null )
        {
            echo json_encode( array(
                'message' => 'Veuillez remplir ce champ',
               'focus' => 'context_5',
                'redirect' => 'false'
                ) );
        }else{
            
            switch ($action) 
            {
                case 'insert':
                    $this->db->insert('success_stories', $data);
                     echo json_encode( array(
                        'message' => 'Enregistré avec succès',
                        'redirect' => 'true'
                     ) );

                    break;

                case 'update':
                    $this->db->where('id',  $this->input->post('id') );
                    $this->db->update('success_stories', $data);
                     echo json_encode( array(
                        'message' => 'Enregistrement des modifications',
                        'redirect' => 'true'
                    ) );

                    break;
            }
        }
    }
    public function get_datas()
    {
        $data = array();

        $this->db->where('user_id', $this->session->userdata('id') );
        $query = $this->db->get("success_stories");
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
        }

        echo json_encode( $data );
    }
    public function count_success_stories()
    {
         $this->db->where('user_id', $this->session->userdata('id') );
         $query = $this->db->get("success_stories");

         echo json_encode( array(
            'count' => $query->num_rows()
            ) );
        
    }
    public function delete_datas()
    {
        $this->db->where('id', $this->input->post('id') );
        $this->db->delete('success_stories');

         echo json_encode( array(
                'message' => 'Supprimé avec succès'
         ) );
    }
    public function get_datas_id()
    {
        $data = array();

        $this->db->where('id', $this->input->post('id') );
        $query = $this->db->get("success_stories");
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
        }

        echo json_encode( $data );
    }
}

   
  