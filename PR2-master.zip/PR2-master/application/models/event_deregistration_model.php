<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Event_deregistration_model extends CI_Model {

	public function __construct() {
		parent::__construct();
	}

	public function deregister($user_id, $login_id, $event_schedule_id, $user_agent, $seats_cancelled)
	{
		// Get number of guest
		$subscriber_details = $this->db->select('registration_id, number_of_guest')
			->from('event_registration')
			->where('event_schedule_id', $event_schedule_id)
			->where('subscriber', $user_id)
			->where('status', 1)
			->get()
			->row();

		// Change client registered status
		$info = array('event_schedule_id' => $event_schedule_id, 'subscriber' => $user_id);
		$this->db->where($info);
		$this->db->order_by('date_time', 'DESC');
		$this->db->limit(1);
		$this->db->update('event_registration', array('status' => 0));

		// Insert deregistration record - Client
		$this->db->insert('event_deregistration',
			array(
				'registration_id' => $subscriber_details->registration_id,
				'event_schedule_id' => $event_schedule_id,
				'subscriber' => $user_id,
				'seats_reserve' => $subscriber_details->number_of_guest + 1,
				'number_of_place' => $subscriber_details->number_of_guest + 1, 
				'user_agent' => $user_agent
			)
		);

		//get the deregistration id
      	$deregisteredSubcriber = $this->db->insert_id();

		// Cancel Guests
		$this->db->where('inviter_id', $user_id);
		$this->db->where('event_schedule_id', $event_schedule_id);
		$this->db->update('event_subscriber_guest', array('status' => 0));
		
		// Free seats taken up by canceled clients
		$reserved_seats = 'remaining_seat+'.$seats_cancelled;
		$this->db->set('remaining_seat', $reserved_seats, FALSE);
		$this->db->where('event_schedule_id', $event_schedule_id);
		$this->db->update('event_schedule');

		// Update event_status
		$check_seats = $this->db->select('remaining_seat')
								->from('event_schedule')
								->where('event_schedule_id', $event_schedule_id)
								->get()
								->row();	

		if($check_seats->remaining_seat > 0){
			$this->db->where('event_schedule_id', $event_schedule_id);
			$this->db->update('event_schedule', array('event_status' => "AVAILABLE", 'back_office_status' => 2));
		}

		// Update event concurrent process
		$this->db->set('process_status', 0);
	    $this->db->where('login_id', $login_id);
	    $this->db->where('process_type', 2);
	    $this->db->update('event_concurrent_process');

	    return $deregisteredSubcriber;
	}
}
