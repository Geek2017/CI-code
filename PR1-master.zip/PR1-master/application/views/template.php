<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Accueil</title>

    <!-- Bootstrap Core CSS -->
    <link href="<?php echo base_url();?>assets/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
     <link href="<?php echo base_url();?>assets/css/akeen-slider.css" rel="stylesheet">
     <link href="<?php echo base_url();?>assets/css/custom.css" rel="stylesheet">
     <link href="<?php echo base_url();?>assets/css/font-awesome.min.css" rel="stylesheet">
     <link href="<?php echo base_url();?>assets/css/flip.css" rel="stylesheet">
     <link href="<?php echo base_url();?>assets/css/datepicker.min.css" rel="stylesheet">
    <!-- Geocode css-->
    <link href="<?php echo base_url();?>assets/css/geocode.css" rel="stylesheet">
     
     <link href="<?php echo base_url();?>assets/css/dataTables.responsive.css" rel="stylesheet">
     
    <!-- Toast message -->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/plugins/toast/style/showToast.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/plugins/smoke/css/smoke.min.css" />
    <!-- jQuery -->
    <script src="<?php echo base_url();?>assets/js/jquery.js"></script>
         <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    
</head>

<body>

    <?php 
    $this->load->view($nav_menu);
	$this->load->view($content); 
    ?>

	<!-- Footer -->
    <footer>
     <div class="container">
        <?php 
         echo $this->backoffices->get_sadmin_personalizes(2); 
        ?>
     </div>
      <div id="sub-footer">
         <div class="container">
         <div class="partnerlogo text-center"><img src="<?php echo base_url('assets/img/hdsi-2015-bleu.svg'); ?>"></div>
             <div class="row">
                 <div  class="col-lg-12">
                    <ul class="social-network">
                         <li><a href="#"><img src="<?php echo base_url('assets/img/linkedin-footer.png'); ?>"  alt="linkedin Logo"/></a></li>
                         <li><a href="#" ><img src="<?php echo base_url('assets/img/twitter-footer.png'); ?>"  alt="twitter Logo"/></a></li>
                         <li><a href="#" ><img src="<?php echo base_url('assets/img/google-plus-footer.png'); ?>"  alt="g+ Logo"/></a></li>
                    </ul>
                </div>
                     <div class="copyright">
                     <hr class="footer-copyright ">
                         <p>
                         &copy; AKEEN 2015. Tout droits réservés par Akeen Mobilité.
                         </p>
                     </div>
                 </div>
               
             </div>
        </div>
    </footer>
     </div>
     </div>

    

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>


    <script src="<?php echo base_url();?>assets/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/dataTables.bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/dataTables.responsive.js"></script>
    <script src="<?php echo base_url();?>assets/js/jquery.maskedinput.min.js"></script> 
    <script src="<?php echo base_url(); ?>assets/js/jquery.flip.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets/plugins/toast/script/showToast.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/head.min.js"></script> 
    <script src="<?php echo base_url(); ?>assets/js/bootbox.min.js"></script> 
    <script src="<?php echo base_url(); ?>assets/js/validator/app.js"></script>
    <script src="<?php echo base_url(); ?>assets/plugins/smoke/js/smoke.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/plugins/smoke/lang/fr.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/bootstrap-datepicker.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/datepicker-fr.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/profesional_job.js"></script>

     <!-- Load geonames -->
    <script type="text/javascript" src="http://api.geonames.org/export/geonamesData.js?username=akeen.12345"></script>
    <script type="text/javascript" src="http://api.geonames.org/export/jsr_class.js"></script>

    <!-- Script to Activate the Carousel --> 
     <?php 
     $validated = isset( $validated  ) ? $validated  : "";
     if( $validated == true) {
        echo " <script>
//        $('#token').modal('show');
        $('#token_f').modal('show');
        </script>";
        }else{
         echo " <script>
        $('#token_f').modal('hide');
//        $('#token').modal('hide');
        </script>";
        }
    ?>
    <script>
        $(function(){
            var start = $('#start_date').val()
            // set end date to max one year period:
            var end = '+0d';

            $('#start_date').datepicker({
                //startDate : start,
                endDate   : end,
                language: 'fr'
            // update "toDate" defaults whenever "fromDate" changes
            }).on('changeDate', function(){
                // set the "toDate" start to not be later than "fromDate" ends:
                $('#end_date').datepicker('setStartDate', $(this).val());
                
            }); 

            $('#end_date').datepicker({
                startDate : start,
                endDate   : end,
                language: 'fr'
            // update "fromDate" defaults whenever "toDate" changes
            })  

        });
        $('#clearButton').on('click', function() {
            $('#end_date').val('');
        });

        var start = $('#bday').val()
            // set end date to max one year period:
            var end = '+0d';

            $('#bday').datepicker({
                //startDate : start,
                format: 'dd/mm/yyyy',
                endDate   : '+0d',
                language: 'fr'
            // update "toDate" defaults whenever "fromDate" changes
            })
        $('#edit_profile').click(function() {
                $("body").delegate("#bday", "focusin", function(){
                    $('#bday').datepicker({
                        format: 'dd/mm/yyyy',
                        endDate   : '+0d',
                        language: 'fr'
                    // update "toDate" defaults whenever "fromDate" changes
                    })
                });
            });
        $('.carousel').carousel({
            interval: 3000 //changes the speed
        })
        $(function(){
            $(".flip").flip({
                trigger: 'hover'
            });
        });
        $("#menu-toggle").click(function(e) {
        
        $("body").toggleClass("toggled");
        });
        $("#menu-close").click(function(e) {
            
            $("body").removeClass("toggled");
        });
        $("#menu-close-l").click(function(e) {
            
            $("body").removeClass("toggled");
        });
        var url = "<?php echo base_url(); ?>";
   
        $(document).ready(function()
        {
            head.ready(function()
            {
             head.js(
                [
                    url+'assets/js/validator/reload.js',
                    url+'assets/js/validator/profile.js',
                    url+'assets/js/validator/login.js',
                    url+'assets/js/validator/referent.js',
                    url+'assets/js/validator/referents_table.js',
                    url+'assets/js/validator/enterkey.js',
                    url+'assets/js/validator/upload.js',
                    url+'assets/js/validator/satisfaction_curve.js',
                    url+'assets/js/geocode.js'
                       
                ],
                function () 
                {
                   //console.log("loaded validators");
                }
             );
            });
            $("#end_date, #start_date").mask('99/99/9999', {placeholder: "jj/mm/aaaa"});
        });

        var lastname = '<?php echo $this->session->userdata("lastname") ?>';
        if(lastname == ""){
            $("#pre-reg-btn").click();
        }
        
         
       

        
    </script>
</body>

</html>