<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pointimprovement extends CI_Controller {

	function __construct() 
	{
        parent::__construct();
    }
    
    public function populate()
    {
    $data = array();
        $query = $this->db->get_where('question_answers', array('user_id' => $this->session->userdata('id'), 'question_id' => 73));
        
        if ($query->num_rows() > 0) 
        {
            foreach ($query->result() as $row) 
            {
                foreach( json_decode($row->answer_caption,true) as $key=> $ans)
                {
                    if (strpos($ans['answer_caption'], '_2') !== false) {
                       $data[] = $ans;
                    }
                     
                }
            }
        }
        echo json_encode( $data ); 
    }
    public function get_improvement()
    {
        $data = array();
        $query = $this->db->get_where('question_answers', array('user_id' => $this->session->userdata('id'), 'question_id' => 73));
        if ($query->num_rows() > 0) 
        {
            foreach ($query->result() as $row) 
            {
                    $i = 1;

                    foreach( json_decode($row->answer_caption,true) as $key=> $ans)
                    {
                        if( $ans['answer_caption'] != null && strpos($ans['answer_caption'], '_1') !== FALSE ){
                             $data[$i] = array_unique($ans, SORT_REGULAR) ;
                              $i++;
                        }   
                       
                    }
                
            }
        }
        echo json_encode( $data ); 
    }
    public function populate_select_projection()
    {
        $data = array();
        $query = $this->db->get_where('question_answers', array('user_id' => $this->session->userdata('id'), 'question_id' => 94));
        
        if ($query->num_rows() > 0) 
        {
            foreach ($query->result() as $row) 
            {
                foreach( json_decode($row->answer_caption,true) as $key=> $ans)
                {
                    $data[] = $ans;
                }
            }
        }
        echo json_encode( $data ); 
    }
    public function populate_select_projection_7_2()
    {
        $data = array();
        $query = $this->db->get_where('question_answers', array('user_id' => $this->session->userdata('id'), 'question_id' => 80));
        $fou = $raisonnable = $realisable = '';
        if ($query->num_rows() > 0)
        {
            foreach ($query->result() as $row)
            {
                $datas = json_decode($row->answer_caption,true);
                foreach( json_decode($row->answer_caption,true) as $key=> $ans)
                {
                    if($ans['answer_caption'] == 'Le plus fou')
                        $fou = $datas[$key-1] ? $datas[$key-1]['answer_caption'] : null;
                    elseif($ans['answer_caption'] == 'Le plus raisonnable')
                        $raisonnable = $datas[$key-1] ? $datas[$key-1]['answer_caption'] : null;
                    elseif($ans['answer_caption'] == 'Le plus réalisable')
                        $realisable = $datas[$key-1] ? $datas[$key-1]['answer_caption'] : null;
                }
            }
        }
        echo json_encode( ['fou'=>$fou,'raisonnable'=>$raisonnable,'réalisable'=>$realisable] );
    }
    public function populate_max_rational()
    {
        $data = array();
        $query = $this->db->get_where('question_answers', array('user_id' => $this->session->userdata('id'), 'question_id' => 102));
        
        if ($query->num_rows() > 0) 
        {
            foreach ($query->result() as $row) 
            {
                foreach( json_decode($row->answer_caption,true) as $key=> $ans)
                {
                    $data[] = $ans;
                }
            }
        }
        echo json_encode( $data ); 
    }
    public function get_select_options(){
        $data = array();
        $query = $this->db->get_where('question_answers', array('user_id' => $this->session->userdata('id'), 'question_id' => 80));
        
        if ($query->num_rows() > 0) 
        {
            foreach ($query->result() as $row) 
            {
                foreach( json_decode($row->answer_caption,true) as $key=> $ans)
                {
                    $data[] = $ans;
                }
            }
        }
        echo json_encode( $data ); 
    }
    public function valeurs(){
        $data = array();
        $query = $this->db->get_where('question_answers', array('user_id' => $this->session->userdata('id'), 'question_id' => 75));
        
        if ($query->num_rows() > 0) 
        {
            foreach ($query->result() as $row) 
            {
                foreach( json_decode($row->answer_caption,true) as $key=> $ans)
                {
                    $data[] = $ans;
                }
            }
        }
        echo json_encode( $data ); 
    }
    public function update_piste(){
    
        $keys = [];
        $values = [];
        $piste_answer = [];

     
        //unset( array_search( '0', $_POST ) );
         //unset( array_search( 'id', $_POST ) );

        unset($_POST[0]);
        foreach ($_POST as $key => $value) {
           array_push($keys , $key);
           array_push($values, $value);
        }
        foreach($values as $key => $vals){
                        $data = [
                            'answer_title'       => $keys[$key],
                            'answer_caption'     => strlen(trim($vals)) > 0 ? $vals : null,
                        ];
                        array_push($piste_answer, $data);
            }
        unset($piste_answer[0]);
        $piste_answer = array_values($piste_answer);
        $data = array(
            'user_id' => $this->session->userdata('id'),
            'answer' => json_encode( $piste_answer )
        );
        //print_r( $data );
        $this->db->where('id',$this->input->post('id'));
        $this->db->update('piste', $data);

        echo json_encode( array( 
            'msg' => 'Enregistré avec succès'
        ) );
    }
     public function add_piste(){
    
        $keys = [];
        $values = [];
        $piste_answer = [];
        unset($_POST[0]);
        foreach ($_POST as $key => $value) {
           array_push($keys , $key);
           array_push($values, $value);
        }

        foreach($values as $key => $vals){
                        $data = [
                            'answer_title'       => $keys[$key],
                            'answer_caption'     => strlen(trim($vals)) > 0 ? $vals : null,
                        ];
                        array_push($piste_answer, $data);
            }
        
        $data = array(
            'user_id' => $this->session->userdata('id'),
            'answer' => json_encode( $piste_answer )
        );
        $this->db->insert('piste', $data);

        echo json_encode( array( 
            'msg' => 'Enregistré avec succès'
        ) );
    }
    public function get_piste($flag = null){
        $data = [];
        $id = [];
        $content = [];

         $this->db->where('user_id', $this->session->userdata('id') );
         $query = $this->db->get("piste");
         if ($query->num_rows() > 0) {
             foreach ($query->result() as $row) {
                  $content = [
                         'title' => json_decode($row->answer),
                         'id' => $row->id
                         ];
                 array_push($data, $content);
             }
             if($flag)
                 return json_encode(  $data );
             else
                echo json_encode(  $data );
         }

    }
    public function load_piste(){
        $data = [];
        $id = [];
        $content = [];

         $this->db->where('id', $this->input->post('id') );
         $query = $this->db->get("piste");
         if ($query->num_rows() > 0) {
             foreach ($query->result() as $row) {
                  $content = [
                         'title' => json_decode($row->answer),
                         'id' => $row->id
                         ];
                 array_push($data, $content);
             }
             echo json_encode(  $data );
         }

    }
    public function add_plan_d(){
    
        $keys = [];
        $values = [];
        $piste_answer = [];

         if( trim($_POST['obstacleobjectif'])  == null ){
             echo json_encode( array( 
                 'msg' => 'Veuillez compléter le champ',
                 'type' => 'error',
                 'focus_' => '#obstacleobjectif'
             ) );
        }else if( trim($_POST['actionlien']) == null ){
             echo json_encode( array( 
                'msg' => 'Veuillez compléter le champ',
                 'type' => 'error',
                 'focus_' => '#actionlien'
             ) );
        }else if( trim($_POST['echéance']) == null ){
            echo json_encode( array( 
                'msg' => 'Veuillez compléter le champ',
                 'type' => 'error',
                 'focus_' => '#echéance'
             ) );
        }else if(trim($_POST['budget'] )== null ){
             echo json_encode( array( 
                'msg' => 'Veuillez compléter le champ',
                 'type' => 'error',
                 'focus_' => '#budget'
             ) );
        }else if( trim($_POST['moyens']) == null ){
             echo json_encode( array( 
                'msg' => 'Veuillez compléter le champ',
                 'type' => 'error',
                 'focus_' => '#moyens'
             ) );
        }else if( trim($_POST['résultat']) == null ){
             echo json_encode( array( 
                'msg' => 'Veuillez compléter le champ',
                 'type' => 'error',
                 'focus_' => '#résultat'
             ) );
        }else{
                foreach ($_POST as $key => $value) {
                   array_push($keys , $key);
                   array_push($values, $value);
                }

                foreach($values as $key => $vals){
                                $data = [
                                    'answer_title'       => $keys[$key],
                                    'answer_caption'     => strlen(trim($vals)) > 0 ? $vals : null,
                                ];
                                array_push($piste_answer, $data);
                    }
                
                $data = array(
                    'user_id' => $this->session->userdata('id'),
                    'answer' => json_encode( $piste_answer )
                );
                $this->db->insert('plan', $data);

                echo json_encode( array( 
                     'msg' => 'Enregistré avec succès',
                     'type' => 'success',
                ) );
        }

       
    }
    public function update_plan_d(){
    
        $keys = [];
        $values = [];
        $piste_answer = [];
        
        if( trim($_POST['obstacleobjectif'])  == null ){
             echo json_encode( array( 
                 'msg' => 'error',
                 'type' => 'error',
                 'focus_' => '#obstacleobjectif'
             ) );
        }else if( trim($_POST['actionlien']) == null ){
             echo json_encode( array( 
                'msg' => 'error',
                 'type' => 'error',
                 'focus_' => '#actionlien'
             ) );
        }else if( trim($_POST['echéance']) == null ){
            echo json_encode( array( 
                'msg' => 'error',
                 'type' => 'error',
                 'focus_' => '#echéance'
             ) );
        }else if(trim($_POST['budget']) == null ){
             echo json_encode( array( 
                'msg' => 'error',
                 'type' => 'error',
                 'focus_' => '#budget'
             ) );
        }else if( trim($_POST['moyens']) == null ){
             echo json_encode( array( 
                'msg' => 'error',
                 'type' => 'error',
                 'focus_' => '#moyens'
             ) );
        }else if( trim($_POST['résultat']) == null ){
             echo json_encode( array( 
                'msg' => 'error',
                 'type' => 'error',
                 'focus_' => '#résultat'
             ) );
        }else{
            
             foreach ($_POST as $key => $value) {
               array_push($keys , $key);
               array_push($values, $value);
            }

        foreach($values as $key => $vals){
                        $data = [
                            'answer_title'       => $keys[$key],
                            'answer_caption'     => strlen(trim($vals)) > 0 ? $vals : null,
                        ];
                        array_push($piste_answer, $data);
            }
        
        $data = array(
            'user_id' => $this->session->userdata('id'),
            'answer' => json_encode( $piste_answer )
        );
        $this->db->where('id', $this->input->post('id') );
        $this->db->update('plan', $data);

     
                echo json_encode( array( 
                     'msg' => 'success',
                     'type' => 'success',
                ) );
        }
    }
    public function get_plan_d(){
        $data = array();

         $this->db->where('user_id', $this->session->userdata('id') );
         $query = $this->db->get("plan");
         if ($query->num_rows() > 0) {
             foreach ($query->result() as $row) {
                  $content = [
                         'title' => json_decode($row->answer),
                         'id' => $row->id
                         ];
                 array_push($data, $content);
                
             }
             echo json_encode($data);
         }

    }
     public function load_plan_d(){
        $data = array();

         $this->db->where('id', $this->input->post('id') );
         $query = $this->db->get("plan");
         if ($query->num_rows() > 0) {
             foreach ($query->result() as $row) {
                $data[] = json_decode($row->answer);
                
             }
             echo json_encode($data);
         }

    }
    public function delete_plan_d(){
        $this->db->where('id', $this->input->post('id') );
        $this->db->delete('plan');

         echo json_encode( array(
                'message' => 'Supprimé avec succès'
         ) );

    }
    /*public function max_rational(){
        $data_r = [];

        $query = $this->db->get_where('question_answers', array( 'user_id' => $this->session->userdata('id')  , 'question_id' => 102 ));


        if ($query->num_rows() > 0)
        {
            foreach ($query->result() as $row)
            {
                foreach ( json_decode($row->answer_caption,true) as $key => $value) {
                    if (strpos($value['answer_caption'], 'r_piste_') > -1){
                        $data = [
                            'rate' => substr( $value['answer_caption'] , 8 , strpos( $value['answer_caption'], "-") - 8 ),
                            'highest' => str_replace('-', '',  substr( $value['answer_caption'] ,  strpos( $value['answer_caption'], "-") ) ) != null ? str_replace('-', '',  substr( $value['answer_caption'] ,  strpos( $value['answer_caption'], "-") ) ) : ''
                        ];
                        array_push($data_r, $data);
                    }

                }




            }
        }
        //echo json_encode( array('highest' => $highest , 'rate' => $rate ) );
        echo json_encode(  max($data_r) );

    }
    public function max_rational_highest(){
        $highest = [];
        $rate  = [];
        $data_r = [];

        $query = $this->db->get_where('question_answers', array( 'user_id' => $this->session->userdata('id')  , 'question_id' => 102 ));
        

        if ($query->num_rows() > 0) 
        {
            foreach ($query->result() as $row) 
            {
                foreach ( json_decode($row->answer_caption,true) as $key => $value) {
                    if (strpos($value['answer_caption'], 'r_piste_') > -1){
                              $data = [
                                        'rate' => substr( $value['answer_caption'] , 8 , strpos( $value['answer_caption'], "-") - 8 ),
                                        'highest' => str_replace('-', '',  substr( $value['answer_caption'] ,  strpos( $value['answer_caption'], "-") ) ) != null ? str_replace('-', '',  substr( $value['answer_caption'] ,  strpos( $value['answer_caption'], "-") ) ) : ''
                                    ];
                            array_push($data_r, $data);
                    }
                   
                }
            }
        }      
        return max($data_r) ;

    }*/
    public function max_rational_h($flag = null)
    {
        $highest = [];
        $rate  = 0;
        $highest_val  = 0;
        $final_piste = null;

        $query = $this->db->get_where('question_answers', array( 'user_id' => $this->session->userdata('id')  , 'question_id' => 102 ));

        if ($query->num_rows() > 0)
        {
            foreach ($query->result() as $row)
            {
                $arr = json_decode($row->answer_caption,true);
                $piste = [];
                $has_under = 0;
                foreach($arr as $key => $aR){
                    if(strpos($aR['answer_caption'],"_"))
                        $has_under++;
                    $piste[] = $aR['answer_caption'];
                }
                $pistes = array_splice($piste, 0,$has_under);
                $values = array_splice($piste, -$has_under,$has_under);
                $highest_val = array_keys($values, max($values))[0];
                $rate = $values[$highest_val];
                $highest = $pistes[$highest_val];
                $highest = substr( $highest , 0, strpos($highest, "_"));
                $highest_piste = $this->db->where('id',$highest)->where('user_id',$this->session->userdata('id'))->get('piste')->row();
                foreach(json_decode($highest_piste->answer) as $hp){
                    if($hp->answer_title === 'titrepiste')
                        $final_piste = $hp->answer_caption;
                }
            }
        }
        if($flag)
            return json_encode( array('key_id'=>$highest_val,'highest' => $final_piste , 'rate' => $rate ) );
        else
            echo json_encode( array('key_id'=>$highest_val,'highest' => $final_piste , 'rate' => $rate ) );
    }
    public function get_piste_higest(){
        
        $data = array();

         $this->db->where('user_id', $this->session->userdata('id') );
         $query = $this->db->get("piste");
         if ($query->num_rows() > 0) {
             foreach ($query->result() as $row) {
                foreach (json_decode($row->answer,true) as $key => $value) {
                   if( $value['answer_caption'] ==  json_decode($this->max_rational_h(true))->highest ){
                    $data[$row->id] = json_decode($row->answer);
                   }
                }
        
             }
             echo json_encode($data);
         }

    }
    public function get_piste_highest_info()
    {
        $max = json_decode($this->max_rational_h(true))->key_id;
        $piste = [];
        foreach(json_decode($this->get_piste(true)) as $aRow){
            $piste[] = $aRow;
        }
        $highest_piste = $piste[$max];
        $data = [];
        foreach($highest_piste->title as $aRow){
            $data[$aRow->answer_title] = $aRow->answer_caption;
        }
        echo json_encode($data);
    }
    public function delete_piste(){
       $this->db->where('id', $this->input->post('id') );
        $this->db->delete('piste');

         echo json_encode( array(
                'message' => 'Supprimé avec succès'
         ) );
    }
}
