<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Satisfaction_curve extends CI_Controller {

	function __construct() 
	{
        parent::__construct();
    }
	public function table()
	{
		$this->satisfaction_curves->tables();
	}
	public function add()
	{
		$this->satisfaction_curves->adds();
	}
	public function delete()
	{
		$this->satisfaction_curves->deletes();
	}
	public function update()
	{
		$this->satisfaction_curves->updates();
	}
	public function get_satisfaction()
	{
		$this->satisfaction_curves->get_satisfactions();
	}
	public function count_scurve()
	{
		$this->satisfaction_curves->count_scurves();
	}
	
	
}
