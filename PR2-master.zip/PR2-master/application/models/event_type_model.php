<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Event_type_model extends CI_Model {

    var $column_order = array('event_type_id','event_type'); //set column field database for datatable orderable
    var $column_search = array('event_type'); //set column field database for datatable searchable just firstname , lastname , address are searchable
    var $order = array('event_type_id' => 'desc'); // default order

    public function __construct() {
        parent::__construct();
    }

    private function _get_datatables_query($data_source){
        $this->db->select("event_type_id, event_type");
        $this->db->from("event_type");
        $this->db->where('status', 1);

        $i = 0;
        foreach ($this->column_search as $item) {// loop column
            if($data_source['search']['value']) {  // if datatable send POST for search
                if($i===0){ // first loop
                    $this->db->like($item, $data_source['search']['value']);
                } else {
                    $this->db->or_like($item, $data_source['search']['value']);
                }
            }
            $i++;
        }

        if(isset($data_source['order'])) { // here order processing
            if(isset($data_source['order']['0']['dir'])) {
                $this->db->order_by($this->column_order[$data_source['order']['0']['column']], $data_source['order']['0']['dir']);
            }
        } else if(isset($this->order)) {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    public function get_subscriber_information_list_export($data_source){
        $this->_get_datatables_query($data_source);
        $query = $this->db->get();
        return $query->result();
    }

    public function get_datatables($data_source){
        $this->_get_datatables_query($data_source);
        if($data_source['length'] != -1)
            $this->db->limit($data_source['length'], $data_source['start']);
        $query = $this->db->get();
        return $query->result();
    }

    public function count_filtered($data_source){
        $this->_get_datatables_query($data_source);
        $query = $this->db->get();
        return $query->num_rows();
    }

    public function count_all($data_source){
        $this->_get_datatables_query($data_source);
        return $this->db->count_all_results();
    }

    public function event_types()
    {
        $query = $this->db->distinct()
            ->select('et.event_type_id, et.event_type')
            ->from('event_type et')
            ->where('et.status', 1)
            ->order_by('et.event_type', 'ASC')
            ->get();

        return $query->result();
    }

	public function home()
	{
        $query = $this->db->distinct()
            ->select('et.event_type_id, et.event_type')
            ->from('event_type et')
            ->join('event e', 'et.event_type_id=e.event_type_id')
            ->where('et.status', 1)
            ->where('e.back_office_status !=', 0)
            ->where('e.back_office_status !=', 5)
            ->where('e.back_office_status !=', 6)
            ->order_by('et.event_type_id', 'ASC')
            ->get();

		return $query->result();
	}

	public function myaccount()
	{
		$query = $this->db->select('*')
						  ->from('event_type')
                          ->where("status", 1)
						  ->get();

		return $query->result();
	}

    public function list_event_types(){
        $this->db->select("*");
        $this->db->where("status", 1);
        return $this->db->get("event_type")->result();
    }

    public function add_event_type($event_type)
    {
        $this->db->insert("event_type", array("event_type" => $event_type, "status" => 1));
        return $this->db->insert_id();
    }

    public function edit_event_type($event_type_id, $event_type)
    {
        $this->db->where("event_type_id", $event_type_id);
        $update = $this->db->update("event_type", array("event_type" => $event_type));
        return $update;
    }

    public function delete_event_type($event_type)
    {
        $this->db->where("event_type_id", $event_type);
        $update = $this->db->update("event_type", array("status" => 0));
        return $update;
    }

    public function check_event_type($event_type, $event_type_id){
        $this->db->where("event_type", $event_type);
        $this->db->where("status", 1);
        if($event_type_id !=""){
            $this->db->where("event_type_id", $event_type);
        }
        return $this->db->get("event_type")->num_rows();
    }

}