<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Event_email_template_map_model extends CI_Model {

    var $column_order = array(null,'eett.email_type','eet.email_tpl_name','events_title', 'eetm.email_map_status', null); //set column field database for datatable orderable
    var $column_search = array('eett.email_type','eet.email_tpl_name','events_title'); //set column field database for datatable searchable just firstname , lastname , address are searchable
    var $order = array('eetm.email_tpl_id' => 'desc'); // default order

    public function __construct() {
        parent::__construct();
    }

    private function _get_datatables_query($data_source){
        $_query = ""; $_search = ""; $_ordey_by = ""; $data = array(); $select = "";
        $_query .= "SELECT eetm.email_mapping_id, eetm.email_tpl_id, eet.email_tpl_name, eett.email_type,eett.email_type_id,
           
            (CASE
              WHEN eetm.email_mapping_status = 1 THEN 'Publié'
              WHEN eetm.email_mapping_status = 0 THEN 'Deleted'
              ELSE 'Email n\'est pas encore créé'
            END) AS email_map_status,
            
            (SELECT 
                GROUP_CONCAT(e.title ORDER BY eetm.email_mapping_id ASC SEPARATOR ', ') 
                AS events_title
                FROM event e
                WHERE eetm.event_id = e.event_id  
                AND eetm.email_mapping_status = 1) AS events_title,
             
             (SELECT 
                GROUP_CONCAT(e.event_id ORDER BY eetm.email_mapping_id ASC SEPARATOR ', ') AS events_ids
                FROM event e
                WHERE eetm.event_id = e.event_id 
                AND eetm.email_mapping_id = eetm.email_mapping_id 
                AND eetm.email_mapping_status = 1) AS events_ids

             FROM event_email_template_mapping eetm
            LEFT JOIN event_email_template eet ON eet.email_tpl_id = eetm.email_tpl_id
            LEFT JOIN event_email_template_type eett ON eett.email_type_id = eet.email_type_id
            WHERE eetm.email_mapping_status =1 ";
        $i = 0;

        if($data_source['search']['value']) {
            $i = 0;
            foreach ($this->column_search as $item) {// loop column
                if($i===0){ // first loop
                    array_push($data, "%".$data_source['search']['value']."%");
                    $_search .= " AND ( ".$item." LIKE ? ";
                } else {
                    array_push($data, "%".$data_source['search']['value']."%");
                    $_search .= " OR ".$item." LIKE ? ";
                }
                $i++;
            }
            $_search .= ")";
        }

        if(isset($data_source['order'])) { // here order processing
            if(isset($data_source['order']['0']['dir']) && !empty($data_source['order']['0']['dir'])) {
                $_ordey_by .= " ORDER BY ".$this->column_order[$data_source['order']['0']['column']]." ".$data_source['order']['0']['dir'];
            } else {
                $_ordey_by .= " ORDER BY ".key($this->order)." ".$this->order[key($this->order)];
            }
        } else if(isset($this->order)) {
            $_ordey_by .= " ORDER BY ".key($this->order)." ".$this->order[key($this->order)];
        }

        // $_query .= " GROUP BY eetm.email_tpl_id";



        return array("query"=>$_query.$_search.$_ordey_by, "data" =>$data);
    }

    public function get_datatables($data_source){
        $_query = $this->_get_datatables_query($data_source);

        if($data_source['length'] != -1){
            $_query["query"] .= " LIMIT ".$data_source['start'].", ".$data_source['length'];
        }
        $data = $this->db->query($_query["query"], $_query["data"]);
        return $data->result();
    }

    public function count_filtered($data_source){
        $_query = $this->_get_datatables_query($data_source);
        return $this->db->query($_query["query"], $_query["data"])->num_rows();
    }

    public function count_all($data_source){
        $_query = $this->_get_datatables_query($data_source);
        return $this->db->query($_query["query"], $_query["data"])->num_rows();
    }

    public function add_email_template_map($data){
        $this->db->insert("event_email_template_map", $data);
        if($this->db->affected_rows()){
            return $this->db->insert_id();
        }
        return false;
    }

    public function assign_email_template($data){

        //check whether the event already has the template of the same email type.
        $this->check_event_email_template_assignment($data);

        $this->db->insert("event_email_template_mapping", $data);
        if($this->db->affected_rows()){
            return $this->db->insert_id();
        }
        return false;
    }

    public function update_assign_email_template($email_mapping_id, $data){
        //update change in template used
        $this->db->where("email_mapping_id", $data["email_mapping_id"]);
        $this->db->update("event_email_template_map", array("email_tpl_id" => $data["email_tpl_id"]));

        //change the map id in schedule table
        //$this->db->where("email_map_id", $data["email_map_id"]);
        //$this->db->where("email_type_id", $data["email_type_id"]);
        //$this->db->where("event_id !=", $data["event_id"]);
        //$this->db->update("event_email_schedule", array("email_map_id" => null));

        //update change in event assignment
        $this->db->where("email_mapping_id", $data["email_mapping_id"]);
        $check_update = $this->db->update("event_email_template_mapping", 
            array("event_id" => $data["event_id"]));
        if($check_update){
            return true;
        }
        return false;
    }

    public function delete_assign_email_template($email_mapping_id){
        // $this->db->where("email_map_id", $email_mapping_id);
        // $this->db->update("event_email_template_map", array("email_map_status" => 0));

        $this->db->where("email_mapping_id", $email_mapping_id);
        $this->db->update("event_email_template_mapping", array("email_mapping_status" => 0));
        if($this->db->affected_rows()){
            return true;
        }
        return false;
    }

    public function check_event_email_template_assignment($post){
        /**
            This function checks and updates the email template of an event.
            If there is already assigned template, then unset the old one and add the new one.
        */
        $where = "";
        if(isset($post["email_mapping_id"]) && !empty($post["email_mapping_id"])){
            $where = " AND a.email_mapping_id != ".$post["email_mapping_id"];
        }
        
        $this->db->query("
            UPDATE event_email_template_mapping a
            LEFT JOIN event_email_template b ON
                a.email_tpl_id = b.email_tpl_id
            SET a.email_mapping_status = 0
            WHERE a.event_id = ".$post['event_id']."
                AND b.email_type_id = ".$post["email_type_id"]."
                AND a.email_mapping_status = 1".$where);
    }
}