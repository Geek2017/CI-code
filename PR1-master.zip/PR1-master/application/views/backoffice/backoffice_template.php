<?php
defined('BASEPATH') OR exit('No direct script access allowed');
//$this->session_checker->is_authorize( $this->session->userdata('role') );
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Accueil</title>

    <!-- Bootstrap Core CSS -->
    <link href="<?php echo base_url();?>assets/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="<?php echo base_url();?>assets/css/akeen-slider.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/css/custom.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/css/flip.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/css/dashboard/index.css" rel="stylesheet">
    <!-- Toast message -->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/plugins/toast/style/showToast.css" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->


    <!-- jQuery -->
    <script src="<?php echo base_url();?>assets/js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/jquery.maskedinput.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/jquery.flip.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets/plugins/toast/script/showToast.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/head.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/bootbox.min.js"></script>
    <!-- Script to Activate the Carousel -->
    <script>
        $('.carousel').carousel({
            interval: 3000 //changes the speed
        })
        $(function(){
            $(".flip").flip({
                trigger: 'hover'
            });
        });
    </script>

    <script>
        var url = "<?php echo base_url(); ?>";
    </script>

    <script type="text/javascript">
        $(document).ready(function()
        {
            head.ready(function()
            {
                head.js(
                    [
                        url+'assets/js/validator/reload.js',
                        url+'assets/js/validator/profile.js',
                        url+'assets/js/validator/login.js'
                    ],
                    function ()
                    {
                        //console.log("loaded validators");
                    }
                );
            });
        });
        var lastname = '<?php echo $this->session->userdata("lastname") ?>';
        if(lastname == ""){
            $("#pre-reg-btn").click();
        }
    </script>
    <!-- Custom JS -->
</head>

<body>
<input type="hidden" id="baseURL" name="baseURL" value="<?php echo base_url(); ?>">
<?php $this->load->view($nav_menu); ?>
<div class="dashboard-container">
    <div class="row">
        <?php $this->load->view($content); ?>
    </div>
</div>



</body>

</html>