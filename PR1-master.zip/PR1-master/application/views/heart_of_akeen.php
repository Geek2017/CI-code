<!-- Page Content -->
<div class="container static">
    <div class="row">
        <div class="col-lg-10 col-lg-offset-1">
        <?php 
            if(isset($user_role)) {
            	if($this->session->userdata("lastname") != null){?>
                    <a class="align-left" href="<?php echo site_url('main/progress'); ?>"><img src="<?php echo base_url('assets/img/return.png'); ?>"/> Retour</a>
                        <?php } ?>
                             <?php
                        }else{
                            ?>
                          <a class="align-left" href="<?php echo site_url('main/'); ?>"><img src="<?php echo base_url('assets/img/return.png'); ?>"/> Retour</a>
                             <?php
                        }
                        ?>  
            <h1 class="text-center">Le c&#339;ur d&#8217;AkeeN</h1>
        	<p>AkeeN est une start-up o&#249; le web se met au service de la mobilit&#233; interne professionnelle de tous les collaborateurs, au moindre co&#251;t.</p><br>
            <p>AkeeN les accompagne au travers d&#8217;un parcours, adoss&#233; &#224; une plateforme web, complet et structur&#233; en dix &#233;tapes aboutissant &#224; un projet professionnel, s&#8217;appuyant &#224; chaque &#233;tape sur des exercices pratiques.</p><br>
            <p>L&#8217;objectif est de favoriser l&#8217;engagement des salari&#233;s en conciliant les &#233;volutions et les besoins de l&#8217;entreprise avec les comp&#233;tences et les aspirations individuelles 
            de chacun.</p>
        </div>        
    </div>
</div>