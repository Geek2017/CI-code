<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class User_login_history_model extends CI_Model {

	public function __construct() {
		parent::__construct();
	}

	public function client_checkdb($data, $description)
	{
        $status = array('status' => 0);
        $this->db->where('user_id', $data['user_id']);
        $this->db->where('status', 1);
        //check if login_id exists
        if(isset($data["login_id"]) && !empty($data["login_id"])) {
            $this->db->where('history_id', $data["login_id"]);
        }
        $this->db->update('user_login_history', $status);

		// Insert new entry in log
		$entry = array (
			'user_id' => $data['user_id'],
			'description' => $description,
			'session_id' => $data['session_id'],
			'user_agent' => $data['agent'],
			'ip_address' => $data['ip_address'],
			'status' => 1
		);
        //INSERT the login_id when the user revokes his login session
        if($description === "LOGOUT") {
            if(isset($data["login_id"]) && !empty($data["login_id"])) {
                $entry["login_id"] = $data["login_id"];
            }
        }
		$this->db->insert('user_login_history', $entry);
        return $this->db->insert_id();
	}

	public function client_set_preference($id)
	{
		$query = $this->db->query("SELECT user_id FROM user_login_history WHERE user_id = ? ORDER BY user_id asc limit 2", array($id));

		if($query->num_rows() == 1){
			return true;
		}
		else
		{
			return false;
		}
	}

	//check subscriber login status
	public function subscriber_login_status($subscriberID){
		$query = $this->db->query("select * from user_login_history where status='1' and user_id='$subscriberID' and description='LOGIN'");
		if($query->num_rows() == 1){
			return true;
		}
		else
		{
			return false;
		}
	}
}