<div id="main">
    <div class="">
        <div id="tbl"><button type="button" class="btn btn-primary glyphicon glyphicon-plus" data-toggle="modal" onclick="Guests.add_btn()" ><span class="btn_desc"> Ajouter un utilisateur</span></button></div>
           <br><br>
             <table id="guests" class="table-responsive table table-striped table-bordered dt-responsive nowrap dataTable" cellspacing="0" width="100%">
                <thead>
                    <tr>
                        <th>E-mail professionnel</th>
                        <th>Nom</th>
                        <th>Prénom</th>
                        <th>Société</th>
                        <th>Date de création</th>
                        <th>Date de début</th>
                        <th>Progression</th>
                        <th>Total du temps pour finir le parcours </th>
                        <th>Statut </th>
                        <th>Actions </th>
                    </tr>
                </thead>
            </table>
    </div>
</div>
<style>
    td{
        word-break: break-all;
    }
</style>

<!-- Modal -->
<div class="modal fade" id="add_guest_modal" tabindex="-1" role="dialog"
     aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <!-- Modal Header -->
            <div class="modal-header" style="background-color:#337AB7; color:#FFFFFF;">
                <button type="button" class="close"
                        data-dismiss="modal">
                    <span aria-hidden="true">&times;</span>
                    <span class="sr-only">Annuler</span>
                </button>
                <h4 class="modal-title" id="myModalLabel">
                    Formulaire d'utilisateur
                </h4>
            </div>
            <!-- End Modal Header -->

            <!-- Modal Body -->
            <div class="modal-body">
                <form class="form-horizontal" role="form" id="add_guest_form">
                    <div class="form-group">
                        <label class="col-sm-3 control-label" for="username" >*  Adresse e-mail</label>
                        <div class="col-sm-8">
                            <input  type="text" class="form-control" id="email" name="email"  placeholder=""/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label" for="name" >Nom</label>
                        <div class="col-sm-8">
                            <input  type="text" class="form-control" id="firstname" name="firstname"  placeholder=""/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label" for="name" >Prénom</label>
                        <div class="col-sm-8">
                            <input  type="text" class="form-control" id="lastname" name="lastname"  placeholder=""/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label" for="name" >Société</label>
                        <div class="col-sm-8">
                            <input  type="text" class="form-control" id="company" name="company"  placeholder=""/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label" for="name" >Métier ou Poste actuel</label>
                        <div class="col-sm-8">
                            <input  type="text" class="form-control" id="position" name="position"  placeholder=""/>
                        </div>
                    </div>
                </form>
            </div>
            <!-- End Modal Body -->

            <!-- Modal Footer -->
            <div class="modal-footer">
                <center>
                    <button type="button" class="btn btn-primary" id="guest_form_btn" onclick="Guests.add_user();">
                       Enregistrer les modifications
                    </button>
                    <button type="button" class="btn btn-default" data-dismiss="modal">
                        Annuler
                    </button>
                </center>
            </div>
            <!-- End Modal Footer -->

        </div>
    </div>
</div>


<div class="modal fade" id="pre-reg">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header header-form">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h2 class="text-center modal-title">Previsualizer</h2>
            </div>
        
            <div class="modal-body">
                <div class="container wc-form">
    
                    <form id="profile" role="form">
                    <div class="col-md-6">
                        <div class="form-group-sm">
                            <label>Nom</label>
                            <input type="text" class="form-control nxt" id="lastname" placeholder="Nom" >
                        </div>
                        <div class="form-group-sm">
                            <label>Prénom</label>
                            <input type="text" class="form-control nxt" id="firstname" placeholder="Prénom" >
                        </div>
                        <div class="form-group-sm">
                            <label>Date de naissance</label>
                            <input type="text" class="form-control nxt" id="bday" placeholder="Date de naissance">
                        </div>
                        <div class="form-group-sm">
                            <label>Téléphone Portable</label>
                            <input type="text" class="form-control nxt" id="contact" placeholder="Téléphone Portable">
                        </div>
                        <div class="form-group-sm">
                            <label>Adresse Mail</label>
                            <input type="text" class="form-control nxt" id="username" placeholder="Adresse Mail">
                        </div>          
                        <div class="form-group-sm">
                            <label>Adresse</label>
                            <input type="text" class="form-control nxt" id="address" placeholder="Adresse">
                        </div>
                        
                    </div>
                    <div class="col-md-6">
                        <div class="form-group-sm">
                            <label>Code postal</label>
                            <input type="text" class="form-control nxt" id="zip" onkeypress="return app.numbers(event);"  placeholder="Code postal">
                        </div>
                        <div class="form-group-sm">
                            <label>Ville</label>
                            <input type="text" class="form-control nxt" id="city" placeholder="Ville">
                        </div>
                        <div class="form-group-sm">
                            <label>Pays</label>
                            <input type="text" class="form-control nxt" id="country" placeholder="Pays">
                        </div>
                        <div class="form-group-sm">
                            <label>Métier ou Poste actuel </label>
                            <input type="text" class="form-control nxt" id="position" placeholder="Métier ou Poste actuel ">
                        </div>
                        <div class="form-group-sm">
                            <label>Nombre d’années dans ce dernier poste</label>
                            <input type="text" class="form-control nxt" id="number_year" placeholder="Nombre d’années dans ce dernier poste">
                        </div>
                        <div class="form-group-sm">
                            <label>Date de démarrage de la mobilité AkeeN</label>
                            <input type="text" class="form-control" id="started_date" disabled=disabled  placeholder="Date de démarrage de la mobilité AkeeN">
                        </div>
                    </div>
                    <!-- <div class="col-md-6 col-md-offset-3">
                        <br>
                        <button class="btn btn-primary"  data-dismiss="modal" aria-label="Close" >Annuler</button>
                    </div> -->
                    </form>
                </div>
                
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->