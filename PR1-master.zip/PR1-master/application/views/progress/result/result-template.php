<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

    <!-- Bootstrap Core CSS -->
    <link href="<?php echo base_url();?>assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/css/jquery-ui.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="<?php echo base_url();?>assets/css/akeen-slider.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/css/section_profile.css" rel="stylesheet">
<!--    <link href="--><?php //echo base_url();?><!--assets/css/section.css" rel="stylesheet">-->
    <link href="<?php echo base_url();?>assets/css/custom.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/css/flip.css" rel="stylesheet"

    <!-- Toast message -->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/plugins/toast/style/showToast.css" />
    <style type="text/css">
    @media print {
    body {-webkit-print-color-adjust: exact;}
    }
    </style>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <!-- jQuery -->
    <script src="<?php echo base_url();?>assets/js/jquery.js"></script>
    <script type="text/javascript">
        var url = "<?php echo base_url(); ?>";
    </script>
    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/jquery.maskedinput.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/jquery.flip.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets/plugins/toast/script/showToast.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/head.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/bootbox.min.js"></script>

    <script src="<?php echo base_url(); ?>assets/js/jquery-ui.min.js"></script>
</head>

<body>

<input type="hidden" id="baseURL" name="baseURL" value="<?php echo base_url(); ?>">
<div class="sec-content" id="sec-content">
    <?php $this->load->view($content); ?>
</div>


</body>

<script src="<?php echo base_url();?>assets/js/dashboard/index.js"></script>
<script src="<?php echo base_url(); ?>assets/js/chart2.js"></script>
<script src="<?php echo base_url();?>assets/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url();?>assets/js/dataTables.bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/validator/app.js"></script>
<script src="<?php echo base_url(); ?>assets/js/profesional_job.js"></script>
<!-- Script to Activate the Carousel -->
<script>

    $('button, .btn').remove();
    $('.carousel').carousel({
        interval: 3000 //changes the speed
    })
    $(function(){
        $(".flip").flip({
            trigger: 'hover'
        });
    });
    $("#menu-toggle").click(function(e) {

        $("body").toggleClass("toggled");
    });
    $("#menu-close").click(function(e) {

        $("body").removeClass("toggled");
    });
    $("#menu-close-l").click(function(e) {

        $("body").removeClass("toggled");
    });

    $(document).ready(function()
    {
        head.ready(function()
        {
            head.js(
                [
                    url+'assets/js/akeen_js.js'
                ]
            );
        });
    });

    var lastname = '<?php echo $this->session->userdata("lastname") ?>';
    if(lastname == ""){
        $("#pre-reg-btn").click();
    }

    var a = 0;
    var printer = $('#printer');

    $(window).load(function () {
        function h(e) {
            $(e).removeAttr('rows').css({'height':'0','overflow-y':'hidden'}).height(e.scrollHeight);
        }
        $('textarea').each(function () {
            h(this);
        }).on('input', function () {
            h(this);
        });
        
        if( app.searchstr(window.location.href, 'm_result')  ){
            $.each($('.sectionID'),function(index, val){
                getAnswer('result', $(this).val());
            });
            
            printer.append('<button id="print_btn_now" disabled=disabled class="btn btn-primary glyphicon glyphicon-print" onclick="window.print();">Chargement...</button>');
        }
    });

    if( app.getUrlParameter("print") || app.searchstr(window.location.href, 'm_result') ){
            document.write('<div id="loader" style="display:table; position: absolute; top: 0; left: 0; width: 100%; height: 100%; z-index: 10000; background-color: rgba(0, 0, 0, 0.42);">'
        + '<div style="display:table-cell; vertical-align:middle; text-align: center;">'
        + '<br /><img src="'+ url +'assets/img/loading.gif" />'
        + '</div></div>');
    }

    $(document).ready(function () {
            $("#print_btn_now").click(function () {
                    window.print();
            });
           //traits.init_choix_graph();
    });

    $(document).on("ajaxComplete", function(e, xhr, settings){
         if( settings.url == url + "index.php/language/get_highest_point?type=0" ){
             traits.init_choix_graph();
             $('#choix_title').remove();
         }
      setInterval(function(){
            if( app.getUrlParameter("print") || app.searchstr(window.location.href, 'm_result') ){
                 $("#print_btn_now").attr("disabled", false).text("Print");         
                 $('#loader').fadeOut(500);
             }
           if(app.getUrlParameter("print"))
                 window.print();
      },9000); 

    });

</script>

<script src="<?php echo base_url(); ?>assets/js/chart_s2.js"></script>
<script src="<?php echo base_url();?>assets/js/global.js"></script>




