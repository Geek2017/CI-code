<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Authentication extends CI_Controller {

	function __construct() 
	{
        parent::__construct();
    }
	public function check_email()
	{
		if($email = $this->input->post('username')){
			if( $this->profiles->email_required($email) )
			{
				echo json_encode(array(
					'mcontent' 	=> 'error',
					'message' 	=> "Format d'email invalide",
				));
			}else if($user = $this->users->get_user_info(['username'=>$email])->row()){
				$user_data = $this->users->get_user_info_data(['username'=>$email])->row();
				if($user->password && $user->active == 1 && $user_data) {
					echo json_encode(array(
						'mcontent' => 'success',
						'message' => "",
						'fullname' => $this->users->get_full_name($user->id)
					));
				}else if($this->authentications->check_date_interval($user->date_created) && $user->active == 0) {
					$this->logs->insert_logs(date('Y-m-d H:i:s'),$user->id,$this->input->ip_address(),'Login failed - Account deactivated');
					echo json_encode(array(
						'mcontent' => 'error',
						'message' => "Le compte est incatif",
					));
				}else{
					$this->logs->insert_logs(date('Y-m-d H:i:s'),$user->id ,$this->input->ip_address(),'Logged In - First log in');
					$this->session->set_userdata(array(
						'id' => $user->id,
						'username' => $user->username,
						'password' => $user->password,
						'token_id' => $user->token_id,
						'org' => $user->ord_id,
						'role' => $user->role_id,
						'visited' => $user->visited,
						'time_session' => date('Y-m-d H:i:s')
					));
					echo json_encode(array(
						'mcontent' => 'redirect',
						'message' => 'Vous avez été connecté avec succès',
					));
				}
			}else{
				echo json_encode(array(
					'mcontent' 	=> 'error',
					'message' 	=> "Désolé, Akeen ne reconnaît pas cet e-mail",
				));
			}
		}
	}
	public function login()
	{
		$this->remember_me();
		$this->authentications->check_login();
	}
	public function remember_me()
	{
		if($this->input->post("remember") == "true"){
			
			$username= array(
				'name'   => 'username',
				'value'  => $this->input->post("username"),
				'expire' => '86500',
			);

			$password= array(
				'name'   => 'password',
				'value'  => $this->input->post("password"),
				'expire' => '86500',
			);
			$remember= array(
				'name'   => 'remember',
				'value'  => $this->input->post("remember"),
				'expire' => '86500',
			);
	  	
	  		$this->input->set_cookie($username);
	  		$this->input->set_cookie($password);
	  		$this->input->set_cookie($remember);

		}else{
            delete_cookie('username');
            delete_cookie('password');
            delete_cookie('remember');
		}

	}
	public function logout()
	{
		$this->session->sess_destroy();

		switch ( $this->session->userdata('role')  ) {
			case '1':
			case '2':
				redirect('admin');
				break;
			
			default:
				redirect('/', 'refresh');
				break;
		}
	}
	public function forgot_password()
	{
		echo $this->authentications->forgot_password();
	}
	public function submit_forgot()
	{
		 $this->authentications->submit_forgot();
	}
}
