<style type="text/css">
 .btn {
    display: inline-block;
    padding: 6px 12px;
    margin-bottom: 0;
    font-size: 14px;
    font-weight: normal;
    line-height: 1.42857143;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    background-image: none;
    border: 1px solid transparent;
    border-radius: 4px;
}
 .btn-success {
    color: #fff;
    background-color: #5cb85c;
    border-color: #4cae4c;
}
 .fileinput-button {
    position: relative;
    overflow: hidden;
}

 .fileinput-button input {
    position: absolute;
    top: 0;
    right: 0;
    margin: 0;
    opacity: 0;
    -ms-filter:'alpha(opacity=0)';
    font-size: 200px;
    direction: ltr;
    cursor: pointer;
}
</style>
<script>
$( document ).ready(function() {
    $("#userfile").on("change", function(){
        $("#file_name").html( $('#userfile')[0].files[0].name  );
    });
});   
</script>

<div class="container welcome">


    <h1 class="text-center">Télécharger votre CV en PDF</h1>
    <center>
    <form method='post' enctype='multipart/form-data' accept-charset='utf-8' name='formname' id='formname'  method='post' action='<?php echo base_url()."index.php/upload/do_upload";?>' enctype='multipart/form-data'>

    <span class="btn btn-success fileinput-button">
     <span id="browse_file">Insérer votre CV</span>
            <input type='file' class="btn btn-primary" name='userfile' id='userfile' size='20' />
     </span>
     <br />
     <br />
     <span id="file_name"></span>

    <br />
    <br />
    <input type='submit' class="btn btn-primary"  id='upload' onclick="Upload.upload_new(event);" value='Télécharger' />
     <a href="<?php echo base_url('index.php/main/my_profile'); ?>" class="btn btn-primary">Suivant</a>
    <input type='hidden' class="btn btn-primary" id='pdf' value="<?php echo $filename ; ?>"/>
    </form>
     <br />
    <embed width="1000" id="pdf_view" height="450" src="<?php echo $filename !='' ? $filename : ''  ; ?>" type="application/pdf"></embed>
    </center>

</div>