<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	class Upload extends MY_Controller
	{
		public function __construct()
		{
    		//parent::__construct();
            $this->my_controller_parent_construct();
            $this->load_language_backoffice();
            $this->show_page_404(array(1,2), "backoffice");
            $this->clear_cache();
            $this->is_logged_in();
		}

        private function makedir($dirpath, $mode=0777)
        {
            if(file_exists('./uploads/campaign')) {
                if (is_writable(dirname('./uploads/campaign'))) {
                    return is_dir($dirpath) || mkdir($dirpath, $mode, true);
                }
                else{
                    return false;
                }
            }else{
                return false;
            }
        }

        private function unlink_file($full_path)
        {
            unlink($full_path);
        }
		
		// public function import_file()
		// {
			// require_once('xlsx_reader.php');
			// $config['upload_path'] = 'uploads/customer/';
			// $config['file_name'] = 'sample2.xlsx';
			
			// $data_sheet = array();
			// if(!is_readable($updaload_data["full_path"])) 
			// {
				// echo "note read";
			// } 
			// else 
			// {
				// $xlsx = new Xlsx_reader($updaload_data["full_path"]);
				// $sheetNames = $xlsx->getSheetNames();
					
				// foreach($sheetNames as $sheetName) 
				// {
					// $sheet = $xlsx->getSheet($sheetName);
					// $data_sheet = $sheet->getData();
					// break;
				// }				
			// }
			
			// print_r($data_sheet);
		// }
		
		
		public function save()
		{
			$type = $this->input->get('type');
			$id = $this->input->get('id');
			$document_name = $this->input->get('documentname');
			$version_in_use = $this->input->get('version');
			$document_type = $this->input->get('documenttype');
			$notes = $this->input->get('notes');
			
			$files = $_FILES['uploadeddocs'];						
			
			$result = "";
			if($files['name'])
			{
				if(!$files['error'])
				{
					$ext = pathinfo($files['name'], PATHINFO_EXTENSION);
					$file_name = generate_random_keys(15) . "." . $ext;
					move_uploaded_file($files['tmp_name'], "./assets/images/uploads/customer/" . $file_name);
					
					switch($type)
					{
						case 'customer':
							$this->load->model('customer_documents_model');
							$customer_documents_data = array(
								'customer_id' => $id,
								'document_name' => $document_name,
								'notes' => $notes,
								'file_name' => $file_name,
								'document_type' => $document_type,
								'version_in_use' => $version_in_use,
								'updated_by' => 1
							);
							
							$this->customer_documents_model->add_customer_documents($customer_documents_data);
							break;
					}
					
					$result = $id;
				}
				else
				{
					$result = "Error encountered on your upload";
				}
			}
			else
			{
				$result = "Failed to upload file";
			}
			
			output_to_json($this, $result);
		}
		
		public function saveCampaignDocs()
        {
            $type = $this->input->get('type');
            $id = $this->input->get('id');
            $document_name = $this->input->get('docname');
            $notes = $this->input->get('notes');
            $path_des = './uploads/campaign';
            $files = $_FILES['userfile'];
            $result = array();
            ini_set('upload_max_filesize', '10M');
            ini_set( 'post_max_size', '10M');


            $this->load->model('campaign_documents_model');

            if (isset($files['name']) && !empty($files['name'])) {

                if ($_FILES['userfile']["size"] <= 10000000)
                {
                if ($this->makedir($path_des)) {
                    if ($files['name']) {
                        if (!$files['error']) {
                            //check docname
                            $docid = (isset($_GET['docid']) && !empty($_GET['docid'])) ? $_GET['docid'] : "";
                            $check_doc_name = $this->campaign_documents_model->check_document_name($id, $document_name, $docid);

                            if ($check_doc_name <= 0) {
                                $ext = pathinfo($files['name'], PATHINFO_EXTENSION);
                                $file_name = generate_random_keys(15) . "." . $ext;
                                if(file_exists($path_des))
                                {
                                    if (is_writable(dirname($path_des)))
                                    {
                                        if (is_writable($path_des)) {
                                            move_uploaded_file($files['tmp_name'], $path_des . "/" . $file_name);
                                        }else{
                                            array_push($result, array(
                                                "mtype" => false,
                                                "mcontent" => "Unable to upload file. Permission denied."
                                            ));

                                            echo json_encode($result);
                                            exit;
                                        }
                                    }else{
                                        array_push($result, array(
                                            "mtype" => false,
                                            "mcontent" => "Unable to upload file. Permission denied."
                                        ));

                                        echo json_encode($result);
                                        exit;
                                    }
                                }else{
                                    array_push($result, array(
                                        "mtype" => false,
                                        "mcontent" => "Unable to upload file. Permission denied."
                                    ));
                                    exit;
                                }

                                switch ($type) {
                                    case 'campaign':
                                        $campaign_documents_data = array(
                                            'campaign_id' => $id,
                                            'document_name' => $document_name,
                                            'notes' => $notes,
                                            'file_name' => $file_name,
                                            'updated_by' => $this->data["login_user_data"]["id"]
                                        );
                                        $msg = "";

                                        if (isset($_GET['docid']) && !empty($_GET['docid'])) {
                                            $campaign_documents_data['id'] = $_GET['docid'];
                                            $check = $this->campaign_documents_model->edit_campaign_docs($campaign_documents_data, true);
                                            $msg = "Campaign document has been updated!";
                                        } else {
                                            $check = $this->campaign_documents_model->add_campaign_documents($campaign_documents_data);
                                            $msg = "New campaign document has been added!";
                                        }

                                        if ($check) {
                                            array_push($result, array(
                                                "mtype" => true,
                                                "mcontent" => $msg
                                            ));
                                        } else {
                                            array_push($result, array(
                                                "mtype" => false,
                                                "mcontent" => "Failed to upload file!"
                                            ));
                                        }

                                        break;
                                }
                            } else {
                                array_push($result, array(
                                    "mtype" => false,
                                    "mcontent" => "Document name already exists!"
                                ));
                            }
                        } else {
                            array_push($result, array(
                                "mtype" => false,
                                "mcontent" => "Error encountered on your upload."
                            ));
                        }
                    } else {
                        array_push($result, array(
                            "mtype" => false,
                            "mcontent" => "Failed to upload file."
                        ));
                    }
                } else {
                    array_push($result, array(
                        "mtype" => false,
                        "mcontent" => "Destination file can't be found or user have no access permission."
                    ));
                }
            }else{
                    array_push($result, array(
                        "mtype" => false,
                        "mcontent" => "File size must not exceed to 10MB!"
                    ));
                }
            } else{

                if (isset($_GET['docid']) && !empty($_GET['docid'])) {
                    $campaign_documents_data = array(
                        'id'    => $_GET['docid'],
                        'campaign_id' => $id,
                        'document_name' => $document_name,
                        'notes' => $notes,
                        'updated_by' => $this->data["login_user_data"]["id"]
                    );

                    $check = $this->campaign_documents_model->edit_campaign_docs($campaign_documents_data, false);
                    if ($check) {
                        array_push($result, array(
                            "mtype" => true,
                            "mcontent" => "Campaign document has been updated!"
                        ));
                    } else {
                        array_push($result, array(
                            "mtype" => false,
                            "mcontent" => "Failed to upload file!"
                        ));
                    }
                }
            }

            echo json_encode($result);
        }


		function randomPrefix($length) 
		{
			$random= "";
			srand((double)microtime()*1000000);

			$data = "AbcDE123IJKLMN67QRSTUVWXYZ"; 
			$data .= "aBCdefghijklmn123opq45rs67tuv89wxyz"; 
			$data .= "0FGH45OP89";

			for($i = 0; $i < $length; $i++) 
			{ 
			$random .= substr($data, (rand()%(strlen($data))), 1); 
			}

			return $random; 
		}
	}
?>