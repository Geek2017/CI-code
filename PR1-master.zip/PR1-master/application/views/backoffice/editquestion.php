<br/>
<br/>
<br/>
<br/>
<?php $data = (json_decode($data));
      $cont = $data->content[0];
?>
<div class="container">
<form method="post" id="editQuestion">
    <?php echo form_dropdown('section', $options, $cont->q_section); ?>
    <input type="hidden" name="question_id" value="<?php echo $cont->q_id; ?>">
    Question ID : <?php echo $cont->q_id; ?>
    <textarea id="question" name="question">
        <?php echo htmlspecialchars($cont->q_content); ?>
    </textarea>
    <input type="button" name="Submit" id="submitQ" value="Submit">
</form>
<div class="pagination">
    <?php
    foreach ($data->pagination as $page):
        echo $page;
    endforeach;
    if ($data->last_page == true)
        echo '<button type="Submit" class="btn btn-primary proceed">Procéder</button>';

    ?></div>

</div>
<script src="<?php echo base_url(); ?>assets/ckeditor/ckeditor.js"></script>
<script>
    CKEDITOR.replace( 'question' );
</script>

<script>
    $(document).ready(function() {
        var BASE_URL = $('#baseURL').val();

        //for (instance in CKEDITOR.instances) {
           // CKEDITOR.instances[instance].updateElement();
            //CKEDITOR.instances[instance].setData($('#content').val());
        //}

        $('#submitQ').on('click', function(e){
            e.preventDefault();

            $.ajax({
                url: BASE_URL + "index.php/postquestion",
                type: 'post',
                data: $('#editQuestion').serialize(),
                success: function (data) {
                    if(data=='true'){
                        alert("Success");
                        CKupdate();
                    }
                }
            });
        });
        function CKupdate(){
            for ( instance in CKEDITOR.instances ){
                CKEDITOR.instances[instance].updateElement();
            }
        }
    });
</script>