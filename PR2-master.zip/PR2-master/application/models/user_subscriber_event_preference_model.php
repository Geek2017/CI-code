<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class User_subscriber_event_preference_model extends CI_Model {

	public function __construct() {
		parent::__construct();
	}

	public function setPreferences($subscriber_id, $preferences)
	{
		$this->db->where('subscriber_id', $subscriber_id)
				 ->delete('user_subscriber_event_preference');

		foreach($preferences as $preference){
			$entry = array (
				'subscriber_id' => $subscriber_id,
				'event_preference' => $preference
			);
			$this->db->insert('user_subscriber_event_preference', $entry);
		}
	}

	public function myaccount($user_id)
	{
		$row = $this->db->select('subscriber_id')
					    ->from('user_subscriber')
					    ->where('subscriber', $user_id)
					    ->get()
					    ->row();

		$query = $this->db->select('user_subscriber_event_preference.subscriber_id, user_subscriber_event_preference.event_preference_id, event_type.event_type')
						  ->from('user_subscriber_event_preference')
						  ->join('event_type', 'user_subscriber_event_preference.event_preference = event_type.event_type_id')
						  ->where('subscriber_id', $row->subscriber_id)
						  ->get();

		return $query->result();
	}

	public function update_preferences($user_id, $login_id, $preferences)
	{
		$row = $this->db->select('subscriber_id')
					    ->from('user_subscriber')
					    ->where('subscriber', $user_id)
					    ->get()
					    ->row();

		$this->db->where('subscriber_id', $row->subscriber_id)
				 ->delete('user_subscriber_event_preference');
		
		if($preferences){
			foreach($preferences as $preference){
				$entry = array (
					'subscriber_id' => $row->subscriber_id,
					'event_preference' => $preference
				);
				$this->db->insert('user_subscriber_event_preference', $entry);
			}
		}

		$this->db->set('process_status', 0);
        $this->db->where('login_id', $login_id);
        $this->db->where('process_type', 10);
        $this->db->update('event_concurrent_process');

		// New Preferences
		$query = $this->db->select('user_subscriber_event_preference.event_preference, event_type.event_type')
						  ->from('user_subscriber_event_preference')
						  ->join('event_type', 'user_subscriber_event_preference.event_preference=event_type.event_type_id')
						  ->where('user_subscriber_event_preference.subscriber_id', $row->subscriber_id)
						  ->get();

		$rows = $query->result();
		$preferences_list = array();
		foreach ($rows as $value) {
			array_push($preferences_list, $value->event_type);
		}
		return $preferences_list;
	}

	public function check_profile_info_update($user_id, $field, $profile_info)
    {
    	$info = explode(", ", $profile_info);
    	// if(empty($info[0])) var_dump($info);
    	// 	else print_r("Not empty");
    	$user = $this->db->select('subscriber_id')
					    ->from('user_subscriber')
					    ->where('subscriber', $user_id)
					    ->get()
					    ->row();

		$query = $this->db->select('user_subscriber_event_preference.subscriber_id, user_subscriber_event_preference.event_preference_id, event_type.event_type')
						  ->from('user_subscriber_event_preference')
						  ->join('event_type', 'user_subscriber_event_preference.event_preference = event_type.event_type_id')
						  ->where('subscriber_id', $user->subscriber_id)
						  ->get();

		$rows = $query->result();
		
		$number_of_preferences = $query->num_rows();

		if(empty($info[0]) && $number_of_preferences == 0) return array('status' => false, 'data' => array());
		if($number_of_preferences != count($info)) { // check if preferences on db is same as current display
			$preferences = array();
			foreach ($rows as $row) {
				array_push($preferences, $row->event_type);				
			}
			return array('status' => true, 'data' => implode(", ", $preferences));
		} else {			
			$pref_count = 0;
			foreach ($rows as $row){
				$pref_count++;
				if(!in_array($row->event_type, $info)) {
					$preferences = array();
					foreach ($rows as $row2) {
						array_push($preferences, $row2->event_type);
					}
					return array('status' => true, 'data' => implode(", ", $preferences));		
				}
				if($pref_count == $number_of_preferences) return array('status' => false, 'data' => array());
			}
		}
					
    }
}