<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Session_checker {

		public function __construct()
		{
			$this->ci = & get_instance();
			$this->ci->load->library('session');
		}


        public function session_filled()
        {
			 if( empty( $this->ci->session->userdata('role') ) ){
			    redirect('main','refresh');
			 }
			 return true;
        }
        public function is_admin()
        {
			if( $this->ci->session->userdata('role') != 1 )
			{
				redirect('auth/logout');
			}
        }
		public function is_authorize()
		{
			 if( !empty( $this->ci->session->userdata('role') ) == 1 || !empty( $this->ci->session->userdata('role') ) == 2 ) {
				redirect( 'admin/dashboard', 'refresh' );
			 }
			 
		}

        public function is_user()
        {
			if( $this->ci->session->userdata('role') == 1 )
			{
				redirect( '/', 'refresh' );
			}
        }
        public function check_date($split,$date)
        {
        	 	$orderdate = explode($split,  $date);
			 	$day = $orderdate[0];
			 	$month   = $orderdate[1];
				$year  = $orderdate[2];
				
			 	if( $day > 31 || $month > 12 ){
			 		return "true";
			 	}else{
			 		return "false";
			 	}
        }
}
