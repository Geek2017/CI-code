<?php
    $config['protocol'] = 'smtp';
    $config['smtp_host'] = 'ssl://smtp.gmail.com'; 
    $config['smtp_port'] = '465';
    $config['smtp_user'] = 'akeen.email@gmail.com'; //https://www.google.com/settings/security/lesssecureapps -> turn on(accept email)
    $config['smtp_pass'] = 'wylogpassword'; 
    $config['mailtype'] = 'html';
    $config['charset'] = 'utf-8';
    $config['wordwrap'] = TRUE;
    $config['newline'] = "\r\n"; 
    $config['crlf'] = "\r\n";

    //http://www.geonames.org
    //username akeen.12345
    //email akeen.email@gmail.com
    //password wylogpassword
?>