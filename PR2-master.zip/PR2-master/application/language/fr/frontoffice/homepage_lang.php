<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/* HOMEPAGE */

// Header
$lang["homepage"] = "Page d'accueil";
$lang["create_an_account"] = "Créer un compte";
$lang["return_to_site"] = "Retour au site";

// Paragraphs
$lang["events"]["first_paragraph"] = "En remerciement de votre fidélité, Le Monde vous propose d'assister gratuitement aux spectacles et événements ci-dessous.";
$lang["events"]["second_paragraph"] = "Réservez vos places en vous connectant au moyen de vos identifiants LeMonde.fr";
$lang["invite_guests"] = "Invitez certains individus?";
$lang["invite_friends"] = "Inviter un ami";
$lang["first_name"] = "Prénom";
$lang["last_name"] = "Nom de famille";
$lang["seat"] = "place";
$lang["seats"] = "places";

// Filters
$lang["filter_by_month"] = "FILTRER PAR MOIS";
$lang["filter_by_type"] = "FILTRER PAR TYPE";
$lang["filter_by_city"] = "FILTRER PAR VILLE";
$lang["all_events"] = "Tous les événements";
$lang["all_months"] = "Tous les mois";
$lang["all_cities"] = "Toutes les villes";
$lang["filter"] = "Filtrer";
$lang["by_month"] = "Par mois";
$lang["by_type"] = "Par type";
$lang["by_city"] = "Par ville";
$lang["january"] = "Janvier";
$lang["february"] = "Février";
$lang["march"] = "Mars";
$lang["april"] = "Avril";
$lang["may"] = "Mai";
$lang["june"] = "Juin";
$lang["july"] = "Juillet";
$lang["august"] = "Août";
$lang["september"] = "Septembre";
$lang["october"] = "Octobre";
$lang["november"] = "Novembre";
$lang["december"] = "Décembre";

// Buttons
$lang["invite_more"] = "Invitez d'autres personnes";

// Footer
$lang["footer"] = "Les données collectées nous permettent de vous adresser vos newsletters et des messages personnalisés ainsi que, le cas échéant, de gérer votre abonnement. Elles sont destinées aux services internes et sauf opposition à nos partenaires. Conformément à la loi, vous disposez d'un droit d'accès, de rectifications et d'opposition, en vous connectant à votre compte ou en vous adressant à LE MONDE INTERACTIF, Service marketing, 80, boulevard Auguste-Blanqui, 75013 Paris.";

/* Forgot Password - Email Sent */
$lang["login"]["js"]["back_to_homepage"] = "Retour à la page de connexion";