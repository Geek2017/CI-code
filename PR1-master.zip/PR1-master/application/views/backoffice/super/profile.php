<div id="main">
    <!-- <div class="table-responsive">
     <table id="s_profile" class="table table-striped table-bordered" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>Nom Prénom</th>
                <th>Adresse e-mail</th>
                <th>Fonction</th>
                <th>Identifiant</th>
                <th></th>
            </tr>
        </thead>
                <?php
                if($profile_lists){
                    foreach($profile_lists as $list)
                    {
                        echo "<tr>";
                        echo " <td>".$list->firstname. ',' .$list->lastname."</td>";
                        echo " <td>".$list->email."</td>";
                        echo " <td>SUPERADMIN</td>";
                        echo " <td>".$list->username."</td>";
                        echo '<td><button onclick="s_profile.update_form('.$list->user_id.');" class="btn btn-primary">Mettre à jour le profi</button></td>';
                        echo "</tr>";
                    }
                }
                ?>
                
        </tbody>
    </table>
    </div> -->
    <h3>Mon Profil</h3>
    <table class="table table-striped table-hover" style="width:50%">
        <thead>
            <tr>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php
                if($profile_lists){
                    foreach($profile_lists as $list)
                    {
                        echo "<tr>";
                        echo "<td>Nom Prénom</td>";
                        echo "<td>:</td>";
                        echo " <td>".$list->firstname. ' ' .$list->lastname."</td>";
                        echo "</tr>";
                        echo "<tr>";
                        echo "<td>E-mail professionnel</td>";
                        echo "<td>:</td>";
                        echo " <td>".$list->email."</td>";
                        echo "</tr>";
                        echo "<tr>";
                        echo "<td>Fonction</td>";
                        echo "<td>:</td>";
                        echo " <td>SUPERADMIN</td>";
                        echo "</tr>";
                        echo "<tr>";
                        echo "<td>Identifiant</td>";
                        echo "<td>:</td>";
                        echo " <td>".$list->username."</td>";
                        echo "</tr>";
                        echo "<tr>";
                        echo '<td><button onclick="s_profile.update_form('.$list->user_id.');" class="btn btn-primary">Mettre à jour le profil</button></td>';
                        echo "<td></td>";
                        echo "<td></td>";
                        echo "</tr>";
                    }
                }
                ?>
        </tbody>
    </table>
</div>




<!-- Modal -->
<div class="modal fade" id="s_profile_modal" tabindex="-1" role="dialog"
     aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <!-- Modal Header -->
            <div class="modal-header" style="background-color:#337AB7; color:#FFFFFF;">
                <button type="button" class="close"
                        data-dismiss="modal">
                    <span aria-hidden="true">&times;</span>
                    <span class="sr-only">Annuler</span>
                </button>
                <h4 class="modal-title" id="myModalLabel">
                    Formulaire d'un profil
                </h4>
            </div>
            <!-- End Modal Header -->

            <!-- Modal Body -->
            <div class="modal-body profile-modal">
                <form class="form-horizontal" role="form" id="s_update_form">
                    <div class="form-group">
                        <label class=" control-label" for="firstname" >Nom</label>
                        <div class="">
                            <input  type="text" class="form-control" id="firstname" name="firstname"  placeholder=""/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class=" control-label" for="lastname" >Prénom</label>
                        <div class="">
                            <input  type="text" class="form-control" id="lastname" name="lastname"  placeholder=""/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class=" control-label" for="email" >* E-mail professionnel</label>
                        <div class="">
                            <input  type="text" class="form-control" id="email" name="email"  placeholder=""/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class=" control-label" for="username" >* Identifiant</label>
                        <div class="">
                            <input  type="text" class="form-control" id="username" name="username"  placeholder=""/>
                        </div>
                    </div>
                      <div class="form-group">
                        <label class=" control-label" for="password" >* Mot de passe</label>
                        <div class="">
                            <input  type="password" class="form-control" id="password" name="password"  placeholder=""/>
                        </div>
                    </div>
                     <div class="form-group">
                        <label class=" control-label" for="npass" >Nouveau mot de passe</label>
                        <div class="">
                            <input  type="password" class="form-control" id="npass" name="npass"  placeholder=""/>
                        </div>
                    </div>
                     <div class="form-group">
                        <label class=" control-label" for="cpass" >Confirmer le nouveau mot de passe</label>
                        <div class="">
                            <input  type="password" class="form-control" id="cpass" name="cpass"  placeholder=""/>
                        </div>
                    </div>
                </form>
            </div>
            <!-- End Modal Body -->

            <!-- Modal Footer -->
            <div class="modal-footer">
                <center>
                    <button type="button" class="btn btn-primary" id="s_form_profile_btn" onclick="s_profile.submit_update();">
                       Enregistrer les modifications
                    </button>
                    <button type="button" class="btn btn-default" data-dismiss="modal">
                       Annuler
                    </button>
                </center>

            </div>
            <!-- End Modal Footer -->

        </div>
    </div>
</div>
