<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Event_email_filter_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    public function get_filters(){
    	$query = $this->db->select('*')
    		->from('event_email_filter')
    		->where('email_filter_status', 1)
    		->get()
    		->result();

    	return $query;
    }

}