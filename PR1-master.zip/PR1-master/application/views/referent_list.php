<?php 
$show = ( $this->users->with_referent() === '1' ) ? "true" : "false";
?>
<div class="referents">
<div class="home">

    <div class="table-responsive">
        <?php 
        if( $this->users->with_referent() )
        {
            ?>
                <button type="button" class="add-btn btn btn-primary" data-toggle="modal" href='#first_email'> <span class="glyphicon glyphicon-envelope"></span> Modèle du premier émail</button>
            <?php
        }
        else
        {

        }
        ?>
        <div id="tbl">
            <BR><BR>
            <button type="button" class="add-btn btn btn-primary" id="btnAdd"> <span class="glyphicon glyphicon-plus"></span>Ajouter un référent</button>

        </div>
       <br><br>

            <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
            
                <thead>
                    <tr>
                        <th>Secteur</th>
                        <th>Entreprise/Filiale</th>
                        <th>Métier</th>
                        <th>Fonction</th>
                        <th>Nom</th>
                        <th>Prénom</th>
                        <th>Lien avec vous</th>
                        <th>Mail</th>
                        <th>Validé</th>
                        <th>a répondu</th>
                        <th>Actions</th>
                    </tr>
                </thead>
         
        
            </table>

        
    </div>
</div>



<div class="">
    <?php
     $s_last = $this->uri->total_segments(); 
     $q = $this->uri->segment($s_last);
    ?>
    <?php if ($q == 10): ?>
        <a href="<?php echo site_url(); ?>/sections/1/<?php echo  10 - (count($this->questions->get_q_id_org(1,"0")) - 1); ?>" type="button" class="btn btn-primary pull-right" >Suivant</a>
    <?php endif ?>
</div>

<input type="hidden" id="baseURL" name="baseURL" value="<?php echo base_url(); ?>">
<div class="modal fade" id="edit_referents">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="bootbox-close-button close" data-dismiss="modal" aria-hidden="true" style="margin-top: -10px;">×</button>
            </div>
            <div class="modal-body">
                <div class="container w100 wc-form">
                    <form id="edit_pref_form">
                        <input type="hidden" id="ref_id" name="ref_id">
                       
                            <div class="form-group-sm">
                                <label>Secteur :</label>
                                <input type="text" class="form-control nxt" id="Secteur" placeholder="Secteur" required="true">
                            </div>
                            <div class="form-group-sm">
                                <label>Entreprise/Filiale :</label>
                                <input type="text" class="form-control nxt" id="Entreprise" placeholder="Entreprise/Filiale" required="true">
                            </div>
                            <div class="form-group-sm">
                                <label>Métier :</label>
                                <input type="text" class="form-control nxt" id="Metier" placeholder="Métier" required="true">
                            </div>
                            <div class="form-group-sm">
                                <label>Fonction :</label>
                                <input type="text" class="form-control nxt" id="Fonction" placeholder="Fonction" required="true">
                            </div>
                            <div class="form-group-sm">
                                <label>Nom :</label>
                                <input type="text" class="form-control nxt" id="Nom" placeholder="Nom" required="true">
                            </div>
                            <div class="form-group-sm">
                                <label>Prénom :</label>
                                <input type="text" class="form-control nxt" id="Prenom" placeholder="Prénom" required="true">
                            </div>
                            <div class="form-group-sm">
                                <label>Lien avec vous :</label>
                                <!-- <input type="text" class="form-control nxt" id="Lien" placeholder="Lien avec vous" required="true"> -->
                                <select id="Lien" class="form-control">
                                    <option value="Pair">Pair</option>
                                    <option value="Collaborateur">Collaborateur</option>
                                    <option value="N+1">N+1</option>
                                    <option value="Externe">Externe</option>
                                </select>
                            </div>
                            <div class="form-group-sm">
                                <label>Mail :</label>
                                <input type="email" class="form-control nxt" id="r_email" placeholder="Mail" required="true">
                            </div>
                       
                        
                            <br>
                            <div class="col-md-offset-4">
                            <input type="submit" id="submit_edit_pref" class="btn btn-primary nxt" value="Valider">
                            <button type="button" class="btn btn-primary nxt" data-dismiss="modal">Annuler</button>
                            </div>
                    </form>
                </div>

            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
</div>

<div class="modal fade" id="first_email">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">&nbsp;</h4>
            </div>
            <div class="modal-body">
                </p><div id="emails">Bonjour, </div>
                    <p>Je suis actuellement un bilan de mobilité professionnel en interne. Ce processus intègre le retour de la vision de mon réseau professionnel interne sur ma personnalité, et des pistes professionnelles potentielles en interne par exemple dans ma structure ou une autre filiale. Dans ce cadre, seriez-vous d’accord pour m’accompagner et répondre à un questionnaire de 15 minutes ?
                    </p><p>Si votre réponse est positive, je vous remercie de suivre le lien suivant et de compléter le questionnaire : </p>
                    <div id="tokens" style=" word-wrap: break-word;"><div><a href=""><?php echo base_url().'index.php/main/token/'.$this->session->userdata('token_id'); ?></a></div></div>
                    <br>
                    <p>Dans tous les cas, je vous remercie pour votre attention à ce mail.</p>

                    <p><span class="nom_prenom"><?php echo $this->users->get_full_name($this->session->userdata('id'),1); ?></span></p>                   
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
                <!-- <button type="button" class="btn btn-primary">Save changes</button> -->
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->