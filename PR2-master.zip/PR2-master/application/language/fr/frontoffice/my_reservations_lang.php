<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/* MY RESERVATIONS PAGE */

// Labels
$lang['my_reservations'] = 'Mes réservations';
$lang['reservation_history'] = 'Historique des réservations';
$lang['change_bookings'] = 'Modifier les réservations';
$lang["filter_by_month"] = "FILTRER PAR MOIS";
$lang["filter_by_type"] = "FILTRER PAR TYPE";
$lang["filter_by_city"] = "FILTRER PAR VILLE";
$lang["all_events"] = "Tous les événements";
$lang["all_months"] = "Tous les mois";
$lang["all_cities"] = "Toutes les villes";
$lang["all"] = "All";