<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$autoload['packages'] = array();
$autoload['libraries'] = array('pagination','database','session','session_checker','form_validation','user_agent','upload','token','email','french_calendar');
$autoload['drivers'] = array();
$autoload['helper'] = array('url','cookie','helpers','form','email');
$autoload['config'] = array();
$autoload['language'] = array();
$autoload['model'] = array('authentications','backoffices','dashboards','globalmodel','users','profiles','questions','charts','uploads','mains','referents','menuitems','languages','job','satisfaction_curves','pdfs','trainings','competences','success_stories','logs','videos');
