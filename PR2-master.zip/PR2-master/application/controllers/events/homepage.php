<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Homepage extends MY_Controller {

    public function __construct()
    {
        //parent::__construct();
        $this->my_controller_parent_construct();
//        $this->check_session_time_out_fo("fo");
        $this->load->model("event_model");
    }

    public function filter_events()
    {
        $this->check_session_time_out_fo("fo");

        $month = $this->input->post('month');
        $type = $this->input->post('type');
        $city = $this->input->post('city');
        $page = $this->input->post('page');

        $client_session = $this->data['logged_in'];
        $user_id = $client_session['user_id'];

        if(!$this->check_cookie_and_session()){
            $logged_in = false;
        } else {
            $logged_in = true;
        }

        if($month == 0){
            if($type == 0){
                if($city == 0) $filter = '_default_';
                else $filter = 'city';
            }
            else {
                if($city == 0) $filter = 'type';
                else $filter = 'type_city';
            }
        }
        else {
            if($type == 0) {
                if($city == 0) $filter = 'month';
                else $filter = 'month_city';
            }
            else {
                if($city == 0) $filter = 'month_type';
                else $filter = 'all';
            }
        }

        $query = $this->event_model->filter_events($filter, $page, $month, $type, $city, $user_id, false);


        $result = array(
            "mtype" => "success",
            "mdata" => array(
                'details' => $query['data'],
                'pages' => $query['pagination'],
                'result_count' => $query['result_count'],
                'logged_in' => $query['logged_in']
            )
        );

        output_to_json($this, $result);
    }

    public function check_bo_status()
    {
        $event_id = $this->input->post('event_id');
        $event_status = $this->event_model->check_bo_status($event_id);

        if(!$this->check_cookie_and_session())
        {
            echo $event_status;
            if($event_status == 1){
                $result = array (
                    'mtype' => 'success',
                    'message' => "Published",
                    'mdata' => 1
                );
            } else if($event_status == 2){
                $this->check_seats($event_id);
                return;
            } else if($event_status == 3){
                $result = array (
                    'mtype' => 'success',
                    'message' => "Locked",
                    'mdata' => 3
                );
            } else if($event_status == 4){
                $result = array (
                    'mtype' => 'success',
                    'message' => "Closed",
                    'mdata' => 4
                );
            } else {
                $result = array (
                    'mtype' => 'success',
                    'message' => "Published",
                    'mdata' => 1
                );
            }
            output_to_json($this, $result);
        } else {
            if($event_status == 1){
                $result = array (
                    'mtype' => 'success',
                    'message' => "Published",
                    'mdata' => 1
                );
                output_to_json($this, $result);
            } else if($event_status == 4){
                $result = array (
                    'mtype' => 'success',
                    'message' => "Closed",
                    'mdata' => 4
                );
                output_to_json($this, $result);
            } else {
                $this->check_subscription($event_id);
            }
        }
    }

    public function check_subscription($event_id)
    {
        $this->load->model('event_registration_model');
        $this->load->model('event_wait_list_model');

        $client_session = $this->data['logged_in'];
        $user_id = $client_session['user_id'];

        $subscribed = $this->event_registration_model->check_subscription($user_id, $event_id);
        if($subscribed)
        {
            $result = array (
                'mtype' => 'success',
                'message' => "Cancel Button",
                'mdata' => 5 // Button - Cancel
            );
            output_to_json($this, $result);
        }
        else
        {
            $subscribed_waitlist = $this->event_wait_list_model->check_subscription($user_id, $event_id);
            if($subscribed_waitlist){
                $status = $this->event_model->check_seats($event_id);
                if($status == 1){
                    $result = array (
                        'mtype' => 'success',
                        'message' => "Open - Book",
                        'mdata' => 2
                    );
                }
                else {
                    $result = array (
                        'mtype' => 'success',
                        'message' => "Waitlist Cancel Button",
                        'mdata' => 6 // Button - Cancel Registration in Waitlist
                    );
                    output_to_json($this, $result);
                }
            } else {
                $this->check_seats($event_id);
            }
        }

    }

    public function check_seats($event_id)
    {
        $this->load->model('event_registration_model', '', TRUE);
        $this->load->model('event_wait_list_model', '', TRUE);

        $status = $this->event_model->check_seats($event_id);

        if($status == 1) {
            // $event_status = $this->event_model->check_event_status($event_id);
            // if($event_status == 'AVAILABLE') {
                $result = array (
                    'mtype' => 'success',
                    'message' => "Open - Book",
                    'mdata' => 2
                );
            // }
            // else {
            //     $result = array (
            //         'mtype' => 'success',
            //         'message' => "Full",
            //         'mdata' => 3
            //     );
            // }
        } else if($status == 2){
            $result = array (
                'mtype' => 'success',
                'message' => "Open - Book in waitlist",
                'mdata' => 7
            );
        } else {
            $result = array (
                'mtype' => 'success',
                'message' => "Full",
                'mdata' => 3
            );
        }
        output_to_json($this, $result);
    }

}