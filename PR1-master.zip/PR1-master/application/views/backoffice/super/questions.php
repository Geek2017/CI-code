<div id="main">
    <div class="table-responsive">
        <!--        <div id="tbl"><button type="button" class="btn btn-primary glyphicon glyphicon-plus" id="btnAdd"></button></div>-->
        <br><br>
        <table id="tbl_questionnaires" class="table table-striped table-bordered" cellspacing="0" width="100%">
            <thead>
            <tr>
<!--                <th>ID</th>-->
                <th>Numéro de section</th>
                <th>Ordre de question</th>
                <th>Statut</th>
                <th>Actions</th>
            </tr>
            </thead>
            <tbody></tbody>
        </table>
    </div>
</div>

<div class="modal fade in" id="modal_question">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">Contact dans le cadre d’un bilan de mobilité interne</h4>
            </div>
            <div class="modal-body">
                <form action="" method="POST" role="form" id="edit_question_form" class="section-form">
                    <input type="hidden" name="question_id" id="question_id" required>
                    <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                            <div class="form-group-sm">
                                <label for="">Section</label>
                                <select name="section_id" id="section_id" class="chosen-select" required>
                                    <?php
                                        foreach($sections->result() as $sec)
                                            echo '<option value="'.$sec->id.'">'.$sec->section_id.' - '.$sec->section_title.'</option>';

                                    ?>
                                </select>
                            </div>
                            <div class="form-group-sm">
                                <label for="">Ordre</label>
                                <input type="number" class="form-control"  name="q_order" id="q_order" min="1" placeholder="" required>
                            </div>
                            <div class="form-group-sm">
                                <label for="">Contenu</label>
                                <textarea class="form-control"  name="q_content" id="q_content"  placeholder=""  required>
                                    </textarea>
                            </div>
                            <div class="form-group-sm">
                                <label for="">Récupérer la description de la section</label>
                                <select class="form-control"  name="fetch_description" id="fetch_description"  required>
                                    <option value="1">Oui</option>
                                    <option value="0" selected>Non</option>
                                </select>
                            </div>
                            <div class="form-group-sm">
                                <label for="">Statut</label>
                                <select class="form-control"  name="status" id="q_status"  required>
                                    <option value="1">Activée</option>
                                    <option value="0">Désactivée</option>
                                </select>
                            </div>
                        </div>
                    </div>


            </div>
            <div class="modal-footer">
                <button type="button" onclick="questions.submit_edit();" id="submit_edit_question" class="btn btn-primary nxt">Soumettre</button>
            </div>
            </form>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
