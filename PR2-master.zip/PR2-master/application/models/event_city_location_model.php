<?php
class Event_city_location_model extends MY_Model {

    var $column_order = array('city_location_id','city'); //set column field database for datatable orderable
    var $column_search = array('city'); //set column field database for datatable searchable just firstname , lastname , address are searchable
    var $order = array('id' => 'desc'); // default order

    public function __construct() {
        parent::__construct();
    }

    private function _get_datatables_query($data_source){
        $this->db->select("city_location_id, city");
        $this->db->from("event_city_location");
        $this->db->where('status', 1);

        $i = 0;
        foreach ($this->column_search as $item) {// loop column
            if($data_source['search']['value']) {  // if datatable send POST for search
                if($i===0){ // first loop
                    $this->db->like($item, $data_source['search']['value']);
                } else {
                    $this->db->or_like($item, $data_source['search']['value']);
                }
            }
            $i++;
        }

        if(isset($data_source['order'])) { // here order processing
            if(isset($data_source['order']['0']['dir'])) {
                $this->db->order_by($this->column_order[$data_source['order']['0']['column']], $data_source['order']['0']['dir']);
            }
        } else if(isset($this->order)) {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    public function get_subscriber_information_list_export($data_source){
        $this->_get_datatables_query($data_source);
        $query = $this->db->get();
        return $query->result();
    }

    public function get_datatables($data_source){
        $this->_get_datatables_query($data_source);
        if($data_source['length'] != -1)
            $this->db->limit($data_source['length'], $data_source['start']);
        $query = $this->db->get();
        return $query->result();
    }

    public function count_filtered($data_source){
        $this->_get_datatables_query($data_source);
        $query = $this->db->get();
        return $query->num_rows();
    }

    public function count_all($data_source){
        $this->_get_datatables_query($data_source);
        return $this->db->count_all_results();
    }

	public function add_city($city)
	{
        $this->db->insert("event_city_location", array("city" => $city, "status" => 1));
        return $this->db->insert_id();
	}

    public function edit_city($city_location_id, $city)
    {
        $this->db->where("city_location_id", $city_location_id);
        $update = $this->db->update("event_city_location", array("city" => $city));
        return $update;
    }

    public function delete_city($city_location_id)
    {
        $this->db->where("city_location_id", $city_location_id);
        $update = $this->db->update("event_city_location", array("status" => 0));
        return $update;
    }

    public function check_city($city, $city_location_id){
        $this->db->where("city", $city);
        if($city_location_id !=""){
            $this->db->where("city_location_id !=", $city_location_id);
        }
        $this->db->where("status", 1);
        return $this->db->get("event_city_location")->num_rows();
    }

    public function add_to_activity_logs($activity_log){
        $this->db->insert("user_activity_log", $activity_log);
    }

    public function list_city(){
        $this->db->select("*");
        $this->db->where("status", 1);
        return $this->db->get("event_city_location")->result();
    }

    public function home(){
        $query = $this->db->distinct()
            ->select('ecl.city_location_id, ecl.city')
            ->from('event_city_location ecl')
            ->join('event e', 'ecl.city_location_id=e.city_location')
            ->where('ecl.status', 1)
            ->where('e.back_office_status !=', 0)
            ->where('e.back_office_status !=', 5)
            ->where('e.back_office_status !=', 6)
            ->order_by('ecl.city_location_id', 'ASC')
            ->get();

        return $query->result();
    }
}

?>