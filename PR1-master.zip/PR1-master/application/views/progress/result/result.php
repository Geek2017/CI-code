<div class="container-fluid sec-bg">
    <div class="s_section">
        <input type="hidden" id="section_id" value="<?php echo $this->uri->segment(3); ?>">
        <div id="s_result">
            <?php
            if($questions) 
            {
                $q_number = 1;
                $section_title = "";
                foreach ($questions as $question) 
                {
                        if($section_title != $question->section_title ) {
                            $section_title = $question->section_title;
                            $q_number = 1;
                            echo "<h3>".$section_title."</h3>";
                        }
                        echo '<div class="result-container">';
                        echo '<input type="hidden" class="sectionID" value="'.$question->q_section.'">';
                        echo '<input type="hidden" class="qID" name="q_id" value="' . $question->q_id . '">';
                        if($question->with_graph == 1)
                        {
                            ?>
                            <canvas id="graphTest" width="400" height="190" style="padding-left:10px; padding-right:10px;"></canvas>
                            <script src="<?php echo base_url(); ?>assets/js/chart_s2.js"></script>
                            <?php
                        }
                        echo "<h3>Q" . $q_number . " : </h3>";
                        $content = str_replace(['\n','\r'], "", $question->q_content);
                        echo $content;
                        echo '</div>';
                    $q_number++;
                }
            }
            ?>
        </div>
    </div>
</div>
<style>
    #s_result input,
    #s_result textarea{
        font-weight: bold;
        background-color: #fff;
    }
    @media print and (color) {
       * {
          -webkit-print-color-adjust: exact;
          print-color-adjust: exact;
       }
       #print_btn_now{
          display: none !important;
       }
    }

</style>
<script>
    $('.result-container input, .result-container textarea, .result-container button, #add_job').attr('disabled', true);
</script>