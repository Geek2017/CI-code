<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Main extends CI_Controller {

	function __construct() {
        parent::__construct();

    }
	public function index()
	{		
			if( $this->session->userdata('role') == 3 || empty(  $this->session->userdata('role') )  )
			{
			 	 $data = array(
								'token' => '',
								'content' => 'home',
								'nav_menu' => 'page-nav',
								'user_role' => $this->session->userdata('role')
				);
				$this->load->view('template', $data);
			}
			else
			{
				redirect( 'admin/dashboard', 'refresh' );
			}
			
			
	}
	public function token($token)
	{
//		$token = $this->token->exist( $token ) ? $token : "" ;
		$referent_data = $this->mains->get_my_referentinfo($token) > 0 ? $this->mains->get_my_referentinfo($token) : "";
//		$validated = $this->mains->check_token_confirm($token);
//		$data = array(
//			'token' => $token,
//			'referent_data' => $referent_data,
//			'validated' => $validated,
//			'content' => 'home',
//			'nav_menu' => 'page-nav',
//			'user_role' => $this->session->userdata('role')
//		);
//		$this->load->view('template', $data);
		$token = $this->users->get_user_info(['token_id' => $token])->num_rows() ? $token : ( $this->token->exist( $token ) ? $token : "" );
		$total_ref = $this->referents->count_referents_use_token($token,true);
		$data = array(
			'token' => $token,
			'referent_data' => $referent_data,
//			'validated' => $validated,
			'content' => 'home',
			'nav_menu' => 'page-nav',
			'user_role' => $this->session->userdata('role'),
			'total_ref'	=>	$total_ref > 0
		);
		$this->load->view('template', $data);
			
	}

	public function who_are_we(){
		
		$data = array(
			'content' => 'who_are_we',
			'nav_menu' => 'page-nav',
			'user_role' => $this->session->userdata('role')
			);
		$this->load->view('template', $data);
	}
	public function heart_of_AkeeN(){

		$data = array(
			'content' => 'heart_of_akeen',
			'nav_menu' => 'page-nav',
			'user_role' => $this->session->userdata('role')
			);
		$this->load->view('template', $data);
	}
	public function AMPI_course(){

		$data = array(
			'content' => 'ampi_course',
			'nav_menu' => 'page-nav',
			'user_role' => $this->session->userdata('role')
			);
		$this->load->view('template', $data);
	}
	public function commitments_of_AkeeN(){

		$data = array(
			'content' => 'commitments_of_akeen',
			'nav_menu' => 'page-nav',
			'user_role' => $this->session->userdata('role')
			);
		$this->load->view('template', $data);
	}
	public function question_frequency(){

		$data = array(
			'content' => 'question_frequency',
			'nav_menu' => 'page-nav',
			'user_role' => $this->session->userdata('role')
			);
		$this->load->view('template', $data);
	}
	public function press_area(){

		$data = array(
			'content' => 'press_area',
			'nav_menu' => 'page-nav',
			'user_role' => $this->session->userdata('role')
			);
		$this->load->view('template', $data);
	}
	public function ethical_charter_AkeeN(){
		$data = array(
			'content' => 'ethical_charter_akeen',
			'nav_menu' => 'page-nav',
			'user_role' => $this->session->userdata('role')
			);
		$this->load->view('template', $data);
	}
	public function legal_notice(){
		$data = array(
			'content' => 'legal_notice',
			'nav_menu' => 'page-nav',
			'user_role' => $this->session->userdata('role')
			);
		$this->load->view('template', $data);
	}
	public function terms_of_service(){
		$data = array(
			'content' => 'terms_of_service',
			'nav_menu' => 'page-nav',
			'user_role' => $this->session->userdata('role')
			);
		$this->load->view('template', $data);
	}
	public function contact_us(){
		$data = array(
			'content' => 'contact_us',
			'nav_menu' => 'page-nav',
			'user_role' => $this->session->userdata('role')
			);
		$this->load->view('template', $data);
	}
	public function issues_of_internal_mobility(){
		$data = array(
			'content' => 'issues_of_internal_mobility',
			'nav_menu' => 'page-nav',
			'user_role' => $this->session->userdata('role')
			);
		$this->load->view('template', $data);
	}
	public function glossary(){
		$data = array(
			'content' => 'glossary',
			'nav_menu' => 'page-nav',
			'user_role' => $this->session->userdata('role')
			);
		$this->load->view('template', $data);
	}
	public function welcome(){
		
		$this->session_checker->session_filled();
		$this->session_checker->is_user();
		$arr = $this->mains->accounts();


		$user_info = $this->users->get_user_info(['id' => $this->session->userdata('id')])->row();
		$user_tbl = $this->users->get_table_user(['user_id' => $this->session->userdata('id')]);
		if (!$user_info->token_id) {
			$token = $this->token->generate();
			$data = [
				'token_id' => $token
			];
			$this->users->update_user_info($data);
			$this->session->set_userdata('token_id',$token);
		}
		$data = array(
			'content' => 'welcome',
			'nav_menu' => 'page-nav',
			'user_role' => $this->session->userdata('role'),
			'user_email' => $arr['user_email'],
			'firstname'	=>	$user_tbl ? $user_tbl->row()->firstname : null,
			'lastname'	=>	$user_tbl ? $user_tbl->row()->lastname  : null,
			'position'	=>	$user_tbl ? $user_tbl->row()->position  : null
			);
		$this->load->view('template', $data);
	}
	public function progress(){

		$this->session_checker->session_filled();
		$this->session_checker->is_user();

		if( $this->session->userdata('lastname') != null )
		{
			$data = array(
				'content' => 'progress',
				'nav_menu' => 'page-nav',
				'user_role' => $this->session->userdata('role'),
				'firstQ' => $this->questions->getFirstQ(),
				);
			$this->load->view('template-sidebar', $data);
		}else{
			redirect('/main/welcome', 'refresh');
		}
	}
	public function my_profile(){

		$this->session_checker->session_filled();
		$this->session_checker->is_user();

		if( $this->session->userdata('lastname') != null )
		{
			$data = array(
				'content' => 'my_profile',
				'nav_menu' => 'page-nav',
				'user_role' => $this->session->userdata('role'),
				'firstQ' => $this->questions->getFirstQ(),
				);
			$this->load->view('template-sidebar', $data);
		}else{
			redirect('/main/welcome', 'refresh');
		}
	}
	public function myprofile_result(){

		$this->session_checker->session_filled();
		$this->session_checker->is_user();

		$id = $this->uri->segment(3);
		$data = array(
//			'data' => $this->questions->get_answers(  $id ),
//			'questions' => $this->questions->getAllQuestionsBySection(  $id ),
//			'user_role' => $this->session->userdata('role'),
//			'percent' => $this->questions->getPercentage($id),
//			'next_item'	=>	$this->questions->getNextItem($id),
//			'view_file' => $this->uploads->view_file(),
//			'content' => 'progress/result/result',
			'data' => $this->questions->get_answers(  $id ),
			'questions' => $this->questions->getAllQuestionsBySection(  $id ),
			'content' => 'progress/section-1/result-1',
			'nav_menu' => 'page-nav',
			'sidebar' => 'progress/sidebar',
			'progress' => 'progress/progress-state',
			'user_role' => $this->session->userdata('role'),
			'percent' => $this->questions->getPercentage($id),
//			'next_item'	=>	$this->questions->getNextItem($this->questions->getSectionByID($id)->row()->id),
			'next_item'	=>	$this->questions->getSectionByID($id + 1)->row() ? $id + 1 : '',
			'view_file' => $this->uploads->view_file(),
			'jobs' => $this->job->get_my_job(),
			'activity' => $this->job->get_my_activity(),
			'savoir' => $this->job->get_my_savoir(),
			'faire' => $this->job->get_my_faire(),
			'etre' => $this->job->get_my_etre(),
		);
		$this->load->view('progress/result/result-template', $data);
	}
	public function singleresult(){

		$this->session_checker->session_filled();
		$this->session_checker->is_user();

		$id = $this->uri->segment(3);
		$this->load->view('progress/result/result-single',  array(
			'data' => $this->questions->get_single_answers( $id ),
			'questions' => $this->questions->get_single_answers( $id ),
			'content' => 'progress/section-1/single-print'
		));
	}
	public function m_result(){

		$this->session_checker->session_filled();
		$this->session_checker->is_user();

		
		$data = array(
			'content' => 'progress/section-1/m_result',
		);
		$this->load->view('progress/result/result-template', $data);
	}

	public function leProcess(){

		$this->session_checker->session_filled();
		$this->session_checker->is_user();

		if( $this->session->userdata('lastname') != null )
		{
			$data = array(
				'content' => 'le-process',
				'nav_menu' => 'page-nav',
				'user_role' => $this->session->userdata('role')
				);
			$this->load->view('template', $data);
		}else{
			redirect('/main/welcome', 'refresh');
		}
	} 
	public function profesional_job( $id = null ){

		$this->session_checker->session_filled();
		$this->session_checker->is_user();

		if( $this->session->userdata('lastname') != null )
		{
			$data = array(
				'job_info' => $id != "" ?  $this->job->job_information( $id ) : "" ,
				'content' => 'profesional_job',
				'nav_menu' => 'page-nav',
				'user_role' => $this->session->userdata('role'),
				);
			$this->load->view('template', $data);
		}else{
			redirect('/main/welcome', 'refresh');
		}
	}
	public function satisfaction($id){

		$this->session_checker->session_filled();
		$this->session_checker->is_user();
		$this->session->set_userdata('job_id',$id);

		if( $this->session->userdata('lastname') != null )
		{
			$data = array(
				'job_info' => $id != "" ?  $this->job->job_information( $id ) : "" ,
				'content' => 'satisfactions',
				'nav_menu' => 'page-nav',
				'user_role' => $this->session->userdata('role'),
				);
			$this->load->view('template', $data);
		}else{
			redirect('/main/welcome', 'refresh');
		}
	}
	public function my_job(){

		$this->session_checker->session_filled();
		$this->session_checker->is_user();

		if( $this->session->userdata('lastname') != null )
		{
			$data = array(
				'content' => 'view_job',
				'nav_menu' => 'page-nav',
				'user_role' => $this->session->userdata('role'),
				'jobs' => $this->job->get_my_job(),
				'activity' => $this->job->get_my_activity(),
				'savoir' => $this->job->get_my_savoir(),
				'faire' => $this->job->get_my_faire(),
				'etre' => $this->job->get_my_etre(),
				);
			$this->load->view('template', $data);
		}else{
			redirect('/main/welcome', 'refresh');
		}
	}
	public function glosaire(){
 		$this->session_checker->session_filled();
		$this->session_checker->is_user();

		if( $this->session->userdata('lastname') != null )
		{
			$data = array(
				'content' => 'glosaire',
				'nav_menu' => 'page-nav',
				'user_role' => $this->session->userdata('role'),
				'firstQ' => $this->questions->getFirstQ(),
				);
			$this->load->view('template-sidebar', $data);
		}else{
			redirect('/main/welcome', 'refresh');
		}
	}

	public function forgot_password($token = null)
	{
		$c_token = $this->users->get_user_info(['forgot_password'=>$token]);
		$token = $c_token->num_rows() > 0 ? $token : null;
		$data = array(
			'forgot_password_token' => $token,
			'content' => 'home',
			'nav_menu' => 'page-nav',
		);
		$this->load->view('template', $data);

	}

}
