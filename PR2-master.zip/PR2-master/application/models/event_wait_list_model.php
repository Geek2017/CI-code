<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Event_wait_list_model extends CI_Model {

	public function __construct() {
        parent::__construct();
    }

    public function check_subscription($user_id, $event_schedule_id)
	{
		$query = $this->db->select('*')
						  ->from('event_wait_list')
						  ->where('event_schedule_id', $event_schedule_id)
						  ->where('wait_list_subscriber', $user_id)
						  ->order_by('date_time', 'DESC')
						  ->limit(1)
						  ->get();

		if($query->num_rows() == 0) return false;
		else {
			$row = $query->row();
			if($row->status == 0) return false;
			else return true;
		}
	}

    public function register_waitlist($user_id, $login_id, $event_schedule_id, $user_agent, $seats_reserved, $guest_emails) {

        $registeredSubcriberWL = false;

    	// Remaining waiting list seats
    	$remaining_seats = $this->db->select('quota_waiting_list_seat')
			->from('event_schedule')
			->where('event_schedule_id', $event_schedule_id)
			->get()
			->row();

		if($remaining_seats->quota_waiting_list_seat < 1) return false;
		else{
	    	$this->db->insert('event_wait_list',
	    		array(
	    			'event_schedule_id' => $event_schedule_id,
	    			'wait_list_subscriber' => $user_id,
	    			'number_of_places' => $seats_reserved,
	    			'user_agent' => $user_agent
	    		)
	    	);

            //get the registration id
            $registeredSubcriberWL = $this->db->insert_id();

	    	if(!empty($guest_emails)){
                foreach($guest_emails as $email){
                    $this->db->insert('event_subscriber_guest',
                        array(
                            'inviter_id' => $user_id,
                            'event_schedule_id' => $event_schedule_id,
                            'email_address' => $email,
                            'status' => 1
                        )
                    );
                }
            }

	    	// Subtract from remaining seats
	    	$reserved_seat = 'quota_waiting_list_seat-'.$seats_reserved;
			$this->db->set('quota_waiting_list_seat', $reserved_seat, FALSE);
			$this->db->where('event_schedule_id', $event_schedule_id);
			$this->db->update('event_schedule');
	    }
	    //}    	

		// Update event_status and back_office_status
		$check_seats = $this->db->select('quota_waiting_list_seat')
								->from('event_schedule')
								->where('event_schedule_id', $event_schedule_id)
								->get()
								->row();

		if($check_seats->quota_waiting_list_seat <= 0){
			$this->db->where('event_schedule_id', $event_schedule_id);
			$this->db->update('event_schedule', array('back_office_status' => 3, 'event_status' => "FULL"));
		}

        // Update event concurrent process
        $this->db->set('process_status', 0);
        $this->db->where('login_id', $login_id);
        $this->db->where('process_type', 3);
        $this->db->update('event_concurrent_process');

        return $registeredSubcriberWL;
    }

    public function seats_reserved($user_id, $event_schedule_id){
		$query = $this->db->select('number_of_places')
			->from('event_wait_list')
			->where('wait_list_subscriber', $user_id)
			->where('event_schedule_id', $event_schedule_id)
			->where('status', 1)
			->order_by('date_time', 'DESC')
			->limit(1)
			->get();
		$guests = $query->row();
		return $guests->number_of_places;
	}

    public function prepare_list_for_reinvitation_email($email_schedule_id, $event_schedule_id, $limit){
        /*
          Email key will be used to get the group of recipient ids in one single query
          which will also be used to insert into the table "event_email_recipient_other_detail"
          to get the exact id and exact connection.
        */
        $email_key = "2E".generate_random_keys(8);

        $this->db->query("INSERT INTO
        event_email_recipient(event_schedule_id, email_type_id, email_key, reference_id)
        (SELECT ?, ?, ?, ewl.wait_list_id
        FROM event_wait_list ewl
        WHERE ewl.wait_list_id NOT IN(SELECT eer.reference_id
                FROM event_email_recipient eer
                WHERE eer.email_status IN(1, 0, 5)
                AND eer.event_schedule_id = ?
                AND eer.email_type_id = 2
                GROUP BY eer.reference_id)
        AND ewl.status = 1
        AND ewl.event_schedule_id= ?
        ORDER BY ewl.wait_list_id ASC
        LIMIT 0, $limit )", array($event_schedule_id, 
            2, 
            $email_key,
            $event_schedule_id, $event_schedule_id)
        );

        //insert into other details table
        $this->db->query("INSERT INTO event_email_recipient_other_detail(email_sched_reference_id, email_sched_reference, email_recipient_id)
          (SELECT ?, ?, email_recipient_id
          FROM event_email_recipient eer
          WHERE eer.email_type_id = ?
          AND eer.email_key = ?
          AND eer.event_schedule_id= ? )",
        array($email_schedule_id, 
          1,              
          2, //email_type_id for reinvitation waitlist
          $email_key,
          $event_schedule_id)
        );

        return $this->db->affected_rows();
    }

    public function get_data_waitlists(){
        $result = $this->db->select("
                e.event_id,
                es.event_schedule_id,
                e.title as event_title,
                et.event_type,
                es.event_status,
                ecl.city as city,
                (CASE WHEN e.location IS NULL THEN \"\" ELSE e.location END) as event_place_name,
                (CASE WHEN e.address IS NULL THEN \"\" ELSE e.address END) as event_address,
                (CASE WHEN e.code_postal IS NULL THEN \"\" ELSE e.code_postal END) as event_postal_code,
                es.rate as event_rate,
                ewl.number_of_places as seats_reserved,
                ecl.city as event_venue,
                efa.file_name as event_picture,
                e.description as event_description,
                es.start_date_time as event_start_date")
            ->select("DAYNAME(es.start_date_time) AS event_start_day_name", FALSE)
            ->select("DATE_FORMAT(es.start_date_time, '%e') AS event_start_day", FALSE)
            ->select("DATE_FORMAT(es.start_date_time, '%m') AS event_start_month", FALSE)
            ->select("DATE_FORMAT(es.start_date_time, '%M') AS event_start_month_name", FALSE)
            ->select("DATE_FORMAT(es.start_date_time, '%Hh%i') AS event_start_hour", FALSE)
            ->select("DATE_FORMAT(es.start_date_time, '%Y') AS event_start_year", FALSE)
            ->from(" event_email_recipient eer")
            ->join("event_schedule es", "es.event_schedule_id = eer.event_schedule_id", "left")
            ->join("event e", "e.event_id = es.event_id", "left")
            ->join('event_type et', 'et.event_type_id = e.event_type_id',"left")
            ->join('event_wait_list ewl', 'ewl.event_schedule_id = eer.event_schedule_id AND ewl.wait_list_id = eer.reference_id AND ewl.status=1',"left")
            ->join('event_city_location ecl', 'ecl.city_location_id = e.city_location', "left")
            ->join('event_file_attachment efa', 'efa.event_id = e.event_id AND efa.status=1 AND efa.attachment_type =1', "left")
            ->where("(eer.email_status = 0 OR (eer.email_status = 3 AND eer.email_number_of_send_attempt <=3))")
            ->where("e.use_email_template",1)
            ->where("ewl.event_schedule_id = eer.event_schedule_id ")
            ->where("eer.email_type_id", 2)
            // ->where("(CASE
            //             WHEN eer.email_sched_reference = 1
            //             THEN 
            //                 (SELECT eeds.email_type_id
            //                 FROM event_email_schedule ees
            //                 LEFT JOIN `event_email_default_setting` eeds 
            //                   ON `eeds`.`email_tpl_setting_id` = `ees`.`reference` 
            //                   AND eeds.email_type_id = 2
            //                 WHERE ees.email_schedule_id = eer.email_sched_reference_id
            //                   AND ees.event_schedule_id = eer.event_schedule_id
            //                   /*AND ees.email_schedule_status= 1*/
            //                 LIMIT 1)
            //             WHEN eer.email_sched_reference = 2
            //             THEN
            //                 (SELECT eeds.email_type_id
            //                 FROM event_email_default_setting eeds
            //                 WHERE eeds.email_tpl_setting_id = eer.email_sched_reference_id
            //                   /*AND eeds.email_tpl_setting_status= 1*/
            //                   AND eeds.email_type_id = 2
            //                 LIMIT 1)
            //         END) = 2")
           // ->where("eer.reference_id IN(
           //     SELECT wait_list_id
           //     FROM event_wait_list
           //     WHERE wait_list_id = eer.reference_id
           //     AND event_id = eer.event_id
           //     AND status = 1
           // )")
            ->where("ewl.wait_list_id = eer.reference_id")
            ->where("ewl.status",1)
            ->where_in("e.back_office_status", array(2,3))
            ->where("es.start_date_time > NOW()")
            ->where("es.remaining_seat >", 0)
            ->where("es.event_status", "AVAILABLE")
            ->group_by("eer.event_schedule_id")
            ->get();

        if ($result->num_rows() > 0) {
            return $result->result();
        }
        return false;
    }

    public function get_waitlists_subscribers($event_schedule_id, $limit){
        $result = $this->db->query("SELECT
            ewl.wait_list_subscriber as subscriber_id,
            eer.reference_id,
            u.email_address,
            CONCAT(u.first_name, ' ', u.last_name) AS subscriber,
            eer.email_recipient_id,
            eer.email_number_of_send_attempt
        FROM
            event_email_recipient eer
        LEFT JOIN event_wait_list ewl 
            ON ewl.event_schedule_id = eer.event_schedule_id 
            AND ewl.wait_list_id = eer.reference_id 
            AND ewl.status=1
        LEFT JOIN user u 
            ON u.user_id = ewl.wait_list_subscriber
        LEFT JOIN event_schedule es 
            ON es.event_schedule_id = eer.event_schedule_id
        LEFT JOIN event e 
            ON e.event_id = es.event_id
        WHERE ewl.status=1
            AND eer.reference_id = ewl.wait_list_id
            AND e.use_email_template = 1  
            AND eer.email_type_id = 2  
            /*AND
                (CASE
                    WHEN eer.email_sched_reference = 1
                    THEN 
                        (SELECT eeds.email_type_id
                        FROM event_email_schedule ees
                        LEFT JOIN `event_email_default_setting` eeds 
                          ON `eeds`.`email_tpl_setting_id` = `ees`.`reference` 
                          AND eeds.email_type_id = 2
                        WHERE ees.email_schedule_id = eer.email_sched_reference_id
                          AND ees.event_schedule_id = eer.event_schedule_id
                          AND ees.email_schedule_status= 1
                        LIMIT 1)
                    WHEN eer.email_sched_reference = 2
                    THEN
                        (SELECT eeds.email_type_id
                        FROM event_email_default_setting eeds
                        WHERE eeds.email_tpl_setting_id = eer.email_sched_reference_id
                        AND eeds.email_tpl_setting_status= 1
                          AND eeds.email_type_id = 2
                        LIMIT 1)
                END) = 2*/
            AND ewl.wait_list_subscriber NOT IN(
                  SELECT er.subscriber
                  FROM event_registration er
                  WHERE er.event_schedule_id = eer.event_schedule_id
                  AND er.subscriber = ewl.wait_list_subscriber
                  AND er.status = 1
              )
            AND (eer.email_status = 0 OR (eer.email_status = 3 AND eer.email_number_of_send_attempt <=3))
            AND eer.event_schedule_id = ?
            AND es.start_date_time >= NOW()
            AND es.remaining_seat > 0
            AND es.event_status = 'AVAILABLE'
            GROUP BY eer.reference_id
            LIMIT 0, $limit", array($event_schedule_id));

        if ($result->num_rows() > 0) {
            return $result->result();
        }
        return false;
    }

    public function get_waitlist_reinvitation_email_data($email_recipient_id, $subscriber){
        $result = $this->db->select("
                e.event_id,
                es.event_schedule_id,
                e.title as event_title,
                es.event_status,
                et.event_type,
                u.email_address,
                ecl.city as city,
                (CASE WHEN e.location IS NULL THEN \"\" ELSE e.location END) as event_place_name,
                (CASE WHEN e.address IS NULL THEN \"\" ELSE e.address END) as event_address,
                (CASE WHEN e.code_postal IS NULL THEN \"\" ELSE e.code_postal END) as event_postal_code,
                es.rate as event_rate,
                ewl.number_of_places as seats_reserved,
                ecl.city as event_venue,
                efa.file_name as event_picture,
                eet.email_tpl_detail,
                e.description as event_description,
                es.start_date_time as event_start_date")
            ->select("DAYNAME(es.start_date_time) AS event_start_day_name", FALSE)
            ->select("DATE_FORMAT(es.start_date_time, '%e') AS event_start_day", FALSE)
            ->select("DATE_FORMAT(es.start_date_time, '%m') AS event_start_month", FALSE)
            ->select("DATE_FORMAT(es.start_date_time, '%M') AS event_start_month_name", FALSE)
            ->select("DATE_FORMAT(es.start_date_time, '%Hh%i') AS event_start_hour", FALSE)
            ->select("DATE_FORMAT(es.start_date_time, '%Y') AS event_start_year", FALSE)
            ->select("CONCAT(u.first_name, ' ', u.last_name) AS subscriber", FALSE)
            // ->select("CONCAT('(', u.email_address, ')') AS email_address", FALSE)
            ->from(" event_email_recipient eer")
            ->join("event_schedule es", "es.event_schedule_id = eer.event_schedule_id", "left")
            ->join("event e", "e.event_id = es.event_id", "left")
            ->join("event_wait_list ewl", "ewl.wait_list_id = eer.reference_id", "left")
            ->join("user u", "u.user_id = ewl.wait_list_subscriber", "left")
            ->join('event_type et', 'et.event_type_id = e.event_type_id',"left")
            ->join('event_email_template eet', 'eet.email_tpl_id = eer.email_tpl_id',"left")
            ->join('event_city_location ecl', 'ecl.city_location_id = e.city_location', "left")
            ->join('event_file_attachment efa', 'efa.event_id = e.event_id AND efa.status=1 AND efa.attachment_type =1', "left")
            ->where("eer.email_status = 1")
            ->where("eer.email_recipient_id", $email_recipient_id)
            ->group_by("eer.event_schedule_id")
            ->get();
        if($result->num_rows() > 0){
            return $result->row();
        }
        return false;
    }
}