<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 

class Mail {

	function send($text, $to, $subject){ 

		require_once 'application/swiftmailer/lib/swift_required.php'; 

		//Create the Transport 
		$transport = Swift_SmtpTransport::newInstance ('smtp.example.com', 465, 'ssl') 
		->setUsername('your username') 
		->setPassword('your password'); 
		
		$mailer = Swift_Mailer::newInstance($transport); 

		//Create a message 
		$message = Swift_Message::newInstance($subject) 
		->setFrom(array('your email' => 'your name')) 
		->setTo($to) 
		->setBody($text); 
		
		//Send the message 
		$result = $mailer->send($message);
	}

}

?>