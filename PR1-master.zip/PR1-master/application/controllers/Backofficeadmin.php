<?php
defined('BASEPATH') OR exit('No direct script access allowed');
include_once (dirname(__FILE__) . "/Main.php");
class BackOfficeAdmin extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
    }

    public function dashboard()
    {
        $this->session_checker->session_filled();
        $data = array(
            'content' => 'backoffice/index',
            'menuItems'=> $this->menuitems->getMenuItems(),
            'nav_menu' => 'backoffice/nav-menu',
            'header' => 'backoffice/header',
            'footer' => 'backoffice/footer',
        );
        $this->load->view('backoffice/template', $data);
    }

    public function company_profile()
    {
        $this->session_checker->session_filled();
        $company_profile = $this->backoffices->get_company($this->session->userdata('org'))->get()->row();
        $error = '';
        $success = false;
        if($this->input->post()){
            $id = $company_profile->user_id;
            $user = $id ? $this->users->get_user_info(['id'=>$id])->row() : null;
            $user_email = $user ? $user->username : null;
            $password = $user ? $user->password : null;
            $input = array(
                'nom'                   =>  $this->input->post('firstname'),
                'prenom'                =>  $this->input->post('lastname'),
                'email_adresse'         =>  $this->input->post('username'),
                'subsidiary'            =>  $this->input->post('subsidiary'),
                'mot_de_passe'          =>  $this->input->post('password') ? sha1($this->input->post('password')) : null,
                'nouveau_mot_de_passe'  =>  $this->input->post('new_password'),
                'adresse'               =>  $this->input->post('address_line1'),
                'code_postal'           =>  $this->input->post('zip_code'),
                'site_web'              =>  $this->input->post('website_url'),
            );
            $rules = array(
                'nom'                   =>  'minlength:2',
                'prenom'                =>  'minlength:2',
                'email_adresse'         =>  'required|valid_email|Invalid email',
                'subsidiary'            =>  'required',
                'mot_de_passe'          =>  'required|NotEqual:' . $password . '|Incorrect password',
                'nouveau_mot_de_passe'  =>  'NotEqual:' . $this->input->post('confirm_password') . '|Les deux mots de passe ne correspondent pas',
                'adresse'               =>  'minlength:4',
                'code_postal'           =>  'numeric',
//                'site_web'              =>  'valid_url|Invali URL format',
            );
            $validator = $this->globalmodel->akeenValidator($input, $rules);
            if($validator){
                $error =
                    array(
                        'result' => $validator
                    );
            }else if($this->users->check_email_existing($this->input->post('username'), $user_email)){
                $error =
                    array(
                        'result' => [[
                            'name'  =>  'username',
                            'error' =>  'Adresse e-mail déjà existant'
                            ]]
                    );
            }else {
                $data = $this->backoffices->submit_company($this->input->post());
                $error = $data;
                if (json_decode($data)->mcontent == 'Success')
                    $success = true;
                else {
                    $error = $data;
                }
            }
            echo ak_return($success, $error);
            die(1);
        }
        $data_company = [
            'id'                =>  $company_profile->id,
            'name'              =>  $company_profile->name,
            'subsidiary'        =>  $company_profile->subsidiary,
            'sector'            =>  $company_profile->sector,
            'num_staff'         =>  $company_profile->num_staff ? $company_profile->num_staff : null,
            'address_line1'     =>  $company_profile->address_line1,
            'zip_code'          =>  $company_profile->zip_code,
            'org_city'          =>  $company_profile->org_city,
            'org_country'       =>  $company_profile->org_country,
            'civility'          =>  $company_profile->civility,
            'lastname'          =>  $company_profile->lastname,
            'firstname'         =>  $company_profile->firstname,
            'function'          =>  $company_profile->function,
            'contact'           =>  $company_profile->contact,
            'username'          =>  $company_profile->username,
        ];
        if($this->uri->segment(3) == 'edit'){
            $data_company['password'] = null;
            $data_company['new_password'] = null;
            $data_company['confirm_password'] = null;
        }
        $data = array(
            'content'   => 'backoffice/admin/companyprofile',
            'menuItems' => $this->menuitems->getMenuItems(),
            'nav_menu'  => 'backoffice/nav-menu',
            'header'    => 'backoffice/header',
            'footer'    => 'backoffice/footer',
            'data'      =>  $data_company,
            'post'      =>  $this->input->post() ? $this->input->post() : null
        );
        $this->load->view('backoffice/template', $data);
    }

    public function company_users()
    {
        $data = array(
            'content' => 'backoffice/admin/company_users',
            'menuItems'=> $this->menuitems->getMenuItems(),
            'nav_menu' => 'backoffice/nav-menu',
            'header' => 'backoffice/header',
            'footer' => 'backoffice/footer',
        );
        $this->load->view('backoffice/template', $data);
    }

    public function get_company_users()
    {
        $company_users = $this->backoffices->get_company_users(null, $this->session->userdata('org'));
        $dtResult = GlobalModel::setDatatable($company_users, array(
            'username',
            'firstname',
            'lastname',
            'email',
            'contact',
            'address',
            'city',
            'country'
            ),
            'id');
        foreach ($dtResult['objResult'] as $aRow) {
            $data = array(
                $aRow->username,
                $aRow->firstname,
                $aRow->lastname,
                $aRow->email,
                $aRow->contact,
                $aRow->country.", ".$aRow->city." ".$aRow->address
            );
            $dtResult['aaData'][] = $data;
        }
        unset($dtResult['objResult']);
        echo json_encode($dtResult);
    }

    public function personalize()
    {
        $data = array(
            'content' => 'backoffice/admin/personalize',
            'menuItems'=> $this->menuitems->getMenuItems(),
            'nav_menu' => 'backoffice/nav-menu',
            'header' => 'backoffice/header',
            'footer' => 'backoffice/footer',
            'personalize' => $this->backoffices->has_logo($this->session->userdata('org')) ? $this->backoffices->has_logo($this->session->userdata('org')) : null
        );
        $this->load->view('backoffice/template', $data);
    }
    public function submit_personalize()
    {
        if($this->input->post()){
            $logo = 'default.png';
            if($_FILES['logo_file']["name"]){
                $logo = json_decode($this->do_upload());
                if($logo->result === true){
                    $logo = $logo->content;
                }else{
                    echo json_encode(['result'=>'error','message'=>$logo->content]);
                }
            }
            $data_personalize = [
                'ord_id' => $this->session->userdata('org'),
                'logo'   => $logo,
                'style'  => json_encode($this->input->post()),
            ];
            if($this->backoffices->has_logo($this->session->userdata('org'))){
                $this->db->where('ord_id', $this->session->userdata('org'));
                $this->db->update('admin_personalize', $data_personalize);
            }else{
                $this->db->insert('admin_personalize',$data_personalize);
            }
            echo json_encode(['result'=>'success','message'=>'Mise à jour avec succès']);
        }
    }
    public function do_upload()
    {
        $id = $this->session->userdata('org');
        $new_filename = "logo_". $id;
        $error = "";
        try {
            if (
                !isset($_FILES['logo_file']['error']) ||
                is_array($_FILES['logo_file']['error'])
            ) {
                $error = 'Invalid parameters.';
            }

            switch ($_FILES['logo_file']['error']) {
                case UPLOAD_ERR_OK:
                    break;
                case UPLOAD_ERR_NO_FILE:
                    $error ='No file sent.';
                    break;
                case UPLOAD_ERR_INI_SIZE:
                case UPLOAD_ERR_FORM_SIZE:
                    $error = 'Exceeded filesize limit.';
                    break;
                default:
                    $error = 'Unknown errors.';
                    break;
            }

            if ($_FILES['logo_file']['size'] > 300000000) {
                $error = 'Exceeded filesize limit.';
            }
            $file_type = array(
                'jpg' => 'image/jpg',
                'jpeg'=> 'image/jpeg',
                'png' => 'image/png',
                'bmp' => 'image/bmp',
            );
            if (!$ext = array_search($_FILES['logo_file']['type'],$file_type))
                $error = 'Invalid file format. Accepted format: jpg, png & bmp';
            if($error)
                return json_encode(['result'=>false,'content'=>$error]);
            $filename = "./uploads/logo/";

            if (!file_exists($filename)) {
                mkdir($filename, 0777);
            }

            if (!move_uploaded_file(
                $_FILES['logo_file']['tmp_name'],
                sprintf('./uploads/logo/%s.%s',
                    $new_filename,
                    $ext
                )
            )) {
                $error = 'Film non téléchargé';
            }
            $return = $new_filename.".".$ext;
            if($error){
                return json_encode(['result'=>false,'content'=>$error]);
            }
            return json_encode(['result'=>true,'content'=>$return]);

        } catch (RuntimeException $e) {
            return $e->getMessage();
        }
    }
}
