<div class="row">
    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 ref_margin">
        <div class="form-group-sm">
            <p class="ref_b">
                En suivant la grille ci-dessous, donnez votre perception de la personne concernée selon ses compétences et des idées d’activités pour l’avenir dans votre entreprise
            </p>
            <p class="ref_b">a. Analyse du CV </p>
            <p class="ref_b">Concernant le CV, l’idée n’est pas de le revoir dans le détail, mais de le parcourir en 2 minutes (temps moyen passé par un DRH ou un Manager opérationnel sur un CV) et de répondre à 3 questions :</p>
            <p>o&nbsp;&nbsp;&nbsp;Ai-je envie de lire le CV ? Oui / Non </p>
            <textarea name="envie" class="ref_textarea" required></textarea>
            <p>o&nbsp;&nbsp;&nbsp;Quels sont les atouts du CV sur le fond et la forme (structure, couleur, photo, caractères,…)?</p>
            <textarea name="atouts" class="ref_textarea" required></textarea>
            <p>o&nbsp;&nbsp;&nbsp;Quels sont les points faibles du CV sur le fond et la forme?</p>
            <textarea name="faibles" class="ref_textarea" required></textarea>
            <br/>
            <br/>
            <br/>
            <p class="ref_b">b. Vision de l’autre  </p>
            <p class="ref_b">En suivant la grille ci-dessous, donnez votre perception de la personne concernée en notant ses compétences de 1 à 6. La seule question à vous poser par ligne est : de votre point de vue, cette personne est-elle bonne pour…. Si vous ne savez pas répondre à une ligne, notez NSP et finalisez ce tableau par des idées de métier, poste, ou activité en interne pour l’avenir. Une colonne vous permet de rajouter un contact qui pourrait aider la personne à mieux appréhender ce métier.</p>
            <table border="1" class="table table-striped"  id="token_nb">
                <thead>
                <tr>
                    <th scope="col">Nb</th>
                    <th scope="col">
                        <div style="left: 209.123px; top: 299.458px; font-size: 18.1774px; font-family: sans-serif; transform: scaleX(0.952341);">Th&eacute;matique</div>
                    </th>
                    <th scope="col">Note de 1 (--) à 6 (++++) NSP</th>
                    <th scope="col">Commentaires</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td>1</td>
                    <td>Capacité d’adaptation et de résolution de problèmes</td>
                    <td><input name="input_1" type="number" min="1" max="6" required></td>
                    <td><textarea name="comment_1" class="r_t"></textarea></td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>Sens de l’organisation/ Gestion de projet </td>
                    <td><input name="input_2" type="number" min="1" max="6" required></td>
                    <td><textarea name="comment_2" class="r_t"></textarea></td>
                </tr>
                <tr>
                    <td>3</td>
                    <td>Capacité de communication / sens des relations interpersonnelles</td>
                    <td><input name="input_3" type="number" min="1" max="6" required></td>
                    <td><textarea name="comment_3" class="r_t"></textarea></td>
                </tr>
                <tr>
                    <td>4</td>
                    <td>Sens des responsabilités (engagement) et du travail bien fait</td>
                    <td><input name="input_4" type="number" min="1" max="6" required></td>
                    <td><textarea name="comment_4" class="r_t"></textarea></td>
                </tr>
                <tr>
                    <td>5</td>
                    <td>Capacité à travailler sous pression </td>
                    <td><input name="input_5" type="number" min="1" max="6" required></td>
                    <td><textarea name="comment_5" class="r_t"></textarea></td>
                </tr>
                <tr>
                    <td>6</td>
                    <td>Force de proposition / créativité / initiative</td>
                    <td><input name="input_6" type="number" min="1" max="6" required></td>
                    <td><textarea name="comment_6" class="r_t"></textarea></td>
                </tr>
                <tr>
                    <td>7</td>
                    <td>Capacité à travailler en collectif</td>
                    <td><input name="input_7" type="number" min="1" max="6" required></td>
                    <td><textarea name="comment_7" class="r_t"></textarea></td>
                </tr>
                <tr>
                    <td>8</td>
                    <td>Accompagnement du changement / formation</td>
                    <td><input name="input_8" type="number" min="1" max="6" required></td>
                    <td><textarea name="comment_8" class="r_t"></textarea></td>
                </tr>
                <tr>
                    <td>9</td>
                    <td>Capacités de management / gestion des conflits</td>
                    <td><input name="input_9" type="number" min="1" max="6" required></td>
                    <td><textarea name="comment_9" class="r_t"></textarea></td>
                </tr>
                <tr>
                    <td>10</td>
                    <td>Leadership / stratégie/ donne du sens </td>
                    <td><input name="input_10" type="number" min="1" max="6" required></td>
                    <td><textarea name="comment_10" class="r_t"></textarea></td>
                </tr>
                <tr>
                    <td>11</td>
                    <td>Energie / ténacité / engagement</td>
                    <td><input name="input_11" type="number" min="1" max="6" required></td>
                    <td><textarea name="comment_11" class="r_t"></textarea></td>
                </tr>
                <tr>
                    <td>12</td>
                    <td>Espace libre</td>
                    <td><input name="input_12" type="number" min="1" max="6" required></td>
                    <td><textarea name="comment_12" class="r_t"></textarea></td>
                </tr>
                </tbody>
            </table>
            <table border="1" class="table table-striped"  id="token_nb_2">
                <thead>
                <tr>
                    <td></td>
                    <td></td>
                    <td>Métier / Poste / activité</td>
                    <td>Option : Contacts suggérés pour en savoir plus</td>
                </tr>
                </thead>
                <tbody>
                    <tr>
                        <td colspan="2">Selon vous, quel métier, poste, activité lui conviendraient le mieux demain en interne à votre entreprise ou votre Groupe? Auriez-vous des contacts à lui suggérer qui pourraient lui plaire selon vous? </td>
                        <td>
                            <p>1. <input type="text" name="activity_1" class="r_t_t_t_r" required></p>

                            <p>2. <input type="text"  name="activity_2" class="r_t_t_t_r" ></p>

                            <p>3. <input type="text"  name="activity_3" class="r_t_t_t_r" ></p>

                            <p>4. <input type="text"  name="activity_4" class="r_t_t_t_r" ></p>

                            <p>5. <input type="text"  name="activity_5" class="r_t_t_t_r" ></p>
                        </td>
                        <td>
                            <p>1. <input type="text"  name="contact_1" class="r_t_t_t_r"> </p>

                            <p>2. <input type="text"  name="contact_2" class="r_t_t_t_r" ></p>

                            <p>3. <input type="text"  name="contact_3" class="r_t_t_t_r" ></p>

                            <p>4. <input type="text"  name="contact_4" class="r_t_t_t_r" ></p>

                            <p>5. <input type="text"  name="contact_5" class="r_t_t_t_r" ></p>
                        </td>
                    </tr>
                </tbody>
            </table>
            <p>&nbsp;</p>

        </div>

    </div>
</div>