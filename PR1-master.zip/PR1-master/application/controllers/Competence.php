<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Competence extends CI_Controller {

    function __construct()
    {
        parent::__construct();
    }
  
    public function add()
    {
      $this->competences->adds();
    }
    public function data()
    {
        $limit = $this->uri->segment(3) ? $this->uri->segment(3) : null;
        $this->competences->datas($limit);
    }
     public function update()
    {
       $this->competences->updates();
    }

}
