<!-- Page Content -->
<div class="container about">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="text-center">Qui sommes-nous ?</h1>
            <br>
            <p class="">AkeeN est une start-up où le web se met au service de la mobilité professionnelle interne des collaborateurs. C’est :</p>
           	<ul class="content-ul">
                <li><span>Une vision : devenir la plateforme référente en matière de mobilité professionnelle interne des collaborateurs</span></li>
            	<li><span>Une cible claire: des collaborateurs, autonomes, responsables et motivés pour prendre en main leur devenir professionnel et définir au sein de leur entreprise un projet professionnel réaliste et en accord avec leurs priorités </span></li>
 				<li><span>Un processus digitalisé, structuré et testé : un cheminement au travers de 10 étapes testé au travers d’une béta version. Des objectifs et instructions données à chaque étape via des vidéos qui permettent d’accompagner efficacement et simplement les parcours. </span></li>
 				<li><span>Un dispositif novateur d’accompagnement personnalisé d’un Collaborateur : un processus de bout en bout, du bilan professionnel et personnel à une ouverture sur un réseau de DRH interne et d’opérationnels qui permet au collaborateur de construire son projet professionnel à son rythme, en toute objectivité et confidentialité.</span></li>
 				<li><span>Une équipe professionnelle et expérimentée : 11 experts de l’accompagnement ayant tous signés la charte déontologique AkeeN appuient notre process d’accompagnement. </span></li>
 				<li><span>Une « passion contagieuse » : nous aimons ce que nous faisons, qui est d’aider les entreprises à favoriser l’engagement de leurs collaborateurs et de permettre à nos accompagnés de se construire un avenir professionnel en accord avec leurs priorités personnelles.</span></li>
            </ul>
            <br>
        </div>
        <div class="col-lg-1">
        	<img src="<?php echo base_url('assets/img/profile.jpg')?>" alt="" class="img-responsive profile-img">
        </div>
        <div class="col-lg-11">
        	<p><strong>Priscilla ChazotMagdelaine</strong> a créé AkeeN pour accompagner la performance de ses clients en utilisant à bon escient trois techniques, le conseil, la formation et le coaching, et en s’appuyant sur ses propres expériences :</p>
        	<br>
        </div>
        <div class="col-lg-12">
        	<br>
        	<ul class="profile">
        		<li><strong>professionnelles</strong> : 6 ans d’audit financier chez Arthur Andersen, 15 ans de conseil dont 13 ans au sein de Capgemini Consulting, et 3 ans en tant que responsable de l’offre finance de SopraConsulting, manager de 20 consultants, plus récemment tutrice, professeur de contrôle de gestion à HEC et coach professionnelle</li>
        		<li><strong>académiques</strong> : un Mastère en finance Gestion à HEC et un diplôme d’Executive Coaching à l’Université de Cergy Pontoise, </li>
        		<li><strong>bénévoles</strong> : Marraine à l’Avarap (gestion d’un groupe de 14 cadres en recherche d’un projet professionnel motivant), membre du Comité Economique et Social d’Asnières-sur-Seine, administrateur du  DUCPEC(Alumni des diplômés de l’Executive Coaching de Cergy Pontoise), organisation d’évènements pour le compte d’HEC-Entreprendre au féminin.</li>
        	</ul>
        	<br>
        	<p>Priscillaa construit ceparcours digitalisé de mobilité professionnelle complet qui permet de faire un bilan professionnel et personnel, un 360, et in fine de construire son projet professionnel.  Elle est aussi en train de rédiger un livre sur la mobilité professionnelle : « Faites votre bilan pour redynamiser votre carrière : A vous de jouer ! » à paraitre en 2017 aux éditions DUNOD.</p>
        </div>        
    </div>
</div>