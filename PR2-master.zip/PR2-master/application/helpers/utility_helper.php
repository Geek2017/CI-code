<?php
	function styles_bundle(){
	   return base_url().'resources/styles/';
	}
	
	function scripts_bundle(){
	   return base_url().'resources/scripts/';
	}

    function plugins_bundle(){
        return base_url().'resources/plugins/';
    }
	
	function images_bundle(){
	   return base_url().'resources/images/';
	}

    function app_bundle(){
        return base_url().'resources/app/';
    }

	function escape($string)
	{
		return htmlspecialchars($string, ENT_QUOTES);
	}

	function makedir($dirpath, $mode=0777)
	{
		return is_dir($dirpath) || mkdir($dirpath, $mode, true);
	}

	function unlink_file($full_path)
	{
		unlink($full_path);
	}
	function fo_bundle()
	{
        return base_url().'resources/frontoffice/';
    }
    function hstroke_bundle()
	{
        return base_url().'resources/images/frontoffice/heart_stroke/';
    }
    function banner_bundle()
	{
        return base_url().'resources/images/frontoffice/banner/';
    }
    function origin_folders($folder_name)
    {
    	
    	switch (  $folder_name   ) {
    		case 'hstroke':
    				return  './resources/images/frontoffice/heart_stroke/';
    			break;
    		
    		case 'banner':
    				return  './resources/images/frontoffice/banner/';
    			break;

            case 'events' : 
    		          return './resources/images/frontoffice/events/';
                break;
            case 'sponsors' : 
                      return './resources/images/frontoffice/sponsors/';
                break;
            default :
    				return  './resources/images/frontoffice/';
    		break;

    		
    	}
    }
?>