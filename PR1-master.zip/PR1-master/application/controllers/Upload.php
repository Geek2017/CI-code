<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Upload extends CI_Controller {

    function __construct()
    {
        parent::__construct();
    }
  
    public function do_upload()
    {
        $type = $this->input->get('type');
        if($type == 'pitch_film')
            echo $this->uploads->save_video($this->session->userdata('id'), $type);
        else {
            if ($this->uploads->save_csv()) {
                echo json_encode(array(
                    'type' => 'success',
                    'msg' => "Votre CV a été téléchargé avec succès"
                ));
            } else{
                echo json_encode(array(
                    'type' => 'error',
                    'msg' => "Quelque chose a mal tournée lors de l'enregistrement du fichier, veuillez essayer à nouveau."
                ));
            }
        }
    }
    public function get_video($id = null)
    {
        $this->uploads->get_video($id, $this->input->post('type'));
    }
    public function get_cv()
    {
       
       $found = $this->uploads->has_resume();
        return array( 
            'filename' => $found['filename'], 
            'path' =>$found['path'],
            'uploadedCsV'  => $found['uploadedCsV']
            ) ;
    
    }
    public function cv()
    {
        $this->session_checker->session_filled();
        $this->session_checker->is_user();
        $cv = $this->get_cv();

        $data = array(
          'content' => 'upload_form',
          'filename' => $cv['filename'] !="" ? '../../uploads/'.$cv['filename'] : "" ,
          'nav_menu' => 'page-nav',
          'user_role' => $this->session->userdata('role'),
          );
        $this->load->view('template', $data);
    }
    public function newcv()
    {
       $this->session_checker->session_filled();
        $this->session_checker->is_user();
        $cv = $this->get_cv();

        $data = array(
          'content' => 'cv',
          'filename' => $cv['filename'] !="" ? '../../uploads/'.$cv['filename'] : "" ,
          'nav_menu' => 'page-nav',
          'user_role' => $this->session->userdata('role'),
          );
        $this->load->view('template', $data);
    }
    public function validate_cv()
    {
       $found = $this->uploads->has_resume();
        echo json_encode( 
          array( 
            'filename' => $found['filename'], 
            'path' =>$found['path'],
            'uploadedCsV'  => $found['uploadedCsV']
            )
        );
    }
    public function section_video_exist()
    {
        echo $this->uploads->get_video( $this->input->post("section_id") ,'section_video');
    }
    public function delete_video_exist()
    {
        $this->uploads->delete_video_exists();
    }

}
