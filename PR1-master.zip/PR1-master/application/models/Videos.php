<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Videos extends CI_Model {

    protected $video = 'video';

    function __construct()
    {
        parent::__construct();
    }
    public function get_section_video($section_id){


    $section_id = $section_id > 0 ? $section_id : 0 ;
    $this->db->where('video.section_id',$section_id)
            ->order_by('id','desc');
    $query = $this->db->get('video');
     if(  $query->row() ){
     	return  $query->row();
     }else{
     	return false;
     }
  
    }
}
?>