<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sections extends CI_Controller {

	function __construct() {
        parent::__construct();
    }

	function section1(){

		$this->session_checker->session_filled();
		$this->session_checker->is_user();
		
		$data = array(
			'content' => 'progress/section-1/section-1',
			'nav_menu' => 'page-nav',
			'sidebar' => 'progress/sidebar',
			'progress' => 'progress/progress-state',
			'user_role' => $this->session->userdata('role')
		);
		$this->load->view('progress/sec-template', $data);
	}
	function result(){

		$this->session_checker->session_filled();
		$this->session_checker->is_user();

		$id = $this->uri->segment(3);
		$this->globalmodel->is_section_allow((int)$id);
		$data = array(
			'data' => $this->questions->get_answers(  $id ),
			'questions' => $this->questions->getAllQuestionsBySection(  $id ),
			'content' => 'progress/section-1/result-1',
			'nav_menu' => 'page-nav',
			'sidebar' => 'progress/sidebar',
			'progress' => 'progress/progress-state',
			'user_role' => $this->session->userdata('role'),
			'percent' => $this->questions->getPercentage($id),
//			'next_item'	=>	$this->questions->getNextItem($this->questions->getSectionByID($id)->row()->id),
			'next_item'	=>	$this->questions->getSectionByID($id + 1)->row() ? $id + 1 : '',
			'view_file' => $this->uploads->view_file(),
			'jobs' => $this->job->get_my_job(),
			'activity' => $this->job->get_my_activity(),
			'savoir' => $this->job->get_my_savoir(),
			'faire' => $this->job->get_my_faire(),
			'etre' => $this->job->get_my_etre(),
		);
		$this->load->view('progress/sec-template', $data);
	}
	function viewresult(){

		$this->session_checker->session_filled();
		$this->session_checker->is_user();
		
		$id = $this->uri->segment(3);
		$this->globalmodel->is_section_allow($id);

		$data = array(
			'data' => $this->questions->get_answers(  $id ),
			'questions' => $this->questions->getAllQuestionsBySection(  $id ),
			'content' => 'progress/section-1/result-1',
//			'content' => 'progress/result/result',
			'nav_menu' => 'page-nav',
			'sidebar' => 'progress/sidebar',
			'progress' => 'progress/progress-state',
			'user_role' => $this->session->userdata('role'),
			'percent' => $this->questions->getPercentage($id),
//			'next_item'	=>	$this->questions->getNextItem($this->questions->getSectionByID($id)->row()->id),
			'next_item'	=>	$this->questions->getSectionByID($id + 1)->row() ? $id + 1 : '',
			'view_file' => $this->uploads->view_file(),
			'jobs' => $this->job->get_my_job(),
			'activity' => $this->job->get_my_activity(),
			'savoir' => $this->job->get_my_savoir(),
			'faire' => $this->job->get_my_faire(),
			'etre' => $this->job->get_my_etre(),
		);
		$this->load->view('progress/sec-template', $data);
	}
	public function result_all(){

		$this->session_checker->session_filled();
		$this->session_checker->is_user();

		$data = array(
			'content' => 'progress/result/result_all',
			'nav_menu' => 'page-nav',
			'sidebar' => 'progress/sidebar',
			'progress' => 'progress/progress-state',
			'user_role' => $this->session->userdata('role'),
			'view_file' => $this->uploads->view_file(),
			'jobs' => $this->job->get_my_job(),
			'activity' => $this->job->get_my_activity(),
			'savoir' => $this->job->get_my_savoir(),
			'faire' => $this->job->get_my_faire(),
			'etre' => $this->job->get_my_etre(),
		);

//		'questions' => $this->questions->getAllQuestionsBySection(  $id ),
//		'data' => $this->questions->get_answers(  $id ),
//		'next_item'	=>	$this->questions->getSectionByID($id + 1)->row() ? $id + 1 : '',
		$this->load->view('progress/result/result-template', $data);

//		$pdfFilePath = FCPATH."/uploads/result/test.pdf";
//
//		$data['page_title'] = 'Hello world'; // pass data to the view
//
//
//		if (file_exists($pdfFilePath) == FALSE)
//
//		{
//
//			ini_set('memory_limit','132M'); // boost the memory limit if it's low ;)
//
//			$html = $this->load->view('progress/result/result-template', $data, true); // render the view into HTML
//
//			$this->load->library('pdf');
//
//			$pdf = $this->pdf->load();
//
//			$pdf->SetFooter($_SERVER['HTTP_HOST'].'|{PAGENO}|'.date(DATE_RFC822)); // Add a footer for good measure ;)
//
//			$pdf->WriteHTML($html); // write the HTML into the PDF
//
//			$pdf->Output($pdfFilePath, 'F'); // save to file because we can
//
//		}

//		redirect("/uploads/result/test.pdf");
	}
	public function fin()
	{
		$this->session_checker->session_filled();
		$this->session_checker->is_user();
		$data = array(
			'token' => '',
			'content' => 'fin',
			'nav_menu' => 'page-nav',
			'user_role' => $this->session->userdata('role')
		);
		$this->load->view('template', $data);
	}
}