<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/* BACK OFFICE MENU */
$lang["menu_dashboard"] = "Tableau de bord";
$lang["menu_events"] = "Événements";
$lang["menu_statistics"] = "Statistiques";
$lang["menu_statistics_subscriber"] = "Les abonnés";
$lang["menu_statistics_emails"] = "Mails";
$lang["menu_system_config"] = "Configuration du système";
$lang["menu_system_config_users_account"] = "Compte utilisateur";
$lang["menu_system_config_city_location"] = "Lieu Ville";
$lang["menu_system_config_event_preference"] = "Préférence d'événement";
$lang["menu_system_config_contact_email"] = "Contact Emial";
$lang["menu_personalization"] = "Personalization";

/* User Profile */
$lang["user_profile"] = "Profil";
$lang["user_logout"] = "Déconnexion";

/* Page Titles */
$lang["page_my_profile"] = "Mon Profil";
$lang["page_users_account_management"] = "Utilisateurs Gestion de compte";
$lang["page_city_location"] = "Lieu Ville";
$lang["page_event_preference"] = "Préférence d'événement";
$lang["page_contact_email"] = "Contact Email";
$lang["page_personalization"] = "Personalisation";

//DASHBOARD WORDINGS
/*
Tableau de bord
- Nombre total de visiteurs
- Nouveaux visiteurs
- Anciens Visiteurs
- Taux de rebond
- Inscriptions par Connexions
- Inscriptions par événements et connexions
- Temps de connexion
- Moy. Temps de connexion
- Nombre de pages visitées par connexions
- Moy. Des pages visitées par connexions
- Utilisateurs
- Journée
- Semaine
- Mois
- Hier
- Les 7 derniers jours
- Les 30 derniers jours
- Ce mois-ci
- Gamme personnalisée
- Appliquer
- Annuler
* Pls. date format : DD/MM/YY
 */
//for statatistics
$lang["dashboard"]["visitors"] = "Visiteurs";
$lang["dashboard"]["number_of_connections"] = "Nombre de connexions";
$lang["dashboard"]["total_visitors"] = "Nombre total de visiteurs";
$lang["dashboard"]["new_visitors"] = "Nouveaux visiteurs";
$lang["dashboard"]["returning_visitors"] = "Anciens Visiteurs";
$lang["dashboard"]["bounce_rate"] = "Taux de rebond";
$lang["dashboard"]["reg_per_con"] = "Inscriptions par Connexions";
$lang["dashboard"]["reg_by_con"] = "Inscriptions par événements et connexions";
$lang["dashboard"]["connection_time"] = "Temps de connexion";
$lang["dashboard"]["avg_connection_time"] = "Moy. Temps de connexion";
$lang["dashboard"]["pageview_by_con"] = "Nombre de pages visitées par connexions";
$lang["dashboard"]["avg_pageview_by_con"] = "Moy. Des pages visitées par connexions";
$lang["dashboard"]["users"] = "Abonnés";

//date range picker
$lang["dashboard"]["day"] = "Journée";
$lang["dashboard"]["week"] = "Semaine";
$lang["dashboard"]["month"] = "Mois";
$lang["dashboard"]["today"] = "Revenir à aujourd'hui";
$lang["dashboard"]["yesterday"] = "Hier";
$lang["dashboard"]["last_7_days"] = "Les 7 derniers jours";
$lang["dashboard"]["last_30_days"] = "Les 30 derniers jours";
$lang["dashboard"]["this_month"] = "Ce mois-ci";
$lang["dashboard"]["last_month"] = "Mois précédent";
$lang["dashboard"]["custom_range"] = "Periode personnalisée";
$lang["dashboard"]["apply"] = "Appliquer";
$lang["dashboard"]["cancel"] = "Annuler";
$lang["dashboard"]["client_id"] = GA_CLIENT_ID;
$lang["dashboard"]["alldata_id"] = GA_CLIENT_ALLDATA_ID;
$lang["dashboard"]["byuser_id"] = GA_CLIENT_BYUSER_ID;

/* End of file main_lang.php */
/* Location: ./application/language/main_lang.php */
