<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$lang["resend_email_modal_title"] = "Resend Email";
$lang["resend_email_firstname"] = "Firstname";
$lang["resend_email_lastname"] = "Lastname";
$lang["resend_email_email"] = "Email";
$lang["resend_email_status"] = "Status";
$lang["resend_email_action"] = "Action";
$lang["resend_email_btn_send"] = "Send";
$lang["resend_email_btn_close"] = "Fermer";


//message sending email 
$lang["resend_email_success"] = "ONQUEUE";
$lang["resend_email_error"] = "Plese select atleast one";