<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/* MY ACCOUNT PAGE */

// Labels
$lang["create_subscriber_account"] = "Créer un compte d'abonné";
$lang["first_name"] = "Prénom";
$lang["last_name"] = "Nom de famille";
$lang["email_address"] = "Adresse e-mail";
$lang["username"] = "Identifiant";
$lang["password"] = "Mot de passe";

// Buttons
$lang["create_account"] = "Créer un compte";

// Alert
$lang["account_created"] = "Client Account Created";