<?php
	//$profile =  $this->uri->segment(2) != null ? $this->uri->segment(2) : "";

	if(isset($dat)){
		$data = (json_decode($dat));
		$rows = $data->total_rows;
		$answered = $data->answered;
	}else{
		$rows = 0;
		$answered = 0;
	} ?>

<?php 
	if ($rows == 0) {
		$s_last = $this->uri->total_segments();
	}else{
		$s_last = $this->uri->total_segments()-1;
	}
	$section_num = $this->uri->segment($s_last);

    $this->db->select('*');
    $this->db->from('section');
    $this->db->where('section_id',$section_num);
    $query = $this->db->get();
    $sec = $query->result();
    $sec = $sec[0];

	$r_last = $this->uri->total_segments()-1;
	$result = $this->uri->segment($r_last);

	if($section_num) { ;
		$Percent_Done = $this->questions->getPercentage_($section_num);
	}
?>
<?php
$model = new Backoffices();
$personalize = $model->has_logo($this->session->userdata('org')) ? $model->has_logo($this->session->userdata('org')) : null;
$color = $personalize ? json_decode($personalize->style) : null;
?>
<style>
	.side-content .chart span {
		<?php echo $color ? 'color:#'.$color->left_menu_text : ''; ?>
	}
</style>
<div class="side-content" style="<?php echo $color ? 'background:#'.$color->left_menu_bg.'; color:#'.$color->left_menu_text : ''; ?>">
	<h3 class="text-center"><?php echo $sec->section_title; ?></h3>
	<hr style="<?php echo $color ? 'border-color:#'.$color->left_menu_text : ''; ?>">

	<?php if($rows == 0 ){ ?>
	<div class="number-q text-center">
		<?php
			if ($result == 'result') {
				echo '<div class="chart progress_bar ss" id="graph" data-percent="100"></div>';
			}else{
				if (isset($Percent_Done)){
					echo '<div class="chart progress_bar ss" id="graph" data-percent="'.$Percent_Done.'"></div>';
				}else{
					echo '<div class="chart progress_bar ss" id="graph" data-percent="0"></div>';
				}
			}
		
			
	?>
	</div>
	<?php }else{ ?>
	<div class="q-number text-center">
		<?php

		$last = $this->uri->total_segments();
		$record_num = $this->uri->segment($last);
		$record_num_orig = $record_num;
		$percentage = ceil($answered / $rows * 100);
		$t_percent = 100/$rows;
		$percent = (int)$t_percent;
		$percentage = $percent*($record_num-1);

		$count_answered = $this->questions->countAnsweredQuestion(floor($section_num), $this->session->userdata('id'));
		$count_questions = $this->questions->count_this('question',floor($section_num));
		/** STATIC CODE */
		if($section_num == 4.2){
			$record_num_ = $record_num;
			$rows = $record_num < 5 ? 4 : 3;
			$record_num = $record_num > 4 ? $record_num - 4 : $record_num;
		}
//		$rows = $section_num == 4.2 && $record_num < 5 ? 4 : ($section_num == 4.2 && $record_num == 5 ? 3 : $rows);
//		$record_num = $section_num == 4.2 && $record_num > 4 ? $record_num - 4 : $record_num;
		?>
		<p class="text-center"><span class="q-count-up"><?php echo $record_num; ?></span>/<span class="q-count-down"><?php echo $rows; ?></span></p>
	</div>
	
	<?php 
			if (isset($Percent_Done)){ // TODO: Clean this code
//				$Percent_Done_ = $Percent_Done;
//				$Percent_Done = $section_num == 4.2 && $record_num_orig > 4 ? $Percent_Done : 100;
//				if($section_num != 4.2)
//					$Percent_Done =  $Percent_Done_;
				echo '<div class="chart progress_bar ss" id="graph" data-percent="'.$Percent_Done.'"></div>';
			}else{
				echo '<div class="chart progress_bar ss" id="graph" data-percent="0"></div>';
			}
	?>
			
	<?php }  ?>

	
</div>
