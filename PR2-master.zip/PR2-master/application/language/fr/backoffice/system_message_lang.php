<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/* BACK OFFICE MENU */
$lang["menu_dashboard"] = "Tableau de bord";

//Events
$lang["menu_events"] = "Événements";
$lang["menu_events_mail"] = "Email d'événement";
$lang["menu_events_reminder"] = "Email de rappel";
$lang["menu_events_waitlist_management"] = "Paramètre liste d'attente";
$lang["menu_event_management"] = "Gestion des événements";

//email
$lang["menu_email"] = "Email";
$lang["menu_email_template"] = "Template Email";
$lang["menu_email_default_setting"] = "Paramètre par défaut";
$lang["menu_email_assign_template"] = "Attribution des Templates";
$lang["menu_email_reminder"] = "Email de Rappel";
$lang["menu_email_waitlist_reinvitation"] = "Waitlist Reinvitation";
$lang["menu_email_push"] = "Push événement";

//Reports
$lang["menu_reports"] = "Rapport";
$lang["menu_reports_export_client_list"] = "Les abonnés";
$lang["menu_reports_export_event_data"] = "Les données de l'événement";
$lang["menu_reports_statistics"] = "Statistiques";
$lang["menu_reports_subscriber"] = "Les abonnés";
$lang["menu_reports_emails"] = "Mails";

//Config
$lang["menu_system_config"] = "Configuration du système";
$lang["menu_system_config_users_account"] = "Compte utilisateur";
$lang["menu_system_config_city_location"] = "Lieu Ville";
$lang["menu_system_config_event_preference"] = "Préférence d'événement";
$lang["menu_system_config_contact_email"] = "Contact Emial";

$lang["menu_personalization"] = "Personalization";

/* User Profile */
$lang["user_profile"] = "Profil";
$lang["user_logout"] = "Déconnexion";

/* Page Titles */
$lang["page_my_profile"] = "Mon Profil";
$lang["page_users_account_management"] = "Gestion de compte d'utilisateur";
$lang["page_city_location"] = "Lieu Ville";
$lang["page_event_preference"] = "Préférence d'événement";
$lang["page_contact_email"] = "Contact Email";

/* End of file main_lang.php */
/* Location: ./application/language/main_lang.php */
