<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Dashboard extends MY_Controller {
    public function __construct() {
        //parent::__construct();
        $this->my_controller_parent_construct();
        $this->check_session_timed_out("bo");
        $this->load_language_backoffice();
        $this->show_page_404(array(1,2), "backoffice");
        $this->clear_cache();
        $this->is_logged_in();

        $this->load->model('event_dashboard_gaoauth_code_model');
    }

    public function get_access_and_refresh_tokens() {
        //status expired
        // 0 = alive, 1 = expired, 3 = no refresh_token
        if (isset($_SESSION['ga_token']) && $_SESSION['ga_token']) {
            $date_now = new DateTime();
            $token_expires_in = new DateTime($_SESSION['ga_token']["access_token_expiration"]);
            //check if token has expired
            if($date_now < $token_expires_in){
                return array("expired" => 0, "tokens" => $_SESSION['ga_token']);
            }
        }
        $oauth_code = $this->event_dashboard_gaoauth_code_model->get_refresh_token();
        if($oauth_code) {
            return array("expired" => 1, "tokens" => $oauth_code);
        } else {
            return array("expired" => 2);
        }
    }

    public function ganalytics() {
        $tokens = $this->get_access_and_refresh_tokens();

        //access_token is still alive
        if($tokens["expired"] == 0) {
            output_to_json($this, array("mtype" => "success", "message" => $tokens["token"]["access_token"],
                "mdetail" => array("servertime" => new DateTime(), "access_token_expiration" => $tokens["token"]["access_token_expiration"])));

        } else if($tokens["expired"] == 1) {

            $new_tokens = $this->exec_get_access_and_refresh_token($tokens["tokens"]["refresh_token"]);

            if($new_tokens["mtype"] == "success"){
                $accessToken = $new_tokens["message"];
                $access_token_expiration = date_modify(new DateTime(), "+" . $accessToken['expires_in'] . "seconds");
                $access_token_expiration_ = $access_token_expiration->format("Y-m-d H:i:s");

                //update the database
                $updated = $this->event_dashboard_gaoauth_code_model->update_access_token($tokens["tokens"]["oauth_code_id"], array("access_token_expiration" => $access_token_expiration_, "access_token" => $accessToken["access_token"]));
                if ($updated) {
                    session_start();
                    $_SESSION['ga_token'] = array("access_token" => $accessToken["access_token"], "access_token_expiration" => $access_token_expiration_);
                    output_to_json($this, array("mtype" => "success", "message" => $accessToken["access_token"],
                        "mdetail" => array("servertime" => new DateTime(), "access_token_expiration" => $access_token_expiration_)));
                } else {
                    output_to_json($this, array("mtype" => "error", "message" => "Reload the page. <a href='".base_url('dashboard/')."'>Please reload the page.</a>"));
                }
            } else {
                //error
                output_to_json($this, $new_tokens);
            }
        } else {
            //sign-in again
            output_to_json($this, array('mtype' => 'signin', 'message' => "Votre connexion à votre compte Google a expiré."));
        }
    }

    public function oauth2callback() {
        if($this->input->post("oauth_code")) {
            $gapi_result = $this->exec_get_refresh_token($this->input->post("oauth_code"));
            if ($gapi_result["mtype"] == "success") {
                $accessToken = $gapi_result["message"];
                $access_token_expiration = date_modify(new DateTime(), "+" . $accessToken['expires_in'] . "seconds");
                $result = $this->event_dashboard_gaoauth_code_model->save_new_oauth_code(array(
                    "user_id" => $this->data["logged_in"]["user_id"],
                    "oauth_code" => $this->input->post("oauth_code"),
                    "access_token" => $accessToken["access_token"],
                    "refresh_token" => $accessToken["refresh_token"],
                    "access_token_expiration" => $access_token_expiration->format("Y-m-d H:i:s"),
                    "status" => 1
                ));
                if ($result) {
                    session_start();
                    $_SESSION['ga_token'] = array("access_token" => $accessToken["access_token"], "access_token_expiration" => $access_token_expiration->format("Y-m-d H:i:s"));
                    output_to_json($this, array("mtype" => "success", "message" => $accessToken["access_token"],
                        "mdetail" => array("servertime" => new DateTime(), "access_token_expiration" => $access_token_expiration->format("Y-m-d H:i:s"))));
                } else {
                    output_to_json($this, array("mtype" => "error", "message" => "Votre connexion à votre compte Google a expiré."));
                }
            } else {
                output_to_json($this, $gapi_result);
            }
        }
    }

    private function exec_get_access_and_refresh_token($refresh_token) {
        $curl = curl_init( "https://accounts.google.com/o/oauth2/token" );
        curl_setopt( $curl, CURLOPT_POST, true );
        curl_setopt( $curl, CURLOPT_POSTFIELDS, array(
            'refresh_token' => $refresh_token,
            'grant_type' => 'refresh_token',
            'client_id' => GA_CLIENT_ID,
            'client_secret' => GA_CLIENT_SECRET
        ));

        curl_setopt( $curl, CURLOPT_RETURNTRANSFER, 1);
        $auth = curl_exec( $curl );
        $auth_message = json_decode($auth);

        if(isset($auth_message->error)){
            return array(
                'mtype' => 'error',
                'message' => 'Error : '.$auth_message->error.((isset($auth_message->error_description))?'. Description : '.$auth_message->error_description:'')
            );
        } else if(isset($auth_message->access_token)) {
            return array(
                'mtype' => 'success',
                'message' => (array) $auth_message
            );
        } else {
            return array(
                'mtype' => 'signin',
                'message' => "Votre connexion à votre compte Google a expiré."
            );
        }
    }

    private function exec_get_refresh_token($get_oauth_code) {
        $curl = curl_init( "https://accounts.google.com/o/oauth2/token" );
        curl_setopt( $curl, CURLOPT_POST, true );
        curl_setopt( $curl, CURLOPT_POSTFIELDS, array(
            'client_id' => GA_CLIENT_ID,
            'client_secret' => GA_CLIENT_SECRET,
            'redirect_uri' => "postmessage",
            'code' => $get_oauth_code, // The code from the previous request
            'grant_type' => 'authorization_code'));

        curl_setopt( $curl, CURLOPT_RETURNTRANSFER, 1);
        $auth = curl_exec( $curl );
        $auth_message = json_decode($auth);
        if(isset($auth_message->error)){
            return array(
                'mtype' => 'error',
                'message' => 'Error : '.$auth_message->error.((isset($auth_message->error_description))?'. Description : '.$auth_message->error_description:'')
            );
        } else if(isset($auth_message->access_token)) {
            return array(
                'mtype' => 'success',
                'message' => (array) $auth_message
            );
        } else {
            return array(
                'mtype' => 'signin',
                'message' => "Votre connexion à votre compte Google a expiré."
            );
        }
    }

    public function gsignout(){
        if($this->input->post("type")){
            $this->event_dashboard_gaoauth_code_model->gsignout_by_user($this->data["logged_in"]["user_id"]);
            output_to_json($this, array("mtype" => "signin", "message" => "Votre connexion à votre compte Google a expiré."));
        } else {
            output_to_json($this, array("mtype" => "signin", "message" => "Votre connexion à votre compte Google a expiré."));
        }
    }
}

//access_token and refresh_token
//https://twittercommunity.com/t/how-to-check-whether-an-access-token-is-expired-or-not/783
//getting access token using refresh_token via curl
//http://stackoverflow.com/questions/30120759/get-access-token-using-refresh-token
//http://stackoverflow.com/questions/34384222/issue-with-google-api-php-client-getting-error-when-running-the-quick-start-scr
//http://stackoverflow.com/questions/19629561/moment-js-set-the-base-time-from-the-server
//https://github.com/auth0/auth0.js
