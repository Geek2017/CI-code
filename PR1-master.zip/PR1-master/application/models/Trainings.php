<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Trainings extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
    public function post_datas()
    {
        //$duree = $this->input->post('opt') == 2 ? true : false;

         $data = array(
            'user_id' => $this->session->userdata('id'),
            'years' => $this->input->post('years'),
            'formation' => $this->input->post('formation'),
            'initial_continue' => $this->input->post('opt'),
            'number_date' => $this->input->post('number_date'),
            'diplome' => $this->input->post('diplome'),
            'type' => $this->input->post('type') ,
            'niveau' => $this->input->post('niveau'),
            'maitrise' => $this->input->post('maitrise'),
            'satisfaction' => $this->input->post('satisfaction'),
            'total' => $this->input->post('total')
        );

         if( !is_numeric( $this->input->post('years') ) )
         {
            echo json_encode( array( 
                'focus' => 'years' , 
                'redirect' => 'false' ,
                'message' => 'Nombre seulement'
                 ) );
         }
         else if( $this->input->post('formation') == null )
         {
            echo json_encode( array( 
                'focus' => 'formation' , 
                'redirect' => 'false' ,
                'message' => 'Formation / Organisme obligatoire'
                 ) );
         }
         else if( $this->input->post('number_date')  == null )
         {
            echo json_encode( array( 
                'focus' => 'number_date' , 
                'redirect' => 'false' ,
                'message' => 'Nombre seulement' 
                ) );
         }
         else if( $this->input->post('diplome') == null  )
         {
            echo json_encode( array( 
                'focus' => 'diplome' , 
                'redirect' => 'false' ,
                'message' => 'Diplome, savoir faire obligatoire' 
                ) );
         }
         else if( $this->input->post('maitrise')  == null )
         {
             echo json_encode( array( 
                'focus' => 'maitrise' , 
                'redirect' => 'false' ,
                'message' => 'La valeur doit être  comprise entre 1 et 4'
                 ) );
         }
         else if( $this->input->post('satisfaction')  == null )
         {
             echo json_encode( array( 
                'focus' => 'satisfaction' , 
                'redirect' => 'false' ,
                'message' => 'La valeur doit être  comprise entre 1 et 4'
                 ) );
         }
         else if( $this->input->post('maitrise') > 4 || $this->input->post('maitrise') < -4)
         {
             echo json_encode( array( 
                'focus' => 'maitrise' , 
                'redirect' => 'false' ,
                'message' => 'La valeur doit être  comprise entre 1 et 4'
                 ) );
         }
         else if( $this->input->post('satisfaction') > 4 || $this->input->post('satisfaction') < -4)
         {
             echo json_encode( array( 
                'focus' => 'satisfaction' , 
                'redirect' => 'false' ,
                'message' => 'La valeur doit être  comprise entre 1 et 4'
                 ) );
         }
         else
         {
            $this->db->insert('training', $data);
            echo json_encode( array( 'redirect' => 'true' ,'message' => 'Enregistré avec succès' ) );
         }
        
    }
    public function update_datas()
    {
         //$duree = $this->input->post('opt') == 2 ? true : false;

         $data = array(
            'years' => $this->input->post('years'),
            'formation' => $this->input->post('formation'),
            'initial_continue' => $this->input->post('opt'),
            'number_date' => $this->input->post('number_date'),
            'diplome' => $this->input->post('diplome'),
            'type' => $this->input->post('type') ,
            'niveau' => $this->input->post('niveau'),
            'maitrise' => $this->input->post('maitrise'),
            'satisfaction' => $this->input->post('satisfaction'),
            'total' => $this->input->post('total')
        );
        
        
         if( !is_numeric( $this->input->post('years') ) )
         {
            echo json_encode( array( 
                'focus' => 'years' , 
                'redirect' => 'false' ,
                'message' => 'Nombre seulement'
                 ) );
         }
         else if( $this->input->post('formation') == null )
         {
            echo json_encode( array( 
                'focus' => 'formation' , 
                'redirect' => 'false' ,
                'message' => 'Formation / Organisme obligatoire'
                 ) );
         }
         else if(  $this->input->post('number_date') == null   )
         {
            echo json_encode( array( 
                'focus' => 'number_date' , 
                'redirect' => 'false' ,
                'message' => 'Nombre seulement' 
                ) );
         }
         else if( $this->input->post('diplome') == null  )
         {
            echo json_encode( array( 
                'focus' => 'diplome' , 
                'redirect' => 'false' ,
                'message' => 'Diplome, savoir faire obligatoire' 
                ) );
         }
         else if( $this->input->post('maitrise')  == null )
         {
             echo json_encode( array( 
                'focus' => 'maitrise' , 
                'redirect' => 'false' ,
                'message' => 'La valeur doit être  comprise entre 1 et 4'
                 ) );
         }
         else if( $this->input->post('satisfaction')  == null )
         {
             echo json_encode( array( 
                'focus' => 'satisfaction' , 
                'redirect' => 'false' ,
                'message' => 'La valeur doit être  comprise entre 1 et 4'
                 ) );
         }
         else if( $this->input->post('maitrise') > 4 || $this->input->post('maitrise') < -4)
         {
             echo json_encode( array( 
                'focus' => 'maitrise' , 
                'redirect' => 'false' ,
                'message' => 'La valeur doit être  comprise entre 1 et 4'
                 ) );
         }
         else if( $this->input->post('satisfaction') > 4 || $this->input->post('satisfaction') < -4)
         {
             echo json_encode( array( 
                'focus' => 'satisfaction' , 
                'redirect' => 'false' ,
                'message' => 'La valeur doit être  comprise entre 1 et 4'
                 ) );
         }
         else
         {
            $this->db->where('id', $this->input->post('id') );
            $this->db->update('training', $data);

            echo json_encode( array( 'redirect' => 'true' ,
                'message' => 'Enregistré avec succès'
                 ) );
         }

       
    }
    public function get_datas()
    {
         $id = $this->session->userdata('id');
         $results = $this->db->query("SELECT * FROM training WHERE user_id='$id' ")->result_array();
         echo json_encode( $results  );
    }
    public function get_datas_initial($initial)
    {
        $id = $this->session->userdata('id');

         
        $results = $this->db->query( "SELECT formation, total FROM `training`  
                WHERE initial_continue = '$initial'
                AND user_id = '$id'
                ORDER BY total DESC
                LIMIT 1" )->result_array();
        echo json_encode( $results  );
    }
    public function get_trainings()
    {
         $id = $this->input->post('id');
         $results = $this->db->query("SELECT * FROM training WHERE id='$id' ")->result_array();
         echo json_encode( $results  );
    }
    public function deletes()
    {
        $this->db->where('id', $this->input->post('id') );
        $this->db->delete('training');
         echo json_encode( array(
                'message' => 'Supprimé avec succès'
            ) );
    }
    public function count_trainings()
    {
        $this->db->where('user_id', $this->session->userdata('id'));
        $query = $this->db->get("training");
       
        echo json_encode( array(
             'count' => $query->num_rows()
            ) );
    }

}

   
  