<?php if ( !defined('BASEPATH')) exit('No direct script access allowed');

class Authentication extends MY_Controller {

    public function __construct()
    {
        //parent::__construct();
        $this->my_controller_parent_construct();
        //load files
        $this->load->helper(array('form'));
        $this->load->model('event_model', '', TRUE);
        $this->load->model('user_model', '', TRUE);
        $this->load->model('user_login_history_model', '', TRUE);
        $this->load->model('user_forgot_password_model', '', TRUE);
    }

    public function index()
    {
        $this->login();
    }

    public function get_system_locale(){
        $_lang_ = array();
        $_lang_["_app"] = $this->lang->line('js');
        if($this->input->post()) {
            if ($this->input->post("data")){
                $which_dir = ($this->input->post("reqtype") == 1) ? "backoffice" : "frontoffice";

                foreach ($this->input->post("data") as $key => $value) {
                    $try_expl = explode("|", $value);
                    $this->lang->load($which_dir . '/' . $try_expl[0], 'fr');

                    if (sizeof($try_expl) > 1) {
                        foreach ($try_expl as $key => $val) {
                            if ($key > 0) {
                                /*Implement for multiple lang*/
                                //$_lang_[$try_expl[0]][$val]=array();
                                //$_lang_[$try_expl[0]][$val] = $this->lang->line($val);
                                $_lang_[$try_expl[0]] = $this->lang->line($val);
                            }
                        }
                    } else {
                        $_lang_[$value] = $this->lang->line($value);
                    }
                }
            }
        }
        output_to_json($this, $_lang_);
    }

    public function auth()
    {
        if(!$this->check_cookie_and_session())
        {
            $this->data['content'] = 'backoffice/login/login_view';
            $this->data['page_title'] = $this->lang->line("login")["bo_login_page_title"];
            $this->data['remember_me'] = $this->remember_me('remember_me_bo', 'bo');
            $this->data['load_scripts'] = array
            (
                "<script src='".app_bundle()."backoffice/login/authentication.js' type='text/javascript'></script>"
            );
            $this->load->view('authentication_view', $this->data);
        }
        else{
            $this->redirect_to_default_page();
        }
    }

    public function login()
    {
        $this->session->unset_userdata('first_logged_in');
        $this->data['content'] = "frontoffice/login/login_view";
        $this->data['page_title'] = $this->lang->line("login")["fo_login_page_title"];
        $this->data['remember_me'] = $this->remember_me('remember_me', '');
        $this->load_extra_files(array(
            "ga" => true
        ));
        array_push($this->data['load_scripts'], "<script src='".app_bundle()."frontoffice/authentication.js' type='text/javascript'></script>");
        if(!$this->check_cookie_and_session()){
            $this->load->view('authentication_view', $this->data);
        }else{
            $this->redirect_to_default_page();
        }
    }
    protected function has_expired_token()
    {
      if(  empty( $this->session->userdata('logged_in') ) || $this->session->userdata('logged_in') == null )
      {
          //alert that 1 time token login has expired
          header('Refresh:3; url= '. base_url('frontoffice/index')); 
          die("1 jeton de temps a expiré!");
      }
    }
    public function auth_token($token = null, $login_by = null)
    {
        $this->has_expired_token();

        if( $this->user_model->token_user_id_exist($token) && isset($login_by) )
        {
            //unset any default sessions
            $this->session->unset_userdata(array( 'logged_in' => array(
                'duration' => '',
                'token_id' => '',
                'logged_in' => '', 
                'login_id' => '', 
                'user_id' => '', 
                'fullname' => '', 
                'role_id' => '', 
                'remember_me' => ''
            ) ));

            //delete any remember me cookie stored remember me is not needed in this 1 time token case
            if (!empty(get_cookie('_L3W0VB3_rememberme'))) 
                delete_cookie('_L3W0VB3_rememberme');

            //get and store user subscriber information
            $match = $this->user_model->authenticate_token($token, array(3));
            $this->data['user_id'] = $match->user_id;
            $this->set_user_data();
            $login_id = $this->user_login_history_model->client_checkdb($this->data, "LOGIN");

            //create new token id
            $access_token = sha1($login_id);

            //Create New Session
            $session_data = array(
                'logged_in' => array(
                    'duration' => time(),
                    'token_id' => $access_token,
                    'login_id' => $login_id,
                    'user_id' => $match->user_id,
                    'fullname' => $match->first_name . " " . $match->last_name,
                    'role_id' => $match->role_id,
                    'LeMondeFO' => 3
                )
            );
            $this->session->set_userdata($session_data);

            //insert token credentials to db as "ACTIVE login state(is_active = 1)"
            $this->user_model->insert_access_token( [
                "subscriber"    => $token,
                "access_token"     =>  $access_token,
                "expiration"      =>  $token,
                "login_by" =>  $login_by,
                "date_login"      =>  date('Y-m-d h:i:s a', time()),
                "date_logout"       =>  '0000-00-00 00:00:00',
                "is_active"        =>  1
            ] );
            //successfull token has been created
            redirect(base_url('frontoffice/index'));
        }else{
            //access has been denied redirect to its referer page
            redirect(base_url('frontoffice/index'));
        }
    }
    public function authenticate()
    {
        $email = $this->input->post('email');
        $password = $this->input->post('password');
        $utype = 0;

        $remembered = ($this->input->post("remember_me") === "true") ? true : false;
        //$match = $this->user_model->authenticate($email, $password, array(3));
        $match = $this->user_model->authenticate_remember_me($email, $password, array(3));
        $check_email = $this->user_model->check_email($email, null, array(3));

        $wss_exec_response = $this->exec_user_auth_wss($email, $password);
        $wss_exec = ($wss_exec_response['ustatus'] === 1)?true:false; //only lemonde user has one (1) ustatus

        /* LOGIN ACCOUNT IS VALID IF,
            case 1 :
                    $match && $wss_exec
                    - if the login account matches with lemonde.fr and this app
            case 2 :
                    $this->check_remember_me_session("remember_me", "", $match) && $match && !$wss_exec
                    - if account was remembered or upon logging in the remembered me checkbox was checked
                    - the login account will not match with WS since the pwd is different
                      yet, still valid cause the account matches with the one in our app
            case 3 :
                    $wss_exec && $check_email
                    - when the user changed his/her pwd from lemonde.fr but not updated the credentials in our app.
        */
        if (($match && $wss_exec) || ($this->check_remember_me_session("remember_me", "", $match) && $match && !$wss_exec) || ($wss_exec && $check_email)) { //1. Lemonde user and subscriber - redirect to homepage of lemonde webapp

            if($wss_exec && $check_email){ //get user info by user email (case 3)
                $match = $this->user_model->get_userinfo_by_email($email, array(3));
            }

            if (!empty(get_cookie('_L3W0VB3_rememberme'))) {
                delete_cookie('_L3W0VB3_rememberme');
            }
            //login
            // User ID, Session ID, IP Address
            $this->data['user_id'] = $match->user_id;
            $this->set_user_data();

            // Update login history
            $login_id = $this->user_login_history_model->client_checkdb($this->data, "LOGIN");

            // Create Session
            $session_data = array(
                'logged_in' => array(
                    'login_id' => $login_id,
                    'user_id' => $match->user_id,
                    'fullname' => $match->first_name . " " . $match->last_name,
                    'role_id' => $match->role_id,
                    'remember_me' => $remembered,
                    'LeMondeFO' => 3
                )
            );
            if($remembered) {
                if ($match->role_id == 3) {
                    $this->session->unset_userdata('remember_me');
                    $this->session->unset_userdata('r_user_id');
                    $this->session->unset_userdata('r_role_id');
                } else {
                    $this->session->unset_userdata('remember_me_bo');
                    $this->session->unset_userdata('rbo_user_id');
                    $this->session->unset_userdata('rbo_role_id');
                }
            } else {
                if ($match->role_id == 3) $this->session->unset_userdata('remember_me');
                else $this->session->unset_userdata('remember_me_bo');
            }
            $this->session->unset_userdata('_l0G4wT9');
            $this->session->set_userdata($session_data);

            $client_session = $this->session->userdata('logged_in');

            //SET COOKIE WHEN REMEMBER ME IS SELECTED
            if ($this->input->post("remember_me") == "true") {
//                $this->remember_me_cookie($match->user_id, $match->role_id, $login_id);
            } else {
                $this->delete_user_cookie();
                delete_cookie('_L3W0VB3_rememberme');
            }

            if (!empty(get_cookie('_L3W0VB3_eventpage'))) {
                $cookie_data = json_decode(get_cookie('_L3W0VB3_eventpage'));
                output_to_json($this, array(
                    "mtype" => "success",
                    "message" => $this->lang->line("login")["login_successful"],
                    "mdata" => array("redirect" => 4, "link" => $cookie_data->event_link) // redirect to event_details page
                ));
                // Code to filet out events based on client's event preference
                /*$preferences = $this->event_model->_get_preferences_query($this->data['user_id']);
                if(in_array($cookie_data->event_type, $preferences)){
                    output_to_json($this, array(
                        "mtype" => "success",
                        "message" => $this->lang->line("login")["login_successful"],
                        "mdata" => array("redirect" => 4, "link" => $cookie_data->event_link) // redirect to event_details page
                    ));
                } else {
                    output_to_json($this, array(
                        "mtype" => "success",
                        "message" => $this->lang->line("login")["login_successful"],
                        "mdata" => array("redirect" => 2) // redirect to events page
                    ));
                }*/
            } else {
                output_to_json($this, array(
                    "mtype" => "success",
                    "message" => $this->lang->line("login")["login_successful"],
                    "mdata" => array("redirect" => 2) // redirect to events page
                ));
            }
        } else if (!$match && $wss_exec) { // NEW ACCOUNT, Redirect to Set Preference Page
            $this->redirect_set_preference($email, $password, $this->input->post("remember_me"));

        } else if ($check_email && !$wss_exec){ // email exists in our database but not on lemonde.fr            
            output_to_json($this, array(
                "mtype" => "error", //error or success or warning or info
                "message" => $this->lang->line("login")["invalid_account_bo"],
                "mdata" => array("redirect" => 0)
            ));
        } else if ($wss_exec_response['ustatus'] === 2){ //2. Lemonde user but not subscribed - redirect to subscription page
            //registration page
            output_to_json($this, array(
                "mtype" => "register", //error or success or warning or info
                "message" => $this->lang->line("login")["account_not_subscribed_yet"],
                "mdata" => array("redirect" => 5)
            ));
        } else if ($match && !$wss_exec) { //invalid username or password
            output_to_json($this, array(
                "mtype" => "error",
                "message" => $this->lang->line("login")["invalid_account_fo"],
                "mdata" => array("redirect" => 0) // Display Invalid credentials
            ));

        } else {
           //!$match && !$wss_exec registration page
            output_to_json($this, array(
                "mtype" => "register", //error or success or warning or info
                "message" => $this->lang->line("login")["not_lemonde_user"],
                "mdata" => array("redirect" => 3)
            ));
        }
    }

    private function redirect_set_preference($email, $password, $remembered)
    {
        //set preference page
        $this->session->unset_userdata('first_logged_in');
        $session_data = array('first_logged_in' => array(
            'email' => $email,
            'subid' => sha1($password),
            "remember_me" => settype($remembered, "boolean")
        ));
        $this->session->set_userdata($session_data);
        
        output_to_json($this, array(
            "mtype" => "error", //error or success or warning or info
            "message" => $this->lang->line("login")["account_activated_redirect_to_preference"],
            "mdata" => array("redirect" => 1)
        ));
    }

    public function verify_login()
    {
        $username = $this->input->post('username');
        $password = $this->input->post('password');
        $utype = $this->input->post("utype");

        //$match = $this->user_model->authenticate($username, $password, array(1,2));
        $match = $this->user_model->authenticate_remember_me($username, $password, array(1,2));
        $remembered = ($this->input->post("remember_me") == "true") ? true : false;

        if($match)
        {
            if($match->status == 1)
            {
                if($match->role_id >= 1 && $match->role_id <= 2)
                {
                    if(!empty(get_cookie('_L3W0VB3_rememberme_bo'))){
                        delete_cookie('_L3W0VB3_rememberme_bo');
                    }
                    // User ID, Session ID, IP Address
                    $this->data['user_id'] = $match->user_id;
                    $this->set_user_data();

                    // Update login history
                    $login_id = $this->user_login_history_model->client_checkdb($this->data, "LOGIN");

                    // Create Session
                    $session_data = array (
                        'logged_in' => array (
                            'login_id' => $login_id,
                            'user_id' => $match->user_id,
                            'fullname' 	=>	$match->first_name." ".$match->last_name,
                            'email_address'  =>	$match->email_address,
                            'role_id' => $match->role_id,
                            'remember_me' => $remembered,
                            'LeMondeBO' =>  1
                        )
                    );

                    if($remembered) {
                        if ($match->role_id == 3) {
                            $this->session->unset_userdata('remember_me');
                            $this->session->unset_userdata('r_user_id');
                            $this->session->unset_userdata('r_role_id');
                        } else {
                            $this->session->unset_userdata('remember_me_bo');
                            $this->session->unset_userdata('rbo_user_id');
                            $this->session->unset_userdata('rbo_role_id');
                        }
                    } else {
                        if ($match->role_id == 3) $this->session->unset_userdata('remember_me');
                        else $this->session->unset_userdata('remember_me_bo');
                    }

                    $this->session->unset_userdata('_l0G4wT9');
                    $this->session->set_userdata($session_data);

                    $client_session = $this->session->userdata('logged_in');


                    //SET COOKIE WHEN REMEMBER ME IS SELECTED
                    if($this->input->post("remember_me") == "true"){
//                        $this->remember_me_cookie($match->user_id, $match->role_id, $login_id);
                    }else{
                        $this->delete_user_cookie();
                    }

                    output_to_json($this, array (
                        "mtype" => "success",
                        "message" => $this->lang->line("login")["login_successful"],
                        "mdata" => array("redirect" => 1) // redirect to events page
                    ));
                } else {
                    output_to_json($this, array(
                        "mtype" => "error", //error or success or warning or info
                        "message" => $this->lang->line("login")["invalid_account_bo"],
                        "mdata" => array("redirect" => 0)
                    ));
                }
            } else {

                output_to_json($this, array(
                    "mtype" => "error", //error or success or warning or info
                    "message" => $this->lang->line("login")["account_deactivated"],
                    "mdata" => array("redirect" => 0)
                ));
            }
        } else {
            output_to_json($this, array(
                "mtype" => "error", //error or success or warning or info
                "message" => $this->lang->line("login")["invalid_account_bo"],
                "mdata" => array("redirect" => 0)
            ));
        }

    }

    private function set_user_data()
    {
        $this->data['session_id'] = $this->session->userdata('session_id');
        $this->data['ip_address'] = $this->input->ip_address();

        // User Agent
        if ($this->agent->is_browser())
        {
            $this->data['agent'] = $this->agent->browser().' '.$this->agent->version();            
        }
        elseif ($this->agent->is_robot())
        {
            $this->data['agent'] = $this->agent->robot();
        }
        elseif ($this->agent->is_mobile())
        {
            $this->data['agent'] = $this->agent->mobile();
            $this->data['device'] = $this->agent->mobile();
        }
        else
        {
            $this->data['agent'] = 'Unidentified User Agent';
        }
        $this->data['platform'] = $this->agent->platform();
    }

    public function client_checkdb($password)
    {
        $email = $this->input->post('email');

        $result = $this->user_model->authenticate($email, $password);

        if($result)
        {
            // Create Session
            $session_data = array (
                'logged_in' => array (
                    'user_id' => $result->user_id,
                    'username' => $result->first_name
                )
            );

            $this->session->set_userdata($session_data);
            session_start();

            $client_session = $this->session->userdata('logged_in');

            // User ID, Session ID, IP Address
            $this->data['user_id'] = $client_session['user_id'];
            $this->set_user_data();

            // Update login history
            $this->user_login_history_model->client_checkdb($this->data, "LOGIN");
            return true;
        }
        else
        {
            $this->form_validation->set_message('client_checkdb', $this->lang->line("login")["forgot_un_pwd"]);
            return false;
        }
    }

// Forgot Password -----------------------------------------------------------------------------------------------------------

    public function forgot_password_bo()
    {
        $this->data['content'] = "backoffice/login/forgotpass_view";
        $this->data['page_title'] = $this->lang->line("login")["bo_login_page_title"];
        $this->data['load_scripts'] = array (
            "<script src='".app_bundle()."backoffice/login/authentication.js' type='text/javascript'></script>",
            "<script src='".app_bundle()."backoffice/login/forgotpass.js' type='text/javascript'></script>"
        );
        $this->load->view('authentication_view', $this->data);
    }

    public function forgotpass_page()
    {
        $this->data['content'] = "frontoffice/login/forgotpass_view";
        $this->data['page_title'] = $this->lang->line("login")["fo_login_page_title"];
        $this->data['load_scripts'] = array (
            "<script src='".app_bundle()."frontoffice/authentication.js' type='text/javascript'></script>",
            "<script src='".app_bundle()."frontoffice/forgotpass.js' type='text/javascript'></script>"
        );
        $this->load->view('authentication_view', $this->data);
    }

    public function check_email()
    {
        $email = $this->input->post('email');
        $user_role = array(3);
        if($this->input->post("type")){
            $user_role = array(1,2);
        }

        $found = $this->user_model->identify_email($email, $user_role);

        if($found)
        {
            $this->send_email($email, $found);
            $result = array(
                "mtype" => "success", //error or success or warning or info
                "message" => $this->lang->line("login")["email_registered"],
                "mdata" => array("r" => $found)
            );
            output_to_json($this, $result);
        }
        else
        {
            $result = array(
                "mtype" => "error", //error or success or warning or info
                "message" => $this->lang->line("login")["email_not_registered"],
                "mdata" => array()
            );
            output_to_json($this, $result);
        }
    }

    private function send_email($to_email, $role_id)
    {
        $this->load->library("swiftmailer_libr");
        $token = random_string('unique');
        $code = substr($token, 0, 10);
        $route_page = ($role_id == 3)?"enter_code_page":"enter_code";
        $message = "";

        $mail_content = array();
        $message .= "<br>Si vous avez oublie&#769; votre mot de passe, veuillez cliquer sur le lien suivant et entrer le code ci-dessous :<br><br>";
        $message .= "<a href='".base_url($route_page)."?email=".$to_email."' target='_blank'>> Changer mon mot de passe <</a><br>";
        $message .= "Code : " . $code;

        $mail_content["logo"] = "http://s1.lemde.fr/mmpub/img/espace-client/logo-lemonde.png";
        $mail_content["description"] = $message;
        $mail_content["reset_code"] = $code;
        $mail_content["open_in_a_newtab"] = true;
        $email_tpl = $this->load->view("backoffice/email_template/forgot_password_tpl", $mail_content, true);

        $email_data = array(
            'recipient' => $to_email,
            'subject' => "LeMonde - ".$this->lang->line("login")["pwd_reset_notif"],
            'message' => $email_tpl
        );

        $swiftmailer_response = $this->swiftmailer_libr->fo_send_email($email_data);

        if($swiftmailer_response["status"]) {
            $this->user_forgot_password_model->send_email($to_email, $code, $role_id);
        }
    }

    //for backoffice
    public function enter_code()
    {
        $this->data['content'] = "backoffice/login/resetcode_view";
        $this->data['page_title'] = $this->lang->line("login")["enter_code"];
        $this->data['load_scripts'] = array (
            "<script src='".app_bundle()."backoffice/login/authentication.js' type='text/javascript'></script>",
            "<script src='".app_bundle()."backoffice/login/forgotpass.js' type='text/javascript'></script>"
        );
        $this->load->view('authentication_view', $this->data);
    }

    //for frontoffice
    public function enter_code_page()
    {
        $this->data['content'] = "frontoffice/login/resetcode_view";
        $this->data['page_title'] = $this->lang->line("login")["enter_code"];
        $this->data['load_scripts'] = array (
            "<script src='".app_bundle()."frontoffice/authentication.js' type='text/javascript'></script>",
            "<script src='".app_bundle()."frontoffice/forgotpass.js' type='text/javascript'></script>"
        );
        $this->load->view('authentication_view', $this->data);
    }

    public function check_code()
    {
        $email = $this->input->post('email');
        $code = $this->input->post('code');

        $match = $this->user_forgot_password_model->check_code($email, $code);

        if($match == 0){
            $result = array(
                "mtype" => "error", //error or success or warning or info
                "message" => $this->lang->line("login")["code_expired"],
                "mdata" => $match
            );
            output_to_json($this, $result);
        }else if($match == 1){
            $result = array(
                "mtype" => "success", //error or success or warning or info
                "message" => $this->lang->line("login")["code_valid"],
                "mdata" => $match
            );
            output_to_json($this, $result);
        }else if ($match == 2){
            $result = array(
                "mtype" => "error", //error or success or warning or info
                "message" => $this->lang->line("login")["code_invalid"],
                "mdata" => $match
            );
            output_to_json($this, $result);
        }else if($match == 3){
            $result = array(
                "mtype" => "error", //error or success or warning or info
                "message" => $this->lang->line("login")["invalid_email"],
                "mdata" => $match
            );
            output_to_json($this, $result);
        }else{
            $result = array(
                "mtype" => "error", //error or success or warning or info
                "message" => $this->lang->line("unknown_error"),
                "mdata" => "NaN"
            );
            output_to_json($this, $result);
        }

    }

    //for frontoffice
    public function reset_password_page()
    {
        $this->data['content'] = "frontoffice/login/resetpassword_view";
        $this->data['page_title'] = $this->lang->line("login")["enter_reset_code"];
        $this->data['load_scripts'] = array (
            "<script src='".app_bundle()."frontoffice/authentication.js' type='text/javascript'></script>",
            "<script src='".app_bundle()."frontoffice/forgotpass.js' type='text/javascript'></script>"
        );
        $this->load->view('authentication_view', $this->data);
    }

    //for backoffice
    public function reset_password()
    {
        $this->data['content'] = "backoffice/login/resetpassword_view";
        $this->data['page_title'] = $this->lang->line("login")["enter_reset_code"];
        $this->data['load_scripts'] = array (
            "<script src='".app_bundle()."backoffice/login/authentication.js' type='text/javascript'></script>",
            "<script src='".app_bundle()."backoffice/login/forgotpass.js' type='text/javascript'></script>"
        );
        $this->load->view('authentication_view', $this->data);
    }

    public function new_password()
    {
        $email = $this->input->post('email');
        $password = $this->input->post('password');
        $user_role = array(3);
        if($this->input->post("type")){
            $user_role = array(1,2);
        }
        $this->user_model->new_password($email, $password, $user_role);
    }

    // Logout
    public function logout($logoutState=1)
    {

        if($this->session->userdata('logged_in')) {
            session_start();
            $client_session = $this->session->userdata('logged_in');

            if( !empty($client_session['token_id']) )
            {
                 $logged_in = $this->data['logged_in'];
                 $access_token = !empty( $client_session['login_id'] ) ? sha1($client_session['login_id']): null;
                 $this->user_model->update_access_token( $access_token );
            }

            // User ID, Session ID, IP Address
            $this->data['user_id'] = $client_session['user_id'];
            $this->data['login_id'] = $client_session['login_id'];
            $this->set_user_data();

            $this->user_login_history_model->client_checkdb($this->data, "LOGOUT");
            $this->session->unset_userdata('logged_in');
            $this->session->unset_userdata('_l0G4wT9');
            if($client_session['role_id'] == 3) $this->session->unset_userdata('remember_me');
            else $this->session->unset_userdata('remember_me_bo');
            $this->session->unset_userdata('first_logged_in');
            $this->delete_user_cookie();
            session_destroy();

            // //check if remember me checkbox is checked before
            // // if(!is_null(get_cookie('_L3W0VB3_userdata')) && !empty(get_cookie('_L3W0VB3_userdata'))) {
            // if($client_session['remember_me']){     
            //     if($client_session["role_id"] == 3) {
            //         $this->session->set_userdata(array('remember_me' => 1, 'r_user_id' => $client_session['user_id'], 'r_role_id' => $client_session["role_id"]));
            //     } else {
            //         $this->session->set_userdata(array('remember_me_bo' => 1, 'rbo_user_id' => $client_session['user_id'], 'rbo_role_id' => $client_session["role_id"]));
            //     } 
            //     // $this->remember_me_credentials($client_session['user_id'], $client_session["role_id"]);
            // }
            // //delete cookie
            // $this->delete_user_cookie();

            // === > Other code
            //delete temp files 
            $this->delete_temporary_attachment($client_session['user_id']);

            //check if remember me checkbox is checked before
            // if(!is_null(get_cookie('_L3W0VB3_userdata')) && !empty(get_cookie('_L3W0VB3_userdata'))) {
            if($client_session['remember_me']){     
                if($client_session["role_id"] == 3) {
                    $this->session->set_userdata(array('remember_me' => 1, 'r_user_id' => $client_session['user_id'], 'r_role_id' => $client_session["role_id"]));
                } else {
                    $this->session->set_userdata(array('remember_me_bo' => 1, 'rbo_user_id' => $client_session['user_id'], 'rbo_role_id' => $client_session["role_id"]));
                } 
                // $this->remember_me_credentials($client_session['user_id'], $client_session["role_id"]);
            }
            //delete cookie
            $this->delete_user_cookie();
            // == >

            //redirection
            if ($client_session["role_id"] == 1 || $client_session["role_id"] == 2) {
                redirect(base_url('auth'));
            } else {
                redirect(base_url(($logoutState==1)?'login':'home'));
            }
            // var_dump('Redirects through if statement');
        }else if(!is_null(get_cookie('_L3W0VB3_userdata')) && !empty(get_cookie('_L3W0VB3_userdata'))){
            $client_session = json_decode(get_cookie('_L3W0VB3_userdata'));
            $this->session->set_userdata(array("remember_me" => 1));
            $this->delete_user_cookie();
            if ($client_session->r_cookie_id == 1 || $client_session->r_cookie_id == 2) {
                redirect(base_url('auth'));
            } else {
                redirect(base_url('login'));
            }
            // var_dump('Redirects through first else if statement');
        } else if($this->session->userdata('first_logged_in')){
            session_start();
            $this->session->unset_userdata('first_logged_in');
            $this->session->unset_userdata('logged_in');
            $this->session->unset_userdata('_l0G4wT9');
            $this->session->unset_userdata('remember_me');
            session_destroy();
            redirect(base_url('home'));
            // var_dump('Redirects through second else if statement');
        } else{
            // var_dump('Redirects through else statement');
            redirect(base_url('home'));
        }
    }

    public function show_session() {
        output_to_json(
            $this, array(
                "sessions" => $this->session->all_userdata()
            )
        );
    }

    public function delete_temporary_attachment($logged_in, $prefix="ea"){
        if(isset($logged_in)) {
            $file_loc = './uploads/';
            $mask = $this->data["logged_in"]["user_id"].$prefix.'_*.*';
            return array_map('unlink', glob($file_loc.$mask));
        } else {
            show_404();
        }
    }

    public function userdata(){
        $this->load->helper('cookie');
        $client_session = $this->session->userdata('logged_in');
        if($this->input->post($remember_me) == "true"){
            $cookie_data = array(
                // 'name'   => ($client_session['role_id'] == 3) ? 'rememberme' : 'rememberme_bo',
                'name' => 'userdata',
                'value'  => json_encode(array(
                    "cookie_id" => $client_session['user_id'],
                    "r_cookie_id" => $client_session['role_id']
                )),
                'expire' => '172800', //2days
                'prefix' => '_L3W0VB3_',
                'domain' => 'localhost'
            );
            $this->input->set_cookie($cookie_data);
        }
    }

    // public function remember_me_cookie($user_id, $role_id, $login_id){
    //     $this->load->helper('cookie');
    //     $this->delete_user_cookie();
    //     $cookie_user_id = array(
    //         'name'   => 'userdata',
    //         'value'  => json_encode(array(
    //             "login_id" => $login_id,
    //             "cookie_id" => $user_id,
    //             "r_cookie_id" => $role_id
    //         )),
    //         'expire' => '172800', //2days
    //         'prefix' => '_L3W0VB3_',
    //         'domain' => $_SERVER['HTTP_HOST']
    //     );
    //     //$this->input->set_cookie($cookie_user_id);
    //     set_cookie($cookie_user_id);

    //     // 'expire' => time() + (86400 * 30),
    //     // 'expire' => strtotime('+ 1 minutes'),
    //     // print_r(json_decode(get_cookie('_L3W0VB3_userdata'))); 
    //     // print_r("Remember Me Cookie made"); exit();
    // }

    public function remember_me_credentials($user_id, $role_id){
        $this->load->helper('cookie');

        $cookie_data = array(
            'name'   => ($role_id == 3) ? 'rememberme' : 'rememberme_bo',
            'value'  => json_encode(array(
                "cookie_id" => $user_id,
                "r_cookie_id" => $role_id
            )),
            'expire' => '172800', //2days
            'prefix' => '_L3W0VB3_',
            'domain' => 'localhost'
        );
        $this->input->set_cookie($cookie_data);
    }

    private function delete_user_cookie(){
        delete_cookie('_L3W0VB3_userdata');
        delete_cookie('_gat');
        delete_cookie('_ga');
    }

    public function create_client_account()
    {
        $this->load->model('user_subscriber_model', '', TRUE);

        $first_name = $this->input->post('first_name');
        $last_name = $this->input->post('last_name');
        $email = $this->input->post('email');
        $username = $this->input->post('username');
        $password = $this->input->post('password');

        $client_id = $this->user_model->create_client_account($first_name, $last_name, $email, $username, $password);
        $this->user_subscriber_model->create_client_account($client_id);

        $result = array(
            "mtype" => "success", //error or success or warning or info
            "message" => $this->lang->line('account_created'),
            "mdata" => array()
        );
        output_to_json($this, $result);
    }

    private function exec_user_auth_wss($email_address, $user_pwd){
        $httpdata = array(
            "mail"  =>  $email_address,
            "password" => $user_pwd,
            "stay_connected" => true //by default
        );
        $httpurl = "http://www.lemonde.fr/sfuser/sfws/auth/login/";
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => $httpurl,
            CURLOPT_RETURNTRANSFER => true,
            CURLINFO_HEADER_OUT => 1,
            CURLOPT_ENCODING => "",
            CURLOPT_HEADER => true,
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => http_build_query($httpdata),
            CURLOPT_HTTPHEADER => array(
                "cache-control: no-cache",
                "content-type: application/x-www-form-urlencoded"
            )
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);

        if ($err) {
            return array("ustatus" => 0);
        } else {
            //check response cookies
            preg_match_all('/^Set-Cookie:\s*([^\r\n]*)/mi', $response, $matches);
            $WSCookies = array();
            foreach($matches[1] as $item) {
                parse_str($item, $_cookie);
                foreach($_cookie as $is_deleted){
                    if(strpos($is_deleted, "deleted") === FALSE){
                        $WSCookies = array_merge($WSCookies, $_cookie);
                    }
                }
            }
            if(count($WSCookies)) {
                /*  1. Lemonde user and subscriber - redirect to homepage of lemonde webapp
                    2. Lemonde user but not subscribed - redirect to subscription page
                    3. Not lemonde user - Redirect sign up page
                 */
                //return $this->authenticate_login_attempt($WSCookies, $response);
                $checker = $this->authenticate_login_attempt($WSCookies, $response);
                $bypass_account = array("cvergara@wylog.com", "cortiz@wylog.com", "lemonde.test1@gmail.com","vclenisa@yahoo.com", "lemonde.test1@gmail.com", "lemondetest2@gmail.com", "lemondetest3@gmail.com");
                if(in_array($this->input->post('email'), $bypass_account) && $checker["ustatus"] == 2){
                    $checker["ustatus"] = 1;
                }
                return $checker;
            } else {
                //need register new account
                return array("ustatus" => 3); //Not lemonde user
            }
        }
    }

    private function authenticate_login_attempt($WSCookies, $response){
        $valid_account = $this->get_curl_response_body($response);
        //if(isset($WSCookies['lmd_a_s']) && isset($WSCookies['lmd_a_sp']) && $valid_account) {
        if(isset($WSCookies['lmd_a_s']) && $valid_account) {
            return array("ustatus" => 1); //Lemonde user and subscriber
        } else if(isset($WSCookies['lmd_a_m']) && $valid_account) {
            return array("ustatus" => 2); //Lemonde user but not subscribed
        }
        return array("ustatus" => 3); //Not lemonde user
    }

    private function get_curl_response_body($response){
        $start = strpos($response, "\r\n\r\n") + 4;
        $body = strtolower(substr($response, $start, strlen($response) - $start));
        if($body === "true") {
            return true;
        }
        return false;
    }
    // REMEMBER ME 
    private function remember_me($session_id, $loc) {
        if($this->session->userdata($session_id)){
            $this->load->model('user_model');
            return $this->user_model->remember_me($this->session->userdata('r'.$loc.'_user_id'), $this->session->userdata('r'.$loc.'_role_id'));
        }
        return array();
    }

    private function check_remember_me_session($session_id, $loc, $match){
        if($this->session->userdata($session_id) && $match){
            $remUserId = $this->session->userdata('r'.$loc.'_user_id');
            $remRoleId = $this->session->userdata('r'.$loc.'_role_id');

            if($remUserId === $match->user_id && $remRoleId === $match->role_id){
                //valid remember me
                return true;
            }
        }
        return false;
    }

//    subscriber login check-BO
	public function subscriber_login_check(){
		$subscriberID = $this->input->post('subcriber');
		$result = $this->user_login_history_model->subscriber_login_status($subscriberID);

		echo json_encode($result);

	}

}


/* End of file authentication.php */
/* Location: ./application/controllers/authentication.php */