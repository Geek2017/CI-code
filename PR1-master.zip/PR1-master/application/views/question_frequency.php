<!-- Page Content -->
<div class="container static">
    <div class="row">
        <div class="col-lg-10 col-lg-offset-1">
         <?php 
            if(isset($user_role)) {
                if($this->session->userdata("lastname") != null){?>
                    <a class="align-left" href="<?php echo site_url('main/progress'); ?>"><img src="<?php echo base_url('assets/img/return.png'); ?>"/> Retour</a>
                        <?php } ?>
                             <?php
                        }else{
                            ?>
                          <a class="align-left" href="<?php echo site_url('main/'); ?>"><img src="<?php echo base_url('assets/img/return.png'); ?>"/> Retour</a>
                             <?php
                        }
                        ?>  
            <h1 class="text-center">Questions fr&#233;quentes </h1>

        	<p><b>0. Comment garantir que le collaborateur ira jusqu&#8217;au bout du parcours ?</b></p>
            <p>AkeeN ne peut rien garantir mais nous mettrons tout en place pour <b>garder la motivation</b> du collaborateur par une &#171; gamification &#187; du profil, une frise d&#8217;avancement et des mails de relance en cas de non connexion durant trois semaines. De plus, des coachs exp&#233;riment&#233;s sont pr&#234;ts &#224; intervenir dans les 72 heures suite &#224; une demande.</p><br>

            <p><b>1. Comment rassurer le collaborateur sur la politique de confidentialit&#233; ?</b></p>
            <p>AkeeN prot&#232;ge la vie priv&#233;e de ses utilisateurs en respectant la l&#233;gislation en vigueur. Ainsi, AkeeN a d&#233;clar&#233; la collecte et le traitement de vos donn&#233;es personnelles aupr&#232;s de la CNIL. La politique de confidentialité a été élaborée pour vous informer au mieux de la politique générale à laquelle AkeeN se soumet pour assurer la protection de vos données personnelles dans le cadre de l'utilisation de son site. Par ailleurs, nous sommes amen&#233;s &#224; modifier r&#233;guli&#232;rement cette politique pour suivre l'&#233;volution de nos services et de vos droits. Toute mise &#224; jour sera visiblement signal&#233;e sur nos pages.</p><br>

            <p><b>2. Si l&#8217;entreprise d&#233;cide de prendre l&#8217;option d&#8217;accompagnement de ses collaborateurs par des coachs, quel dispositif est <br>pr&#233;vu ?
            <p>En option, AkeeN propose plusieurs formules d&#8217;accompagnement :</b><p>

            <ul class="static-dashed">
                <li>Cadres sup&#233;rieurs : 2 heures de coaching</li>
                <li>Cadres et employ&#233;s : 1 heure de coaching </li>
            </ul>

            <ol>
                <li>L’entreprise choisit 3 coachs référents sur la base des 12 coachs AkeeN qui suivent tous la charte déontologique d’AkeeN dont l’obligation de confidentialité.</li>
                <li>Les RH d&#233;cident des collaborateurs qui auront le droit &#224; 1 ou 2 heures de coaching, des identifiants leurs seront affect&#233;s en fonction de leur profil, ce qui permettra &#224; l&#8217;entreprise de suivre ces parcours.</li>
                <li>En d&#233;but de parcours le collaborateur choisit un coach r&#233;f&#233;rent parmi les trois propos&#233;s et lui envoie un mail.<br>
                Les coachs ont alors acc&#232;s &#224; toutes les informations compl&#233;t&#233;es par le collaborateur en toute transparence. Il est d&#8217;ailleurs de son devoir d&#8217;en prendre connaissance avant le RDV pris avec le collaborateur. Le tarif propos&#233; inclut donc le temps de pr&#233;paration et le temps de coaching. </li>
                <li>Une semaine avant le RDV envisag&#233;, le collaborateur envoie  un mail au coach r&#233;f&#233;rent pour fixer un RDV &#224; distance via skype ou webex.</li>
                <li>Les temps de coaching : Dans les 2 cas, AkeeN propose 1 heure lors de l&#8217;&#233;tape Projet professionnel / Pitch et Plan d&#8217;actions, cette heure permettra d&#8217;accompagner la mise en &#339;uvre. En ce qui concerne les cadres sup&#233;rieurs, nous proposons une heure en amont lors de l&#8217;&#233;tape pistes professionnelles pour accompagner le cadre sup&#233;rieur dans le choix de ses trois pistes de r&#233;flexion.</li>
            </ol>
			
        </div>        
    </div>
</div>