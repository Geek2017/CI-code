<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 

class Pagenotfound extends CI_Controller 
{
    public function __construct() 
    {
        parent::__construct(); 
    } 
 
    public function index() { 
        $this->output->set_status_header('404'); 
        
        $data['title'] = "Error - Page Not Found";
        $data['message'] = "
                            Merci de verifier l'URL.

                            Vous pouvez cliquer ici pour être rediriger sur la page d'accueil ";

        $this->load->view('404', $data );
    } 
} 
