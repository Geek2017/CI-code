<?php 
$config['upload_path']          = './uploads/';
$config['allowed_types']        = 'pdf';
$config['max_size']             = 0;
// $config['allowed_types']        = 'gif|jpg|png|pdf';
// $config['max_size']             = 100;
// $config['max_width']            = 1024;
// $config['max_height']           = 768;
?>