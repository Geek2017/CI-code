<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$lang["subscribed"] = "Merci, nous avons bien pris votre réservation en compte.";
$lang["unsubscribed"] = "Merci, nous avons bien pris votre désistement en compte.";
$lang["max_entries"] = "Cet événement a déjà le nombre maximal d'inscriptions.";
$lang["already_registered"] = "Vous êtes déjà inscrit a cette evenement";
$lang["already_cancelled"] = "Vous avez déjà annulé a cette evenement";
$lang["logged_on_another_device"] = "Vous êtes déjà connecté sur la page de cet événement avec un autre terminal mobile ou via un autre navigateur, merci d'utiliser votre session d'origine pour finaliser votre réservation";
$lang["button_not_updated"] = "Le bouton n'est pas mis à jour!";

// Waiting List 
$lang["waiting_list"] = "Il y a encore des places disponibles sur la liste d'attente";
$lang["subscribed_waitlist"] = "Vous vous êtes enregistrés avec succès à la liste d'attente. Un email vous sera envoyé dès qu'une place se libérera.";
$lang["unsubscribed_waitlist"] = "Vous avez annulé votre inscription de la liste d'attente.";
$lang["max_entries_waitlist"] = "Il n'y a plus de places disponibles sur la liste d'attente";

// Mail - Subjects
$lang["subject_book"] = "Confirmation de réservation";
$lang["subject_cancel"] = "Annulation de réservation";
$lang["subject_book_waitlist"] = "Confirmation d'inscription sur liste d'attentee";

// Mail - Closing Remarks
$lang["thank_you_for_your_loyalty"] = "Nous vous remercions de votre fidélité.";
$lang["wish_you_a_pleasant_moment"] = "Nous vous souhaitons un agréable moment.";
$lang["informing_unavailability"] = "Nous vous remercions d'avoir pris le temps de nous informer de votre indisponibilité.";
$lang["best_regards"] = "Bien cordialement,";

// Days
$lang["Sunday"] = "Dimanche";
$lang["Monday"] = "Lundi";
$lang["Tuesday"] = "Mardi";
$lang["Wednesday"] = "Mercredi";
$lang["Thursday"] = "Jeudi";
$lang["Friday"] = "Vendredi";
$lang["Saturday"] = "Samedi";

// Months
$lang["January"] = "Janvier";
$lang["February"] = "Février";
$lang["March"] = "Mars";
$lang["April"] = "Avril";
$lang["May"] = "Mai";
$lang["June"] = "Juin";
$lang["July"] = "Juillet";
$lang["August"] = "Août";
$lang["September"] = "Septembre";
$lang["October"] = "Octobre";
$lang["November"] = "Novembre";
$lang["December"] = "Décembre";
$lang["january"] = "janvier";
$lang["february"] = "février";
$lang["march"] = "mars";
$lang["april"] = "avril";
$lang["may"] = "mai";
$lang["june"] = "juin";
$lang["july"] = "juillet";
$lang["august"] = "août";
$lang["september"] = "septembre";
$lang["october"] = "octobre";
$lang["november"] = "novembre";
$lang["december"] = "décembre";

/* End of file events_lang.php */



