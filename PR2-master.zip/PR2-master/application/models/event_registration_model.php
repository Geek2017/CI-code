<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Event_registration_model extends CI_Model {

	public function __construct() {
		parent::__construct();
	}

	public function check_subscription($user_id, $event_schedule_id)
	{
		$query = $this->db->select('*')
						  ->from('event_registration')
						  ->where('event_schedule_id', $event_schedule_id)
						  ->where('subscriber', $user_id)
						  ->order_by('date_time', 'DESC')
						  ->limit(1)
						  ->get()
						  ->row();

		if(!$query) return false;
		else {
			if($query->status == 0) return false;
			else return true;
		}
	}

	public function register($user_id, $login_id, $event_schedule_id, $user_agent, $seats_reserved, $guest_emails)
	{	
		$remaining_seats = $this->db->select('remaining_seat')
			->from('event_schedule')
			->where('event_schedule_id', $event_schedule_id)
			->get()
			->row();

		if($remaining_seats->remaining_seat < $seats_reserved){
			return false;	
		} 
		else {
      // Check Waitlist first
			$this->load->model('event_wait_list_deregistration_model');
			$check_waitlist = $this->db->select('*')
				->from('event_wait_list')
				->where('wait_list_subscriber', $user_id)
                ->where('event_schedule_id', $event_schedule_id)
				->where('status', 1)
				->get()
				->row();

			if($check_waitlist) $this->event_wait_list_deregistration_model->deregister_waitlist($user_id, $login_id, $event_schedule_id, $user_agent);
			// Register Client
			$this->db->insert('event_registration',
				array(
					'event_schedule_id' => $event_schedule_id,
					'subscriber' => $user_id,
					'number_of_guest' => $seats_reserved-1,
          'user_agent' => $user_agent
				)
			);

      //get the registration id
      $registeredSubcriber = $this->db->insert_id();

      if(!empty($guest_emails)){
          foreach($guest_emails as $email){
              $this->db->insert('event_subscriber_guest',
                  array(
                      'inviter_id' => $user_id,
                      'event_schedule_id' => $event_schedule_id,
                      'email_address' => $email,
                      'status' => 1
                  )
              );
          }
      }

			// Subtract from remaining seats
			// $reserved_seat = 'remaining_seat-'.$seats_reserved;
			// $this->db->set('remaining_seat', $reserved_seat, FALSE);
			// $this->db->where('event_schedule_id', $event_schedule_id);
			// $this->db->update('event_schedule');


       $this->db->query("
          UPDATE event
           SET remaining_seat = (CASE
                  WHEN (remaining_seat - ?) <= 0 THEN 0
                  ELSE (remaining_seat- ?)
                  END)
         WHERE event_id =?", array($seats_reserved, $seats_reserved, $event_id));
       
		}

		// Update event_status and back_office_status
		$check_seats = $this->db->select('remaining_seat, quota_waiting_list_seat')
								->from('event_schedule')
								->where('event_schedule_id', $event_schedule_id)
								->get()
								->row();

    // Update event concurrent process
    $this->db->set('process_status', 0);
    $this->db->where('login_id', $login_id);
    $this->db->where('process_type', 1);
    $this->db->update('event_concurrent_process');

		if($check_seats->remaining_seat <= 0){
			$this->db->where('event_schedule_id', $event_schedule_id);
			if($check_seats->quota_waiting_list_seat <= 0) $this->db->update('event_schedule', array('event_status' => "FULL", 'back_office_status' => 3));
			else $this->db->update('event_schedule', array('event_status' => "FULL"));
		}

		return $registeredSubcriber;
	}

	public function seats_reserved($user_id, $event_schedule_id){
		$query = $this->db->select('number_of_guest')
			->from('event_registration')
			->where('subscriber', $user_id)
			->where('event_schedule_id', $event_schedule_id)
			->where('status', 1)
			->order_by('date_time', 'DESC')
			->limit(1)
			->get();
		$guests = $query->row();
		$seats_reserved = $guests->number_of_guest + 1;
		return $seats_reserved;
	}

    public function get_event_subscribers($event_schedule_id){

        $result = $this->db->query("
         SELECT
          er.date_time as date_registered,
          er.number_of_guest,
          CONCAT(UCASE(LEFT(u.first_name, 1)), SUBSTRING(u.first_name, 2)) AS first_name,
          CONCAT(UCASE(LEFT(u.last_name, 1)), SUBSTRING(u.last_name, 2)) AS last_name,
          u.email_address,
          (CASE
              WHEN u.status = 1 THEN 'Activé'
              ELSE 'Désactivé'
            END) AS status,
          us.mailing_address as address_1, us.location as city,
          us.email_address as sub_email_address, us.telephone_number,
          us.mobile_number, us.subscription_date as subscription_date_op, us.subscriber_id
        FROM
          event_registration er
        LEFT JOIN
          user u ON u.user_id = er.subscriber
        LEFT JOIN
          user_role ur ON u.role_id = ur.role_id
		LEFT JOIN
          user_subscriber us ON us.subscriber = u.user_id
        WHERE
          er.event_schedule_id = ?
        AND
          er.status = 1
        AND
          u.role_id IN(3)", array($event_schedule_id));

        return $result->result();
    }

    public function get_event_subscribers_with_waitlist($event_schedule_id) {
        $result = $this->db->query("
         SELECT
            u.user_id as subscriber_id,
            CONCAT(UCASE(LEFT(u.first_name, 1)), SUBSTRING(u.first_name, 2)) AS first_name,
            CONCAT(UCASE(LEFT(u.last_name, 1)), SUBSTRING(u.last_name, 2)) AS last_name,
            u.email_address,
            (CASE
                 WHEN er.status = 1 THEN 'Confirmé'
                 ELSE 'Confirmé'
                 END
            ) AS reservation_status,
            er.user_agent as navigator,
            DATE_FORMAT(er.date_time, '%e/%m/%Y') as reservation_date,
            DATE_FORMAT(er.date_time, '%Hh%i') as reservation_time,
            (er.number_of_guest + 1) AS total_booked,
            us.mailing_address as address_1, us.location as city,
            us.email_address as sub_email_address, us.telephone_number,
            us.mobile_number, us.subscription_date as subscription_date_op
        FROM
             event_registration er
        LEFT JOIN
          user u ON u.user_id = er.subscriber
        LEFT JOIN
          user_role ur ON u.role_id = ur.role_id
		    LEFT JOIN
          user_subscriber us ON us.subscriber = u.user_id
        WHERE
          er.event_schedule_id = ?
        AND
          er.status = 1
        AND
          u.role_id IN(3)", array($event_schedule_id));

        return $result->result();
    }

    public function get_event_unsubscription($event_schedule_id){
        $result = $this->db->query("
         SELECT
          der.seats_reserve as total_booked,
          der.number_of_place as number_of_place_cancelled,
          CONCAT(UCASE(LEFT(u.first_name, 1)), SUBSTRING(u.first_name, 2)) AS first_name,
          CONCAT(UCASE(LEFT(u.last_name, 1)), SUBSTRING(u.last_name, 2)) AS last_name,
          u.email_address,
          der.user_agent as navigator,
          DATE_FORMAT(er.date_time, '%e/%m/%Y') as reservation_date,
          DATE_FORMAT(er.date_time, '%Hh%i') as reservation_time,
          DATE_FORMAT(der.date_time, '%e/%m/%Y') as date_of_cancellation,
          DATE_FORMAT(der.date_time, '%Hh%i') as time_of_cancellation,
          us.mailing_address as address_1, us.location as city,
          us.email_address as sub_email_address, us.telephone_number,
          us.mobile_number, us.subscription_date as subscription_date_op,
          us.subscriber_id
        FROM
          event_deregistration der
        LEFT JOIN
          event_registration er ON er.registration_id = der.registration_id
        LEFT JOIN
          user u ON u.user_id = der.subscriber
        LEFT JOIN
          user_role ur ON u.role_id = ur.role_id
		    LEFT JOIN
          user_subscriber us ON us.subscriber = u.user_id
        WHERE
          der.event_schedule_id = ?
        AND
          u.role_id IN(3)", array($event_schedule_id));

        return $result->result();
    }

    public function get_event_waitlist($event_schedule_id){
        $result = $this->db->query("
         SELECT
          ewl.number_of_places as total_booked,
          CONCAT(UCASE(LEFT(u.first_name, 1)), SUBSTRING(u.first_name, 2)) AS first_name,
          CONCAT(UCASE(LEFT(u.last_name, 1)), SUBSTRING(u.last_name, 2)) AS last_name,
          u.email_address,
          ewl.user_agent as navigator,
          DATE_FORMAT(ewl.date_time, '%e/%m/%Y') as reservation_date,
          DATE_FORMAT(ewl.date_time, '%Hh%i') as reservation_time,
          us.mailing_address as address_1, us.location as city,
          us.email_address as sub_email_address, us.telephone_number,
          us.mobile_number, us.subscription_date as subscription_date_op, us.subscriber_id
        FROM
          event_wait_list ewl
        LEFT JOIN
          user u ON u.user_id = ewl.wait_list_subscriber
        LEFT JOIN
          user_role ur ON u.role_id = ur.role_id
		LEFT JOIN
          user_subscriber us ON us.subscriber = u.user_id
        WHERE
          ewl.event_schedule_id = ?
        AND
          ewl.status = 1
        AND
          u.role_id IN(3)", array($event_schedule_id));

        return $result->result();
    }

    public function filter_reservations($user_id, $month, $city)
    {
      	$query = $this->db->query('
          SELECT
            e.title,
      			er.date_time,
      			er.number_of_guest
          FROM event e
          LEFT JOIN event_schedule es ON es.event_id = e.event_id
          LEFT JOIN event_registration er ON er.event_schedule_id = es.event_schedule_id
          WHERE er.status = 1 AND er.subscriber = '.$user_id
      	);

        return $query->result();
    }

    public function prepare_list_for_reimnder_email($email_schedule, $event){
        /*
          Email key will be used to get the group of recipient ids in one single query
          which will also be used to insert into the table "event_email_recipient_other_detail"
          to get the exact id and exact connection.
        */
        $email_key = "1E".generate_random_keys(8);

        $this->db->query("INSERT INTO
          event_email_recipient(event_schedule_id, email_type_id, email_key, reference_id)
            (SELECT ?, ?, ?, er.registration_id
            FROM event_registration er
            WHERE er.registration_id
              NOT IN( SELECT eer.reference_id
                      FROM event_email_recipient eer
                      LEFT JOIN event_email_recipient_other_detail eerod
                        ON eerod.email_recipient_id = eer.email_recipient_id
                      WHERE eer.email_type_id = 1
                      AND eerod.email_sched_reference_id = ?
                      AND eerod.email_sched_reference = ?
                      AND eer.email_status IN(1, 0, 5)
                      AND eer.event_schedule_id = ? 
                    )
              AND er.status = 1
              AND er.event_schedule_id= ? )",
            array($event->event_schedule_id,
              1, //email_type_id for reminder email
              $email_key,
              $email_schedule->email_schedule_id, 
              $email_schedule->email_sched_reference, 
              $event->event_schedule_id, 
              $event->event_schedule_id)
            );
            //insert into other details table
            $this->db->query("INSERT INTO event_email_recipient_other_detail(email_sched_reference_id, email_sched_reference, email_recipient_id)
              (SELECT ?, ?, email_recipient_id
              FROM event_email_recipient eer
              WHERE eer.email_type_id = ?
              AND eer.email_key = ?
              AND eer.event_schedule_id= ? )",
            array($email_schedule->email_schedule_id, 
              $email_schedule->email_sched_reference,              
              1, //email_type_id for reminder email
              $email_key,
              $event->event_schedule_id)
            );
        return $this->db->affected_rows();
    }

    public function get_data_reminder_email_list(){
        $result = $this->db->select("
                er.event_schedule_id,
                es.event_id,
                e.title as event_title,
                es.event_status,
                et.event_type,
                e.description as event_description,
                ecl.city as city,
                (CASE WHEN e.location IS NULL THEN \"\" ELSE e.location END) as event_place_name,
                (CASE WHEN e.address IS NULL THEN \"\" ELSE e.address END) as event_address,
                (CASE WHEN e.code_postal IS NULL THEN \"\" ELSE e.code_postal END) as event_postal_code,
                es.rate as event_rate,
                (er.number_of_guest+1) as seats_reserved,
                ecl.city as event_venue,
                efa.file_name as event_picture")
            ->select("DAYNAME(es.start_date_time) AS event_start_day_name", FALSE)
            ->select("DATE_FORMAT(es.start_date_time, '%e') AS event_start_day", FALSE)
            ->select("DATE_FORMAT(es.start_date_time, '%m') AS event_start_month", FALSE)
            ->select("DATE_FORMAT(es.start_date_time, '%M') AS event_start_month_name", FALSE)
            ->select("DATE_FORMAT(es.start_date_time, '%Y') AS event_start_year", FALSE)
            ->select("DATE_FORMAT(es.start_date_time, '%Hh%i') AS event_start_hour", FALSE)
            ->select("DATE_FORMAT(es.start_date_time, '%Y-%m-%e %H:%i:%s') AS event_start_date_time", FALSE)
            ->from(" event_email_recipient eer")
            ->join("event_schedule es", "es.event_schedule_id = eer.event_schedule_id", "left")
            ->join("event e", "e.event_id = es.event_id", "left")
            ->join("event_registration er", "er.event_schedule_id = eer.event_schedule_id AND er.registration_id = eer.reference_id", "left")
            ->join('event_type et', 'et.event_type_id = e.event_type_id',"left")
            ->join('event_city_location ecl', 'ecl.city_location_id = e.city_location', "left")
            ->join('event_file_attachment efa', 'efa.event_id = e.event_id AND efa.status=1 AND efa.attachment_type =1', "left")
            ->join('event_email_recipient_other_detail eerod', 'eerod.email_recipient_id = eerod.email_recipient_id', "left")
            ->where("(eer.email_status = 0 OR (eer.email_status = 3 AND eer.email_number_of_send_attempt <=3))")
            ->where("er.registration_id = eer.reference_id")
            ->where("er.status",1)
            ->where("e.use_email_template",1)
            ->where("eer.email_type_id",1)
            ->where("(CASE
                  WHEN eerod.email_sched_reference = 1
                  THEN (SELECT ees.email_schedule_date
                        FROM event_email_schedule ees
                        LEFT JOIN `event_email_default_setting` eeds 
                          ON `eeds`.`email_tpl_setting_id` = `ees`.`reference` 
                          AND eeds.email_type_id = 1
                        WHERE ees.email_schedule_id = eerod.email_sched_reference_id
                          AND ees.event_schedule_id = eer.event_schedule_id 
                          /*AND ees.email_schedule_status= 1*/
                          AND ees.email_schedule_date <= NOW()
                          ORDER BY ees.email_schedule_date ASC
                        LIMIT 1)
                  WHEN eerod.email_sched_reference = 2
                        THEN (SELECT (CASE
                          WHEN eeds.email_tpl_setting_sched_by = 'HOURS' 
                            THEN DATE_SUB(es.start_date_time, INTERVAL email_tpl_setting_sched HOUR)
                          WHEN eeds.email_tpl_setting_sched_by = 'DAYS' 
                            THEN DATE_SUB(es.start_date_time, INTERVAL email_tpl_setting_sched DAY)
                          ELSE DATE_SUB(es.start_date_time, INTERVAL email_tpl_setting_sched MINUTE)
                        END) as email_schedule_date
                        FROM event_email_default_setting eeds
                        WHERE eeds.email_type_id = 1 
                          AND eeds.email_tpl_setting_id = eerod.email_sched_reference_id
                          /*AND eeds.email_tpl_setting_status= 1*/
                          AND
                          (CASE
                            WHEN eeds.email_tpl_setting_sched_by = 'HOURS' 
                              THEN DATE_SUB(es.start_date_time, INTERVAL email_tpl_setting_sched HOUR)
                            WHEN eeds.email_tpl_setting_sched_by = 'DAYS' 
                              THEN DATE_SUB(es.start_date_time, INTERVAL email_tpl_setting_sched DAY)
                            ELSE DATE_SUB(es.start_date_time, INTERVAL email_tpl_setting_sched MINUTE)
                          END) <= NOW()
                        LIMIT 1)
                END) <= NOW()
            ")
//            ->where("eer.reference_id IN(
//                SELECT registration_id
//                FROM event_registration
//                WHERE registration_id = eer.reference_id
//                AND event_schedule_id = eer.event_schedule_id
//                AND status = 1
//            )")
            ->where_in("es.back_office_status", array(2,3))
            ->where("es.start_date_time >= NOW()")
            ->group_by("eer.event_schedule_id")
            ->get();

        if ($result->num_rows() > 0) {
            return $result->result();
        }
        return false;
    }

    public function get_event_subscribers_list($event_start_date_time, $event_schedule_id, $limit=100){
        $result = $this->db->query("SELECT
            eer.event_schedule_id,
            er.subscriber as subscriber_id,
            eer.reference_id,
            u.email_address,
            CONCAT(u.first_name, ' ', u.last_name) AS subscriber,
            eer.email_recipient_id,
            eer.email_number_of_send_attempt
        FROM
            event_email_recipient eer
        LEFT JOIN event_registration er 
          ON er.event_schedule_id = eer.event_schedule_id 
          AND er.registration_id = eer.reference_id
        LEFT JOIN user u 
          ON u.user_id = er.subscriber
        LEFT JOIN event_schedule es 
          ON es.event_schedule_id = eer.event_schedule_id
        LEFT JOIN event e 
          ON e.event_id = es.event_id
        LEFT JOIN event_email_recipient_other_detail eerod
          ON eer.email_recipient_id = eerod.email_recipient_id
        WHERE
              eer.reference_id = er.registration_id
            AND
              e.use_email_template = 1  
            AND
              er.status = 1
            AND 
              eer.email_type_id = 1  
            AND
              (eer.email_status = 0 OR (eer.email_status = 3 AND eer.email_number_of_send_attempt <=3))
            AND
              eer.event_schedule_id = ".$event_schedule_id."

            AND CONCAT(eerod.email_sched_reference_id,'_',eerod.email_sched_reference) 
            IN(
                SELECT CONCAT(eeds.email_tpl_setting_id,'_',2)
                FROM event_email_default_setting eeds
                WHERE eeds.email_type_id = 1
                AND eeds.email_tpl_setting_status = 1
                AND (CASE
                      WHEN eeds.email_tpl_setting_sched_by = 'HOURS' 
                        THEN DATE_SUB('".$event_start_date_time."', INTERVAL eeds.email_tpl_setting_sched HOUR)
                      WHEN eeds.email_tpl_setting_sched_by = 'DAYS' 
                        THEN DATE_SUB('".$event_start_date_time."', INTERVAL eeds.email_tpl_setting_sched DAY)
                      ELSE DATE_SUB('".$event_start_date_time."', INTERVAL eeds.email_tpl_setting_sched MINUTE)
                    END) <= NOW()
                AND eeds.email_tpl_setting_id NOT IN
                    (
                      SELECT ees.reference
                      FROM event_email_schedule ees
                      WHERE ees.event_schedule_id = ".$event_schedule_id."
                      AND ees.event_schedule_id = eer.event_schedule_id
                      AND ees.email_schedule_status=1
                      GROUP BY ees.reference
                    )
                UNION

                  SELECT CONCAT(ees.email_schedule_id,'_',1)
                  FROM `event_schedule` es
                  LEFT JOIN `event_email_schedule` ees ON `ees`.`event_schedule_id` = `es`.`event_schedule_id`
                        AND ees.email_schedule_status=1
                  LEFT JOIN `event_email_default_setting` eeds ON `eeds`.`email_tpl_setting_id` = `ees`.`reference`
                        AND eeds.email_type_id = 1
                  WHERE `es`.`event_schedule_id` = '".$event_schedule_id."' 
                      AND es.start_date_time >= NOW()
                      AND es.back_office_status IN(2,3)
                      AND ees.email_schedule_date <= NOW()
              )
              AND es.start_date_time >= NOW()
              AND es.back_office_status IN(2,3)
              GROUP BY eer.reference_id
              LIMIT 0,".$limit);

        //AND e.remaining_seat > 0
        //AND e.event_status = 'AVAILABLE'

        if ($result->num_rows() > 0) {
            return $result->result();
        }
        return false;
    }

    public function get_reminder_email_data($email_recipient_id, $subscriber){
        $result = $this->db->select("
                eer.event_schedule_id,
                e.event_id,
                e.title as event_title,
                et.event_type,
                es.event_status,
                u.email_address,
                ecl.city as city,
                (CASE WHEN e.location IS NULL THEN \"\" ELSE e.location END) as event_place_name,
                (CASE WHEN e.address IS NULL THEN \"\" ELSE e.address END) as event_address,
                (CASE WHEN e.code_postal IS NULL THEN \"\" ELSE e.code_postal END) as event_postal_code,
                es.rate as event_rate,
                (er.number_of_guest+1) as seats_reserved,
                ecl.city as event_venue,
                efa.file_name as event_picture,
                eet.email_tpl_detail,
                e.description as event_description,
                es.start_date_time as event_start_date")
            ->select("DAYNAME(es.start_date_time) AS event_start_day_name", FALSE)
            ->select("DATE_FORMAT(es.start_date_time, '%e') AS event_start_day", FALSE)
            ->select("DATE_FORMAT(es.start_date_time, '%m') AS event_start_month", FALSE)
            ->select("DATE_FORMAT(es.start_date_time, '%Hh%i') AS event_start_hour", FALSE)
            ->select("DATE_FORMAT(es.start_date_time, '%Y') AS event_start_year", FALSE)
            ->select("DATE_FORMAT(es.start_date_time, '%M') AS event_start_month_name", FALSE)
            ->select("CONCAT(u.first_name, ' ', u.last_name) AS subscriber", FALSE)
            // ->select("CONCAT('(', u.email_address, ')') AS email_address", FALSE)
            ->from(" event_email_recipient eer")
            ->join("event_schedule es", "es.event_schedule_id = eer.event_schedule_id", "left")
            ->join("event e", "e.event_id = es.event_id", "left")
            ->join("event_registration er", "er.registration_id = eer.reference_id", "left")
            ->join("user u", "u.user_id = er.subscriber", "left")
            ->join('event_type et', 'et.event_type_id = e.event_type_id',"left")
            ->join('event_email_template eet', 'eet.email_tpl_id = eer.email_tpl_id',"left")
            ->join('event_city_location ecl', 'ecl.city_location_id = e.city_location', "left")
            ->join('event_file_attachment efa', 'efa.event_id = e.event_id AND efa.status=1 AND efa.attachment_type =1', "left")
            ->where("eer.email_status = 1")
            ->where("eer.email_recipient_id", $email_recipient_id)
            ->group_by("eer.event_schedule_id")
            ->get();
        if($result->num_rows() > 0){
            return $result->row();
        }
        return false;
    }
}