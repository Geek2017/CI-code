<nav class="navbar navbar-default navbar-fixed-top" role="navigation" id="admin_nav">
	<div class="container">
		<div class="row">
		<br>
		<a href="<?php echo site_url() ?>">
        <img src="<?php echo base_url('assets/img/logo_blue.png'); ?>"  class="modal-logo img-responsive" alt="Akeen logo"/>
        </a>
        </div>
	</div>

		<ul class="nav navbar-nav">

	</ul>
</nav>
<div class="wraper">

<input type="hidden" id="base_url" value="<?php echo ak_url(); ?>" >

<div id="mySidenav" class="sidenav">
	<?php
	/**
	 * To add menu go to MenuItemsModel->MenuItem()
	 */

	$active =  "";
	$auth = new Menuitems();
	$menuItems = $auth->getMenuItems();  ?>
	<?php if (!empty($menuItems)): ?>
		<?php foreach($menuItems as $menuCategory => $menu): ?>
			<?php if(!empty($menu)):  ?>
				<?php foreach($menu as $i => $menuItem) :  
				 $active =   stripos($menuItem['url'],  $this->uri->segment(2) )  ? "style='background-color:#2e6596;'" : "";
				 ?>
					<?php if(is_array($menuItem) && array_key_exists('url',$menuItem)): ?>
						<a <?php echo $active; ?> href="<?php echo stripos($menuItem['url'],"logout") ? '#' : $menuItem['url']; ?>" <?php echo stripos($menuItem['url'],"logout") ? "onclick='Auth.logout()'" : '' ?>><?php echo htmlspecialchars($menuItem['name']) ?></a>
					<?php endif; ?>
				<?php  endforeach; ?>
			<?php endif; ?>
		<?php  endforeach; ?>
	<?php endif ?>
</div>


