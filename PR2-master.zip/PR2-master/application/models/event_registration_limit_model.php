<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Event_registration_limit_model extends CI_Model {

 	protected $table = "event_registration_limit";

	public function __construct() {
        parent::__construct();

        $this->all = "*";
    }

    public function limit_exist($subscriber_id)
    {
    	$this->db->select($this->all);
    	$this->db->where("subscriber_id" , $subscriber_id );
    	$result = $this->db->get($this->table);
        if($result->num_rows() > 0)
            return false; //add limit
        else 
        	return true;// edit limit
    }
    public function get_limits()
    {
    	$this->db->select($this->all);
    	$this->db->where("subscriber_id" , $this->input->post("subscriber_id") );
    	$result = $this->db->get($this->table);
        if($result->num_rows() > 0)
            return array_shift( $result->result_array() );
    }
    public function add_limits( $limit_details )
    {
    	$this->db->insert($this->table, $limit_details);
        return $this->db->insert_id();
    }
    public function put_limits( $subscriber_id, $limit_details )
    { 
        $this->db->where("subscriber_id", $subscriber_id );
        $update = $this->db->update($this->table, $limit_details);
        return $this->db->insert_id();
    }
}