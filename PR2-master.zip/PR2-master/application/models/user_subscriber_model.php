<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class User_subscriber_model extends CI_Model {

	public function __construct() {
		parent::__construct();
	}

    public function add_subscriber_data($data){
        $this->db->insert('user_subscriber', $data);
        return $this->db->insert_id();
    }

	public function setPreferences($user_id, $location, $mail, $email, $tel, $mobile)
	{
		$settings = array(
			'location' => $location,
			'mailing_address' => $mail,
			'email_address' => $email,
			'telephone_number' => $tel,
			'mobile_number' => $mobile
		);
		$this->db->where('subscriber', $user_id);
		$this->db->update('user_subscriber', $settings);
	}

	public function myaccount($user_id)
	{
		$query = $this->db->select('*')
						  ->from('user_subscriber')
						  ->where('subscriber', $user_id)
						  ->get();

		return $query->row();
	}

	public function update_location($user_id, $login_id)
	{
		$location = $this->input->post('location');

		$update = array('location' => $location);
		$this->db->where('subscriber', $user_id);
		$this->db->update('user_subscriber', $update);

		$this->unlock_action(5, $login_id); // unlock action
	}

	public function update_mail($user_id, $login_id)
	{
		$mail = $this->input->post('mail');

		$update = array('mailing_address' => $mail);
		$this->db->where('subscriber', $user_id);
		$this->db->update('user_subscriber', $update);

		$this->unlock_action(6, $login_id); // unlock action
	}
	
	public function update_email($user_id, $login_id)
	{
		$email = $this->input->post('email');

		$update = array('email_address' => $email);
		$this->db->where('subscriber', $user_id);
		$this->db->update('user_subscriber', $update);

		$this->unlock_action(7, $login_id); // unlock action
	}

	public function update_telephone($user_id, $login_id)
	{
		$telephone = $this->input->post('telephone');
		if($telephone == 0 || $telephone == '') $this->db->set('telephone_number', 'NULL', false);
		else $this->db->set('telephone_number', $telephone);
		$this->db->where('subscriber', $user_id);
		$this->db->update('user_subscriber');

		$this->unlock_action(8, $login_id); // unlock action
	}

	public function update_mobile($user_id, $login_id)
	{
		$mobile = $this->input->post('mobile');
		if($mobile == 0 || $mobile == '') $this->db->set('mobile_number', 'NULL', false);
		else $this->db->set('mobile_number', $mobile);
		// $update = array('mobile_number' => $mobile);
		$this->db->where('subscriber', $user_id);
		$this->db->update('user_subscriber');

		$this->unlock_action(9, $login_id); // unlock action
	}

	private function unlock_action($process_type, $login_id)
	{
		$this->db->set('process_status', 0);
        $this->db->where('login_id', $login_id);
        $this->db->where('process_type', $process_type);
        $this->db->update('event_concurrent_process');
	}

	public function create_client_account($id)
	{
		$current_date = date('Y-m-d');
		$this->db->insert('user_subscriber',
			array(
				'subscriber' => $id,
				'subscription_date' => $current_date
			)
		);
	}

    public function email_registered($user_id)
    {
        $query = $this->db->select('us.email_address, u.user_id, u.first_name, u.last_name')
                          ->from('user_subscriber us')
                          ->join('user u', 'u.user_id = us.subscriber', 'left')
                          ->where('us.subscriber', $user_id)
                          ->get()
                          ->row();
        return $query;
    }

    public function check_profile_info_update($user_id, $field, $profile_info)
    {
    	switch($field){
    		case 'location' : $info = 'location'; break;
    		case 'mail' : $info = 'mailing_address'; break;
    		case 'email' : $info = 'email_address'; break;
    		case 'telephone' : $info = 'telephone_number'; break;
    		case 'mobile' : $info = 'mobile_number'; break;
    	}
    	
    	$query = $this->db->select($info)
    		->from('user_subscriber')
    		->where('subscriber', $user_id)
    		->get();
    	$row = $query->row();

    	if($row) {
    		if($row->$info == $profile_info) {
    			return array('status' => false, 'data' => array());
    		}
    		else {
    			return array('status' => true, 'data' => $row->$info);
    		}
    	}

    }

}