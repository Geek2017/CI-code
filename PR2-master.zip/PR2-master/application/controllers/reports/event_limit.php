<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Event_limit extends MY_Controller {
    
    public function __construct()
    {
        $this->my_controller_parent_construct();
        $this->load->model("event_registration_limit_model");

        $this->load->library('session');
        $this->authors = $this->session->userdata('logged_in');
    }

    public function get_limit()
    {
        $results = $this->event_registration_limit_model->get_limits();
        output_to_json($this, array(      
            "limit_id" => $results['limit_id'],
            "subscriber_id" => $results['subscriber_id'],
            "number_of_events" => $results['number_of_events'],
            "duration_time" => $results['duration_time'],
            "duration_unit" => $results['duration_unit'],
            "start_date" => $results['start_date'],
            "end_date" => $results['end_date'],
            "is_active" => $results['is_active'],
            "author" => $results['author'],
            "date_created" => $results['date_created']
        ));
    }
    public function add_limit()
    {
        
        $subscriber_id = $this->input->post("subscriber_id");
        $number_of_events = $this->input->post('number_of_events');
        $duration_time = "+".$this->input->post("duration_time");
        $duration_unit = strtolower( $this->input->post("duration_unit") );
        $start_date = date('Y-m-d h:i:s', time());

        $computed = $duration_time." ".$duration_unit;
        $end_date = date("Y-m-d h:i:s", strtotime( $computed ));
        $is_active =  $this->input->post("is_active") == "1" ? 1 : 0;
        $author = $this->authors['user_id'];
        $date_created = $start_date;
        
        $limit_data =  [
                 'subscriber_id' => $subscriber_id,
                 'number_of_events' => $number_of_events,
                 'duration_time' => $duration_time,
                 'duration_unit' => $duration_unit,
                 'start_date' => $start_date,
                 'end_date' => $end_date,
                 'is_active' => $is_active,
                 'author' =>  $author,
                 'date_created' =>  $date_created
            ];

        $this->event_registration_limit_model->add_limits($limit_data);
        output_to_json($this,array('message' => true));
    }
    public function put_limit()
    {
        
        $subscriber_id = $this->input->post("subscriber_id");
        $number_of_events = $this->input->post('number_of_events');
        $duration_time = "+".$this->input->post("duration_time");
        $duration_unit = strtolower( $this->input->post("duration_unit") );
        $start_date = date('Y-m-d h:i:s', time());

        $computed = $duration_time." ".$duration_unit;
        $end_date = date("Y-m-d h:i:s", strtotime( $computed ));
        $is_active =  $this->input->post("is_active") == "1" ? 1 : 0;
        $author = $this->authors['user_id'];
        $date_created = $start_date;
        
        $limit_data =  [
                 'number_of_events' => $number_of_events,
                 'duration_time' => $duration_time,
                 'duration_unit' => $duration_unit,
                 'start_date' => $start_date,
                 'end_date' => $end_date,
                 'is_active' => $is_active,
                 'author' =>  $author,
                 'date_created' =>  $date_created
            ];

        $this->event_registration_limit_model->put_limits($subscriber_id, $limit_data);
        output_to_json($this,array('message' => true));
    }
}