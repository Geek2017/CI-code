<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Authentications extends CI_Model {

	function __construct() 
	{
        parent::__construct();
    }
	public function check_login()
	{
		$username = $this->input->post('username');
		$password = $this->input->post('password');

		if($check = $this->check($username,$password))
		{
			if($check === 'interval'){
				echo json_encode(array(
					'mcontent' => 'error',
					'message' => "Le compte est incatif",
				));
			}else {
				$user_info = $this->users->get_user_info(['id' => $this->session->userdata('id')])->row();
				if (!$user_info->token_id) {
					$token = $this->token->generate();
					$data = [
						'token_id' => $token
					];
					$this->users->update_user_info($data);
					$this->session->set_userdata('token_id',$token);
				}
				echo json_encode(array(
					'mcontent' => 'success',
					'visited' => $this->session->userdata('visited'),
					'message' => 'Connexion avec succès',
					'org' => $this->session->userdata('org'),
					'role' => $this->session->userdata('role'),
					'lastname' => $this->session->userdata('lastname'),
					'id' => $this->session->userdata('id')
				));
			}
		}
		else if($this->email_check($username,$password))
		{
			$this->logs->insert_logs(date('Y-m-d H:i:s'),$this->session->userdata('id') ,$this->input->ip_address(),'Logged In - First log in');
			echo json_encode(array(
			 	'mcontent' => 'success', 
			 	'visited' => $this->session->userdata('visited') ,
			 	'message' => 'Vous avez été connecté avec succès.',
			 	'role' => $this->session->userdata('role'),
			 	'lastname' => $this->session->userdata('lastname'),
			 	'id' => $this->session->userdata('id') 
			 ));
			
		}
		else
		{
			echo json_encode(array( 
				'mcontent' => 'error', 
				'message' => "Nom d'utilisateur ou mot de passe invalide",
			));
			
		}
	}
	public function check($username,$password)
	{
		$password = sha1($password);

		$check = $this->db->query("SELECT * FROM accounts WHERE username='$username' AND password='$password'; ");

		if($check->num_rows() > 0)
		{
			 $row = $check->row();

			if( $row->visited == 0 )
			{
				$this->update_visited( $row->id );
			}
			if($row->date_created && $this->check_date_interval($row->date_created) && $row->active == 0) {
				$this->logs->insert_logs(date('Y-m-d H:i:s'),$row->id,$this->input->ip_address(),'Login failed - Account deactivated');
				return 'interval';
			}else {
				$this->logs->insert_logs(date('Y-m-d H:i:s'),$row->id,$this->input->ip_address(),'Logged In');
				$this->session->set_userdata(array(
					'id' => $row->id,
					'username' => $row->username,
					'password' => $row->password,
					'token_id' => $row->token_id,
					'org' => $row->ord_id,
					'role' => $row->role_id,
					'visited' => $row->visited,
					'lastname' => $this->get_lastname($row->id),
					'time_session' => date('Y-m-d H:i:s')

			));
				return true;
			}
		}
		else
		{
			return false;
		}
	}
	public function check_date_interval($date)
	{
		$date = strtotime("+".$this->globalmodel->get_setting('account_days_expire')." day", strtotime($date));
		$date_now = strtotime(date('Y-m-d H:i:s'));
		return $date_now > $date;
	}
	public function update_visited( $id )
	{
		$this->db->where('id', $id);
    	$this->db->update('accounts', array('visited' => 1));
    	return true;
	}
	public function get_lastname($user_id)
	{
		$check = $this->db->query("SELECT * FROM users WHERE user_id='$user_id'; ");
      
		if($check->num_rows() > 0)
		{
			 $row = $check->row();
			 return $row->lastname;
		}
	}
	public function email_check($username,$password)
	{
		$username = $username;
		$password = sha1($password);

		$check = $this->db->query("SELECT * FROM accounts WHERE username='$username' AND password='$password'; ");
      
		if($check->num_rows() > 0)
		{
			return true;
		}
		else
		{
			return false;	
		}
	}
	public function forgot_password()
	{
		$email = $this->input->post('email');
		if($email){
			if($user = $this->users->get_user_info(['username'=>$email])->row() ){
				$generate_token = sha1(uniqid( $email , true));
				$token = base_url()."index.php/main/forgot_password/".$generate_token;
				$this->users->update_user_info(['forgot_password'=>$generate_token], $user->id);
				$this->globalmodel->send_email(
					$this->globalmodel->akeen_mail(),
					$email,
					"Akeen - Mot de passe oublié",
					"<p>Bonjour, Pour réinitialiser votre mot de passe, visitez le lien ci-dessous<br/>
						<a target='_blank' href='".$token."'>".$token."</a>
					</p>
					"
				);
				echo ak_return('success','L\'instruction a été envoyée à votre adresse e-mail');
			}else
				echo ak_return('error','Utilisateur non trouvé');

		}
	}
	public function submit_forgot()
	{
		$token 		= $this->input->post('token');
		$password_1 = $this->input->post('password');
		if($user = $this->users->get_user_info(['forgot_password'=>$token])->row() ) {
			$input = array(
				'password' => $password_1,
				'password2' => $this->input->post('password2')
			);
			$rules = array(
				'password' => 'required',
				'password2' => 'required|NotEqual:' . $password_1 . '|Les deux mots de passe ne correspondent pas',
			);
			$validator = $this->globalmodel->akeenValidator($input, $rules);
			if (!$validator){
				$new_password = sha1($password_1);
				$this->users->update_user_info(['password'=>$new_password,'forgot_password'=>NULL], $user->id);
				echo ak_return('success', 'Le mot de passe a réinitialisé');
			}
			else
				echo ak_return('error', $validator[0]['error']);
		}else
			echo ak_return('error','Utilisateur non trouvé');

	}
}
