<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 
	
class Event_speaker_assignee_model extends CI_Model {

    var $column_order = array('sa.speaker_assignee_id','s.speaker_id',null,'s.speaker',null); //set column field database for datatable orderable
    var $column_search = array('s.speaker'); //set column field database for datatable searchable just firstname , lastname , address are searchable
    var $order = array('sa.speaker_assignee_id' => 'desc'); // default order

    public function __construct() {
        parent::__construct();
    }

    private function _get_datatables_query($data_source, $event_id){
        $this->db->select("
            s.speaker_id,
            s.speaker,
            sa.speaker_assignee_id")
            ->from("event_speaker_assignee sa")
            ->join('event_speaker s', 's.speaker_id = sa.speaker_id', 'left')
            ->where("sa.event_id", $event_id)
            ->where("sa.status", 1)
            ->where("s.status", 1);

        $i = 0;
        foreach ($this->column_search as $item) {// loop column
            if ($data_source['search']['value']) {  // if datatable send POST for search
                if ($i === 0) { // first loop
                    $this->db->like($item, $data_source['search']['value']);
                } else {
                    $this->db->or_like($item, $data_source['search']['value']);
                }
            }
            $i++;
        }

        if(isset($data_source['order'])) { // here order processing
            if(isset($data_source['order']['0']['dir']) && !empty($data_source['order']['0']['dir'])) {
                $this->db->order_by($this->column_order[$data_source['order']['0']['column']], $data_source['order']['0']['dir']);
            }
        } else if(isset($this->order)) {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    public function get_events_list_export($data_source,$event_id){
        $this->_get_datatables_query($data_source, $event_id);
        $query = $this->db->get();
        $res = $query->result();
        return $res;
    }

    public function get_datatables($data_source, $event_id){
        $this->_get_datatables_query($data_source, $event_id);
        if($data_source['length'] != -1)
            $this->db->limit($data_source['length'], $data_source['start']);
        $query = $this->db->get();
        return $query->result();
    }

    public function count_filtered($data_source, $event_id){
        $this->_get_datatables_query($data_source, $event_id);
        $query = $this->db->get();
        return $query->num_rows();
    }

    public function count_all($data_source, $event_id){
        $this->_get_datatables_query($data_source, $event_id);
        return $this->db->count_all_results();
    }

    public function add_new_speaker_assignee($data){
        $result = $this->check_duplicate_speaker_assignment($data);

        if(sizeof($result) > 0){
            if($result->status == 0){
                $this->db->where("speaker_assignee_id", $result->speaker_assignee_id);
                $this->db->update("event_speaker_assignee", array("status" => 1));
            }
            //duplication happens here
            return $result->speaker_assignee_id;
        } else {
            $this->db->insert("event_speaker_assignee", array(
                "speaker_id" => $data["speaker_id"],
                "event_id" => $data["event_id"],
                "added_by" => $data["added_by"]
            ));
            return $this->db->insert_id();
        }
    }

    public function check_for_duplication($data){
        $this->db->select("esa.speaker_assignee_id");
        $this->db->where("es.speaker", $data["speaker"]);
        $this->db->where("es.status", 1);
        $this->db->where("esa.status", 1);
        $this->db->where("esa.event_id", $data["event_id"]);
        $this->db->from("event_speaker es");
        $this->db->join("event_speaker_assignee esa", "esa.speaker_id = es.speaker_id", "left");
        return $this->db->get()->num_rows();
    }

    private function check_duplicate_speaker_assignment($data){
        $this->db->select("speaker_assignee_id, status");
        $this->db->where("speaker_id", $data["speaker_id"]);
        $this->db->where("event_id", $data["event_id"]);
        return $this->db->get("event_speaker_assignee")->row();
    }

    public function event_details($user_id, $event_id)
    {
        $query = $this->db->select('`event_speaker_assignee`.`speaker_assignee_id`, `event_speaker_assignee`.`speaker_id`, `event_speaker`.`speaker`, `event_speaker`.`description`, `event_speaker`.`status`, `event_speaker_assignee`.`event_id`, `event_speaker_assignee`.`status`')
            ->from('event_speaker_assignee')
            ->join('event_speaker', 'event_speaker.speaker_id=event_speaker_assignee.speaker_id')
            ->where('event_speaker_assignee.status', 1)
            ->where('event_speaker.status', 1)
            ->where('event_speaker_assignee.event_id', $event_id)
            ->get()
            ->result();

        return $query;
    }
}