<?php
defined('BASEPATH') OR exit('No direct script access allowed');


$route['default_controller'] = 'main';
$route['404_override'] = 'pagenotfound';
$route['translate_uri_dashes'] = FALSE;

//authentications
$route['auth/form'] = 'authentication/form';
$route['auth/check_email'] = 'authentication/check_email';
$route['auth/forgot_password'] = 'authentication/forgot_password';
$route['auth/submit_forgot'] = 'authentication/submit_forgot';
$route['auth/login'] = 'authentication/login';
$route['auth/logout'] = 'authentication/logout';

//backoffice url superadmin
$route['admin'] = 'backoffice/index';
$route['admin/ajax'] = 'backoffice/ajax';

$route['admin/profile'] = 'backoffice/profile';
$route['admin/userstatus'] = 'backoffice/user_status';
$route['admin/dashboard'] = 'backoffice/dashboard';
$route['admin/organizations'] = 'backoffice/organizations';
$route['admin/accounts'] = 'backoffice/accounts';
$route['admin/sections'] = 'backoffice/view_sections';
$route['admin/questions'] = 'backoffice/view_questions';
$route['admin/settings'] = 'backoffice/view_settings';

$route['backoffice'] = 'authentication/super_admin';

//supeardmin profile editing
$route['admin/superprofile'] = 'backoffice/super_profile';

//supeardmin personalization
$route['admin/spersonalize'] = 'backoffice/spersonalize';

$route['welcome'] = 'main/welcome';
//Admin
//$route['admin/dashboard'] = 'backofficeadmin/dashboard';
$route['admin/personalize'] = 'backofficeadmin/personalize';
$route['admin/submit_personalize'] = 'backofficeadmin/submit_personalize';
$route['admin/companyprofile'] = 'backofficeadmin/company_profile';
$route['admin/companyprofile/edit'] = 'backofficeadmin/company_profile';
$route['admin/users'] = 'backofficeadmin/company_users';
$route['admin/users/get'] = 'backofficeadmin/get_company_users';


$route['makequestion'] = 'backoffice/makequestion';
$route['postquestion'] = 'backoffice/postquestion';
$route['getquestion/(:num)'] = 'backoffice/getquestion/$1';
$route['editquestion/(:num)'] = 'backoffice/editquestion/$1';

//Profile validation
$route['validate/profile'] = 'profile/validate_profile';

//User
$route['main/dashboard'] = 'dashboard/index';
$route['main/dashboard/ajax'] = 'dashboard/ajax';
$route['main/myprofile_result/(:any)'] = 'main/myprofile_result';
$route['main/m_result/(:any)'] = 'main/m_result';
$route['main/sresult/(:any)'] = 'main/singleresult';

//Sections
$route['question/ajax'] = 'question/ajax';
$route['sections/fin'] = 'sections/fin';
$route['sections/result/all/(:any)'] =  'sections/result_all/$1';
$route['sections/result/(:any)'] = 'sections/result/$1';
$route['sections/view/(:any)'] = 'sections/viewresult/$1';
$route['sections/(:any)'] = 'question/getSectionQuestion/$1';
$route['sections/(:any)/(:num)'] = 'question/getSectionQuestion/$1/$1';
$route['sections/view/(:any)/(:num)'] = 'question/getSectionQuestion/$1/$1';