<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Logs extends CI_Model
{
    protected $table_logs = 'loginlog';
    protected $table_start = 'startlog';

    function __construct()
    {
        parent::__construct();
    }
    public function insert_logs($date_time,$user_id,$ip,$log)
    {
        $log_data = [
            'date_time' =>  $date_time,
            'user_id'   =>  $user_id,
            'ip'        =>  $ip,
            'log'       =>  $log
        ];
        if($this->db->insert($this->table_logs, $log_data))
            return true;

        return false;
    }
    public function last_activity($user_id = null)
    {
        $user_id = $user_id ? $user_id : $this->session->userdata('id');
        $this->db->where($this->table_logs.'.user_id',$user_id)
                ->order_by('id','desc');
        $query = $this->db->get($this->table_logs);
        return $query->row();
    }
    public function get_last_interval($interval_days, $warning)
    {
        return $this->db
            ->join('users', 'accounts.id = users.user_id')
            ->join($this->table_logs, 'accounts.id = loginlog.user_id')
            ->where('accounts.role_id',USERS)
            ->where('accounts.active',"1")
            ->where('accounts.warning',$warning)
            ->where('accounts.ord_id', ( $this->session->userdata('org') > 0 ? $this->session->userdata('org') : 0 ))
            ->where('date_add(loginlog.date_time,interval '.$interval_days.' day) <' , date('Y-m-d H:i:s'))
            ->group_by("loginlog.user_id")
            ->get('accounts')
        ;
    }
    public function insert_startlog($logid, $section_id, $datetime)
    {
        $log_data = [
            'loginlog_id'   =>  $logid,
            'section_id'    =>  $section_id,
            'date_time'     =>  $datetime,
        ];
        if($this->db->insert($this->table_start, $log_data))
            return true;

        return false;
    }
    public function group_startlog($user_id = null)
    {
        $user_id = $user_id ? $user_id : $this->session->userdata('id');
        $this->db
            ->join($this->table_start,$this->table_start.'.loginlog_id = '.$this->table_logs.'.id')
            ->where($this->table_logs.'.user_id',$user_id)
            ->order_by($this->table_start.'.loginlog_id','asc')
            ->group_by($this->table_start.'.loginlog_id');
        $query = $this->db->get($this->table_logs);
        return $query;
    }
    public function get_startlog($logid, $section_id = null, $user_id = null)
    {
        $user_id = $user_id ? $user_id : $this->session->userdata('id');
        if($section_id) {
            $this->db
                ->where('section_id', $section_id);
            }
            $this->db->join($this->table_start,$this->table_start.'.loginlog_id = '.$this->table_logs.'.id');
            $this->db->where($this->table_logs.'.id',$logid);
            $this->db->where($this->table_logs.'.user_id',$user_id);
            $this->db->order_by($this->table_start.'.id', 'desc');
        $query = $this->db->get($this->table_logs);
        return $query;
    }
    public function status_color($date_created , $user = null)
    {
        if( date('Y-m-d',strtotime( "+60 day",strtotime($date_created) )) <= date('Y-m-d') )
            $color = "gray"  ;
        else if( date('Y-m-d',strtotime( "+30 day",strtotime($date_created) )) <= date('Y-m-d') && $date_created  <  date("Y-m-d",strtotime( "+60 day" ) ) )
            $color = "red"  ;
        else if( date('Y-m-d',strtotime( "+15 day",strtotime($date_created) )) <= date('Y-m-d') && $date_created  <  date("Y-m-d",strtotime( "+30 day" ) ) )
            $color = "orange";
        else
            $color = "green";
        
        return $color;

    }
}