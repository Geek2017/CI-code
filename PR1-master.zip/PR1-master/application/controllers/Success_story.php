<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class success_story extends CI_Controller {

    function __construct()
    {
        parent::__construct();
    }
  
    public function get_data()
    {
      $this->success_stories->get_datas();
    }

    public function get_data_id()
    {
      $this->success_stories->get_datas_id();
    }

    public function post_data()
    {
      $this->success_stories->post_datas();
    }

    public function count_success_story()
    {
        $this->success_stories->count_success_stories();
    }

    public function delete_data()
    {
        $this->success_stories->delete_datas();
    }

}
