<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class MY_Controller extends CI_Controller {
	
	protected $login_user_data = array();
	protected $data = array();

	public function __construct()
	{
		parent::__construct();
//        $this->get_login_user_data();
	}

    protected function my_controller_parent_construct()
	{
		parent::__construct();
        $this->load_default_language();
        $this->get_login_user_data();
	}

    protected function get_login_user_data()
	{
        if ($this->session->userdata('logged_in')) {
            $this->data["logged_in"] = $this->session->userdata('logged_in');
        } else if (!is_null(get_cookie('_L3W0VB3_userdata')) && !empty(get_cookie('_L3W0VB3_userdata'))) {
            $this->load->model('user_model');
            $user_cookie_ = json_decode(get_cookie('_L3W0VB3_userdata'));
            if (isset($user_cookie_) && !empty($user_cookie_) && sizeof($user_cookie_)) {
                if(isset($user_cookie_->login_id) && !empty($user_cookie_->login_id)) {
                    $logged_in = $this->user_model->get_user_data($user_cookie_->cookie_id, $user_cookie_->r_cookie_id);
                    $session_data = array(
                        'login_id' => $user_cookie_->login_id,
                        'user_id' => $logged_in->user_id,
                        "fullname" => $logged_in->first_name . " " . $logged_in->last_name,
                        'role_id' => $logged_in->role_id);
                    if ($user_cookie_->r_cookie_id != 3) {
                        // Create Session
                        $session_data["email_address"] = $logged_in->email_address;
                        $session_data["role_id"] = $logged_in->role_id;
                    }
                    $this->data["logged_in"] = $session_data;
                } else {
                    $this->data["logged_in"] = false;
                }
            }
        } else {
            $this->data["logged_in"] = false;
        }
	}
	
	protected function redirect_to_default_page()
    {
        if(isset($this->data['logged_in']) && !empty($this->data['logged_in'])) {
            $login_user_data = $this->data['logged_in'];
            switch ($login_user_data["role_id"]) {
                CASE 1:
                    redirect(base_url('dashboard'));
                    break;
                CASE 2:
                    redirect(base_url('dashboard'));
                    break;
                CASE 3:
                    redirect(base_url("frontoffice/index"));
                    break;
                default :
                    //no deafult redirection for now
                    break;
            }
        } else {
            if($this->session->userdata('first_logged_in')) {
                redirect(base_url('logout/1'));
            }
        }
	}

    public function token_duration()
    {
        $this->load->library('session');
        $logged_in = $this->session->userdata('logged_in');
    
        if( $this->session->userdata('started') != null && !empty( $logged_in['token_id'] ) ){
            $remaining = time() - $logged_in['duration'];
            $end = ( 30 * 60  ); 
            if($remaining >= $end){
                redirect(base_url('logout/1'));
            }
        }
    }
    protected function show_page_404($role_id, $page){
        if($this->check_cookie_and_session()) {
            if(isset($this->data['logged_in']) && !empty($this->data['logged_in'])) {
                $logged_in = $this->data['logged_in'];
                if (!in_array($logged_in["role_id"], $role_id)) {
                    if ($page == "frontoffice" && in_array($logged_in["role_id"], array(1, 2))) {
                        redirect(base_url("dashboard"));
                    } else if ($page == "backoffice" && in_array($logged_in["role_id"], array(3) )) {
                        redirect(base_url('frontoffice/index'));
                    }else{
                        show_404();
                    }
                }
            } else {
                if($this->session->userdata('first_logged_in')) {
                    redirect(base_url('logout/1'));
                }
            }
        }
    }

    protected function clear_cache(){
        $this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate, no-transform, max-age=0, post-check=0, pre-check=0");
        $this->output->set_header("Pragma: no-cache");
    }

    protected function is_logged_in(){
        if(!$this->check_cookie_and_session()) {
            if(!$this->session->userdata('_l0G4wT9')){
                $this->session->set_userdata(array("_l0G4wT9" => "homepige"));
                //redirect('home');
            }
        }
    }

    public function load_default_language(){
        $this->lang->load('system', 'fr');
    }

    public function load_language_backoffice(){
        $this->lang->load('system', 'fr');
        $this->lang->load('backoffice/system_message', 'fr');
    }

    public function load_language_frontoffice(){
        $this->lang->load('system', 'fr');
        $this->lang->load('frontoffice/homepage', 'fr');
        $this->lang->load('frontoffice/system_config', 'fr');
    }

    protected function check_session_timed_out($disposition="fo", $sess_timeout=1){
        $check_session = $this->check_cookie_and_session();
        if(!$check_session || $check_session == 2) {
            if($disposition != "bo" && $check_session == 2) {
                $this->prepare_timeout_message($disposition, $check_session);
            } else if(!$check_session && $disposition == "bo"){
                $this->prepare_timeout_message($disposition, $check_session);
            }
        }
    }

    protected function check_session_time_out_fo($disposition="fo"){
        $check_session = $this->check_cookie_and_session();
        if($check_session == 2 && $disposition != "bo") {
            $this->prepare_timeout_message($disposition, $this->check_cookie_and_session());
        }
    }

    private function prepare_timeout_message($disposition, $check_session){
        if($disposition != "bo_redirect_now" && $disposition != "fo_redirect_now") {
            $landing_page = ($disposition == "bo") ? "auth" : "login";
            echo json_encode(array(
                "mtype" => "session_timeout",
                "message" => $this->lang->line("session_timeout"),
                "mdetail" => array(
                    "redirect" => 1,
                    "path" => ($check_session == 2) ? base_url("logout/1") : base_url($landing_page),
                    "login_window" => false
                )
            ));
            exit();
        } else {
            $landing_page = ($disposition == "bo") ? "auth" : "login";
            redirect(($check_session == 2) ? base_url("logout/1") : base_url($landing_page));
        }
    }

//    protected function check_session_timedout_admin($disposition="bo"){
//        $check_session = $this->check_cookie_and_session();
//        if(!$check_session || $check_session == 2) {
//            $landing_page = ($disposition == "bo")?"auth":"login";
//           echo json_encode(array(
//                "mtype" => "session_timeout",
//                "message" => $this->lang->line("session_timeout"),
//                "mdetail" => array(
//                    "redirect" => 4000,
//                    "path"     => ($check_session == 2)?base_url("logout"):base_url($landing_page),
//                    "login_window" => false
//                )
//            ));
//            exit();
//        }
//    }

    protected function check_user_session_on_load($check_session, $disposition="fo"){
        if($check_session == 2 && $disposition !="bo") {
            $landing_page = ($disposition == "bo")?"auth":"login";
            return json_encode(array(
                "mtype" => "session_timeout",
                "message" => $this->lang->line("session_timeout"),
                "mdetail" => array(
                    "redirect" => 1,
                    "path"     => ($check_session == 2)?base_url("logout/1"):base_url($landing_page),
                    "login_window" => false
                )
            ));
        } else {
            return json_encode(array("mtype" => "active"));
        }
    }

//    protected function check_session_timedout_client(){
//        $check_session = $this->check_cookie_and_session();
//        if($this->session->userdata("first_logged_in")){
//            //return true;
//        }
//        else if(!$check_session || $check_session == 2) {
//            echo json_encode(array(
//                "mtype" => "session_timeout",
//                "message" => $this->lang->line("session_timeout"),
//                "mdetail" => array(
//                    "redirect" => 2000,
//                    "path"     => ($check_session == 2)?base_url("logout"):base_url("login"),
//                    "login_window" => false
//                )
//            ));
//            exit();
//        }
//    }

    /* there will be different kinds of session checkers
     * 1 = active
     * 2 = session_timeout (your session is no longer valid, happens when multiple instances occur in one single account)
     * 0 = session_expired (cookie expires, codeigniter session expires)
     */
    public function check_cookie_and_session(){
//        if($this->session->userdata('first_logged_in') || $this->session->userdata('logged_in') || (!is_null(get_cookie('_L3W0VB3_userdata')) && !empty(get_cookie('_L3W0VB3_userdata')))) {
        if($this->session->userdata('first_logged_in') || $this->session->userdata('logged_in')) {

            if(!$this->session->userdata('first_logged_in')) {
                $this->load->model('user_model');
                $logged_in = $this->data["logged_in"];
                //check if login id is still valid or active
                $sess = $this->user_model->check_if_session_is_active($logged_in["login_id"], $logged_in["user_id"], $logged_in["role_id"]);
                if (!$sess) {
                    return 2;
                }
            }
            return 1;
        }
        return false;
    }

    public function load_extra_files($with=array()){

        if(!isset($this->data["load_styles"]) && empty($this->data['load_styles'])) {
            $this->data['load_styles'] = array();
        }

        if(!isset($this->data["load_scripts"]) && empty($this->data['load_scripts'])) {
            $this->data['load_scripts'] = array();
        }

        if(isset($with["ajax_helper"]) && $with["ajax_helper"]){
            array_push($this->data['load_scripts'], '<script src="' . base_url('resources/app/ajax.js') . '" type="text/javascript"></script>');
        }

        if(isset($with["datatable"]) && $with["datatable"]){
            array_push($this->data['load_styles'], '<!-- Bootstrap Datatable CSS -->');
            array_push($this->data['load_styles'], '<link href="' . plugins_bundle() . 'datatables/dataTables.bootstrap.min.css" rel="stylesheet"/>');
            array_push($this->data['load_styles'], '<link href="' . plugins_bundle() . 'datatables/responsive.bootstrap.min.css" rel="stylesheet"/>');

            array_push($this->data['load_scripts'], '<!-- Bootstrap Datatable JS-->');
            array_push($this->data['load_scripts'], '<script src="' . plugins_bundle() . 'datatables/jquery.dataTables.min.js" type="text/javascript"></script>');
            array_push($this->data['load_scripts'], '<script src="' . plugins_bundle() . 'datatables/dataTables.bootstrap.min.js" type="text/javascript"></script>');
            array_push($this->data['load_scripts'], '<script src="' . plugins_bundle() . 'datatables/dataTables.responsive.min.js" type="text/javascript"></script>');
            array_push($this->data['load_scripts'], '<script src="' . plugins_bundle() . 'datatables/responsive.bootstrap.min.js" type="text/javascript"></script>');
            array_push($this->data['load_scripts'], '<script src="' . plugins_bundle() . 'datatables/datatables.lang.fr.js" type="text/javascript"></script>');
        }

        if(isset($with["moment"]) && $with["moment"]){
            array_push($this->data['load_scripts'], '<!-- Datetimepicker JS -->');
            array_push($this->data['load_scripts'], '<script src="' . plugins_bundle() . 'momentjs/moment.min.js" type="text/javascript"></script>');
            array_push($this->data['load_scripts'], '<script src="' . plugins_bundle() . 'bootstrap/datepicker/moment-with-locales.js" type="text/javascript"></script>');
//            array_push($this->data['load_scripts'], '<script src="' . plugins_bundle() . 'momentjs/moment-range.min.js" type="text/javascript"></script>');
        }

        if(isset($with["datetime"]) && $with["datetime"]){
            array_push($this->data['load_styles'], '<!-- Datetimepicker CSS -->');
            array_push($this->data['load_styles'], '<link href="' . plugins_bundle() . 'bootstrap/datepicker/bootstrap-datetimepicker.min.css" rel="stylesheet"/>');

            array_push($this->data['load_scripts'], '<!-- Datetimepicker JS -->');
            array_push($this->data['load_scripts'], '<script src="' . plugins_bundle() . 'momentjs/moment.min.js" type="text/javascript"></script>');
            array_push($this->data['load_scripts'], '<script src="' . plugins_bundle() . 'bootstrap/datepicker/moment-with-locales.js" type="text/javascript"></script>');
            array_push($this->data['load_scripts'], '<script src="' . plugins_bundle() . 'momentjs/moment-range.min.js" type="text/javascript"></script>');
            array_push($this->data['load_scripts'], '<script src="' . plugins_bundle() . 'bootstrap/datepicker/bootstrap-datetimepicker.min.js" type="text/javascript"></script>');
        }
        if(isset($with["money_formatter"]) && $with["money_formatter"]){
            array_push($this->data['load_scripts'], '<!-- Money Formatter JS -->');
            array_push($this->data['load_scripts'], '<script src="' . plugins_bundle() . 'bootstrap/currency/accounting.min.js" type="text/javascript"></script>');
        }
        if(isset($with["tinymce"]) && $with["tinymce"]){
            array_push($this->data['load_scripts'], '<!-- TinyMCE JS -->');
            array_push($this->data['load_scripts'], '<script src="' . plugins_bundle() . 'tinymce/tinymce.min.js" type="text/javascript"></script>');
        }
        if(isset($with["form_validator"]) && $with["form_validator"]){
            array_push($this->data['load_styles'], '<!-- Form Validator CSS -->');
            array_push($this->data['load_styles'], '<link href="' . plugins_bundle() . 'bootstrap/validator/bootstrapValidator.min.css" rel="stylesheet"/>');
            array_push($this->data['load_scripts'], '<!-- Form Validator JS -->');
            array_push($this->data['load_scripts'], '<script src="' . plugins_bundle() . 'bootstrap/validator/bootstrapValidator.fr.min.js" type="text/javascript"></script>');
        }
        if(isset($with["dropzone"]) && $with["dropzone"]){
            array_push($this->data['load_styles'], '<!-- File Upload CSS -->');
            array_push($this->data['load_styles'], '<link href="' . plugins_bundle() . 'dropzone/dropzone.css" rel="stylesheet"/>');
            array_push($this->data['load_scripts'], '<!-- File Upload JS -->');
            array_push($this->data['load_scripts'], '<script src="' . plugins_bundle() . 'dropzone/dropzone.js" type="text/javascript"></script>');
        }
        if(isset($with["bootbox"]) && $with["bootbox"]){
            array_push($this->data['load_scripts'], '<!-- Bootbox JS -->');
            array_push($this->data['load_scripts'],'<script src="'.plugins_bundle().'bootstrap/bootbox/bootbox.js" type="text/javascript"></script>');
        }
        if(isset($with["dotdotdot"]) && $with["dotdotdot"]){
            array_push($this->data['load_scripts'], '<!-- Dotdotdot JS -->');
            array_push($this->data['load_scripts'],'<script src="'.plugins_bundle().'jquery/jquery.dotdotdot.min.js" type="text/javascript"></script>');
        }
        if(isset($with["notify"]) && $with["notify"]){
            array_push($this->data['load_scripts'], '<!-- Notify JS -->');
            array_push($this->data['load_scripts'],'<script src="'.plugins_bundle().'bootstrap/notify_3.3.1/bootstrap-notify.min.js" type="text/javascript"></script>');
        }
        if(isset($with["typeahead"]) && $with["typeahead"]){
            array_push($this->data['load_scripts'], '<!-- Boostrap-3-Typeahead JS -->');
            array_push($this->data['load_scripts'],'<script src="'.plugins_bundle().'bootstrap/typeahead/bootstrap3-typeahead.min.js" type="text/javascript"></script>');
        }
        if(isset($with["inputmask"]) && $with["inputmask"]){
            array_push($this->data['load_scripts'], '<!-- Robin Herbots Inputmask JS -->');
            array_push($this->data['load_scripts'],'<script src="'.plugins_bundle().'inputmask/min/jquery.inputmask.bundle.min.js" type="text/javascript"></script>');
        }
        if(isset($with["appjs"]) && $with["appjs"]){
            array_push($this->data['load_scripts'], '<!-- App JS -->');
            array_push($this->data['load_scripts'], '<script src="'.app_bundle().'app.js" type="text/javascript"></script>');
        }
        if(isset($with["ga"]) && $with["ga"]){
            array_push($this->data['load_scripts'], '<!-- Google Analytics -->');
            array_push($this->data['load_scripts'], '<script src="'.scripts_bundle().'google-analytics.js" type="text/javascript"></script>');
        }
        if(isset($with["ga_embed"]) && $with["ga_embed"]){
            array_push($this->data['load_scripts'], '<!-- Google Analytics -->');
            array_push($this->data['load_scripts'], '<script src="'.scripts_bundle().'google-analytics-embed.js" type="text/javascript"></script>');
        }
        if(isset($with["date_range"]) && $with["date_range"]){
            array_push($this->data['load_scripts'], '<!-- Google Analytics -->');
            array_push($this->data['load_styles'], '<link href="'.plugins_bundle().'bootstrap/datepicker/daterangepicker.css" rel="stylesheet"/>');
            array_push($this->data['load_scripts'], '<script src="'.plugins_bundle().'bootstrap/datepicker/daterangepicker.js" type="text/javascript"></script>');
        }

        if(isset($with["bootstrap_select"]) && $with["bootstrap_select"]){
            array_push($this->data['load_scripts'], '<!-- Bootstrap Select -->');
            array_push($this->data['load_styles'], '<link href="'.plugins_bundle().'bootstrap/bootstrap-select/bootstrap-select.min.css" rel="stylesheet"/>');
            array_push($this->data['load_scripts'], '<script src="'.plugins_bundle().'bootstrap/bootstrap-select/bootstrap-select.min.js"></script>');
            array_push($this->data['load_scripts'], '<script src="'.plugins_bundle().'bootstrap/bootstrap-select/ajax-bootstrap-select.min.js"></script>');
        }

        if(isset($with["easycomplete"]) && $with["easycomplete"]){
                array_push($this->data['load_scripts'], '<script src="'.plugins_bundle().'easycomplete/jquery.easy-autocomplete.min.js"></script>');
                array_push($this->data['load_styles'], '<link rel="stylesheet" href="'.plugins_bundle().'easycomplete/easy-autocomplete.min.css">');
                array_push($this->data['load_styles'], '<link rel="stylesheet" href="'.plugins_bundle().'easycomplete/easy-autocomplete.themes.min.css">');
        }
    }

    public function check_subscriber_admin_status(){
	    $data = $this->data['logged_in'];
	    $user = $data['user_id'];
		$tokenID = (isset($data['token_id']) && !empty($data['token_id']))?$data['token_id']:"";
		$this->load->model('user_model');
		$result = $this->user_model->check_admin_subscriber_status($user);
//	    $status = json_encode($result);
	    if($tokenID!=''){
		    if($result==true){
			    output_to_json($this, array("mtype" => "warning" ,"message" => "You cannot perform any actions right now because the subscriber is currently logged in."));
		    }
	    }

    }
}

/* End of file MY_CONTROLLER.php */
/* Location: ./application/core/MY_Controller.php */