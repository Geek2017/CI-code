<!-- Page Content -->
<div class="container internal-mobility">
    <div class="row">
        <div class="col-lg-10 col-lg-offset-1">
         <?php 
            if(isset($user_role)) {
                if($this->session->userdata("lastname") != null){?>
                    <a class="align-left" href="<?php echo site_url('main/progress'); ?>"><img src="<?php echo base_url('assets/img/return.png'); ?>"/> Retour</a>
                        <?php } ?>
                             <?php
                        }else{
                            ?>
                          <a class="align-left" href="<?php echo site_url('main/'); ?>"><img src="<?php echo base_url('assets/img/return.png'); ?>"/> Retour</a>
                             <?php
                        }
                        ?>  
            <h1 class="text-center">Enjeux de la mobilit&#233; interne </h1>

        	<table>
                <tr>
                <th>Enjeux pour l&#8217;entreprise </th>
                <th>Enjeux pour le collaborateur</th>
                <th>Enjeux soci&#233;taux</th>
                </tr>
                
                <tr>
                <td width="300">
                   <ul class="static-bullet">
                        <li><span>Favoriser <b>l’engagement des salariés, leurs perspectives d’employabilité</b> et la 
                        <b>performance</b> qui en découle</span></li>
                        <li><span>S’adapter au marché en ayant des <b>salariés polyvalents, avec une réelle capacité d'adaptation et tout de suite opérationnels</b></span></li>
                        <li><span>Préserver des salariés attachés à la <b>culture de l’entreprise</b> et à ses <b>produits</b>, </span></li>
                        <li><span>Attirer, développer, et fidéliser les <b>talents</b></span></li>
                        <li><span>Contribuer au <b>retour sur investissement interne</b> </span></li>
                        <li><span><b>Réduire les coûts</b> administratifs</span></li>
                        <li><span><b>Développer sa marque employeur (QVT)</b></span></li>
                    </ul> 
                </td>

                <td width="300">
                    <ul class="static-bullet">
                        <li><span><b>Diversifier son parcours professionnel en changeant de poste</b> et / ou de métier </span></li>
                        <li><span><b>Développer ses compétences techniques et comportementales</b></span></li>
                        <li><span><b>Limiter les risques professionnels</b></span></li>
                        <li><span><b>Tirer le meilleur parti des avantages</b> des grands groupes </span></li>
                        <li><span><b>Renforcer son réseau interne</b></span></li>
                        <li><span><b>S’engager pleinement</b> dans un projet professionnel en accord avec son actualité</span></li>
                    </ul>    
                </td>

                <td width="300">
                    <ul class="static-bullet">
                        <li><span><b>Etre solidaire</b> en matière de gestion de l’emploi </span></li>
                        <li><span>Faire de l’entreprise un « <b>role model</b> » dans la gestion interne du capital humain </span></li>
                        <li><span><b>Anticiper les changements d’organisation des entreprises</b> et faciliter les évolutions de carrière afin de contribuer pleinement à l'emploi</span></li>
                    </ul>
                </td>
                </tr>
            </table>
        </div>        
    </div>
</div>