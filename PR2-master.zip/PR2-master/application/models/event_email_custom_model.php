<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Event_email_custom_model extends CI_Model {

    var $column_order = array(null, 'e.title', null, "CONCAT(u.first_name, ' ', u.last_name)", null, null, null, 'eec.email_custom_date_created', null); //set column field database for datatable orderable
    var $column_search = array('e.title','CONCAT(u.first_name, " ", u.last_name)','ees.email_schedule_date_added'); //set column field database for datatable searchable just firstname , lastname , address are searchable
    var $order = array('eec.email_custom_date_created' => 'desc'); // default order

    public function __construct() {
        parent::__construct();
    }

    private function _get_datatables_query($data_source){
        $this->db->select("
            eec.email_custom_id,
            e.title AS event_title,
            e.event_id,
            e.event_status,
            e.remaining_seat,
            eec.email_custom_sendto,
            eec.email_custom_status")

            ->select("(SELECT GROUP_CONCAT(DISTINCT(eef.email_filter) SEPARATOR ', ')
            FROM event_email_filter eef
            LEFT JOIN event_email_custom_filter eecf ON eecf.email_filter_id = eef.email_filter_id
            WHERE eec.email_custom_id = eecf.email_custom_id
            AND eecf.email_custom_filter_status=1) AS email_filter", FALSE)

            //subscribers idS AND VALUES
            ->select("(SELECT CONCAT(GROUP_CONCAT(DISTINCT(CONCAT(u.first_name, ' ', u.last_name)) SEPARATOR ', '), '_||_',
            GROUP_CONCAT(eecr.subscriber_id  SEPARATOR ', '))
            FROM event_email_custom_recipient eecr
            LEFT JOIN user u on u.user_id=eecr.subscriber_id
            WHERE eecr.email_recipient_status =1
            AND eec.email_custom_id =eecr.email_custom_id
            AND u.role_id =3
            ORDER BY eecr.subscriber_id ASC) AS subscribers", FALSE)

            //event ville_ids
            ->select("(SELECT CONCAT(GROUP_CONCAT(eecf_1.email_filter_search SEPARATOR ', '), '_||_',
            GROUP_CONCAT(ecl.city  SEPARATOR ', '))
            FROM event_email_custom_filter eecf_1
            LEFT JOIN event_city_location ecl ON ecl.city_location_id = eecf_1.email_filter_search
            WHERE eec.email_custom_id = eecf_1.email_custom_id
            AND eecf_1.email_filter_id=1 AND eecf_1.email_custom_filter_status = 1
            ORDER BY eecf_1.email_filter_search ASC) AS city", FALSE)

            //event type / event pref ids AND values
            ->select("(SELECT CONCAT(GROUP_CONCAT(eecf_2.email_filter_search SEPARATOR ', '), '_||_',
            GROUP_CONCAT(et.event_type SEPARATOR ', '))
            FROM event_email_custom_filter eecf_2
            LEFT JOIN event_type et ON et.event_type_id = eecf_2.email_filter_search
            WHERE eec.email_custom_id = eecf_2.email_custom_id
            AND eecf_2.email_filter_id=2 AND eecf_2.email_custom_filter_status = 1
            ORDER BY eecf_2.email_filter_search ASC) AS event_type", FALSE)

            //subscription date
            ->select("(SELECT GROUP_CONCAT(eecf_3.email_filter_search SEPARATOR ', ')
            FROM event_email_custom_filter eecf_3
            WHERE eec.email_custom_id = eecf_3.email_custom_id
            AND eecf_3.email_filter_id=3 AND eecf_3.email_custom_filter_status = 1) AS subscription_date", FALSE)

            ->select("(SELECT SUM(email_status=1)
            FROM `event_email_custom_recipient` eecr
            LEFT JOIN user u on u.user_id=eecr.subscriber_id
            WHERE eecr.email_recipient_status =1
            AND eecr.email_custom_id = eec.email_custom_id) AS email_sent", FALSE)

            ->select("(SELECT SUM(email_status=0)
            FROM `event_email_custom_recipient` eecr
            LEFT JOIN user u on u.user_id=eecr.subscriber_id
            WHERE eecr.email_recipient_status =1
            AND eecr.email_custom_id = eec.email_custom_id) AS email_onqueue", FALSE)

            ->select("DATE_FORMAT(eec.email_custom_date_created, '%e/%m/%Y %Hh%i') AS email_push_date_created", FALSE)
            ->select("CONCAT(u.first_name, ' ', u.last_name) AS email_custom_author", FALSE)
            ->from("event_email_custom eec")
            ->join('event e', 'e.event_id = eec.event_id', 'left')
            ->join('user u', 'u.user_id = eec.email_custom_author', 'left')
            ->where_in("e.back_office_status", array(1, 2, 3, 4, 5, 0, 6))
            ->where_in("eec.email_custom_status", array(0,1));

        $i = 0;

        foreach ($this->column_search as $item) {// loop column
            if ($data_source['search']['value']) {  // if datatable send POST for search
                if ($i === 0) { // first loop
                    $this->db->like($item, $data_source['search']['value']);
                } else {
                    $this->db->or_like($item, $data_source['search']['value']);
                }
            }
            $i++;
        }

        if(isset($data_source['order'])) { // here order processing
            if(isset($data_source['order']['0']['dir'])) {
                $this->db->order_by($this->column_order[$data_source['order']['0']['column']], $data_source['order']['0']['dir']);
            }
        } else if(isset($this->order)) {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    public function get_events_list_export($data_source){
        $this->_get_datatables_query($data_source);
        $query = $this->db->get();
        $res = $query->result();
        return $res;
    }

    public function get_datatables($data_source){
        $this->_get_datatables_query($data_source);
        if($data_source['length'] != -1)
            $this->db->limit($data_source['length'], $data_source['start']);
        $query = $this->db->get();
        return $query->result();
    }

    public function count_filtered($data_source){
        $this->_get_datatables_query($data_source);
        $query = $this->db->get();
        return $query->num_rows();
    }

    public function count_all($data_source){
        $this->_get_datatables_query($data_source);
        return $this->db->count_all_results();
    }

    public function list_events_for_push_event_typeahead($search){
        $this->db->select("e.event_id as id, e.title AS name, e.remaining_seat, e.event_status")
            ->from("event e")
            ->where_in("e.back_office_status",array(1,2,3))
            ->where("e.start_date_time > NOW()")
            ->like("e.title", $search)
            ->order_by("e.event_id", "desc")
            ->limit(10);
        return $this->db->get()->result();
    }

    public function typeahead_list_city_location($search, $except){
        $this->db->select("city_location_id as id, city AS name");
        $this->db->from("event_city_location");
        $this->db->where_in("status",array(1));
        $this->db->like("city", $search);
        if(isset($except) && !empty($except)) {
            $this->db->where("city_location_id NOT IN(" . $except . ")");
        }
        $this->db->order_by("city", "asc");
        $this->db->limit(10);
        return $this->db->get()->result();
    }

    public function typeahead_list_event_type($search, $except){
        $this->db->select("event_type_id as id, event_type AS name");
        $this->db->from("event_type");
        $this->db->where_in("status",array(1));
        $this->db->like("event_type", $search);
        if(isset($except) && !empty($except)) {
            $this->db->where("event_type_id NOT IN(" . $except . ")");
        }
        $this->db->order_by("event_type", "asc");
        $this->db->limit(10);
        return $this->db->get()->result();
    }

    public function typeahead_list_active_event($search, $except){
        $this->db->select("event_id as id, title AS name");
        $this->db->from("event");
        $this->db->where_in("back_office_status",array(1,2,3,4,5));
        $this->db->like("title", $search);
        if(isset($except) && !empty($except)) {
            $this->db->where("event_id NOT IN(" . $except . ")");
        }
        $this->db->order_by("title", "asc");
        $this->db->limit(10);
        return $this->db->get()->result();
    }

    public function typeahead_email_recipient($data, $except, $exception="NOT IN"){
        $query = "SELECT u.user_id as id, CONCAT(u.first_name, ' ', u.last_name) AS name
        FROM user_subscriber us
        LEFT JOIN user u ON u.user_id = us.subscriber ";
        $where = " WHERE u.status =1 AND u.role_id = 3 ";

        if(isset($data["event_id"]) && !empty($data["event_id"])) {
            $where .= "AND us.subscriber NOT IN(
            SELECT subscriber
            FROM event_registration
            WHERE event_id = " . $data["event_id"][0] . "
            AND status = 1
            ) ";
        }

        if(isset($data["event_type_id"]) && !empty($data["event_type_id"])){
            $query .= " LEFT JOIN user_subscriber_event_preference usep ON usep.subscriber_id = us.subscriber_id";
            $where .= " AND usep.event_preference IN(" . $data["event_type_id"] . ") ";
        }

        if(isset($data["city_location_id"]) && !empty($data["city_location_id"])){
            $where .= " AND (us.location IS NOT NULL OR us.city_location_id IS NOT NULL) AND (us.city_location_id IN(" . $data["city_location_id"] . ") OR us.location REGEXP '".str_replace(", ","|", $data["city"])."') ";
        }

        if(isset($data["subscription_date_formatted"]) && !empty($data["subscription_date_formatted"]) ){
            $drange = explode(" - ", $data["subscription_date_formatted"]);
            $where .= " AND DATE_FORMAT(us.subscription_date, '%Y-%m-%d') BETWEEN '".$drange[0]."' AND '".$drange[1]."' ";
        }

        if(isset($data["search"]) && !empty($data["search"]) ){
            $where .= " AND CONCAT(u.first_name, ' ', u.last_name) LIKE '%".$data['search']."%' ";
        }

        if(isset($except) && !empty($except)) {
            $where .= " AND u.user_id ".$exception."(" . $except . ") ";
        }

        $query = $query.$where." GROUP BY us.subscriber_id ORDER BY CONCAT(u.first_name, ' ', u.last_name) ASC
        LIMIT 10";

        return $this->db->query($query)->result();
    }

    public function prepareRecipients($data, $email_custom_id){
        $query = "(SELECT ?, u.user_id
        FROM user_subscriber us
        LEFT JOIN user u ON u.user_id = us.subscriber ";
        $where = " WHERE u.status =1 AND u.role_id = 3 ";

        if(isset($data["event_id"]) && !empty($data["event_id"])) {
            $where .= "AND us.subscriber NOT IN(
            SELECT subscriber
            FROM event_registration
            WHERE event_id = " . $data["event_id"][0] . "
            AND status = 1
            ) ";
        }

        if(isset($data["event_type_id"]) && !empty($data["event_type_id"])){
            $query .= " LEFT JOIN user_subscriber_event_preference usep ON usep.subscriber_id = us.subscriber_id";
            $where .= " AND usep.event_preference IN(" . implode(", ",$data["event_type_id"]). ") ";
        }

        if(isset($data["city_location_id"]) && !empty($data["city_location_id"])){
            $where .= " AND (us.location IS NOT NULL OR us.city_location_id IS NOT NULL) AND (us.city_location_id IN(" . implode(", ",$data["city_location_id"]) . ") OR us.location REGEXP '".str_replace(", ","|", $data["city"])."') ";
        }

        //if(isset($data["city_location_id"]) && !empty($data["city_location_id"])){
            //$query .= " LEFT JOIN event_city_location ecl ON ecl.city REGEXP '".str_replace(", ","|", $data["city"])."' ";
            //$where .= " AND (us.city_location_id IN(" . $data["city_location_id"] . ") OR ecl.city REGEXP '".str_replace(", ","|", $data["city"])."') ";
        //}

//        if(isset($data["city_location_id"]) && !empty($data["city_location_id"])){
//            $query .= " LEFT JOIN event_city_location ecl ON ecl.city REGEXP '".str_replace(", ","|", $data["city"])."' ";
//            $where .= " AND (us.city_location_id IN(" . $data["city_location_id"] . ") OR ecl.city REGEXP '".str_replace(", ","|", $data["city"])."') ";
//        }

        if(isset($data["subscription_date_formatted"]) && !empty($data["subscription_date_formatted"]) ){
            $drange = explode(" - ", $data["subscription_date_formatted"]);
            $where .= " AND DATE_FORMAT(us.subscription_date, '%Y-%m-%d') BETWEEN '".$drange[0]."' AND '".$drange[1]."' ";
        }
        $query = $query.$where." GROUP BY us.subscriber_id, u.user_id)";

        $this->db->query("INSERT INTO event_email_custom_recipient(email_custom_id, subscriber_id)".$query,
            array($email_custom_id, 0));

        return $query;
    }

    public function add_email_push($data){
        if(isset($data) && !empty($data)) {
            $this->db->insert("event_email_custom", $data);
            if ($this->db->affected_rows()) {
                return $this->db->insert_id();
            }
            return false;
        }
    }

    public function update_email_push($email_custom_id, $data){
        if(isset($data) && !empty($data)) {
            $this->db->where("email_custom_id", $email_custom_id);
            $updated = $this->db->update("event_email_custom", $data);
            if ($updated) {
                return true;
            }
            return false;
        }
    }

    public function delete_email_push($email_custom_id) {
        //delete recipient
        $this->db->where("email_custom_id", $email_custom_id);
        $this->db->where("email_recipient_status", 1);
        $this->db->where("email_status", 0);
        $this->db->delete("event_email_custom_recipient");

        //delete filters
        $this->db->where("email_custom_id", $email_custom_id);
        $this->db->delete("event_email_custom_filter");

        //hide custom filters
        $this->db->where("email_custom_id", $email_custom_id);
        $this->db->update("event_email_custom", array("email_custom_status" => 2));

        return $this->db->affected_rows();
    }

    public function addCustomFilters($newFilters){
        if(isset($newFilters) && !empty($newFilters)) {
            $this->db->insert_batch("event_email_custom_filter", $newFilters);
            if ($this->db->affected_rows()) {
                return $this->db->insert_id();
            }
            return false;
        }
    }

    public function addCustomRecipients($newFilters){
        if(isset($newFilters) && !empty($newFilters)) {
            $this->db->insert_batch("event_email_custom_recipient", $newFilters);
            if ($this->db->affected_rows()) {
                return $this->db->insert_id();
            }
            return false;
        }
    }

    public function deleteRecipients($newFilters, $email_custom_id){
        //check for dependencies
        if(!$this->checkDependecies($email_custom_id)){
            $this->db->where("email_custom_id", $email_custom_id);
            $this->db->delete("event_email_custom_recipient");
        }
        return true;
    }

    public function deleteFilters($newFilters, $email_custom_id, $email_filter_id){
        //check for dependencies
        if(!$this->checkDependecies($email_custom_id)){
            //$this->db->where("email_filter_search NOT IN(".$newFilters.")");
            $this->db->where("email_custom_id", $email_custom_id);
            $this->db->where("email_filter_id", $email_filter_id);
            $this->db->delete("event_email_custom_filter");
        }
        return true;
    }

    public function checkDependecies($email_custom_id){
        $this->db->where("email_custom_id", $email_custom_id);
        $this->db->where("email_status", 1);
        $this->db->where("email_recipient_status", 1);
        $this->db->limit(1);
        return $this->db->get("event_email_custom_recipient")->num_rows();
    }

    public function get_data_push_event_email(){
        $result = $this->db->select("
                eec.email_custom_id,
                e.event_id,
                es.event_schedule_id,
                e.title as event_title,
                et.event_type,
                es.event_status,
                ecl.city as city,
                e.location as event_place_name,
                e.address as event_address,
                e.code_postal as event_postal_code,
                es.rate as event_rate,
                ecl.city as event_venue,
                efa.file_name as event_picture,
                e.description as event_description,
                es.start_date_time as event_start_date")
            ->select("DAYNAME(es.start_date_time) AS event_start_day_name", FALSE)
            ->select("DATE_FORMAT(es.start_date_time, '%e') AS event_start_day", FALSE)
            ->select("DATE_FORMAT(es.start_date_time, '%m') AS event_start_month", FALSE)
            ->select("DATE_FORMAT(es.start_date_time, '%M') AS event_start_month_name", FALSE)
            ->select("DATE_FORMAT(es.start_date_time, '%Hh%i') AS event_start_hour", FALSE)
            ->select("DATE_FORMAT(es.start_date_time, '%Y') AS event_start_year", FALSE)
            ->from(" event_email_custom eec")
            ->join("event_schedule es", "es.event_schedule_id = eec.event_schedule_id", "left")
            ->join("event e", "e.event_id = es.event_id", "left")
            ->join('event_type et', 'et.event_type_id = e.event_type_id',"left")
            ->join('event_email_custom_recipient eecr', 'eecr.email_custom_id = eec.email_custom_id',"left")
            ->join('event_city_location ecl', 'ecl.city_location_id = e.city_location', "left")
            ->join('event_file_attachment efa', 'efa.event_id = e.event_id AND efa.status=1 AND efa.attachment_type =1', "left")
            ->where("eec.email_custom_status = 1 AND (eecr.email_status = 0 OR (eecr.email_status = 3 AND eecr.email_number_of_send_attempt <=3))")
            ->where("eecr.email_custom_id = eec.email_custom_id")
            ->where("eecr.email_recipient_status",1)
            ->where_in("es.back_office_status", array(2,3))
            ->where("es.start_date_time > NOW()")
            ->where("es.remaining_seat >", 0)
            ->where("es.event_status", "AVAILABLE")
            ->group_by("eec.email_custom_id")
            ->get();

        if ($result->num_rows() > 0) {
            return $result->result();
        }
        return false;
    }

    public function get_push_event_recipients($email_custom_id, $limit) {
        $result = $this->db->query("SELECT
            eecr.subscriber_id,
            eecr.email_recipient_id,
            u.email_address,
            CONCAT(u.first_name, ' ', u.last_name) AS subscriber,
            eecr.email_number_of_send_attempt
        FROM
            event_email_custom_recipient eecr
        LEFT JOIN user u ON u.user_id = eecr.subscriber_id
        LEFT JOIN event_email_custom eec ON eec.email_custom_id = eecr.email_custom_id
        LEFT JOIN event_schedule es ON es.event_schedule_id = eec.event_schedule_id
        LEFT JOIN event e ON e.event_id = es.event_id
        WHERE
            eec.email_custom_status = 1
            AND
            eecr.email_recipient_status=1
            AND
            (eecr.email_status=0 OR (eecr.email_status = 3 AND eecr.email_number_of_send_attempt <=3))
            AND
            eecr.email_custom_id = ?
            AND es.start_date_time >= NOW()
            AND es.remaining_seat > 0
            AND es.event_status = 'AVAILABLE'
            GROUP BY eecr.subscriber_id
            LIMIT 0, $limit", array($email_custom_id));

        if ($result->num_rows() > 0) {
            return $result->result();
        }
        return false;
    }

    public function get_push_event_email_data($email_recipient_id, $subscriber){
        $result = $this->db->select("
                e.event_id,
                es.event_schedule_id,
                e.title as event_title,
                es.event_status,
                et.event_type,
                ecl.city as city,
                (CASE WHEN e.location IS NULL THEN \"\" ELSE e.location END) as event_place_name,
                (CASE WHEN e.address IS NULL THEN \"\" ELSE e.address END) as event_address,
                (CASE WHEN e.code_postal IS NULL THEN \"\" ELSE e.code_postal END) as event_postal_code,
                es.rate as event_rate,
                ecl.city as event_venue,
                efa.file_name as event_picture,
                eet.email_tpl_detail,
                e.description as event_description,
                es.start_date_time as event_start_date")
            ->select("DAYNAME(es.start_date_time) AS event_start_day_name", FALSE)
            ->select("DATE_FORMAT(es.start_date_time, '%e') AS event_start_day", FALSE)
            ->select("DATE_FORMAT(es.start_date_time, '%m') AS event_start_month", FALSE)
            ->select("DATE_FORMAT(es.start_date_time, '%M') AS event_start_month_name", FALSE)
            ->select("DATE_FORMAT(es.start_date_time, '%Hh%i') AS event_start_hour", FALSE)
            ->select("DATE_FORMAT(es.start_date_time, '%Y') AS event_start_year", FALSE)
            ->select("CONCAT(u.first_name, ' ', u.last_name) AS subscriber", FALSE)
            ->select("CONCAT('(', u.email_address, ')') AS email_address", FALSE)
            ->from(" event_email_custom_recipient eecr")
            ->join("event_email_custom eec", "eec.email_custom_id = eecr.email_custom_id", "left")
            ->join("event_schedule es", "es.event_schedule_id = eec.event_schedule_id", "left")
            ->join("event e", "e.event_id = es.event_id", "left")
            ->join("user u", "u.user_id = eecr.subscriber_id", "left")
            ->join('event_type et', 'et.event_type_id = e.event_type_id',"left")
            ->join('event_email_template eet', 'eet.email_tpl_id = eecr.email_tpl_id',"left")
            ->join('event_city_location ecl', 'ecl.city_location_id = e.city_location', "left")
            ->join('event_file_attachment efa', 'efa.event_id = e.event_id AND efa.status=1 AND efa.attachment_type =1', "left")
            ->where("eecr.email_status = 1")
            ->where("eecr.email_recipient_id", $email_recipient_id)
            ->where("eecr.subscriber_id", $subscriber)
            ->group_by("eec.event_schedule_id")
            ->get();
        if($result->num_rows() > 0){
            return $result->row();
        }
        return false;
    }
}