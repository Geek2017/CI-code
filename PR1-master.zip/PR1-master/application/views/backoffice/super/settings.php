<div id="main">
    <div class="table-responsive">
        <!--        <div id="tbl"><button type="button" class="btn btn-primary glyphicon glyphicon-plus" id="btnAdd"></button></div>-->
        <br><br>
        <table id="tbl_settings" class="table table-striped table-bordered" cellspacing="0" width="100%">
            <thead>
            <tr>
                <th>ID</th>
                <th>Code</th>
                <th>Valeur</th>
                <th>Description</th>
                <th>Statut</th>
                <th>Actions</th>
            </tr>
            </thead>
        </table>
    </div>
</div>


<div class="modal fade in" id="modal_setting">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">Contact dans le cadre d’un bilan de mobilité interne</h4>
            </div>
            <div class="modal-body">
                <form action="" method="POST" role="form" id="edit_setting_form" class="setting-form">
                    <input type="hidden" name="setting_id" id="setting_id">
                    <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                            <div class="form-group-sm">
                                <label for="">Code</label>
                                <input type="text" class="form-control nxt txtboxNumberOnlyAmount"  name="setting_code" id="setting_code"  placeholder="" disabled>
                            </div>
                            <div class="form-group-sm">
                                <label for="">Valeur</label>
                                <input type="text" class="form-control nxt"  name="setting_value" id="setting_value"  placeholder="" required>
                            </div>
                            <div class="form-group-sm">
                                <label for="">Description</label>
                                <textarea class="form-control nxt"  name="setting_description" id="setting_description"  placeholder="" required>
                                    </textarea>
                            </div>
                            <div class="form-group-sm">
                                <label for="">Statut</label>
                                <select class="form-control nxt"  name="setting_status" id="setting_status"  required>
                                    <option value="1">Activée</option>
                                    <option value="0">Désactivée</option>
                                </select>
                            </div>
                        </div>
                    </div>


            </div>
            <div class="modal-footer">
                <button type="button" onclick="settings.submit_edit();" id="submit_edit_setting" class="btn btn-primary nxt">Soumettre</button>
            </div>
            </form>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
