<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Jobs extends CI_Controller {

	function __construct() 
	{
        parent::__construct();
    }
	public function add_jobs(){
		$this->job->add_job();
	}
	public function update_jobs(){
		$this->job->update_job();
	}
	public function delete_jobs(){
		$this->job->delete_job();
	}
	public function get_jobs()
    {
        $this->job->get_job_list();
    }
	public function get_activity(){
		$id = $this->uri->segment(3) ? (int)$this->uri->segment(3) : null;
		$this->job->get_activity_list($id);
	}
	public function add_activity(){
		$this->job->add_activity();
		redirect($this->agent->referrer().'#activity_job');
	}
	public function get_savoir(){
		$id = $this->uri->segment(3) ? (int)$this->uri->segment(3) : null;
		$this->job->get_savoir($id);
	}
	public function add_savoir(){
		$this->job->add_savoir();
		redirect($this->agent->referrer().'#savoir_job');
	}
	public function get_faire(){
		$id = $this->uri->segment(3) ? (int)$this->uri->segment(3) : null;
		$this->job->get_faire($id);
	}
	public function add_faire(){
		$this->job->add_faire();
		redirect($this->agent->referrer().'#faire_job');
	}
	public function get_etre(){
		$id = $this->uri->segment(3) ? (int)$this->uri->segment(3) : null;
		$this->job->get_etre($id);
	}
	public function add_etre(){
		$this->job->add_etre();
		redirect($this->agent->referrer().'#etre_job');
	}
	public function delete_satisfaction()
	{
		if($this->job->delete_satisfactions())
		{
			 echo json_encode( array(
	            'redirect' => 'true',
	            'message' => 'Supprimé'
	        ) );
		}else{
			 echo json_encode( array(
	            'redirect' => 'false',
	            'message' => 'Impossible de supprimer'
	        ) );
		}
		
	}
	public function count_job()
	{
		$this->job->count_jobs();
	}
	

	
}
