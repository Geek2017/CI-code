<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/* MY PROFILE */
$lang["my_profile"] = "Mon Profil";

/* Modal Dialog Title */
$lang["modal_update_user_profile"] = "Mise à jour le profil de l'utilisateur";

/* Fields and Buttons */
$lang["first_name"] = "Prénom";
$lang["last_name"] = "Nom de famille";
$lang["full_name"] = "Nom Complet";
$lang["email_address"] = "Adresse e-mail";
$lang["role"] = "Fonction";
$lang["username"] = "Identifiant";
$lang["pwd"] = "Mot de passe";
$lang["new_pwd"] = "Nouveau mot de passe";
$lang["confirm_new_pwd"] = "Confirmer le nouveau mot de passe";
$lang["status"] = "Statut";

/* Button */
$lang["update_profile"] = "Mettre à jour le profil";

/* Confirmation Action Message */
$lang["modal"]["cma_msg"]["update_profile"] = "Enregistrer les changements?";

/* SERVER-SIDE MESSAGE */
$lang["updated_profile_info"] ="Les informations de profil a été mis à jour!";
$lang["old_pwd_didnt_match"] ="Ancien mot de passe ne correspond !";
$lang["old_new_pwd_didnt_match"] ="Nouveau mot de passe et confirmer le nouveau mot de passe ne correspond !";
$lang["full_name_didnt_match"] ="Nom complet existe déjà !";










/* End of file my_profile_lang.php */
/* Location: ./application/language/fr/backoffice/my_profile_lang.php */
