<?php 
$statistics = new Backoffices();
?>

<div id="main">
    <div class="table-responsive">
    <div id="tbl"><button type="button" class="btn btn-primary glyphicon glyphicon-plus" id="add_admin"><span class="btn_desc"> Ajouter une entreprise </span ></button></div>
       <br><br>
     <table id="organizations" class="table table-striped table-bordered" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th><?php echo  $this->languages->lang('email'); ?></th>
                <th><?php echo  $this->languages->lang('subsidiary'); ?></th>
                <th><?php echo  $this->languages->lang('role'); ?></th>
                <th><?php echo  $this->languages->lang('status'); ?></th>
                <th><?php echo  $this->languages->lang('creation_date'); ?></th>
                <th><?php echo  $this->languages->lang('nos_user_in_progress'); ?></th>
                <th><?php echo  $this->languages->lang('user_created_max_user'); ?></th>
                <th><?php echo  $this->languages->lang('done_user'); ?></th>
                <th><?php echo  $this->languages->lang('action'); ?></th>
            </tr>
        </thead>
         <?php 
            if($orgs){
                foreach($orgs as $list)
                {
                    $status = $list->active == "1" ? "<span class=\"ref_validate glyphicon glyphicon-ok-sign\"></span>" : "<span class=\"ref_validate glyphicon glyphicon-remove-sign\"></span>";
                    $icon = $list->active == "1" ? "glyphicon-remove" : "glyphicon-ok";
                    echo "<tr>";
                    echo " <td>".$list->username."</td>";
                    echo "<td>".$list->subsidiary."</td>";//" <td>".$controller->get_organization_by_id($list->ord_id)->name."</td>";
                    echo " <td>".$controller->roles($list->role_id)."</td>";
                    echo " <td>".$status."</td>";

                    echo " <td>".( $list->date_created > 0 ? date("d/m/Y", strtotime($list->date_created)) : "N / A" )."</td>";
                    echo "<td>".$statistics->users_progresions_and_dones( $list->ord_id )['users_in_progress']."</td>";
                    echo " <td>".$statistics->users_progresions_and_dones( $list->ord_id )['all_users']."/".$list->max_users."</td>";
                    echo " <td>".$statistics->users_progresions_and_dones( $list->ord_id )['users_done']."</td>";
          
                 

                    echo '<td><button class="btn btn-primary glyphicon glyphicon-pencil" onclick="Organizations.edit('.$list->id.')"></button> <button class="btn btn-primary glyphicon '.$icon.'" onclick="Organizations.delete('.$list->id.','.$list->active.')" ></button></td>';
                    echo "</tr>";
                } 
            }
            ?>
        </tbody>
    </table>
       
    </div>
</div>


<!-- Modal -->
<div class="modal fade" id="AdminForm" tabindex="-1" role="dialog" 
     aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">

            <!-- Modal Header -->
            <div class="modal-header" style="background-color:#337AB7; color:#FFFFFF;">
                <button type="button" class="close" 
                   data-dismiss="modal">
                       <span aria-hidden="true">&times;</span>
                       <span class="sr-only">Annuler</span>
                </button>
                <h4 class="modal-title" id="myModalLabel">
                     Formulaire d'entreprise
                </h4>
            </div>
            <!-- End Modal Header -->
            
            <!-- Modal Body -->
            <div class="modal-body">
                <form class="form-horizontal" role="form" id="admin">
                    <div class="form-group">
                        <label class="col-sm-4 control-label title-label" for="name" >Entreprise</label>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-4 control-label" for="name" >Groupe</label>
                        <div class="col-sm-7">
                            <input  type="text" class="form-control" id="name" name="name"  placeholder=""/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-4 control-label"for="subsidiary" >* Société / Filiale</label>
                        <div class="col-sm-7">
                            <input  type="text" class="form-control" id="subsidiary" name="subsidiary"  placeholder=""/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label  class="col-sm-4 control-label"for="sector">Secteur</label>
                        <div class="col-sm-7">
                            <input  type="email" class="form-control" id="sector" name="sector" placeholder=""/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label  class="col-sm-4 control-label" for="sector">Nombre d'effectifs</label>
                        <div class="col-sm-7">
                            <input  type="email" class="form-control numberOnly" id="num_staff" name="num_staff" placeholder=""/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label  class="col-sm-4 control-label"for="address_line1">Adresse</label>
                        <div class="col-sm-7">
                            <input  type="email" class="form-control" id="address_line1" name="address_line1" placeholder=""/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-4 control-label"
                               for="zip_code" >Code postal</label>
                        <div class="col-sm-7">
                            <span style="position: relative; z-index: 24;">
                            <input maxlength="5" type="text" class="form-control numberOnly" onblur="postalCodeLookup('FR');" id="zip_code" name="zip_code" placeholder=""/>
                            <span style="position: absolute; top: 20px; left: 0px; z-index:25;visibility: hidden;" id="suggestBoxElement"></span></span>
                         </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-4 control-label"
                               for="city" >Ville</label>
                        <div class="col-sm-7">
                            <input type="text" class="form-control" onblur="closeSuggestBox();"  id="org_city" name="org_city" placeholder=""/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-4 control-label"
                               for="city" >Pays</label>
                        <div class="col-sm-7">
                            <input type="text" class="form-control" id="country" name="org_country" placeholder=""/>
                        </div>
                    </div>
<!--                    <div class="form-group">-->
<!--                        <label class="col-sm-4 control-label"-->
<!--                               for="website_url" >Site web</label>-->
<!--                        <div class="col-sm-7">-->
<!--                            <input type="text" class="form-control" id="website_url" name="website_url" placeholder=""/>-->
<!--                        </div>-->
<!--                    </div>-->

                    <div class="form-group">
                        <label class="col-sm-4 control-label title-label" for="name" >Contact de l'entreprise</label>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-4 control-label"for="name" >Mr. Mme. Mlle</label>
                        <div class="col-sm-7">
                            <input  type="text" class="form-control" id="civility" name="civility"  placeholder=""/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-4 control-label"for="name" >Prénom</label>
                        <div class="col-sm-7">
                            <input  type="text" class="form-control" id="firstname" name="firstname"  placeholder=""/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-4 control-label"for="name" >Nom</label>
                        <div class="col-sm-7">
                            <input  type="text" class="form-control" id="lastname" name="lastname"  placeholder=""/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-4 control-label"for="name" >Fonction</label>
                        <div class="col-sm-7">
                            <input  type="text" class="form-control" id="function" name="function"  placeholder=""/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-4 control-label"for="username" >* E-mail professionnel</label>
                        <div class="col-sm-7">
                            <input  type="text" class="form-control" id="username" name="username"  placeholder=""/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-4 control-label"for="name" >Téléphone professionnel</label>
                        <div class="col-sm-7">
                            <input  type="text" class="form-control" id="telephone" name="contact"   placeholder="0X XX XX XX XX" />
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-4 control-label title-label" for="name" >Information de création</label>
                    </div>
                  <div class="form-group">
                    <label class="col-sm-4 control-label"for="password" >* Mot de passe</label>
                    <div class="col-sm-7">
                        <input  type="password" class="form-control" id="password" name="password"  placeholder=""/>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-4 control-label"for="cpassword" >* Confirmation du mot de passe</label>
                    <div class="col-sm-7">
                        <input  type="password" class="form-control" id="cpassword" name="cpassword"  placeholder=""/>
                    </div>
                  </div>
                    <div class="form-group">
                        <label class="col-sm-4 control-label"
                               for="website_url" >* Nombre maximal d'utilisateurs</label>
                        <div class="col-sm-7">
                            <input type="text" class="form-control numberOnly" id="max_users" name="max_users" placeholder=""/>
                        </div>
                    </div>
                </form>  
            </div>
            <!-- End Modal Body -->
            
            <!-- Modal Footer -->
            <div class="modal-footer">
                <center>
                     <button type="button" class="btn btn-primary" id="admin_btn" onclick="Organizations.add();">
                    Enregistrer les modifications
                    </button>
                    <button type="button" class="btn btn-default" data-dismiss="modal">
                      Annuler
                    </button>

                </center>
                
               
            </div>
            <!-- End Modal Footer -->

        </div>
    </div>
</div>