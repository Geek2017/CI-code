<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 
	
class Event_dashboard_gaoauth_code_model extends CI_Model{

    public function __construct() {
        parent::__construct();
    }

	public function get_refresh_token(){
        $this->db->select('oauth_code_id, refresh_token, access_token, access_token_expiration');
        $this->db->where('status', 1);
        $result = $this->db->get('event_dashboard_gaoauth_code');
        if($result->num_rows() > 0){
            return (array) $result->row();
        }
        return false;
    }

    public function update_access_token($oauth_code_id, $data){
        $this->db->where('oauth_code_id', $oauth_code_id);
        $this->db->update('event_dashboard_gaoauth_code', $data);
        return $this->db->affected_rows();
    }

    public function save_new_oauth_code($data){
       //set previuos oauth code to obsolete
        $this->db->where('status', 1);
        $this->db->update('event_dashboard_gaoauth_code', array('status' => 0));

        //and save the new oauth code
        $this->db->insert('event_dashboard_gaoauth_code', $data);
        return $this->db->insert_id();
    }

    public function gsignout_by_user($user_id){
        $this->db->where('user_id', $user_id);
        $this->db->where('status', 1);
        $this->db->update('event_dashboard_gaoauth_code', array("status" => 0));
        return $this->db->affected_rows();
    }
}

?>