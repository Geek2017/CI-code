<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Subject extends CI_Controller {

	function __construct() 
	{
        parent::__construct();
    }
    public function reset_qualifiers(){
    	
        $table = 0;

        switch ($_POST['table']) {
            case 1:
               $table = "tb1";
            break;

            case 2:
               $table = "tb2";
            break;

            case 3:
               $table = "tb3";
            break;

            case 4:
               $table = "tb4";
            break;
           
        }

        $this->db->where('user_id', $this->session->userdata('id') );
        $this->db->like('name', $table , 'after');
        $this->db->delete('qualifiers');

        echo json_encode( array( 'close' => "true" ) );
       
    }
    public function populate(){
    	$data = array();
		$query = $this->db->get_where('qualifiers', array('user_id' => $this->session->userdata('id')));
		
		if ($query->num_rows() > 0) 
		{
            foreach ($query->result() as $row) 
            {
				$data[] = $row;
            }
        }
        echo json_encode( $data ); 
    }
    public function add_qualifiers(){
    	if( count($_POST) == 3 ){
    		foreach ($_POST as $key => $value) {	
    			$this->db->insert('qualifiers',  array('user_id' => $this->session->userdata('id'), 'name' => $key , 'value' =>  html_entity_decode($value) ) );
    		}
    		echo json_encode( array( 'msg' => 'Les trois qualificatifs ont bien été ajouté' , 'close' => "true" ) );
    	}else{
    		echo json_encode( array( 'msg' => 'Veuillez sélectionner trois qualificatifs' , 'close' => "false" ) );
    	}
    	
    }
	public function subject()
	{
		$data = array();
		$query = $this->db->get_where('question_answers', array('user_id' => $this->session->userdata('id'), 'question_id' => 66));
		
		if ($query->num_rows() > 0) 
		{
            foreach ($query->result() as $row) 
            {
                foreach( json_decode($row->answer_caption,true) as $key=> $ans)
				{
				    $data[] = $ans;
				}
            }
        }
        echo json_encode( $data ); 
	}
}
