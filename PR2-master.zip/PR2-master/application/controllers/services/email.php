<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Email extends MY_Controller {

    protected $search = array();
    protected $replacements = array();

    public function __construct()
    {
        //parent::__construct();
        $this->my_controller_parent_construct();
        $this->lang->load('frontoffice/subscribe', 'fr');
    }

    public function push_event_email($code){
        if(isset($code) && !empty($code)){
            //decode
            $code = base64_decode($code);
            if(!empty($code)){
                $ecode = explode("_", $code);
                if(sizeof($ecode) == 2){
                    $this->load->model("event_email_custom_model");
                    $result = $this->event_email_custom_model->get_push_event_email_data($ecode[0], $ecode[1]);
                    if($result) {
                        $this->initialize_event_vars($result);
                        $email_template = str_replace($this->search, $this->replacements, urldecode($result->email_tpl_detail));
                        echo $this->create_header().$email_template.$this->create_footer();
                    } else{
                        show_404();
                    }
                } else {
                    show_404();
                }
            } else {
                show_404();
            }
        } else {
            show_404();
        }
    }

    public function reminder($code){
        if(isset($code) && !empty($code)){
            //decode
            $code = base64_decode($code);
            if(!empty($code)){
                $ecode = explode("_", $code);
                if(sizeof($ecode) == 2){
                    $this->load->model("event_registration_model");
                    $result = $this->event_registration_model->get_reminder_email_data($ecode[0], $ecode[1]);
                    if($result) {
                        $this->initialize_event_vars($result);
                        $email_template = str_replace($this->search, $this->replacements, urldecode($result->email_tpl_detail));
                        echo $this->create_header().$email_template.$this->create_footer();
                    } else{
                        show_404();
                    }
                } else {
                    show_404();
                }
            } else {
                show_404();
            }
        } else {
            show_404();
        }
	}

    public function waitlist_reinvitation($code){
        if(isset($code) && !empty($code)){
            //decode
            $code = base64_decode($code);
            if(!empty($code)){
                $ecode = explode("_", $code);
                if(sizeof($ecode) == 2){
                    //$this->lang->load('frontoffice/subscribe', 'fr');
                    $this->load->model("event_wait_list_model");
                    $result = $this->event_wait_list_model->get_waitlist_reinvitation_email_data($ecode[0], $ecode[1]);
                    if($result) {
                        $this->initialize_event_vars($result);
                    $email_template = str_replace($this->search, $this->replacements, urldecode($result->email_tpl_detail));
                    echo $this->create_header().$email_template.$this->create_footer();
                    } else{
                        show_404();
                    }
                } else {
                    show_404();
                }
            } else {
                show_404();
            }
        } else {
            show_404();
        }
    }

    public function forgot_password($reset_code){
        if(isset($reset_code) && !empty($reset_code)){
            $this->load->model("user_forgot_password_model");
            //get result using reset_code
            $result = $this->user_forgot_password_model->get_data_by_reset_code($reset_code);
            if($result) {
                $route_page = ($result->role_id == 3)?"enter_code_page":"enter_code";
                $message = "";

                $mail_content = array();
                $message .= "<br>Si vous avez oublie&#769; votre mot de passe, veuillez cliquer sur le lien suivant et entrer le code ci-dessous :<br><br>";
                $message .= "<a href='".base_url($route_page)."?email=".$result->email_address."' target='_blank'>> Changer mon mot de passe <</a><br>";
                $message .= "Code : " . $reset_code;

                $mail_content["logo"] = "http://s1.lemde.fr/mmpub/img/espace-client/logo-lemonde.png";
                $mail_content["description"] = $message;
                $mail_content["open_in_a_newtab"] = false;
                $page = $this->load->view("backoffice/email_template/forgot_password_tpl", $mail_content, true);
                $page = str_replace("{(email)}", "(".$result->email_address.")", $page);
                echo $this->create_header().$page.$this->create_footer();
            } else {
                show_404();
            }
        } else {
            show_404();
        }
    }

    public function email_registered($code){
        if(isset($code) && !empty($code)){
            //decode
            $code = base64_decode($code);
            if(!empty($code)){
                $ecode = explode("_", $code);
                if(sizeof($ecode) == 4){
                    $user_id = $ecode[0]; $event_id = $ecode[1]; $event_schedule_id = $ecode[2];
                    $seats_reserved = $ecode[3];

                    $this->load->model("user_subscriber_model");;
                    $this->load->model("event_model");
                    $this->load->model('event_email_template_model');

                    $user_info = $this->user_subscriber_model->email_registered($user_id);
                    $event_info = $this->event_model->event_details_email($event_schedule_id);
                    $email_tpl = $this->event_email_template_model->get_current_event_email_template($event_id, $event_schedule_id, 3, true);

                    $event_info = $this->add_email_vars($user_info, $event_info, $seats_reserved);

                    $this->initialize_event_vars($event_info);
                    $email_template = str_replace($this->search, $this->replacements, urldecode($email_tpl->email_tpl_detail));
                    echo $this->create_header().$email_template.$this->create_footer();

                } else {
                    show_404();
                }
            } else {
                show_404();
            }
        } else {
            show_404();
        }
    }

    public function email_unregistered($code){
        if(isset($code) && !empty($code)){
            //decode
            $code = base64_decode($code);
            if(!empty($code)){
                $ecode = explode("_", $code);
                if(sizeof($ecode) == 4){
                     $user_id = $ecode[0]; $event_id = $ecode[1]; $event_schedule_id = $ecode[2];
                    $seats_reserved = $ecode[3];
                    
                    $this->load->model("user_subscriber_model");;
                    $this->load->model("event_model");
                    $this->load->model('event_email_template_model');

                    $user_info = $this->user_subscriber_model->email_registered($user_id);
                    $event_info = $this->event_model->event_details_email($event_schedule_id);
                    $email_tpl = $this->event_email_template_model->get_current_event_email_template($event_id, $event_schedule_id, 5, true);
                    
                    $event_info = $this->add_email_vars($user_info, $event_info, $seats_reserved);

                    $this->initialize_event_vars($event_info);
                    $email_template = str_replace($this->search, $this->replacements, urldecode($email_tpl->email_tpl_detail));
                    echo $this->create_header().$email_template.$this->create_footer();

                } else {
                    show_404();
                }
            } else {
                show_404();
            }
        } else {
            show_404();
        }
    }

    public function email_registered_waitlist($code){
        if(isset($code) && !empty($code)){
            //decode
            $code = base64_decode($code);
            if(!empty($code)){
                $ecode = explode("_", $code);
                if(sizeof($ecode) == 4){
                    $user_id = $ecode[0]; $event_id = $ecode[1]; $event_schedule_id = $ecode[2];
                    $seats_reserved = $ecode[3];

                    $this->load->model("user_subscriber_model");;
                    $this->load->model("event_model");
                    $this->load->model('event_email_template_model');

                    $user_info = $this->user_subscriber_model->email_registered($user_id);
                    $event_info = $this->event_model->event_details_email($event_schedule_id);
                    $email_tpl = $this->event_email_template_model->get_current_event_email_template($event_id, $event_schedule_id, 6, true);
                    
                    $event_info = $this->add_email_vars($user_info, $event_info, $seats_reserved);

                    $this->initialize_event_vars($event_info);
                    $email_template = str_replace($this->search, $this->replacements, urldecode($email_tpl->email_tpl_detail));
                    echo $this->create_header().$email_template.$this->create_footer();

                } else {
                    show_404();
                }
            } else {
                show_404();
            }
        } else {
            show_404();
        }
    }

    private function create_header(){
        return '<!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="utf-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <meta name="description" content="">
            <meta name="author" content="">
            <meta Http-Equiv="Cache-Control" Content="no-cache">
            <meta Http-Equiv="Pragma" Content="no-cache">
            <meta Http-Equiv="Expires" Content="0">
            <meta http-equiv="Content-type" content="text/html; charset=UTF-8">
            <title>Le Monde évènements abonnés</title>
            <link href="'.images_bundle().'fav-icon.ico" rel="icon" sizes="32x32">
        </head>
        <body onload="remove_headers()">';
    }

    private function create_footer(){
        return '</body>
        <script type="text/javascript">
        function remove_headers(){
            var tables= document.getElementsByTagName("table");
            //tables[0].style.display = "none";
            tables[0].remove();
        }
        </script></html>';
    }

    private function create_footer_fo() {
        return '</body>
        </html>';
    }

    private function add_email_vars($user_info, $event_info, $seats_reserved=0){
       
        $event_info->{"subscriber"} = $user_info->first_name." ".$user_info->last_name;
        $event_info->{"seats_reserved"} = ($seats_reserved <= 1)?$seats_reserved.' place': $seats_reserved.' places ';
        $event_info->{"email_address"} = $user_info->email_address;

        return $event_info;
    }

    private function initialize_event_vars($event){
        $Vars = array('subscriber','email_address','event_title','event_start_day_name','event_start_day','event_start_month', 'event_start_month_name','event_start_year','event_start_hour','seats_reserved','event_start_day_name', 'city', 'event_description', 'event_venue', 'event_place_name', 'event_address', 'event_postal_code', 'event_rate', 'day', 'addressee', 'start_day', 'start_month', 'start_year', 'start_date_hour', 'subscriber', 'event_url', 'new_tab_url', 'event_picture', 'email_address');
        //for translation
        $toFR = array('event_start_month_name', 'event_start_day_name');

        foreach ($event as $key => $value) {
            if (in_array($key, $Vars)) {                
                //translate to french
                if(in_array($key, $toFR)){
                    $value = $this->lang->line($value);
                }
                $this->search[] = "[[var:" . $key . "]]";
                $this->replacements[] = $value;
            }
        }
        $this->search[] = "[[var:event_url]]";
        $this->replacements[] = base_url('frontoffice/event_details?event_id='.$event->event_id);

        $this->search[] = "[[var:event_picture]]";
        $this->replacements[] = images_bundle().'frontoffice/events/'.$event->event_picture;
    }

    public function upload_default_email_template(){

        $this->load->helper('default_email_template.php');
        $this->load->model("event_email_template_model");
        $result = $this->event_email_template_model->upload_default_email_template(upload_default_email_template());

        if($result){
            print_r("Email templates have been reset.");
        }
    }

}