<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pdf extends CI_Controller {

    function __construct()
    {
        parent::__construct();
    }
  
    public function index()
    {
      //$this->pdfs->generate_pdf('<h1>fsdfdsfdsfsdfdsfsdfsdfsdfdsfsdfsd sdsdfsdsdfsdsdsdfsd fdssdsdf sdsdf</h1>');
    }

}
