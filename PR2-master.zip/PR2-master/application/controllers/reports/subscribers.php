<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Subscribers extends MY_Controller {

    public function __construct() {
        //parent::__construct();
        $this->my_controller_parent_construct();
        //load language files
        $this->load_language_backoffice();
        $this->lang->load('backoffice/reports', 'fr');
        //load model
        $this->load->model("user_model");
    }

    public function export_subscribers_list() {
        $this->check_session_timed_out("bo_redirect_now");

        ini_set('memory_limit', '1024M');
        ini_set('max_execution_time', (60*3));
        $data = array();

        /*BASIC SUBCRIBERS LIST EXPORT TEMPLATE*/
        $column_names = array("genre", "last_name", "first_name", "address_1", "address_2", "address_3", "code_postal",
            "city", "telephone_number", "mobile_number", "email_address", "subscriber_number", "subscription_date_op", "birth_date",
            "event_preference", "status", "number_of_user_and_guest", "avg_number_of_registration", "number_of_registration");

        $subscribers = $this->user_model->get_subscriber_information_list_export($this->data["logged_in"]["user_id"], $this->input->get(), 3);

        /** Include PHPExcel */
        require_once APPPATH  . 'libraries/Classes/PHPExcel.php';
        $sheet_num = 0;

        // Create new PHPExcel object
        $objPHPExcel = new PHPExcel();

        // Set document properties
        $objPHPExcel->getProperties()->setCreator("Le Monde Event Management System")
            ->setLastModifiedBy("Le Monde Event Management System")
            ->setTitle("Office 2007 XLSX Document")
            ->setSubject("Office 2007 XLSX  Document")
            ->setDescription("Test document for Office 2007 XLSX, generated using PHP classes.")
            ->setKeywords("office 2007 openxml php")
            ->setCategory("Export file");

        // Add some data
        $objPHPExcel->setActiveSheetIndex($sheet_num)->setTitle($this->lang->line("reports")["client"]["client_file_name"]);
        $objPHPExcelSheet = $objPHPExcel->getActiveSheet($sheet_num);

        $col = 0;

        if(count($column_names) > 0)
        {
            foreach($column_names as $fcol=>$name)
            {
                if($name == "subscription_date_op" ) {
                    $first_letter = PHPExcel_Cell::stringFromColumnIndex($col);
                    $objPHPExcelSheet->setCellValueByColumnAndRow($col, 1, "");
                    $this->highlight_columns($objPHPExcelSheet, $col, 1);

                    $mergeRange = $first_letter . '1:';
                    $objPHPExcelSheet->setCellValueByColumnAndRow($col, 2, mb_strtoupper('Date').' d\'inscription');
                    $this->highlight_columns($objPHPExcelSheet, $col, 2);
                    $xcolumn = ++$col;
                    $last_letter = PHPExcel_Cell::stringFromColumnIndex($xcolumn);

                    $mergeRange .= $last_letter . '1';
                    $objPHPExcelSheet->setCellValueByColumnAndRow($xcolumn, 2, mb_strtoupper('Heure').' d\'inscription');
                    $this->highlight_columns($objPHPExcelSheet, $xcolumn, 2);
                    $objPHPExcelSheet->mergeCells($mergeRange);
                } else {
                    $first_letter = PHPExcel_Cell::stringFromColumnIndex($col);
                    $header_range = "{$first_letter}1:{$first_letter}2";
                    $objPHPExcelSheet->setCellValueByColumnAndRow($col, 1, mb_strtoupper($this->lang->line($name)));
                    $objPHPExcelSheet->mergeCells($header_range);
                    $objPHPExcelSheet->getStyle($header_range)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
                    $this->highlight_columns($objPHPExcelSheet, $col, 1);
                }

                $col++;
            }
        }

        $col = 0;
        $row = 3;

        if(count($subscribers) > 0)
        {
            foreach($subscribers as $epd)
            {
                foreach($column_names as $fcol=>$name)
                {
                    if($name != "subscription_date_op" ) {
                        if (trim($name) != "" && isset($epd->{$name}) && !empty($epd->{$name})) {
                            $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col++, $row, $epd->{$name});
                        } else {
                            $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col++, $row, "");
                        }
                    } else {
                        $val = ($epd->{$name}!="")?explode(" ", $epd->{$name}):array();
                        $date = (isset($val[0]))?$val[0]:"";
                        $hour = (isset($val[1]))?$val[1]:"";
                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col++, $row, $date);
                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col++, $row, $hour);
                    }
                }
                $col = 0;
                $row++;
            }
        }

        // Auto size columns for each worksheet
        foreach ($objPHPExcel->getWorksheetIterator() as $worksheet) {
            $objPHPExcel->setActiveSheetIndex($objPHPExcel->getIndex($worksheet));
            $sheet = $objPHPExcel->getActiveSheet();
            $cellIterator = $sheet->getRowIterator()->current()->getCellIterator();
            $cellIterator->setIterateOnlyExistingCells(true);
            /** @var PHPExcel_Cell $cell */
            foreach ($cellIterator as $cell) {
                $exception_ = array("A","E","F","G","L","O","R","S","T");
                if(!in_array($cell->getColumn(), $exception_)) {
                    $sheet->getColumnDimension($cell->getColumn())->setAutoSize(true);
                } else {
                    $sheet->getColumnDimension($cell->getColumn())->setWidth(20);
                }
            }
        }

        $filename = "La liste client (".date('d-m-Y H\hi').")";
        // Set active sheet index to the first sheet, so Excel opens this as the first sheet
        $objPHPExcel->setActiveSheetIndex(0);

        // Redirect output to a client’s web browser (Excel2007)
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="'.$filename.'.xlsx"');
        header('Cache-Control: max-age=0');

        // If you're serving to IE 9, then the following may be needed
        header('Cache-Control: max-age=1');

        // If you're serving to IE over SSL, then the following may be needed
        header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
        header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
        header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
        header ('Pragma: public'); // HTTP/1.0

        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        $objWriter->save('php://output');
        exit();
    }

    public function get_subscribers_list(){
        $this->load->model('event_registration_limit_model');
        $list = $this->user_model->get_datatables($this->data["logged_in"]["user_id"], $this->input->post(), 3);
        $this->load->library('session');
        $login_by = $this->data["logged_in"]["user_id"];

        $data = array();
        $row = array();
        foreach ($list as $subscribers) {
            $edit_limit_or_add = $this->event_registration_limit_model->limit_exist($subscribers->sub_id) ? 
                                "subscribers_list.limit_reserve(this)" : "subscribers_list.get_limit_reserve(this)" ;

            $row["subscriber"] = $subscribers->subscriber;
            $row["email_address"] = $subscribers->email_address;
            $row["telephone_number"] = $subscribers->telephone_number;
            $row["mobile_number"] = $subscribers->mobile_number;
            $row["city"] = $subscribers->city;
            $row["status"] = $subscribers->status;
            $row["token_link"] = "
            <button href='#' onclick='subscribers_list.edit_info_modal(this)' class='action-btn' name='{$subscribers->subscriber_id}' data-id='{$subscribers->sub_id}' ><i class='fa fa-pencil' aria-hidden='true'></i></button>
            <button href='#' onclick='subscribers_list.delete(this)' class='action-btn' name='{$subscribers->subscriber}' data-id='{$subscribers->sub_id}' ><i class='fa fa-trash' aria-hidden='true'></i></button>
            <button href='#' onclick='subscribers_list.token_modal(this)' id='$subscribers->sub_id' class='action-btn' name='{$subscribers->subscriber}' data-id='auth_token/{$subscribers->sub_id}/{$login_by}'><i class='fa fa-sign-in' aria-hidden='true'></i></button>
            <button href='#' onclick='{$edit_limit_or_add}' class='action-btn'  name='{$subscribers->subscriber_id}' data-id='{$subscribers->sub_id}' ><i class='fa fa-hourglass-half' aria-hidden='true'></i></button>
               ";
            array_push($data, $row);
        }

        $output = array(
            "draw" => $this->input->post('draw'),
            "recordsTotal" => $this->user_model->count_all($this->data["logged_in"]["user_id"], $this->input->post(), 3),
            "recordsFiltered" => $this->user_model->count_filtered($this->data["logged_in"]["user_id"], $this->input->post(), 3),
            "data" => $data,
        );
        //output to json format
        output_to_json($this, $output);
    }

    private function highlight_columns($objPHPExcelSheet, $col, $row){
        $objPHPExcelSheet->getStyleByColumnAndRow($col, $row)->applyFromArray(
            array
            (
                'fill' => array
                (
                    'type' => PHPExcel_Style_Fill::FILL_SOLID,
                    'color' => array('rgb' => '428bca')
                ),
                'alignment' => array(
                    'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER
                )
            )
        )->getBorders()->getAllBorders()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
    }
    public function delete_subscriber()
    {
        output_to_json($this,
            array(
                'is_success' => $this->user_model->delete_subscribers( $this->input->post('user_id') , ["status" => 0])
            )
        );
    }
    public function get_subscriber()
    {
         output_to_json($this, $this->user_model->get_subscribers( $this->input->post('s_id') ));
    }
    public function put_subscriber()
    {
        $this->user_model->put_subscribers();

         output_to_json($this, array( "success" => true ) );
    }
}