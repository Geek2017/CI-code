<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Subscribe extends MY_Controller {
    
    public function __construct()
    {
        $this->my_controller_parent_construct();

        //load language files
        $this->load_language_frontoffice();
        $this->lang->load('frontoffice/subscribe', 'fr');
        $this->check_subscriber_admin_status();

        //load model
        $this->load->model("event_model");
        $this->load->model("user_activity_log_model");
        $this->load->helper('htmlpurifier');
        //$this->load->library("swiftmailer_libr");
        $this->load->library("mailjet_libr");
    }

    public function check_session()
    {
        $this->check_session_timed_out("fo");
        $this->load->model('event_concurrent_process_model');

        $event_id = $this->input->post('event_id');
        $event_details = $this->event_model->event_details($event_id);
        $subscribed = $this->check_subscription($event_id);
        
        if($this->check_cookie_and_session()) {
            $result = array (
                'mtype' => "success",
                'message' => "Vous n'êtes pas connecté",
                'mdata' => array('details' => $event_details)
            );
            output_to_json($this, $result);
        } else {
            $result = array (
                'mtype' => "session_timeout",
                'message' => "Vous n'êtes pas connecté",
                'mdata' => array('details' => $event_details)
            );
            output_to_json($this, $result);
        }
    }

    public function check_action()
    {
        $this->load->model('event_concurrent_process_model');

        $client_session = $this->data['logged_in'];
        $user_id = $client_session['user_id'];
        $login_id = $client_session['login_id'];   

        $event_id = $this->input->post('event_id');
        $action = $this->input->post('action');
        $action_type = $this->input->post('action_type');
        $event_details = $this->event_model->event_details($event_id);
        $subscribed = $this->check_subscription($event_id);

        if($action == "register"){
            if($subscribed){
                $result = array (
                    'mtype' => "change",
                    'message' => $this->lang->line('already_registered'),
                    'mdata' => array('details' => $event_details)
                );
            } else {
                $process_type = ($action_type == 1) ? 1 : 3;
                $locked = $this->event_concurrent_process_model->check_action($user_id, $login_id, $event_id, $process_type);
                if($locked){
                    $result = array (
                        'mtype' => "block",
                        'message' => $this->lang->line('logged_on_another_device'),
                        'mdata' => array('details' => $event_details)
                    );
                }
                else {
                    $result = array (
                        'mtype' => "success",
                        'message' => "Vous n'êtes pas connecté",
                        'mdata' => array('details' => $event_details)
                    );
                }
            }
        } else { // cancel
            if(!$subscribed){
                $result = array (
                    'mtype' => "change",
                    'message' => $this->lang->line('already_cancelled'),
                    'mdata' => array('details' => $subscribed)
                );
            }
            else {
                $process_type = ($action_type == 1) ? 2 : 4;
                $locked = $this->event_concurrent_process_model->check_action($user_id, $login_id, $event_id, $process_type);
                if($locked){
                    $result = array (
                        'mtype' => "block",
                        'message' => $this->lang->line('logged_on_another_device'),
                        'mdata' => array('details' => $event_details)
                    );
                }
                else {
                    $result = array (
                        'mtype' => "success",
                        'message' => "Vous n'êtes pas connecté",
                        'mdata' => array('details' => $event_details)
                    );
                }
            }
        }
        output_to_json($this, $result);
    }

    public function check_subscription($event_id)
    {
        $this->load->model('event_registration_model');
        $this->load->model('event_wait_list_model');

        $client_session = $this->data['logged_in'];
        $user_id = $client_session['user_id'];        
        
        $subscribed = $this->event_registration_model->check_subscription($user_id, $event_id);
        if($subscribed)
        {
            return true;
        }
        else
        {
            $subscribed_waitlist = $this->event_wait_list_model->check_subscription($user_id, $event_id);
            if($subscribed_waitlist) {
                $seats_available = $this->event_model->check_seats($event_id);
                if($seats_available == 1) return false;
                else return true;
            }
            else 
                return false;
        }    
    }

    public function update_remaining_seats(){
        $this->check_session_timed_out("fo");

        $event_id = $this->input->post('event_id');
        $remaining_seats = $this->event_model->update_remaining_seats($event_id);
        $result = array(
            'mtype' => 'success',
            'message' => 'Update Remaining Seats',
            'mdata' => $remaining_seats
        );
    }

    public function current_event()
    {
        $this->check_session_timed_out("fo");
        $this->load->model('event_model');
        $this->load->model('event_concurrent_process_model');

        $event_id = $this->input->post('event_id');
        $event_details = $this->event_model->event_details($event_id);

        if($event_details->back_office_status == 4) {
            $result = array (
                'mtype' => "error",
                'message' => $this->lang->line("button_not_updated"),
                'mdata' => array()
            );
        } else {
            $result = array (
                'mtype' => "success",
                'message' => "Got Current Event",
                'mdata' => $event_details
            );
        }

        output_to_json($this, $result);
    }
    public function event_date_schedule()
    {
        $this->check_session_timed_out("fo");
        $this->load->model('event_model');

        $event_id = $this->input->post('event_id');
        $event_details = $this->event_model->event_schedule($event_id);

        $result = array (
            'mtype' => "success",
            'message' => $this->lang->line("button_not_updated"),
            'mdata' => $event_details
        );
        output_to_json($this, $result);
        
    }

    public function unlock_action(){

        $this->load->model('event_concurrent_process_model');

        $client_session = $this->data['logged_in'];
        $user_id = $client_session['user_id'];
        $login_id = $client_session['login_id'];   

        $event_id = $this->input->post('event_id');
        $action = $this->input->post('action');
        $action_type = $this->input->post('action_type');

        if ($action == "register"){
            $process_type = ($action_type == 1) ? 1 : 3;
        } else {
            $process_type = ($action_type == 1) ? 2 : 4;
        }
        $this->event_concurrent_process_model->unlock_action($user_id, $login_id, $event_id, $process_type);

    }

    public function cancel_current_event_registration()
    {
        $this->check_session_timed_out("fo");

        $this->load->model('event_model');
        $this->load->model('event_registration_model');
        $this->load->model('event_subscriber_guest_model');

        $client_session = $this->data['logged_in'];
        $user_id = $client_session['user_id'];
        $event_id = $this->input->post('event_id');

        $event_details = $this->event_model->current_event($event_id);
        $seats_reserved = $this->event_registration_model->seats_reserved($user_id, $event_id);
        $guests = $this->event_subscriber_guest_model->cancel_current_event_registration($user_id, $event_id);
        $result = array (
            'mtype' => "success",
            'message' => "Got Current Event",
            'mdata' => (array('event_details' => $event_details, 'seats_reserved' => $seats_reserved, 'guests' => $guests))
        );
        output_to_json($this, $result);
    }

    public function cancel_current_waitlist_registration()
    {
        $this->check_session_timed_out("fo");

        $this->load->model('event_model');
        $this->load->model('event_wait_list_model');
        $this->load->model('event_subscriber_guest_model');

        $client_session = $this->session->userdata('logged_in');
        $user_id = $client_session['user_id'];
        $event_id = $this->input->post('event_id');

        $event_details = $this->event_model->current_event($event_id);
        $seats_reserved = $this->event_wait_list_model->seats_reserved($user_id, $event_id);
        $guests = $this->event_subscriber_guest_model->cancel_current_waitlist_registration($user_id, $event_id);   
        
        $result = array (
            'mtype' => "success",
            'message' => "Got Current Event",
            'mdata' => (array('event_details' => $event_details, 'seats_reserved' => $seats_reserved, 'guests' => $guests))
        );
        output_to_json($this, $result);
    }

    public function register()
    {
        $this->check_session_timed_out("fo");

        $this->load->model("event_registration_model");

        $event_id = $this->input->post('event_id');
        $seats_reserved = $this->input->post('seats_reserved');
        $guest_emails = $this->input->post('guest_emails');
        $availability = $this->event_model->check_availability($event_id, $seats_reserved[0]);

        if($availability == 1){            
            $client_session = $this->data['logged_in'];
            $user_id = $client_session['user_id'];
            $this->email_registered($user_id, $event_id, $seats_reserved[0], $guest_emails);
        }
        else if($availability == 2){
            $result = array (
                'mtype' => "error",
                'message' => $this->lang->line('waiting_list'),
                'mdata' => 1
            );
            output_to_json($this, $result);
        }
        else {
            $result = array (
                'mtype' => "error",
                'message' => $this->lang->line('max_entries'),
                'mdata' => 0
            );
            output_to_json($this, $result);
        }
    }

    public function deregister()
    {
        $this->check_session_timed_out("fo");

        $this->load->model("event_deregistration_model");

        $client_session = $this->data['logged_in'];
        $user_id = $client_session['user_id'];
        $event_id = $this->input->post('event_id');
        $seats_cancelled = $this->input->post('seats_cancelled');
        
        $this->email_unregistered($user_id, $event_id, $seats_cancelled);        
    }

    public function register_waitlist()
    {
        $this->check_session_timed_out("fo");

        $this->load->model('event_wait_list_model');

        $event_id = $this->input->post('event_id');
        $seats_reserved = $this->input->post('seats_reserved');
        $guest_emails = $this->input->post('guest_emails');
        $availability = $this->event_model->check_availability($event_id, $seats_reserved[0]);

        if($availability == 3) {
            $result = array (
                'mtype' => "error",
                'message' => $this->lang->line('max_entries_waitlist'),
                'mdata' => 0
            );         
            output_to_json($this, $result);
        } else {            
            $client_session = $this->data['logged_in'];
            $user_id = $client_session['user_id'];
            $event_id = $this->input->post('event_id');
            $this->email_registered_waitlist($user_id, $event_id, $seats_reserved[0], $guest_emails);       
        }
    }

    public function deregister_waitlist()
    {
        $this->check_session_timed_out("fo");

        $this->load->model('event_wait_list_deregistration_model');

        $client_session = $this->data['logged_in'];
        $user_id = $client_session['user_id'];
        $event_id = $this->input->post('event_id');
        
        $this->email_unregistered_waitlist($user_id, $event_id);
        
    }

    public function deregister_guest()
    {
        $this->load->model('event_subscriber_guest_model');
        $this->set_user_data();

        $client_session = $this->data['logged_in'];
        $user_id = $client_session['user_id'];
        $event_id = $this->input->post('event_id');
        $cancelled_guest = $this->input->post('cancelled_guest');
        $seats_cancelled = $this->input->post('seats_cancelled');

        $this->event_subscriber_guest_model->deregister_guest($event_id, $user_id, $this->data['agent'], $cancelled_guest, $seats_cancelled);
    }

    public function deregister_waitlist_guest()
    {
        $this->load->model('event_subscriber_guest_model');
        $this->set_user_data();

        $client_session = $this->data['logged_in'];
        $user_id = $client_session['user_id'];
        $event_id = $this->input->post('event_id');
        $cancelled_guest = $this->input->post('cancelled_guest');
        $seats_cancelled = $this->input->post('seats_cancelled');

        $this->event_subscriber_guest_model->deregister_waitlist_guest($event_id, $user_id, $this->data['agent'], $cancelled_guest, $seats_cancelled);
    }

    public function email_registered($user_id, $event_schedule_id, $seats_reserved, $guest_emails)
    {
        $this->check_session_timed_out("fo");

        $this->load->model("user_subscriber_model");
        $this->load->model("event_registration_model");
        $this->load->model('event_email_template_model');

        $client_session = $this->data['logged_in'];
        $login_id = $client_session['login_id'];
        $event_info = $this->event_model->event_details_email($event_schedule_id);
        $user_info = $this->user_subscriber_model->email_registered($user_id);

        $email_tpl = $this->event_email_template_model->get_current_event_email_template($event_info->event_id, $event_schedule_id, 3, true);

        if(sizeof($email_tpl) > 0 && sizeof($user_info) > 0 && sizeof($event_info) >0){

            $mailjet_response = $this->mailjet_libr->fo_send_template_email(array(
                "message" => $email_tpl,
                "vars" =>  $this->add_email_vars('foer', $user_info, $event_info, $seats_reserved)
            ));
            
            if($mailjet_response) {
                $this->set_user_data();
                $registered = $this->event_registration_model->register($user_id, $login_id, $event_schedule_id, $this->data['agent'], $seats_reserved, $guest_emails);
                if($registered){
                    $result = array (
                        'mtype' => "success",
                        'message' => $this->lang->line('subscribed'),
                        'mdata' => $mailjet_response//array()//
                    );
                } else {
                    $result = array (
                        'mtype' => "error",
                        'message' => "Error - Not registered",
                        'mdata' => $mailjet_response//array()
                    );
                }
            } else {
                $result = array (
                    'mtype' => "error",
                    'message' => "Something went wrong. Email not sent!",
                    'mdata' => array('email' => $to_email, 'event_info' =>$event_info)
                );
            }
            output_to_json($this, $result);
        } else {
            output_to_json($this, array (
                'mtype' => "error",
                'message' => "No email to send!"
            ));
        }
    }

    public function email_unregistered($user_id, $event_schedule_id, $seats_cancelled)
    {
        $this->check_session_timed_out("fo");

        $this->load->model('user_subscriber_model');
        $this->load->model('event_registration_model');
        $this->load->model('event_deregistration_model');
        $this->load->model('event_email_template_model');

        $client_session = $this->data['logged_in'];
        $login_id = $client_session['login_id'];
        
        $event_info = $this->event_model->event_details_email($event_schedule_id);
        $seats_reserved = $this->event_registration_model->seats_reserved($user_id, $event_schedule_id);
        $user_info = $this->user_subscriber_model->email_registered($user_id);

        $email_tpl = $this->event_email_template_model->get_current_event_email_template($event_info->event_id, $event_schedule_id, 5, true);

        if(sizeof($email_tpl) > 0 && sizeof($user_info) > 0 && sizeof($event_info) >0){

            $mailjet_response = $this->mailjet_libr->fo_send_template_email(array(
                "message" => $email_tpl,
                "vars" =>  $this->add_email_vars('four', $user_info, $event_info, $seats_reserved)
            ));

            if($mailjet_response) {
                $this->set_user_data();
                $this->event_deregistration_model->deregister($user_id, $login_id, $event_schedule_id, $this->data['agent'], $seats_cancelled);
                // $this->event_deregistration_model->add_to_waitlist_for_email($event_id);
                $this->event_model->reopen_event($event_schedule_id);

                $result = array (
                    'mtype' => "success",
                    'message' => $this->lang->line('unsubscribed'),
                    'mdata' => $mailjet_response //array()// 
                );
                
            } else {
                $result = array (
                    'mtype' => "error",
                    'message' => "Something went wrong. Email not sent!",
                    'mdata' => array('email' => $to_email, 'event_info' =>$event_info)
                );
            }
            output_to_json($this, $result);
        } else {
            output_to_json($this, array (
                'mtype' => "error",
                'message' => "No email to send!"
            ));
        }
    }

    public function email_registered_waitlist($user_id, $event_schedule_id, $seats_reserved, $guest_emails){
        $this->check_session_timed_out("fo");

        $this->load->model("user_subscriber_model");
        $this->load->model("user_model");
        $this->load->model('event_email_template_model');
        $this->load->model('event_wait_list_model');

        $client_session = $this->data['logged_in'];
        $login_id = $client_session['login_id'];
        $event_info = $this->event_model->event_details_email($event_schedule_id);
        $user_info = $this->user_subscriber_model->email_registered($user_id);

        $email_tpl = $this->event_email_template_model->get_current_event_email_template($event_info->event_id, $event_schedule_id, 6, true);

        if(sizeof($email_tpl) > 0 && sizeof($user_info) > 0 && sizeof($event_info) >0){

             $mailjet_response = $this->mailjet_libr->fo_send_template_email(array(
                "message" => $email_tpl,
                "vars" =>  $this->add_email_vars('forwl', $user_info, $event_info, $seats_reserved)
            ));

            if($mailjet_response) {
                $this->set_user_data();
                $this->event_wait_list_model->register_waitlist($user_id, $login_id, $event_schedule_id, $this->data['agent'], $seats_reserved, $guest_emails);
                $result = array (
                    'mtype' => "success",
                    'message' => $this->lang->line('subscribed_waitlist'),
                    'mdata' => $mailjet_response // 4 array()//
                );
            } else {
                $result = array (
                    'mtype' => "error",
                    'message' => "Something went wrong. Email not sent!",
                    'mdata' => array('email' => $to_email, 'event_info' =>$event_info)
                );
            }
            output_to_json($this, $result);
        } else {
            output_to_json($this, array (
                'mtype' => "error",
                'message' => "No email to send!"
            ));
        }
    }

    public function email_unregistered_waitlist($user_id, $event_id)
    {
        $this->check_session_timed_out("fo");

        $this->load->model('user_subscriber_model');
        $this->load->model('event_deregistration_model');

        $client_session = $this->data['logged_in'];
        $login_id = $client_session['login_id'];
        $to_email = $this->user_subscriber_model->email_registered($user_id);
        $event_info = $this->event_model->event_details($event_id);

        $this->set_user_data();
        $this->event_wait_list_deregistration_model->deregister_waitlist($user_id, $login_id, $event_id, $this->data['agent']);
        $result = array (
            'mtype' => "success",
            'message' => $this->lang->line('unsubscribed_waitlist'),
            'mdata' => array()
        );
        output_to_json($this, $result);
        
    }

    private function set_user_data(){
        // User Agent
        if ($this->agent->is_browser()){
            $this->data['agent'] = $this->agent->browser().' '.$this->agent->version();
        } elseif ($this->agent->is_robot()){
            $this->data['agent'] = $this->agent->robot();
        } elseif ($this->agent->is_mobile()){
            $this->data['agent'] = $this->agent->mobile();
        } else {
            $this->data['agent'] = 'Unidentified User Agent';
        }
    }

    public function return_action()
    {
        $this->check_session_timed_out("fo");

        $event_id = $this->input->post('event_id');
        $page_number = $this->event_model->_get_page_number($event_id);
        $result = array (
            'mtype' => "success",
            'mdata' => array('page_number' => $page_number)
        );
        output_to_json($this, $result);
    }

    public function page_visit()
    {
        $this->load->model('event_page_visit_model');

        $event_id = $this->input->post('event_id');
        $client_session = $this->data["logged_in"];
        if(!$this->check_cookie_and_session()) $page_visitor = NULL;
        else $page_visitor = $client_session["user_id"];
        $this->event_page_visit_model->page_visit($event_id, $page_visitor);        
    }

    public function save_link_to_cookie()
    {
        $this->load->helper('cookie');
        $this->delete_link_cookie();
        
        $event_id = $this->input->post('event_id');
        $event_type = $this->event_model->save_link_to_cookie($event_id);
        $cookie_eventpage = array(
            'name'   => 'eventpage',
            'value'  => json_encode(array(
                "event_link" => base_url('frontoffice/event_details?event_id='.$event_id),
                "event_type" => $event_type
            )),
            'expire' => time() + (86400 * 30),
            'prefix' => '_L3W0VB3_'
        );
        set_cookie($cookie_eventpage);

        output_to_json($this, array(
            "mtype" => "success",
            "message" => "Link Cookie Created!",
            "mdetail" => array("redirect" => 2000, "path" => base_url('login'))
        ));
    }

    public function clear_link_cookie()
    {
        $this->load->helper('cookie');
        $this->delete_link_cookie();
    }

    private function delete_link_cookie()
    {
        delete_cookie('_L3W0VB3_eventpage');
    }

    private function add_email_vars($action, $user_info, $event_info, $seats_reserved){
       
        $event_info->{"subscriber"} = $user_info->first_name." ".$user_info->last_name;
        $event_info->{"seats_reserved"} = ($seats_reserved <= 1)?$seats_reserved.' place': $seats_reserved.' places ';
        $event_info->{"event_url"}  = base_url('frontoffice/event_details?event_id='.$event_info->event_id);
        $event_info->{"new_tab_url"} =  base_url("e/".$action."/".base64_encode($user_info->user_id."_".$event_info->event_id."_".$event_info->event_schedule_id."_".$seats_reserved)."/");
        $event_info->{"event_picture"} =  images_bundle().'frontoffice/events/'.$event_info->event_picture;
        $event_info->{"email_address"} = $user_info->email_address;

        return $event_info;
    }
}