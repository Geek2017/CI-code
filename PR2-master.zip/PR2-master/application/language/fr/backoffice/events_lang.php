<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/* USER ACCOUNTS MANAGEMENT */

//BUTTONS && PAGE NAME
$lang["event_management"] = "Gestion des événements";
$lang["event_information"] = "Les informations d'événements";
$lang["animation"] = "Animation";


//FIELDS && TABLE COLUMNS
$lang["location"] = "Lieu";
$lang["event_city_location"] = "Ville de rattachement";
$lang["event_type"] = "Type d’événement";
$lang["event_title"] = "Nom d’événement";
$lang["name_of_place"] = "Nom du lieu";
$lang["address"] = "Adresse";
$lang["code_postal"] = "Code postal";
$lang["author"] = "Auteur";
$lang["date_created"] = "Date de création";
$lang["schedule_date"] = "Date de rappel";
$lang["event_status"] = "Statut d’événement";
$lang["bo_status"] = "Statut dans Back office";
$lang["start_date"] = "Date de début";
$lang["end_date"] = "Date de fin";
$lang["avl_seats"] = "Places disponibles";
$lang["remaining_seats"] = "Places restantes";
$lang["event_rate"] = "Tarif";
$lang["reservation_start_date"] = "Date de réservation";
$lang["reservation_end_date"] = "End Date de réservation";
$lang["opening_date"] = "Date d'ouverture des inscriptions";
$lang["select"] = "Selectionnez";
$lang["seats_per_subscriber"] = "Quota de nombre de personnes par compte abonné";
$lang["edit_form_schedule_title"] = "Edit Schedule";
$lang["quota_of_waiting_list"] = "Quotas de places en liste d'attente";
$lang["file_deleted"] ="Le fichier a été mise à jour.";
$lang["cant_delete_file"] ="Impossible de supprimer le fichier.";
$lang["espeaker_deleted"] ="An event speaker has been deleted.";
$lang["cant_delete_espeaker"] ="Impossible de supprimer l'intervenant.";
$lang["updated_espeaker"] ="An event speaker has been updated.";
$lang["cant_update_espeaker"] ="Impossible de mettre à jour.";
$lang["event_email_status"] ="Statut d'email";
$lang["event_email_schedule"] ="Planifier l'envoi de votre email";
$lang["choose_event"] ="Choisissez un événement";
$lang["filter_subscriber_by"] ="Filtrer les abonnés par";
$lang["filter_subscriber_by_all"] ="Tous";
$lang["filter_subscriber_by_eventpref"] ="Préférence de l'événement";
$lang["cannot_create_mail"] ="Nous ne sommes pas en mesure de créér une nouvelle invitation";
$lang["create_mail"] ="L'email de rappel a été crée";
$lang["cannot_update_mail"] ="Nous ne sommes pas en mesure de faire une mise à jour de l'invitation";
$lang["created_reminder_email"] ="Un email a été créé";
$lang["updated_reminder_email"] ="L'email de rappel a été mis à jour";
$lang["deleted_reminder_email"] ="L'email de rappel a été supprimé";
$lang["onqueue_mail"] ="Email en attente";
$lang["sent_mail"] ="Email envoyé";
$lang["failed_mail"] ="Êchec de l'envoi";
$lang["total_subscriber"] ="Nombre total d'abonnés";
$lang["browse_file"] ="Parcourir les fichiers...";

//LINKS
$lang["event_preview"] = "Prévisualisez";
$lang["click_to_preview"] = "Cliquez pour afficher l'événement";

// CONFIRMATION ACTION MESSAGE ON MODAL
$lang["events"]["title"]["add_new_event"] = "Ajouter une nouvelle préférence d'événement";
$lang["events"]["title"]["add_new_event_date"] = "Add new event date";
$lang["events"]["title"]["event_speaker"] = "Intervenant";
$lang["events"]["title"]["add_event_speaker"] = "Ajouter un intervenant.";
$lang["events"]["title"]["event_attachment"] = "Pièce jointe";
$lang["events"]["title"]["partners"] = "Partenaires";
$lang["events"]["title"]["speakers_partners"] = "Partenaires et Intervenant";
$lang["events"]["title"]["update_event"] = "Mettre à jour les informations d'événements";
$lang["events"]["publish_event"] = "L'événement est en cours de publication. Attendez l'envoi des emails aux déstinataires";
$lang["events"]["saving_event_loader"] = "Veuillez patienter pendant l'enregistrement de l'information";
$lang["events"]["cma_msg"]["add_new_event"] = "Ajoutez ce nouvel événement ?";
$lang["events"]["cma_msg"]["save_changes"] = "Enregistrez les changements ?";
$lang["events"]["cma_msg"]["delete_event_speaker"] = "Delete this event speaker ";
$lang["events"]["btn"]["save_new_event"] = "Enregister le nouvel événement";
$lang["events"]["btn"]["add_event_email"] = "Créér un email d'événement";
$lang["events"]["btn"]["add_event_ereminder"] = "Créér un email de rappel";
$lang["events"]["cma_msg"]["add_event_ereminder"] = "Voulez-vous enregistrer votre email de rappel ?";
$lang["events"]["btn"]["update_event_email"] = "Mettre à jour l'email d'événement";
$lang["events"]["btn"]["update_event_ereminder"] = "Editer un email de rappel";

$lang["events"]["val"]["invlaid_date"] = "Le format de la date n'est pas bon. Utilisez le format JJ / MM / AAAA 1h00";
$lang["events"]["val"]["invalid_rem_seat"] = "Le nombre de places restantes ne doit pas être supérieur au nombre de places disponibles.";
$lang["events"]["val"]["email_desc"] = "Impossible de publier l'événement. Description necéssaire.";
$lang["events"]["val"]["attachment_required"] = "Veuillez remplir tous les champs.";
$lang["events"]["val"]["required_event_speaker"] = "Un intervenant est nécessaire.";
$lang["events"]["val"]["required_event_startdate"] = "La date de l'événement est requise.";
$lang["events"]["val"]["date_feature_single"] = "Only one date entry is required!";
$lang["events"]["val"]["date_feature_multiple"] = "At least two event dates are required!";
$lang["events"]["val"]["combine_seats_required"] = "Input number of seats!";
$lang["events"]["val"]["seat_feature_required"] = "Select seat feature!";

$lang["events"]["cma_msg"]["delete_event"] = "Voulez-vous vraiment supprimer cet événement de façon permanente";
$lang["events"]["cma_msg"]["delete_event_schedule"] = "Êtes-vous sûr de vouloir supprimer définitivement cette date d'événement";
$lang["events"]["btn"]["add_event"] = "Ajouter un événement";
$lang["events"]["_file"]["event_attachment"] = "Pièce jointe";
$lang["events"]["_file"]["attachment_detail"] = "Pièce jointe Détail";
$lang["events"]["_file"]["date_uploaded"] = "Date de téléchargement";
$lang["events"]["_file"]["browse_file"] = "Chercher le fichier";
$lang["events"]["_file"]["start_upload"] = "Lancer";
$lang["events"]["_file"]["cancel_upload"] = "Annuler";
$lang["events"]["_file"]["confirm_upload"] = "Télécharger le fichier ?";
$lang["events"]["_file"]["confirm_cancel"] = "Annuler téléchargement de fichier ?";
$lang["events"]["_file"]["img_only"] = "Vous pouvez télécharger un fichier JPG, GIF, ou PNG";
$lang["events"]["_file"]["specified_only"] = "Vous pouvez télécharger un fichier JPG, GIF, PNG, ou MP4";
$lang["events"]["_file"]["single_file_only"] = "Merci de ne sélectionner qu'un fichier.";
$lang["events"]["_file"]["replace_current_attachment"] = "Ce fichier remplacera le fichier actuel.";
$lang["events"]["_file"]["attachment_uploaded"] = "Un fichier a été téléchargé.";
$lang["events"]["_file"]["saved_temp_file"] = "Une pièce jointe a été enregistrée dans l'emplacement temporaire.";
$lang["events"]["_file"]["temp_file"] = "Le fichier est enregistré dans l'emplacement temporaire. Merci d'enregistrer les modifications pour visualiser le fichier dans le Front.";
$lang["events"]["_file"]["required_attachment"] = "Impossible de publier l'événement. Une pièce jointe est nécessaire.";
$lang["events"]["_file"]["no_attachment_yet"] = "Aucun fichier ajouté";
$lang["events"]["_file"]["confirm_delete_file"] = "Êtes-vous sur de vouloir supprimer le fichier?";
$lang["events"]["e_mail"]["schedule_date"] = "La date ne doit pas dépasser la date de réservation";
$lang["events"]["e_mail"]["event_first"] = "Selectionnez un événement";
$lang["events"]["e_mail"]["publishing_email"] = "Veuillez patienter pendant la publication de l'email";
$lang["events"]["attachment"]["events"] = origin_folders('events');
$lang["events"]["attachment"]["sponsors"] = origin_folders('sponsors');

//research filter
$lang["events"]["_filter"]["all"] = "Tous";
$lang["events"]["_filter"]["event_title"] = "Titre d'événement";
$lang["events"]["_filter"]["month_year"] = "Par mois et année";
$lang["events"]["_filter"]["event_location"] = "Emplacement de l'événement";
$lang["events"]["_filter"]["bo_status"] = "Statut dans Back office";
$lang["events"]["_filter"]["event_status"] = "Statut d'événement";
$lang["events"]["_filter"]["event_type"] = "Type d’événement";
$lang["events"]["_filter"]["research"] = "Rechercher";

//event statuses
$lang['events']['event_status']["available"] = "Disponible";
$lang['events']['event_status']["full"] = "Complet";
//backoffice statuses
$lang['events']['bo_status']["bostat0"] = "En cours de création";
$lang['events']['bo_status']["bostat1"] = "Publié";
$lang['events']['bo_status']["bostat2"] = "Ouvert";
$lang['events']['bo_status']["bostat3"] = "Verrouillé";
$lang['events']['bo_status']["bostat4"] = "Fermé";
$lang['events']['bo_status']["bostat5"] = "Archivé";
$lang['events']['bo_status']["bostat7"] = "Terminee";

// SERVER-SIDE ERROR MESSAGE
$lang["unknown_error"] = "Quelque-chose s'est mal passé!";
$lang["event_title_exist"] = "Le nom d'événement existe déjà";
$lang["added_new_event"] = "Nouvel événement a été ajouté avec succès.";
$lang["updated_event"] = "Les informations d'événements ont été mise à jour.";
$lang["event_deleted"] = "Un événement a été supprimé.";
$lang["event_info_retvd"] = "Les informations d'événements ont été récupérées.";

/* END OF EVENT PREFERENCE */



/* WAITLIST MANAGEMENT PARAMETERS */

$lang["event_waitlist_param_1"] = "Nombre d'heures avant l'envoi";
$lang["event_waitlist_param_2"] = "Nombre d'abonnés";
$lang["manage_reinvitation_setting"] = "Paramètre email de la liste d'attente";
$lang["waitlist_mgmt"]["title"] = "Paramètre email de la liste d'attente";
$lang["waitlist_mgmt"]["btn"]["save_new_setting"] = "Sauvegarder les paramètres";
$lang["waitlist_mgmt"]["cma_msg"]["save_new_setting"] = "Sauvegarder les paramètres?";


/* event schedule, event email tempalte assignment*/
$lang['heartstroke'] = "Use hearstroke?";
$lang['date_feature'] = "Date feature";
$lang['single_date'] = "Single Date";
$lang['multiple_date'] = "Multiple Date";
$lang['seat_feature'] = "Seat Feature";
$lang['perdate'] = "Per Date";
$lang['combine'] = "Combine";
$lang['reservation'] = "Reservation";
$lang['waitlist_reservation_label'] = "Waiting list Reservation";
$lang['waitlist_reservation'] = "Can reserve more than 1 place per event schedule?";
$lang['events']['btn']['add_event_date'] = "Add Event Date";

/* event_schedule_list columns */


/* WAITLIST PARAMETERS*/
//---------------------------------------------------------------------------------------------------------------------------------


/* End of file events_lang.php */
/* Location: ./application/language/fr/backoffice/events_lang.php */
