<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Users_account extends MY_Controller {
    public function __construct()
    {
        //parent::__construct();
        $this->my_controller_parent_construct();
        $this->check_session_timed_out("bo");
        //load language file
        $this->load_language_backoffice();
        $this->lang->load('backoffice/system_config', 'fr');

        $this->load->model("user_model");
        $this->load->model("user_activity_log_model");
    }

    public function add_new_user(){
        if($this->input->post()) {
            $data = array();
            $data["mdetail"] = array();

            $pwd = $this->validate($this->input->post(NULL, TRUE), "pwd", null);
            $username = $this->validate($this->input->post(NULL, TRUE), "username", null);
            $email = $this->validate($this->input->post(NULL, TRUE), "email", null);

            if ($pwd["error"] || $username["error"] || $email["error"]) {
                if ($pwd["error"]) {
                    array_push($data["mdetail"], array("field" => "password", "message" => $pwd["message"]));
                }
                if ($username["error"]) {
                    array_push($data["mdetail"], array("field" => "username", "message" => $username["message"]));
                }
                if ($email["error"]) {
                    array_push($data["mdetail"], array("field" => "email_address", "message" => $email["message"]));
                }

                $data["mtype"] = "error";
                $data["message"] = $this->lang->line("check_input");

                output_to_json($this, $data);
            } else {
                //no error so add new user
                $insert_id = $this->user_model->add_new_user($this->input->post(NULL, TRUE));
                if ($insert_id) {
                    $logs = $this->activity_logs_for_add($insert_id);
                    if (!$logs) {
                        output_to_json($this, array(
                            "mtype" => "error",
                            "message" => $this->lang->line("saving_act_logs_err")
                        ));
                    } else {
                        output_to_json($this, array(
                            "mtype" => "success",
                            "message" => $this->lang->line("new_user_added")
                        ));
                    }
                } else {
                    output_to_json($this, array(
                        "mtype" => "error",
                        "message" => $this->lang->line("unknown_error_on_act_logs")
                    ));
                }
            }
        }else{
            show_404();
        }
    }

    private function activity_logs_for_add($user_id)
    {
        return $this->user_activity_log_model->add_activity_log(array(
            "description" => "Add new user",
            "user_id" => $this->data["logged_in"]["user_id"],
            "action" => "ADD",
            "table_origin" => "user",
            "reference_id" => $user_id
        ));
    }

    public function edit_user_account($user_id){

        if($this->input->post()){
            $data = array();
            $data["mdetail"] = array();

            $pwd = $this->validate($this->input->post(NULL, TRUE), "pwd", $user_id);
            $username = $this->validate($this->input->post(NULL, TRUE), "username", $user_id);
            $email = $this->validate($this->input->post(NULL, TRUE), "email", $user_id);

            if ($pwd["error"] || $username["error"] || $email["error"]) {
                if ($pwd["error"]) {
                    array_push($data["mdetail"], array("field" => "password", "message" => $pwd["message"]));
                }
                if ($username["error"]) {
                    array_push($data["mdetail"], array("field" => "username", "message" => $username["message"]));
                }
                if ($email["error"]) {
                    array_push($data["mdetail"], array("field" => "email_address", "message" => $email["message"]));
                }

                $data["mtype"] = "error";
                $data["message"] = $this->lang->line("check_input");

                output_to_json($this, $data);
            } else {
                $activity_logs = $this->activity_logs_b4_update($user_id, $this->input->post(NULL, TRUE));

                //no error so add new user
                $update = $this->user_model->edit_user_account($user_id, $this->input->post(NULL, TRUE));
                if ($update) {
                    $logs = $this->activity_logs_for_edit($user_id, $activity_logs);
                    if (!$logs) {
                        output_to_json($this, array(
                            "mtype" => "error",
                            "message" => $this->lang->line("saving_act_logs_err")
                        ));
                    } else {
                        output_to_json($this, array(
                            "mtype" => "success",
                            "message" => $this->lang->line("updated_user_info")
                        ));
                    }
                } else {
                    output_to_json($this, array(
                        "mtype" => "error",
                        "message" => $this->lang->line("unknown_error_on_act_logs")
                    ));
                }
            }
        }else{
            show_404();
        }
    }

    private function activity_logs_b4_update($user_id, $data){
        $activity_logs = "";
        if(!$this->user_model->check_if_something_is_changed($user_id, $data["username"], "username")){
            //udpated username
            $activity_logs .=" - ".$this->lang->line("change_username")."<br/>";
        }
        if($data["password"] != "" && $data["confirm_password"] != ""){
            if(!$this->user_model->check_if_something_is_changed($user_id, $data["password"], "password")){
                //udpated password
                $activity_logs .=" - ".$this->lang->line("change_pwd")."<br/>";
            }
        }
        if($data["email_address"] != ""){
            if(!$this->user_model->check_if_something_is_changed($user_id, $data["email_address"], "email_address")){
                //udpated eamil
                $activity_logs .=" - ".$this->lang->line("change_email")."<br/>";
            }
        }
        if(!$this->user_model->check_if_fullname_is_changed($user_id, $data["first_name"], $data["last_name"])){
            //udpated full name
            $activity_logs .=" - ".$this->lang->line("change_employee_name")."<br/>";
        }

        return $activity_logs;
    }

    private function activity_logs_for_edit($user_id, $activity_logs){
        if($activity_logs != ""){
            return array("success" => $this->user_activity_log_model->add_activity_log(array(
                "description" => $activity_logs,
                "user_id"     => $this->data["logged_in"]["user_id"],
                "action"      => "EDIT",
                "table_origin"=> "user",
                "reference_id"=> $user_id
            )));
        }

        return array("success" => 1);
    }

    private function validate($data, $query, $user_id){

        $result = array("error"	=> false);

        switch($query){
            case "pwd" :
                if(($this->input->post("password")!= "" && $this->input->post("confirm_password") != "") && (strtolower($this->input->post("password")) != strtolower($this->input->post("confirm_password")))){
                    $result["error"] = true;
                    $result["message"] = $this->lang->line("pwd_did_not_match");
                }
                break;

            case "username" :
                $check_name = $this->user_model->check_username($data["username"], $user_id);
                if($check_name){
                    $result["error"] = true;
                    $result["message"] = $this->lang->line("username_exist");
                }
                break;

            case "email" :
                $check_email = $this->user_model->check_email($data["email_address"], $user_id, array(1,2));
                if($check_email){
                    $result["error"] = true;
                    $result["message"] = $this->lang->line("email_exist");
                }
                break;

            default :
                $result["error"] = false;
                break;
        }

        return $result;
    }

    public function delete_user_account($user_id){

        if($this->input->post() && $user_id) {
            //must check dependencies before deleting, without checking, errors might encounter due to foreign keys
            $result = $this->user_model->delete_user_account($user_id);
            if ($result) {

                $act_log = $this->user_activity_log_model->add_activity_log(array(
                    "description" => "- ".$this->lang->line("account_deleted")."<br>",
                    "user_id"     => $this->data["logged_in"]["user_id"],
                    "action"      => "DELETE",
                    "table_origin"=> "user",
                    "reference_id"=> $user_id
                ));

                if($act_log){
                    output_to_json($this, array(
                        "mtype" => "success",
                        "message" => $this->lang->line("account_deleted")
                    ));
                }else{
                    output_to_json($this, array(
                        "mtype" => "error",
                        "message" => $this->lang->line("saving_act_logs_err")
                    ));
                }
            } else {
                output_to_json($this, array(
                    "mtype" => "error",
                    "message" => $this->lang->line("cannot_delete_account")
                ));
            }
        } else {
            show_404();
        }
    }

    public function deactivate_activate_user_account($user_id, $action){
        if($this->input->post() && $user_id && $action) {
            $status = ($action==1)?2:1;
            //must check dependencies before deleting, without checking, errors might encounter due to foreign keys
            $result = $this->user_model->deactivate_activate_user_account($user_id, $status);
            if($result){
                $description = (($action==1)?$this->lang->line('deactivated_account'):$this->lang->line('activated_account'));
                $act_log = $this->user_activity_log_model->add_activity_log(array(
                    "description" => "- ".$description."<br>",
                    "user_id"     => $this->data["logged_in"]["user_id"],
                    "action"      => "EDIT",
                    "table_origin"=> "user",
                    "reference_id"=> $user_id
                ));

                if($act_log){
                    output_to_json($this, array(
                        "mtype" => "success",
                        "message" => $description
                    ));
                }else{
                    output_to_json($this, array(
                        "mtype" => "error",
                        "message" => $this->lang->line("saving_act_logs_err")
                    ));
                }
            }else {
                output_to_json($this, array(
                    "mtype" => "error",
                    "message" => (($action==1)?$this->lang->line('unable_deactivate_account'):$this->lang->line('unable_activate_account'))
                ));
            }
        } else {
            show_404();
        }
    }

    public function get_user_account_list(){
        if($this->input->post() && $this->data["logged_in"]["user_id"]) {
            $list = $this->user_model->get_datatables($this->data["logged_in"]["user_id"], $this->input->post(), 1);
            $data = array();
            $row = array();
            $x = $this->input->post("start");

            foreach ($list as $employee) {
                $row["employee_order"] = ++$x;
                $row["employee"] = $employee->employee;
                $row["email_address"] = $employee->email_address;
                $row["username"] = $employee->username;
                $row["role"] = $employee->role_name;
                $row["status"] = $employee->status;
                $row["action"] = array("user_id" => $employee->user_id,
                    "email_address" => $employee->email_address,
                    "username" => $employee->username,
                    "status" => $employee->user_status,
                    "first_name" => $employee->first_name,
                    "last_name" => $employee->last_name);
                array_push($data, $row);
            }
            $output = array(
                "draw" => $this->input->post('draw'),
                "recordsTotal" => $this->user_model->count_all($this->data["logged_in"]["user_id"], $this->input->post(), 1),
                "recordsFiltered" => $this->user_model->count_filtered($this->data["logged_in"]["user_id"], $this->input->post(), 1),
                "data" => $data,
            );
            //output to json format
            output_to_json($this, $output);
        } else {
            show_404();
        }
    }
}