<?php  if (! defined('BASEPATH')) {
    exit('No direct script access allowed');
}
/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	http://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There area two reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router what URI segments to use if those provided
| in the URL cannot be matched to a valid route.
|
*/

/*********************************************************************************************
							DEFAULT ROUTES
*********************************************************************************************/
	
	$route['default_controller'] = "frontoffice/home/";
	$route["page_not_found"] = "page_error_handler/index/";
	$route['404_override'] = 'page_error_handler';

/*********************************************************************************************
							END OF DEFAULT ROUTES
*********************************************************************************************/


/*********************************************************************************************
							START OF FRONT OFFICE PAGES ROUTES
*********************************************************************************************/
	
	$route["home"] = "frontoffice/home/";
	$route["frontoffice"] = "frontoffice/home/";
	$route["in_development"] = "frontoffice/in_development/";
	$route["set_preference"] = "profile/preferences/index/";
	$route["test_page"] = "frontoffice/test/";
	$route["mentions-legales"] = "frontoffice/mentions_legales/";

/*********************************************************************************************
							END OF FRONT OFFICE PAGES ROUTES
*********************************************************************************************/


/*********************************************************************************************
							START OF BACK OFFICE PAGES ROUTES
*********************************************************************************************/
	
	$route["backoffice/dashboard"] = "backoffice/index/";
	$route["backoffice"] = "backoffice/index/";
	$route["dashboard"] = "backoffice/index/";

/*********************************************************************************************
							END OF BACK OFFICE PAGES ROUTES
*********************************************************************************************/	


/*********************************************************************************************
								USER AUTHENTICATION ROUTING 
*********************************************************************************************/
	
	/********************** LOGIN ROUTES ******************************************/
	$route["get_locale"] = "authentication/get_system_locale/";
	$route["authenticate"] = "authentication/authenticate/";
	$route["auth_token/(:any)"] = "authentication/auth_token/$1";
	$route["verify_login"] = "authentication/verify_login/";
	/********************** END OF LOGIN ROUTES ***********************************/

	/********************** FORGOT PASSWORD ***************************************/
	$route["enter_code_page"] = "authentication/enter_code_page/";
	$route["enter_code"] = "authentication/enter_code/";
	$route["update_password"] = "authentication/update_password/";
	$route["new_password"] = "authentication/new_password/";
	$route["check_code"] = "authentication/check_code/";
	$route["check_email"] = "authentication/check_email/";
	$route["reset_password_page"] = "authentication/reset_password_page/";
	$route["reset_password"] = "authentication/reset_password/";
	$route['forgot_password_bo'] = "authentication/forgot_password_bo/";
	$route['forgot_password'] = "authentication/forgotpass_page/";
	/********************** END OF FORGOT PASSWORD *******************************/

	/********************** BO and FO LOGIN **************************************/
	$route['login'] = "authentication/login/";
	$route['auth'] = "authentication/auth/";
	$route["logoff/(:num)"] = "authentication/logout/$1";
	$route["logout/(:num)"] = "authentication/logout/$1";
	$route["sign-out/(:num)"] = "authentication/logout/$1";
	$route["resources"] = "page_error_handler/index/";
	/********************** END OF BO and FO LOGIN ******************************/


/*********************************************************************************************
							END OF USER AUTHENTICATION ROUTING 
*********************************************************************************************/


/*********************************************************************************************
								BACK OFFICE PAGE ROUTING 
***************************** ***************************************************************/
	

	/****************  MAIN PAGE ****************************************************/
		$route["users_account"] = "backoffice/users_account/";
		$route["city_location"] = "backoffice/city_location/";
		$route["event_type"] = "backoffice/event_type/";
		$route["contact_email"] = "backoffice/contact_email/";
		$route["event"] = "backoffice/event/";
		$route["statistics"] = "backoffice/statistics/";
		$route["my_profile"] = "backoffice/user_profile/";
	/****************  End OF MAIN PAGE *********************************************/

	/********************** My PROFILE **********************************************/
		$route["update_my_profile"] = "profile/user_profile/update/";
	/********************** END OF MY PROFILE ***************************************/


	/********************************************************************************
								START OF PERSONALISATION
	**********************************************************************************/
			
		/********************** REGISTRATION FORM VALIDATION ********************/
		$route["personalization"] = "backoffice/personalization/";
		$route["personalize/get_reg_form"] = "personalization/personalization/get_reg_form";
		$route["personalize/update_reg_form"] = "personalization/personalization/update_reg_form";
		$route["personalize/create_reg_form_rules"] = "personalization/personalization/create_reg_form_rules";
		/********************** END OF REGISTRATION FORM VALIDATION ************/

		/********************** BANNER UPLOADING *******************************/
		$route["personalize/get_banner"] = "personalization/personalization/get_banner";
		$route["personalize/upload_banner"] = "personalization/personalization/upload_banner";
		/********************** END OF BANNER UPLOADING ************************/

		/********************** MENTION LEGALES ********************************/
		$route['personalization/append_mentions_legales'] = "personalization/personalization/append_mentions_legales";
		$route['personalization/update_mentions_legales'] = "personalization/personalization/update_mentions_legales";
		/********************** END OF MENTION LEGALES ************************/

		/********************** HEART STROKE *********************************/
		$route['personalize/upload_logo'] = "personalization/personalization/upload_logo";
		$route['personalize/upload_get_logo'] = "personalization/personalization/upload_get_logo";
		/********************** END OF HEART STROKE **************************/

	/********************************************************************************
								END OF PERSONALISATION
	**********************************************************************************/

	
	/********************************************************************************
								START OF PERSONALISATION
	**********************************************************************************/
	$route["faq"] = "backoffice/faq/";
	/********************************************************************************
								END OF PERSONALISATION
	**********************************************************************************/


	/*************************************************************************************
								START OF EMAIL ROUTES
	**************************************************************************************/

		$route["email_template"] = "backoffice/email_template/";
		$route["email_reminder"] = "backoffice/email_reminder/";
		$route["email_default_setting"] = "backoffice/email_default_setting/";
		$route["email_assign_template"] = "backoffice/email_assign_template/";
		$route["email_waitlist_reinvitation"] = "backoffice/email_waitlist_reinvitation/";
		$route["push_event"] = "backoffice/push_event/";


		/********************** EMAIL TEMPLATE ******************************************/
		$route["get_email_template_list"] = "email/email_template/get_email_template_list/";
		$route["get_email_default_setting_list"] = "email/email_default_setting/get_email_default_setting_list/";
		$route["get_email_assign_template_list"] = "email/email_assign_template/get_email_assign_template_list/";
		$route["get_email_reminder_list"] = "email/email_reminder/get_email_reminder_list/";
		$route["get_email_push_list"] = "email/email_push/get_email_push_list/";
		$route["load_email_type/(:any)"] = "email/email_template/get_tpl_form/$1";
		$route["get_email_template_content/(:num)"] = "email/email_template/get_email_template_content/$1/";
		$route["list_email_templates"] = "email/email_template/typeahead_email_template/";
		$route["list_email_events"] = "email/email_template/typeahead_event/";
		$route["list_email_recipient"] = "email/email_push/typeahead_email_recipient/";
		$route["refresh_sub_list"] = "email/email_push/refresh_subcribers_list/";
		/************************ End of EMAIL TEMPLATE *******************************/


		 /********************** CREATE EMAIL *****************************************/
		$route["create_email_template"] = "email/email_template/create_email_template/";
		$route["update_email_template/(:num)"] = "email/email_template/update_email_template/$1/";
		$route["check_template_dependencies/(:num)"] = "email/email_template/check_template_dependencies/$1/";

		$route["save_default_configuration"] = "email/email_default_setting/save_default_configuration/";
		$route["update_default_configuration/(:num)"] = "email/email_default_setting/update_default_configuration/$1/";
		$route["delete_configuration_setting/(:num)"] = "email/email_default_setting/delete_configuration_setting/$1/";

		$route["assign_email_template"] = "email/email_assign_template/assign_email_template/";
		$route["update_assign_email_template/(:num)"] = "email/email_assign_template/update_assign_email_template/$1/";
		$route["delete_assign_email_template/(:num)"] = "email/email_assign_template/delete_assign_email_template/$1/";
		/********************** END OF CREATE EMAIL **********************************/


		 /********************** EMAIL REMINDER **************************************/
		$route["add_email_reminder"] = "email/email_reminder/add_email_reminder/";
		$route["update_email_reminder"] = "email/email_reminder/update_email_reminder/";
		$route["delete_email_reminder"] = "email/email_reminder/delete_email_reminder/";
		$route["list_email_reminder"] = "email/email_reminder/typeahead_event/";
		/********************** END OF EMAIL REMINDER *******************************/


		/********************** EMAIL PUSH ******************************************/
		$route["add_email_push"] = "email/email_push/add_email_push/";
		$route["update_email_push"] = "email/email_push/update_email_push/";
		$route["delete_email_push"] = "email/email_push/delete_email_push/";
		$route["list_email_push"] = "email/email_push/typeahead_event/";
		$route["list_city_location"] = "email/email_push/typeahead_list_city_location/";
		$route["list_event_type"] = "email/email_push/typeahead_list_event_type/";
		$route["list_active_events"] = "email/email_push/typeahead_list_active_event/";
		/********************** END OF EMAIL PUSH **********************************/


		/********************** CRON ROUTES ***************************************/
		$route["e/r/(:any)"] = "services/email/reminder/$1";
		$route["e/wri/(:any)"] = "services/email/waitlist_reinvitation/$1";
		$route["e/fp/(:any)"] = "services/email/forgot_password/$1";
		$route["e/four/(:any)"] = "services/email/email_unregistered/$1";
		$route["e/foer/(:any)"] = "services/email/email_registered/$1";
		$route["e/forwl/(:any)"] = "services/email/email_registered_waitlist/$1";
		$route["e/epe/(:any)"] = "services/email/push_event_email/$1";
		/********************** END OF CRON ROUTES *******************************/

	
	/********************************************************************************
								END OF EMAIL ROUTES
	**********************************************************************************/


	/********************************************************************************
								START OF EVENT ROUTES
	**********************************************************************************/

		$route["list_events"] = "events/event/typeahead_event/";


		/********************** EVENT ASSIGN EMAIL TEMPALTE *********************/
		$route['event_assigned_email_template/(:any)/(:any)'] = "events/event_assign_email_template/by_event/$1/$2";
		$route['search_by_template_id/(:any)'] = "events/event_assign_email_template/search_by_template_id/$1";
		$route['assign_email_template/(:any)'] = "events/event_assign_email_template/assign_email_template/$1";
		$route['trash_template_event_schedule/(:any)'] = "events/event_assign_email_template/remove_template_event_schedule/$1";
		$route['check_default_template/(:any)'] = "events/event_assign_email_template/get_set_default_template/$1";
		$route['update_default_template/(:any)'] = "events/event_assign_email_template/update_set_default_template/$1";
		$route['assign_template_event_schedule/(:any)'] = "events/event_assign_email_template/assign_template_event_schedule/$1";
		$route['remove_template_event_schedule/(:any)/(:any)'] = "events/event_assign_email_template/remove_template_event_schedule/$1/$2";

		/********************** END OF EVENT ASSIGN EMAIL TEMPALTE *************/

		/********************** EVENT SPONSOR *********************/
		$route["add_event"] = "events/event/add_event";
		$route["delete_event/(:num)"] = "events/event/delete_event/$1";
		$route["update_event/(:num)"] = "events/event/update_event/$1";
		$route["preview_event/(:num)"] = "events/event/preview_event/$1";
		$route["event_info/(:num)"] = "events/event/event_info/$1";
		$route["list_event/(:num)"] = "events/event/list_event/$1";
		/********************** END OF EVENT SPONSOR *************/

		/********************** EVENT RESEND EMAIL TEMPALTE *********************/
		$route['get_datatable/(:any)/(:any)'] = "events/event_resend_email/get_datatable/$1/$2";
		$route['get_email_template_type'] = "events/event_resend_email/get_email_template_type";
		$route['insert_reference_id'] = "events/event_resend_email/insert_reference_id";
		/********************** END of EVENT RESEND EMAIL TEMPALTE *************/
		

		/********************** EVENT SCHEDULE *********************/
		$route["add_event_schedule"] = "events/event_schedule/add_event_schedule/";
		$route["update_event_schedule/(:num)"] = "events/event_schedule/update_event_schedule/$1/";
		$route["delete_event_schedule/(:num)"] = "events/event_schedule/delete_event_schedule/$1/";
		$route["list_event_schedule/(:num)"] = "events/event_schedule/list_event_schedule/$1/";
		/********************** END OF EVENT SCHEDULE *************/

		/********************** EVENT SPEAKER *********************/
		$route["add_event_speaker/(:num)"] = "events/event_speaker/add_event_speaker/$1";
		$route["delete_event_speaker/(:num)"] = "events/event_speaker/delete_event_speaker/$1";
		$route["update_event_speaker/(:num)"] = "events/event_speaker/update_event_speaker/$1";
		$route["list_event_speaker/(:num)"] = "events/event_speaker/list_event_speaker/$1";
		/********************** END OF EVENT SPEAKER *************/

		/********************** EVENT ATTACHMENT *********************/
		$route["add_event_attachment/(:num)"] = "events/event_attachment/add_event_attachment/$1";
		$route["delete_event_attachment/(:num)"] = "events/event_attachment/delete_event_attachment/$1";
		$route["update_event_attachment/(:num)"] = "events/event_attachment/update_event_attachment/$1";
		$route["list_event_attachment/(:num)"] = "events/event_attachment/list_event_attachment/$1";
		/********************** END OF EVENT ATTACHMENT *************/

		/********************** EVENT SPONSOR *********************/
		$route["add_event_sponsor/(:num)"] = "events/event_sponsor/add_event_sponsor/$1";
		$route["delete_event_sponsor/(:num)"] = "events/event_sponsor/delete_event_sponsor/$1";
		$route["update_event_sponsor/(:num)"] = "events/event_sponsor/update_event_sponsor/$1";
		$route["list_event_sponsor/(:num)"] = "events/event_sponsor/list_event_sponsor/$1";
		/********************** END OF EVENT SPONSOR *************/

	/********************************************************************************
								END OF EVENT ROUTES
	**********************************************************************************/


	/********************************************************************************
								START OF REPORTS ROUTES
	**********************************************************************************/
			
		$route["cron_testing"] = "backoffice/cron_testing/";
		$route["subscribers_list"] = "backoffice/reports_subscribers_list/";
		$route["events_data"] = "backoffice/reports_events_list/";
		$route["export_subscribers_list"] = "reports/subscribers/export_subscribers_list/";
		$route["export_events_list/(:num)"] = "reports/events/export_events_list/$1/";
		$route["export_events_info/(:num)"] = "reports/event_info/export_events_list/$1/$1/";
		$route["delete_subscriber"] = "reports/subscribers/delete_subscriber/";
		$route["get_subscriber"] = "reports/subscribers/get_subscriber/";
		$route["put_subscriber"] = "reports/subscribers/put_subscriber/";

		$route["add_limit"] = "reports/event_limit/add_limit/";
		$route["get_limit"] = "reports/event_limit/get_limit/";
		$route["put_limit"] = "reports/event_limit/put_limit/";

	/********************************************************************************
								END OF REPORTS ROUTES
	**********************************************************************************/


	/********************************************************************************
								START OF SYSTEM CONFIGURATION ROUTES 
	**********************************************************************************/
			
		/********************** CITY LOCATION ***********************************/
		$route["city_location_list"] = "admin/city_location/get_city_location_list/";
		/********************** END OF CITY LOCATION ****************************/

		/********************** EVENT PREFERENCES *******************************/
		$route["event_preference_list"] = "admin/event_type/get_event_preference_list/";
		/********************** END OF EVENT PREFERENCES ************************/

		/********************** USER ACCOUNT MANAGEMENT *************************/
		$route["user_account_list"] = "admin/users_account/get_user_account_list/";
		/********************** END OF USER ACCOUNT MANAGEMENT ******************/

	/********************************************************************************
								END OF SYSTEM CONFIGURATION ROUTES 
	**********************************************************************************/

	
	/********************************************************************************
								START OF DASHBORD ROUTES
	**********************************************************************************/
		
		$route["get_total_visitors"] = "dashboard/dashboard/get_total_visitors";
		$route["get_total_connection"] = "dashboard/dashboard/get_total_connection";

	/********************************************************************************
								END OF DASHBORD ROUTES
	**********************************************************************************/

/************************************************************************************************
								END OF BACK OFFICE PAGE ROUTING 
************************************************************************************************/



/*********************************************************************************
				UPLOAD DEFAULT EMAIL TEMPLATE ROUTES
**********************************************************************************/
	$route['upload_email_template'] = 'services/email/upload_default_email_template/';
/*********************************************************************************
				END OF UPLOAD DEFAULT EMAIL TEMPLATE ROUTES
**********************************************************************************/

/* End of file routes.php */
/* Location: ./application/config/routes.php */
