<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Menuitems extends CI_Model
{
    /**
     * Controller to get menu and access
     * [ Ace ]
     */
    private $role;

    public function __construct()
    {
        parent::__construct();
        $this->role = $this->session->userdata('role');
    }

    /**
     * Add the menu items here then proceed to access_link() function
     * @return array
     */
    public function MenuItem()
    {
        // These are the main menu items that should be displayed by views.
        // They route to modules and actions.  Whether they are displayed or
        // not at any given time depends on the user's role id and/or
        // their login status.
        return array(
            // Url format will be like http://akeen/dashboard
            // if you have extra segment you can add like this
            //array('module' => 'dashboard', 'action' => 'index') url will be http://akeen/dashboard/index
            'MenuItems' => array(
                // Super Admin
                $this->languages->lang('home')              => array('module' => 'admin', 'action' => 'dashboard'),
                //$this->languages->lang('user_status')          => array('module' => 'admin', 'action' => 'userstatus'),
                $this->languages->lang('profile')           => array('module' => 'admin', 'action' => 'profile'),
                $this->languages->lang('organizations')     => array('module' => 'admin', 'action' => 'organizations'),
                $this->languages->lang('guest')             => array('module' => 'admin', 'action' => 'accounts'),
                $this->languages->lang('personnalisation')  => array('module' => 'admin', 'action' => 'personalize'),
                $this->languages->lang('sections')          => array('module' => 'admin', 'action' => 'sections'),
                $this->languages->lang('questions')         => array('module' => 'admin', 'action' => 'questions'),
                $this->languages->lang('settings')          => array('module' => 'admin', 'action' => 'settings'),

                // Admin
//                $this->languages->lang('admin')             => array('module'=> 'admin', 'action' => 'dashboard'),
//                $this->languages->lang('users')             => array('module'=> 'admin', 'action' => 'users'),
                $this->languages->lang('companyprofile')    => array('module'=> 'admin', 'action' => 'companyprofile'),
                $this->languages->lang('superprofile')    => array('module'=> 'admin', 'action' => 'superprofile'),
                $this->languages->lang('spersonalize')    => array('module'=> 'admin', 'action' => 'spersonalize'),


                $this->languages->lang('logout')             => array('module' => 'logout'),
            ),
            // Sub-menu items that are displayed for any action belonging to a particular module.
            // Experimental, will continue soon
//            'SubMenuItems' => array(
//                'users' => array(
//                    'userlist'          => 'Users',
//                    'users_blocked'     => 'Blocked Accounts',
//                ),
//            ),
        );
    }

    public function access_link()
    {
        // Module/action permissions.
        // Role set in constants.php
        // To set multiple access add the role seperated by comma inside [ ] ( e.g. [SUPERADMIN, ADMIN] )
        // To set anyone with higher role level can view/access the module uncomment the code in actionAllowed()
        // (e.g. logout set to ADMIN which means ADMIN and SUPERADMIN can view the module)
        return array(
            'modules' => array(
                'admin'             => array(
                    '*'                 => ANYONE, // FIXME: Who can access admin login page?
                    'dashboard'         => [ SUPERADMIN,ADMIN ],
                    'userstatus'        => [ SUPERADMIN, ADMIN],
                    'profile'           => [ SUPERADMIN],
                    'organizations'     => SUPERADMIN,
                    'accounts'          => [ SUPERADMIN,ADMIN ],
                    'personalize'       => ADMIN,
                    'sections'          => SUPERADMIN,
                    'questions'         => [ SUPERADMIN,ADMIN ],
                    'settings'          => SUPERADMIN,
                    'companyprofile'    => ADMIN,
                    'superprofile'    => SUPERADMIN,
                    'spersonalize'    => SUPERADMIN
                ),
                'logout'            => array(
                    '*'                 => [ SUPERADMIN,ADMIN ]
                ),
            ),
        );
    }

    /**
     * Returns an array of menu items that should be diplayed from the view.
     * Only menu items the current user (and their role level) have access to
     * will be returned as part of the array;
     *
     * @return array
     */
    public function getMenuItems($adminMenus = false)
    {
        $menuItems = $this->MenuItem();
        $allowedItems = array();
        $i = [];
        foreach ($menuItems as $categoryName => $menu) {
            foreach ($menu as $menuName => $menuItem) {
                $f_url  = array_key_exists('f_url',  $menuItem) ? $menuItem['f_url']  : false; // maybe will be use near future
                $module = array_key_exists('module', $menuItem) ? $menuItem['module'] : false;
                $action = array_key_exists('action', $menuItem) ? $menuItem['action'] : '*';
                $exturl = array_key_exists('exturl', $menuItem) ? $menuItem['exturl'] : null;
                $i[] = $categoryName;
                if ($this->actionAllowed($module, $action) && ( is_array($module_action = $this->get("modules.$module.$action")) && array_search($this->role,$module_action) >= 0 || $module_action >= $this->role)) {
                    $allowedItems[$categoryName][] = array(
                        'name'   => $menuName,
                        'exturl' => null,
                        'module' => $module,
                        'action' => $action,
                        'url'    => $this->url( [ $module, $action == '*' ? '': $action ] )
                    );
                }
                else {
                    if (empty($allowedItems[$categoryName])) {
                        $allowedItems[$categoryName] = array();
                    }
                    if ($exturl) {
                        $allowedItems[$categoryName][] = array(
                            'name'   => $menuName,
                            'exturl' => $exturl,
                            'module' => null,
                            'action' => null,
                            'url'    => $this->url( [$exturl] )
                        );
                    }
                    elseif ($this->actionAllowed($module, $action) && $this->get("modules.$module.$action") < $this->role) {
                        $allowedItems[] = array();
                    }
                }
            }
        }
        return $allowedItems;
    }

    /**
     * Get the value held by the specified key.
     *
     * Keys are specified in an object-like format, such as: 'Foo.Bar.Baz'
     * where each dot would denote the difference in depth from key-to-key.
     *
     * @param string $key Key sequence.
     * @param bool $configObjectIfArray True/false whether or not to return instances for values that are an array
     * but cant use it yet because i'm having issue with CodeIgniter
     * @access public
     */
    public function get($key, $configObjectIfArray = true)
    {
        $keys = explode('.', $key);
        $base = $this->access_link();
        $size = count($keys) - 1;
        $x = [];
        $y = [];
        for ($i = 0; $i < $size; ++$i) {
            $currentKey = $keys[$i];
            if (is_array($base) && array_key_exists($currentKey, $base)) {
                $base = &$base[$currentKey];
                $x[] = $currentKey;
                $y[] = $base;
            }
            else {
                // Short-circuit and return null.
                return null;
            }
        }
        $currentKey = $keys[$size];
        if (array_key_exists($currentKey, $base)) {
            $value = &$base[$currentKey];
//            if (is_array($base) && $configObjectIfArray) {
//                return array_values($base);
//            }
//            if (is_array($value) && $configObjectIfArray) { // will be use near future
//                $configClassName = get_class($this);
//                return new $configClassName($value);
//            }
//            else {
                return $value;
//            }
        }
        else {
            // We want to avoid a traditional PHP error when referencing
            // non-existent keys, so we'll silently return null as an
            // alternative ;)
            return null;
        }
    }

    /**
     * Return base url with url set in MenuItem function
     * @param array $url
     * @return string
     */
    public function url(array $url)
    {
        return ak_url().implode($url,"/");
    }

    /**
     * Checks whether or not the current user is able to perform a particular
     * action based on his/her role level and id.
     *
     * @param string $moduleName
     * @param string $actionName
     * @return bool
     * @access public
     */
    public function actionAllowed($moduleName, $actionName = 'index')
    {
        $accessKeys = array("$moduleName.$actionName", "$moduleName.*");
        $accountLevel = $this->role;
        $existentKeys = array();
        foreach ($accessKeys as $key => $accessKey) {
            $accessLevel = $this->get("modules.$accessKey");
            if (!is_null($accessLevel)) {
                $existentKeys[] = $accessKey;
                if(is_array($accessLevel)){
                    foreach($accessLevel as $roleId){
                        if($roleId == $accountLevel){
                           return true;
                        }
                    }
                }
                else if ($accessLevel == ANYONE || $accessLevel == $accountLevel
                    //|| ($accountLevel <= $accessLevel)  // uncomment this if higher role level/id can view/access
                                                        // the other modules of the lower role level/id
                ) {
                    return true;
                }
                return false;
            }
        }
        if (empty($existentKeys)) {
            return -1;
        } else {
            return false;
        }
    }
}


