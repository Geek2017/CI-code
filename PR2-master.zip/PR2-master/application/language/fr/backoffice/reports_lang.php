<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/* SUBSCRIBERS LIST */

//BUTTONS && PAGE NAME

//FIELDS && TABLE COLUMNS

//TABLE COLUMNS
$lang["email_address"] = "Email";
$lang["mailing_address"] = "Mailing Address";
$lang["telephone_number"] = "Tél.";
$lang["subscription_date"] = "Date de souscription";
$lang["event_preference"] = "Préférence d'événement";
$lang["genre"] = "Genre";
$lang["last_name"] = "Nom";
$lang["first_name"] = "Prénom";
$lang["address_1"] = "Adresse1";
$lang["address_2"] = "Adresse2 (Optionnel)";
$lang["address_3"] = "Adresse3 (Optionnel)";
$lang["mobile_number"] = "Numéro de mobile";
$lang["city"] = "Ville";
$lang["code_postal"] = "Code Postal (Optionnel)";
$lang["subscriber_number"] = "Numéro d'abonné (Optionnel)";
$lang["subscription_date_op"] = "Date d'ancienneté (abonné depuis) (Optionnel)";
$lang["birth_date"] = "Date de naissance (Optionnel)";
$lang["total_booked"] = "Nombre de places réservées";
$lang["reservation_status"] = "Statut de la réservation";
$lang["reservation_date"] = "Date de réservation";
$lang["reservation_time"] = "Heure de réservation";
$lang["navigator"] = "Navigateur";
$lang["date_of_cancellation"] = "Date d'annulation";
$lang["time_of_cancellation"] = "Heure d'annulation";
$lang["number_of_place_cancelled"] = "Nombre de places annulées";
$lang["number_of_registration"] = "Total des inscriptions";
$lang["number_of_user_and_guest"] = "Nombre total de places réservées";
$lang["avg_number_of_registration"] = "Moyenne des places réservés";

/* END OF EVENT SUBSCRIBERS LIST */


/* EVENTS LIST */
$lang["export_events_data"] = "Les données de l'événement";

$lang["hour"] = "Heure";
$lang["place_town"] = "Lieu Ville";
$lang["date_month"] = "Période(s)de(s) prestation(s) de l'évènement (date/mois)";
$lang["total_places_avl"] = "Nombre total de places disponibles";
$lang["num_remaining_places"] = "Nombre de places restantes";
$lang["price_rate"] = "Tarifs";
$lang["event_statuses"] = "Statut de l’événement : disponibles/complet";

$lang["reports"]["btn"]["_export"] = "Exporter";
$lang["reports"]["btn"]["export_subscriber_list"] = "Exporter une liste d'abonnés";
$lang["reports"]["event"]["event_file_name"] = "Evénement";
$lang["reports"]["client"]["client_file_name"] = "Les Inscrits";
$lang["reports"]["subscriber"]["subscriber_file_name"] = "Les Inscrits";
$lang["reports"]["unsubscribe"]["unsubscribe_file_name"] = "Les désinscrits";
$lang["reports"]["waitlist"]["waitlist_file_name"] = "Liste d'attente";
/* END OF EVENT EVENTS LIST */



/**
*
* Modal translation for subscriber
**/
//[Token modal] confirmation translations
$lang["event_modal_title"] = "Confirmation";
$lang["event_modal_save"] = "Save";
$lang["event_modal_cancel"] = "Cancel";
$lang["event_modal_confirm"] = "Confirm";

//[Edit and delete] schedule modal translations
$lang["event_modal_title_delete"] = "Delete confirmation";
$lang["event_modal_title_edit"] = "Edit Information";
$lang["event_modal_select"] = "Select";
$lang["event_modal_select_active"] = "Active";
$lang["event_modal_select_deactive"] = "Deactive";

//[reservation limit] translations
$lang["event_modal_title_reservation"] = "Event reservation limit";
$lang["event_modal_is_activate_limit"] = "Activate limit";
$lang["event_modal_number_of_events"] = "Number of events";
$lang["event_modal_number_what"] = "Duration";
$lang["event_modal_number_by"] = "By";
$lang["event_modal_duration_week"] = "WEEK";
$lang["event_modal_duration_month"] = "MONTH";
$lang["event_modal_duration_year"] = "YEAR";

// edit profile
$lang["first_name"] = "Prénom";
$lang["last_name"] = "Nom de famille";
$lang["location"] = "Localisation";
$lang["mailing_address"] = "Adresse postale";
$lang["email_address"] = "Adresse e-mail";
$lang["phone"] = "Téléphone";
$lang["mobile"] = "Mobile";
$lang["event_preferences"] = "Préférences d'événement";
// end edit profile

// Buttons
$lang["save_changes"] = "Enregistrer les modifications";

//Alerts
$lang["alert_title"] = "Warning";
$lang["alert_content"] = "Subscriber was currently logged in. You will not be given an access to its account right now.";

//---------------------------------------------------------------------------------------------------------------------------------


/* End of file reports_lang.php */
/* Location: ./application/language/fr/backoffice/reports_lang.php */