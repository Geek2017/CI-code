<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Email_push extends MY_Controller {
    public function __construct()
    {
        //parent::__construct();
        $this->my_controller_parent_construct();
        $this->check_session_timed_out("bo");
        //load language files
        $this->load_language_backoffice();
        $this->lang->load('backoffice/email', 'fr');
        //load model
        $this->load->model("event_model");
        $this->load->model("event_email_custom_model");
        $this->load->model("event_email_template_model");
        $this->load->model("user_activity_log_model");
        $this->load->helper('htmlpurifier');
    }

    public function get_email_push_list($export=0){
        if($this->input->post() && isset($this->data["logged_in"]["user_id"])){
            $list = $this->event_email_custom_model->get_datatables($this->input->post());
            $data = array();
            $row = array();
            $x = $this->input->post("start");

            foreach ($list as $push_event) {
                $subscribers = ($push_event->subscribers != null)?explode("_||_",$push_event->subscribers):null;
                $event_type = ($push_event->event_type != null)?explode("_||_",$push_event->event_type):null;
                $city = ($push_event->city != null)?explode("_||_",$push_event->city):null;

                $row["event_order"] = ++$x;
                $row["event_title"] = $push_event->event_title;
                $row["event_filters"] = $push_event->email_filter;
                $row["email_subscribers"] = ($push_event->email_custom_sendto == 1)?"ALL SUBSCRIBERS":((sizeof($subscribers) > 0)?$subscribers[0]:$subscribers);
                $row["email_sent"] = ($push_event->email_sent > 0)?$push_event->email_sent:0;
                $row["email_onqueue"] = ($push_event->email_onqueue > 0)?$push_event->email_onqueue:0;
                $row["email_custom_author"] = $push_event->email_custom_author;
                $row["email_push_date_created"] = $push_event->email_push_date_created;
                $row["email_push_status"] = ($push_event->remaining_seat<= 0 || $push_event->event_status == "FULL" || !is_null($push_event->event_status))
                                            ? $this->lang->line("email")["cmsg"]["event_is_full"]
                                            : $this->lang->line("email_push_email_onqueue") ;
                $row["action"] = array(
                    "email_custom_id" => $push_event->email_custom_id,
                    "email_custom_status" => $push_event->email_custom_status,
                    "email_custom_sendto" => $push_event->email_custom_sendto,
                    "subscriber_id" => (sizeof($subscribers) > 0)?$subscribers[1]:$subscribers,
                    "city_location_id" => (sizeof($city) > 0)?$city[0]:$city,
                    "city" => (sizeof($city) > 0)?$city[1]:$city,
                    "event_type_id" => (sizeof($event_type) > 0)?$event_type[0]:$event_type,
                    "event_type" => (sizeof($event_type) > 0)?$event_type[1]:$event_type,
                    "subscription_date" => $push_event->subscription_date,
                    "event_id" => $push_event->event_id
                );
                array_push($data, $row);
            }
            $output = array(
                "draw" => $_POST['draw'],
                "recordsTotal" => $this->event_email_custom_model->count_all($this->input->post()),
                "recordsFiltered" => $this->event_email_custom_model->count_filtered($this->input->post()),
                "data" => $data,
            );
            //output to json format
            output_to_json($this, $output);
        } else {
            show_404();
        }
    }

    public function add_email_push(){
        if($this->input->post() && isset($this->data["logged_in"]["user_id"])) {
            //$push_email_tpl = $this->event_email_template_model->get_current_event_email_template($this->input->post("event_id"), 4, false);
            $email_custom_id = $this->event_email_custom_model->add_email_push(array(
                //"email_tpl_id" => (sizeof($push_email_tpl)>0)?$push_email_tpl->email_tpl_id : null,
                "event_id" => $this->input->post("event_id")[0],
                "email_custom_sendto" => $this->input->post("email_custom_sendto"),
                "email_custom_author" => $this->data["logged_in"]["user_id"],
                "email_custom_status" => $this->input->post("email_custom_status")
            ));

            //insert data
            if ($email_custom_id) {
                $filters = true;
                if($this->input->post("event_type_id")){
                    $filters=$this->checkEmailPushFilters("event_type_id", $this->input->post("event_type_id"), $email_custom_id);
                }

                if($this->input->post("city_location_id")){
                    $filters=$this->checkEmailPushFilters("city_location_id", $this->input->post("city_location_id"), $email_custom_id);
                }

                if($this->input->post("subscription_date")){
                    $filters=$this->checkEmailPushFilters("subscription_date", $this->input->post("subscription_date"), $email_custom_id);
                }

                if($this->input->post("subscriber_id")){
                    $filters=$this->checkEmailPushFilters("subscriber_id", $this->input->post("subscriber_id"), $email_custom_id);
                }

                //prepare list of recipients if "all subscribers are selected and with publish status
                if($this->input->post("email_custom_sendto") == 1 && $this->input->post("email_custom_status") == 1){
                    $this->event_email_custom_model->prepareRecipients($this->input->post(), $email_custom_id);
                }

            }
            if ($email_custom_id && $filters) {
                //email reminder added
                output_to_json($this, array(
                    "mtype" => "success",
                    "message" => $this->lang->line("added_email_reminder")
                ));
            } else {
                output_to_json($this, array(
                    "mtype" => "error",
                    "message" => $this->lang->line("unknown_error")
                ));
            }
        } else {
            show_404();
        }
    }

    public function update_email_push(){
        if($this->input->post("email_custom_id") && isset($this->data["logged_in"]["user_id"])) {
            //$push_email_tpl = $this->event_email_template_model->get_current_event_email_template($this->input->post("event_id"), 4, false);
            $updated = $this->event_email_custom_model->update_email_push($this->input->post("email_custom_id"), array(
                //"email_tpl_id" => (sizeof($push_email_tpl)>0)?$push_email_tpl->email_tpl_id : null,
                "event_id" => $this->input->post("event_id")[0],
                "email_custom_sendto" => $this->input->post("email_custom_sendto"),
                "email_custom_author" => $this->data["logged_in"]["user_id"],
                "email_custom_status" => $this->input->post("email_custom_status")
            ));
            $email_custom_id = $this->input->post("email_custom_id");
            //insert data
            if ($updated) {
                $filters= true;
                if($this->input->post("event_type_id")){
                    $filters= $this->checkEmailPushFilters("event_type_id", $this->input->post("event_type_id"), $email_custom_id, "edit");
                } else{
                    //delete filters
                    $filters=$this->event_email_custom_model->deleteFilters($this->input->post("event_type_id"), $email_custom_id, 2);
                }

                if($this->input->post("city_location_id")){
                    $filters=$this->checkEmailPushFilters("city_location_id", $this->input->post("city_location_id"), $email_custom_id, "edit");
                } else{
                    //delete filters
                    $filters=$this->event_email_custom_model->deleteFilters($this->input->post("city_location_id"), $email_custom_id, 1);
                }
                if($this->input->post("subscription_date")){
                    $filters=$this->checkEmailPushFilters("subscription_date", $this->input->post("subscription_date"), $email_custom_id, "edit");
                } else{
                    //delete filters
                    $filters=$this->event_email_custom_model->deleteFilters($this->input->post("subscription_date"), $email_custom_id, 3);
                }

                if($this->input->post("subscriber_id")){
                    $filters=$this->checkEmailPushFilters("subscriber_id", $this->input->post("subscriber_id"), $email_custom_id, "edit");
                } else {
                    //delete recipients
                    $filters=$this->event_email_custom_model->deleteRecipients($this->input->post("subscriber_id"), $email_custom_id);
                }

                //prepare list of recipients if "all subscribers are selected and with publish status
                if($this->input->post("email_custom_sendto") == 1 && $this->input->post("email_custom_status") == 1){
                    $this->event_email_custom_model->prepareRecipients($this->input->post(), $email_custom_id);
                }
            }
            if ($updated && $filters) {
                //email reminder added
                output_to_json($this, array(
                    "mtype" => "success",
                    "message" => $this->lang->line("added_email_reminder")
                ));
            } else {
                output_to_json($this, array(
                    "mtype" => "error",
                    "message" => $this->lang->line("unknown_error")
                ));
            }
        } else {
            show_404();
        }
    }

    private function checkEmailPushFilters($filterBy, $data, $email_custom_id, $actionType="add"){
        switch($filterBy){
            case "event_type_id" :
                $insert_data=array();

                if($actionType =="edit"){
                    //delete filters
                    $filters=$this->event_email_custom_model->deleteFilters($data, $email_custom_id, 2);
                }
                foreach($data as $row){
                    array_push($insert_data,array(
                        "email_custom_id" => $email_custom_id,
                        "email_filter_id" => 2, //for event_type
                        "email_filter_search" => $row,
                        "email_custom_filter_status"=> 1
                    ));
                }
                //insert new ones
                $inserted =$this->event_email_custom_model->addCustomFilters($insert_data);
                if(!$inserted){
                    return false;
                }
                return true;

                break;

            case "city_location_id" :
                $insert_data=array();

                if($actionType =="edit"){
                    //delete filters
                    $filters= $this->event_email_custom_model->deleteFilters($data, $email_custom_id, 1);
                }
                foreach($data as $row){
                    array_push($insert_data,array(
                        "email_custom_id" => $email_custom_id,
                        "email_filter_id" => 1, //for event_type
                        "email_filter_search" => $row,
                        "email_custom_filter_status"=> 1
                    ));
                }
                //insert new ones
                $inserted =$this->event_email_custom_model->addCustomFilters($insert_data);
                if(!$inserted){
                    return false;
                }
                return true;
                break;

            case "subscription_date" :
                if($actionType =="edit"){
                    //delete filters
                    $filters=$this->event_email_custom_model->deleteFilters($data, $email_custom_id, 3);
                }
                $insert_data=array();
                array_push($insert_data, array(
                    "email_custom_id" => $email_custom_id,
                    "email_filter_id" => 3, //for event_type
                    "email_filter_search" => $data,
                    "email_custom_filter_status"=> 1
                ));
                //insert new ones

                $inserted =$this->event_email_custom_model->addCustomFilters($insert_data);

                if(!$inserted){
                    return false;
                }
                return true;

                break;

            case "subscriber_id" :
                $insert_data=array();

                if($actionType =="edit"){
                    //delete filters
                    $filters= $this->event_email_custom_model->deleteRecipients($data, $email_custom_id, 1);
                }
                foreach($data as $row){
                    array_push($insert_data,array(
                        "email_custom_id" => $email_custom_id,
                        "email_number_of_send_attempt" => 0, //for event_type
                        "subscriber_id" => $row,
                        "email_status"=>0,
                        "email_recipient_status"=> 1
                    ));
                }
                //insert new ones
                $inserted =$this->event_email_custom_model->addCustomRecipients($insert_data);
                if(!$inserted){
                    return false;
                }
                return true;
                break;

            default:
                return true;
                break;
        }
    }

    public function delete_email_push(){
        if($this->input->post("email_custom_id") && isset($this->data["logged_in"]["user_id"])) {
            $delete_email_push = $this->event_email_custom_model->delete_email_push($this->input->post("email_custom_id"));

            if ($delete_email_push) {
                output_to_json($this, array(
                    "mtype" => "success",
                    "message" => $this->lang->line("deleted_reminder_email")
                ));
            } else {
                output_to_json($this, array(
                    "mtype" => "error",
                    "message" => $this->lang->line("unknown_error")
                ));
            }
        } else {
            show_404();
        }
    }

    public function typeahead_event(){
        if($this->input->post("search") && isset($this->data["logged_in"]["user_id"])) {
            output_to_json($this, $this->event_email_custom_model->list_events_for_push_event_typeahead($this->input->post("search")));
        }
    }

    public function typeahead_email_recipient(){
        if($this->input->post("search") && isset($this->data["logged_in"]["user_id"])) {
            if($this->input->post("search")) {
                output_to_json($this, $this->event_email_custom_model->typeahead_email_recipient($this->input->post(), $this->input->post("subscriber_id")));
            }
        }
    }

    public function typeahead_list_city_location(){
        if($this->input->post("search") && isset($this->data["logged_in"]["user_id"])) {
            output_to_json($this, $this->event_email_custom_model->typeahead_list_city_location($this->input->post("search"), $this->input->post("city_location_id")));
        }
    }

    public function typeahead_list_event_type(){
        if($this->input->post("search") && isset($this->data["logged_in"]["user_id"])) {
            output_to_json($this, $this->event_email_custom_model->typeahead_list_event_type($this->input->post("search"), $this->input->post("event_type_id")));
        }
    }

    public function typeahead_list_active_event(){
        if($this->input->post("search") && isset($this->data["logged_in"]["user_id"])) {
            output_to_json($this, $this->event_email_custom_model->typeahead_list_active_event($this->input->post("search"), $this->input->post("filter_event_type_id")));
        }
    }

    public function refresh_subcribers_list(){
        if(isset($this->data["logged_in"]["user_id"])) {
            $exception = ($this->input->post("subscriber_id"))?$this->input->post("subscriber_id"):"";
            $email_custom_sendto = ($this->input->post("email_custom_sendto"))?$this->input->post("email_custom_sendto"):2;
            $data_vars = array("subscriber_id", "subscriber_name");
            $data = array();
            if($email_custom_sendto == 1) {
                $data_vars = array("email_custom_sendto", "email_custom_sendto_values");
            }
            $data[$data_vars[0]] ="";
            $data[$data_vars[1]] ="";

            $result = $this->event_email_custom_model->typeahead_email_recipient($this->input->post(), $exception, "IN");
            $resLength = sizeof($result); $x=1;
            if($resLength > 0){
                foreach($result as $row){
                    $sep = "";
                    if($resLength != $x){
                        $sep =", ";
                    }
                    $data[$data_vars[0]] .=$row->id.$sep;
                    $data[$data_vars[1]] .=$row->name.$sep;
                    $x++;
                }
            }
            output_to_json($this, $data);
        }
    }
}