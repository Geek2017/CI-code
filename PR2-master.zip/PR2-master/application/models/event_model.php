<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Event_model extends CI_Model {

    var $column_order = array(null, 'e.title','et.event_type', 'ecl.city', 'e.date_created', 'es.event_status', null, 'e.status', 'CONCAT(u.first_name, " ", u.last_name)'); //set column field database for datatable orderable
    var $column_search = array('CONCAT(u.first_name, " ", u.last_name)','e.title','e.date_created', 'e.status', 'et.event_type', 'es.event_status', 'ecl.city'); //set column field database for datatable searchable just firstname , lastname , address are searchable
    var $order = array('e.event_id' => 'desc'); // default order

    public function __construct() {
        parent::__construct();
        $this->db->query("SET @@group_concat_max_len =30000");
    }

    private function _get_export_query(){

        return "SELECT
            es.start_date_time as start_date,
            es.end_date_time as end_date,
            e.location as event_venue,
            es.rate as price_rate,
            es.remaining_seat as num_remaining_places,
            es.total_available_seat as total_places_avl,
            es.reservation_start_date as reservation_date,
            (CASE
              WHEN es.event_status = 'AVAILABLE' THEN 'Disponible'
              ELSE 'Complet'
            END) AS event_statuses,
            ecl.city as place_town,
            CONCAT(DATE_FORMAT(es.start_date_time, '%e/%m/%Y') ,' - ', DATE_FORMAT(es.end_date_time, '%e/%m/%Y')) AS date_month,
            CONCAT(DATE_FORMAT(es.start_date_time, '%Hh%i'),' - ', DATE_FORMAT(es.end_date_time, '%Hh%i')) AS hour ";
    }

    private function _get_event_list(){
        return "SELECT
            (SELECT
                GROUP_CONCAT(CONCAT('{\"event_schedule_id\":\"',a.event_schedule_id,
                '\", \"reservation_start_date\":\"',DATE_FORMAT(a.reservation_start_date, '%e/%m/%Y %Hh%i'),
                '\", \"start_date_time\":\"',DATE_FORMAT(a.start_date_time, '%e/%m/%Y %Hh%i'),
                '\", \"end_date_time\":\"',DATE_FORMAT(a.end_date_time, '%e/%m/%Y %Hh%i'),
                '\", \"total_available_seat\":\"',a.total_available_seat,
                '\", \"remaining_seat\":\"',a.remaining_seat,
                '\", \"event_status\":\"',a.event_status,
                '\", \"back_office_status\":\"',a.back_office_status, 
                '\", \"reservation_end_date\":\"',
                (CASE 
                WHEN DATE_FORMAT(a.reservation_end_date, '%e/%m/%Y %Hh%i') IS NULL
                    THEN \"\"
                    ELSE DATE_FORMAT(a.reservation_end_date, '%e/%m/%Y %Hh%i')
                END),
                '\", \"seats_per_subscriber\":\"',a.seats_per_subscriber,
                '\", \"quota_waiting_list_seat\":\"',a.quota_waiting_list_seat,'\"}'                
            ) ORDER BY a.reservation_start_date SEPARATOR ',') as child_events
                 FROM event_schedule a
                WHERE a.event_id = e.event_id
                AND a.back_office_status NOT IN (5,6)
            ) AS event_schedule,
          ecl.city as city";
    }

    private function _get_datatables_query($data_source, $export, $event_schedule_id){
        $_query = ""; $_search = ""; $_ordey_by = ""; $data = array(); $select = "";

        if($export) {
            $_query = $this->_get_export_query();
        } else {
            $_query = $this->_get_event_list();
        }

        $_query .=", e.event_id,
                e.title as event_title,
                et.event_type,
                DATE_FORMAT(e.date_created, '%e/%m/%Y %Hh%i') AS date_created,
                CONCAT(u.first_name, ' ', u.last_name) as author
            FROM event e
            LEFT JOIN event_schedule es ON es.event_id = e.event_id
            LEFT JOIN event_type et ON et.event_type_id = e.event_type_id
            LEFT JOIN event_city_location ecl ON ecl.city_location_id = e.city_location
            LEFT JOIN user u ON u.user_id = e.author
            WHERE
                e.status IN (1)
            AND es.back_office_status NOT IN (5,6) ";

        if($event_schedule_id > 0) {
            $_query .= " AND es.event_schedule_id = ".$event_schedule_id;
        }

        if(isset($data_source["custom_filter_search"]) && !empty($data_source["custom_filter_search"]) && $data_source["custom_filter_search"] != "all"){
            if($data_source["custom_filter_search"] == "start_date_time"){
                $splitte = explode("/", $data_source['search']['value']);
                array_push($data, "%".$splitte[1]."-".$splitte[0]."%");
                $_search .= " AND ( es.start_date_time LIKE ? ";

            } else {
                if (isset($data_source["keyname"]) && !empty($data_source["keyname"])) {
                    if($data_source[$data_source["keyname"]] != "") {
                        $_query .= " AND e.".$data_source["custom_filter_search"]." = '".$data_source[$data_source["keyname"]]."'";
                    }
                    array_push($data, "%".$data_source['search']['value']."%");
                    $_search .= " AND ( e.title LIKE ? ";
                } else {
                    array_push($data, "%".$data_source['search']['value']."%");
                    $_search .= " AND ( e." . $data_source["custom_filter_search"]." LIKE ? ";
                }
            }

            $_search .= ")";
        } else {
            if($data_source['search']['value']) {
                $i = 0;
                foreach ($this->column_search as $item) {// loop column
                    if($i===0){ // first loop
                        array_push($data, "%".$data_source['search']['value']."%");
                        $_search .= " AND ( ".$item." LIKE ? ";
                    } else {
                        array_push($data, "%".$data_source['search']['value']."%");
                        $_search .= " OR ".$item." LIKE ? ";
                    }
                    $i++;
                }
                $_search .= ")";
            }
        }

        // group by event_id
        $_query .=" GROUP BY es.event_id ";

        if(isset($data_source['order'])) { // here order processing
            if(isset($data_source['order']['0']['dir']) && !empty($data_source['order']['0']['dir'])) {
                $_ordey_by .= " ORDER BY ".$this->column_order[$data_source['order']['0']['column']]." ".$data_source['order']['0']['dir'];
            } else {
                $_ordey_by .= " ORDER BY ".key($this->order)." ".$this->order[key($this->order)];
            }
        } else if(isset($this->order)) {
            $_ordey_by .= " ORDER BY ".key($this->order)." ".$this->order[key($this->order)];
        }

        return array("query"=>$_query.$_search.$_ordey_by, "data" =>$data);
    }

    public function get_events_list_export($data_source, $export, $event_schedule_id){
        $_query = $this->_get_datatables_query($data_source, $export, $event_schedule_id);
        $res= $this->db->query($_query["query"], $_query["data"])->result();
        return $res;
    }

    public function get_datatables($data_source, $export, $event_schedule_id){
        $_query = $this->_get_datatables_query($data_source, $export, $event_schedule_id);

        if($data_source['length'] != -1){
            $_query["query"] .= " LIMIT ".$data_source['start'].", ".$data_source['length'];
        }
        
        $data = $this->db->query($_query["query"], $_query["data"]);
        return $data->result();
    }

    public function count_filtered($data_source, $export, $event_schedule_id){
        $_query = $this->_get_datatables_query($data_source, $export, $event_schedule_id);
        return $this->db->query($_query["query"], $_query["data"])->num_rows();
    }

    public function count_all($data_source, $export, $event_schedule_id){
        $_query = $this->_get_datatables_query($data_source, $export, $event_schedule_id);
        return $this->db->query($_query["query"], $_query["data"])->num_rows();
    }

    private function _get_filter_query()
    {
        return "SELECT e.event_id, e.use_heartstroke, efa.file_name, efa.attachment_type, efa.status, e.title, e.city_location, ecl.city, e.location, e.event_type_id, et.event_type, e.author, e.code_postal, e.address, e.city_name, e.date_created, e.description, e.back_office_status,e.display_status FROM event e JOIN event_type et ON e.event_type_id = et.event_type_id JOIN event_file_attachment efa ON e.event_id = efa.event_id JOIN event_city_location ecl ON e.city_location = ecl.city_location_id WHERE efa.status = 1 AND efa.attachment_type = 1 ";
    }

    public function _get_preferences_query($user_id)
    {
        $subscriber_id = $this->db->select('subscriber_id')
            ->from('user_subscriber')
            ->where('subscriber', $user_id)
            ->get()
            ->row()
            ->subscriber_id;

        $preferences = $this->db->select('event_preference')
            ->from('user_subscriber_event_preference')
            ->where('subscriber_id', $subscriber_id)
            ->get()
            ->result_array();

        $prefer = array();
        foreach($preferences as $preference){
            array_push($prefer, $preference['event_preference']);
        }

        return $prefer;
    }

    public function filter_events($filter, $page, $month, $type, $city, $user_id, $logged_in)
    {
        $pages = $page*6-6;

        if($logged_in) $preferences = $this->_get_preferences_query($user_id);

        // Filter ------------------------------------------------------------------------
        $query = $this->_get_filter_query();
        $query .= ' AND e.back_office_status != 0 ';
        $query .= 'AND e.back_office_status != 4 ';
        $query .= 'AND e.back_office_status != 5 ';
        $query .= 'AND e.back_office_status != 6 ';
        $query .= $this->_get_filter_type($filter, $month, $type, $city);
        // if($logged_in) $this->db->where_in('e.event_type_id', $preferences);
        $query .= ' UNION ';
        $query .= $this->_get_filter_query();
        $query .= ' AND e.back_office_status = 4 ';
        $query .= $this->_get_filter_type($filter, $month, $type, $city);
        $query .= ' ORDER BY display_status DESC';
        $query .= ' LIMIT '.$pages.', 6';
        $events = $this->db->query($query);

        // Pagination ---------------------------------------------------------------------
        $query = $this->_get_filter_query();
        $query .= ' AND e.back_office_status != 0 ';
        $query .= 'AND e.back_office_status != 5 ';
        $query .= 'AND e.back_office_status != 6 ';
        $query .= $this->_get_filter_type($filter, $month, $type, $city);
        // if($logged_in) $this->db->where_in('e.event_type_id', $preferences);
        $pagination = $this->db->query($query);

        return array(
            'data' => $events->result(),
            'pagination' => ceil($pagination->num_rows()/6),
            'result_count' => $events->num_rows(),
            'logged_in' => $logged_in
        );
    }

    private function _get_filter_type($filter, $month, $type, $city)
    {
        switch($filter) {
            case 'month':
                return "AND month(e.start_date_time) = ".$month;
            case 'type':
                return "AND e.event_type_id = ".$type;
            case 'city':
                return "AND e.city_location = ".$city;
            case 'month_city':
                return "AND month(e.start_date_time) = ".$month.
                " AND e.city_location = ".$city;
            case 'month_type':
                return "AND month(e.start_date_time) = ".$month.
                " AND e.event_type_id = ".$type;
            case 'type_city':
                return "AND e.event_type_id = ".$type.
                " AND e.city_location = ".$city;
            case 'all':
                return "AND month(e.start_date_time) = ".$month.
                " AND e.event_type_id = ".$type.
                " AND e.city_location = ".$city;
            default : return;
        }
    }

    public function _get_page_number($event_id)
    {
        $this->db->query('SET @row_num := 0');
        $query = $this->db->query("
            SELECT @row_num := @row_num + 1 as 'row_number', t.*
            FROM (
                (SELECT e.event_id, efa.file_name, efa.attachment_type, efa.status, e.title, e.city_location, e.location, e.event_type_id, et.event_type, e.author, e.date_created, e.description, e.rate, e.start_date_time, e.end_date_time, e.total_available_seat, e.seats_per_subscriber, e.quota_waiting_list_seat, e.for_invitation, e.reinvitation_after, e.reservation_start_date, e.remaining_seat, e.event_status, e.back_office_status, e.display_status
                FROM event e
                    JOIN event_type et ON e.event_type_id = et.event_type_id
                    JOIN event_file_attachment efa ON e.event_id = efa.event_id
                WHERE efa.status = 1
                    AND efa.attachment_type = 1
                    AND e.back_office_status != 0
                    AND e.back_office_status != 4
                    AND e.back_office_status != 5
                    AND e.back_office_status != 6)
                UNION
                (SELECT e.event_id, efa.file_name, efa.attachment_type, efa.status, e.title, e.city_location, e.location, e.event_type_id, et.event_type, e.author, e.date_created, e.description, e.rate, e.start_date_time, e.end_date_time, e.total_available_seat, e.seats_per_subscriber, e.quota_waiting_list_seat, e.for_invitation, e.reinvitation_after, e.reservation_start_date, e.remaining_seat, e.event_status, e.back_office_status, e.display_status
                FROM event e
                    JOIN event_type et ON e.event_type_id = et.event_type_id
                    JOIN event_file_attachment efa ON e.event_id = efa.event_id
                WHERE efa.status = 1
                    AND efa.attachment_type = 1
                    AND e.back_office_status = 4)) t,  (SELECT @rownum := 0) r
            ORDER BY display_status DESC, start_date_time ASC
        ");

        foreach($query->result() as $row){
            if($row->event_id == $event_id){
                return ceil($row->row_number/6);
            }
        }
    }

    public function event_details($event_id){
        $attachment_type = $this->event_details_attachment_type($event_id);
        $query = $this->db->select("e.event_id, efa.file_name AS event_picture, efa.mime_type, efa.attachment_type, e.title, efa.status, e.city_location, ecl.city AS event_venue, e.location AS event_place_name, e.event_type_id, et.event_type, e.author, e.code_postal AS postal_code, e.address AS event_address, e.city_name AS event_city_name, e.date_created, e.description, es.rate AS event_rate, es.start_date_time, es.end_date_time, es.total_available_seat, es.seats_per_subscriber, es.quota_waiting_list_seat, es.reservation_start_date, es.remaining_seat, es.event_status, es.back_office_status")
            ->select("DATE_FORMAT(es.start_date_time, '%e/%m/%Y') AS start_date", FALSE)
            ->select("DATE_FORMAT(es.end_date_time, '%e/%m/%Y') AS end_date", FALSE)
            ->select("DAYNAME(es.start_date_time) AS day", FALSE)
            ->select("DATE_FORMAT(es.start_date_time, '%Hh%i') AS start_date_hour", FALSE)
            ->select("DATE_FORMAT(es.end_date_time, '%Hh%i') AS end_date_hour", FALSE)
            ->select("DATE_FORMAT(es.start_date_time, '%e') AS start_day", FALSE)
            ->select("DATE_FORMAT(es.end_date_time, '%e') AS end_day", FALSE)
            ->select("DATE_FORMAT(es.start_date_time, '%m') AS start_month", FALSE)
            ->select("DATE_FORMAT(es.end_date_time, '%M') AS end_month", FALSE)
            ->select("DATE_FORMAT(es.start_date_time, '%Y') AS start_year", FALSE)
            ->select("DATE_FORMAT(es.end_date_time, '%Y') AS end_year", FALSE)
            ->select("DATE_FORMAT(es.start_date_time, '%e %M %Y') AS start_date_day", FALSE)
            ->select("DATE_FORMAT(es.start_date_time, '%e %M') AS start_date_month", FALSE)
            ->select("DATE_FORMAT(es.end_date_time, '%e %M') AS end_date_month", FALSE)
            ->select("DATE_FORMAT(es.start_date_time, '%M') AS event_start_month_name", FALSE)
            ->from("event_schedule es")
            ->join("event e", "e.event_id = es.event_id", "left")
            ->join('event_city_location ecl', 'e.city_location=ecl.city_location_id')
            ->join('event_type et', 'e.event_type_id=et.event_type_id')
            ->join('event_file_attachment efa', 'e.event_id=efa.event_id')
            ->where('es.event_id', $event_id)
            ->where('efa.status !=', 0)
            ->where('efa.attachment_type', $attachment_type)
            ->where('e.back_office_status !=', 0)
            ->where('es.back_office_status !=', 5)
            ->where('es.back_office_status !=', 6)
            ->get();
        return $query->row();
    }
    public function event_timedate($event_id){
        $attachment_type = $this->event_details_attachment_type($event_id);
        $query = $this->db->select("e.event_id, efa.file_name AS event_picture, efa.mime_type, efa.attachment_type, e.title, efa.status, e.city_location, ecl.city AS event_venue, e.location AS event_place_name, e.event_type_id, et.event_type, e.author, e.code_postal AS postal_code, e.address AS event_address, e.city_name AS event_city_name, e.date_created, e.description, es.rate AS event_rate, es.start_date_time, es.end_date_time, es.total_available_seat, es.seats_per_subscriber, es.quota_waiting_list_seat, es.reservation_start_date, es.remaining_seat, es.event_status, es.back_office_status")
            ->select("DATE_FORMAT(es.start_date_time, '%e/%m/%Y') AS start_date", FALSE)
            ->select("DATE_FORMAT(es.end_date_time, '%e/%m/%Y') AS end_date", FALSE)
            ->select("DAYNAME(es.start_date_time) AS day", FALSE)
            ->select("DATE_FORMAT(es.start_date_time, '%Hh%i') AS start_date_hour", FALSE)
            ->select("DATE_FORMAT(es.end_date_time, '%Hh%i') AS end_date_hour", FALSE)
            ->select("DATE_FORMAT(es.start_date_time, '%e') AS start_day", FALSE)
            ->select("DATE_FORMAT(es.end_date_time, '%e') AS end_day", FALSE)
            ->select("DATE_FORMAT(es.start_date_time, '%m') AS start_month", FALSE)
            ->select("DATE_FORMAT(es.end_date_time, '%M') AS end_month", FALSE)
            ->select("DATE_FORMAT(es.start_date_time, '%Y') AS start_year", FALSE)
            ->select("DATE_FORMAT(es.end_date_time, '%Y') AS end_year", FALSE)
            ->select("DATE_FORMAT(es.start_date_time, '%e %M %Y') AS start_date_day", FALSE)
            ->select("DATE_FORMAT(es.start_date_time, '%e %M') AS start_date_month", FALSE)
            ->select("DATE_FORMAT(es.end_date_time, '%e %M') AS end_date_month", FALSE)
            ->select("DATE_FORMAT(es.start_date_time, '%M') AS event_start_month_name", FALSE)
            ->from("event_schedule es")
            ->join("event e", "e.event_id = es.event_id", "left")
            ->join('event_city_location ecl', 'e.city_location=ecl.city_location_id')
            ->join('event_type et', 'e.event_type_id=et.event_type_id')
            ->join('event_file_attachment efa', 'e.event_id=efa.event_id')
            ->where('es.event_id', $event_id)
            ->where('efa.status !=', 0)
            ->where('efa.attachment_type', $attachment_type)
            ->where('e.back_office_status !=', 0)
            ->where('es.back_office_status !=', 5)
            ->where('es.back_office_status !=', 6)
            ->get();
        return $query->result();
    }

    public function event_details_email($event_schedule_id){
        $query = $this->db->select("e.event_id,
                es.event_schedule_id,
                e.title as event_title,
                es.event_status,
                et.event_type,
                ecl.city as city,
                (CASE WHEN e.location IS NULL THEN \"\" ELSE e.location END) as event_place_name,
                (CASE WHEN e.address IS NULL THEN \"\" ELSE e.address END) as event_address,
                (CASE WHEN e.code_postal IS NULL THEN \"\" ELSE e.code_postal END) as event_postal_code,
                es.rate as event_rate,
                ecl.city as event_venue,
                efa.file_name as event_picture,
                e.description as event_description,
                es.start_date_time as event_start_date")
            ->select("DAYNAME(es.start_date_time) AS event_start_day_name", FALSE)
            ->select("DATE_FORMAT(es.start_date_time, '%e') AS event_start_day", FALSE)
            ->select("DATE_FORMAT(es.start_date_time, '%m') AS event_start_month", FALSE)
            ->select("DATE_FORMAT(es.start_date_time, '%M') AS event_start_month_name", FALSE)
            ->select("DATE_FORMAT(es.start_date_time, '%Hh%i') AS event_start_hour", FALSE)
            ->select("DATE_FORMAT(es.start_date_time, '%Y') AS event_start_year", FALSE)
            ->from('event_schedule es')
            ->join("event e", "e.event_id = es.event_id", "left")
            ->join('event_city_location ecl', 'e.city_location=ecl.city_location_id')
            ->join('event_type et', 'e.event_type_id=et.event_type_id')
            ->join('event_file_attachment efa', 'e.event_id=efa.event_id')
            ->where('es.event_schedule_id', $event_schedule_id)
            ->where('efa.status !=', 0)
            ->where('efa.attachment_type', 1)
            ->where('es.back_office_status !=', 0)
            ->where('es.back_office_status !=', 5)
            ->where('es.back_office_status !=', 6)
            ->get();
        return $query->row();
    }

    public function event_details_attachment_type($event_id){
        $query = $this->db->select('*')
            ->from('event_file_attachment')
            ->where('event_id', $event_id)
            ->where('attachment_type', 2)
            ->where('status !=', 0)
            ->get()
            ->row();

        if($query) return 2;
        else return 1;
    }

    public function current_event($event_id){
        $query = $this->db->select('*')
            ->from('event')
            ->where('event_id', $event_id)
            ->get()
            ->row();

        return $query;
    }

    public function save_link_to_cookie($event_id){
        $query = $this->db->select('event_type_id')
            ->from('event')
            ->where('event_id', $event_id)
            ->get()
            ->row();

        return $query->event_type_id;
    }

    public function preview_event($event_id){
        $this->db->select("description, title" );
        $this->db->from("event");
        $this->db->where("back_office_status !=", 6);
        $this->db->where("event_id", $event_id);
        $this->db->limit(1);
        $result = $this->db->get()->result();
        return $result;
    }

    public function event_information($event_id){
        $this->db->select("e.*");
            // ->select("DATE_FORMAT(efa.date_added, '%e/%m/%Y %Hh%i') AS date_added", FALSE);
        $this->db->from("event e");
        // $this->db->join("event_file_attachment efa", "efa.event_id = e.event_id AND efa.status = 1", "left");
        $this->db->where("e.status !=", 0);
        $this->db->where("e.event_id", $event_id);
        $this->db->limit(1);
        $result = $this->db->get()->row();

        return $result;
    }

    public function check_event_title($event_title, $event_id=""){
        if($event_id != ""){
            $this->db->where("event_id !=", $event_id);
        }
        $this->db->where("title", $event_title);
        $this->db->where("back_office_status !=", 6); //not deleted ones
        return $this->db->get("event")->num_rows();
    }

    public function add_event($user_id, $event_data){
        //add remaining values
        $event_data["author"] = $user_id;
        if(sizeof($event_data)){
            $this->db->insert("event", $event_data);
            if($this->db->affected_rows()){
                return $this->db->insert_id();
            }

            return false;
        }
        return false;
    }

    public function update_event($user_id, $event_data, $event_id){
        //add remaining values
        $event_data["author"] = $user_id;
        if($event_data["back_office_status"] == 4){
            $event_data["display_status"] = 0;
        } else {
            $event_data["display_status"] = 1;
        }
        //changing status
        if(isset($event_data["total_available_seat"]) && $event_data["back_office_status"] != 0) {
            // $event_data["remaining_seat"] = $event_data["total_available_seat"];
            if($event_data["total_available_seat"] <= 0 && $event_data["quota_waiting_list_seat"] <= 0){
                if($event_data["back_office_status"] == 0) {
                    $event_data["back_office_status"] = 0;
                    $event_data["event_status"] = "AVAILABLE";
                } else if($event_data["start_date_time"] != "") {
                    if (strtotime(date("Y-m-d H:i:s")) > strtotime(date($event_data["start_date_time"]))) {
                        if(!in_array($event_data["back_office_status"], array(5,0))) { //not yet archived/encours
                            $event_data["back_office_status"] = 4;
                            $event_data["display_status"] = 0; //closed event
                        }
                    } else {
                        $event_data["back_office_status"] = 3; //locked event
                    }
                }else if($event_data["end_date_time"] != ""){
                    if (strtotime(date("Y-m-d H:i:s")) > strtotime(date($event_data["end_date_time"]))) {
                        if(!in_array($event_data["back_office_status"], array(5,0))) { //not yet archived/encours
                            $event_data["back_office_status"] = 4;
                            $event_data["display_status"] = 0; //closed event
                        }
                    } else {
                        $event_data["back_office_status"] = 3; //locked event
                    }
                }
            } else if($event_data["total_available_seat"] <= 0 && $event_data["quota_waiting_list_seat"] > 0){ 
                $event_data["back_office_status"] = 2;
                $event_data["event_status"] = "AVAILABLE";
            } else if($event_data["total_available_seat"] > 0) {
                if(in_array($event_data["back_office_status"], array(3,4))) {
                    $event_data["back_office_status"] = 2; //open event
                }
            }

            // for bug # 16425 : update the total available seats once the remaining seats gets higher than the original avaliable ones.
            // if($event_data["total_available_seat"] > $event_data["rem_seats"]) {
            //     // this happens when lemonde employee added seats to remaining seats/avl. seats
            //     $added_seats = $event_data["total_available_seat"] - $event_data["rem_seats"];
            //     $event_data["total_available_seat"] = $event_data["avl_seats"] + $added_seats;
            // } else {
            //     unset($event_data["total_available_seat"]);
            // }
            if($event_data["total_available_seat"] > $event_data["avl_seats"]) {
                // this happens when lemonde employee added seats to remaining seats/avl. seats
                if($event_data["rem_seats"] <= 0){ 
                    $event_data["event_status"] = "AVAILABLE";
                    $event_data["back_office_status"] = 2;
                }
                $added_seats = (($event_data["total_available_seat"] - $event_data["avl_seats"]) > 0)?($event_data["total_available_seat"] - $event_data["avl_seats"]):0;
                $event_data["remaining_seat"] = $event_data["rem_seats"] + $added_seats;
            } else {
                $removed_seats = (($event_data["avl_seats"] - $event_data["total_available_seat"]) > 0)?($event_data["avl_seats"] - $event_data["total_available_seat"]):0;
                $event_data["remaining_seat"] = (($event_data["rem_seats"] - $removed_seats) <=0)?0:($event_data["rem_seats"] - $removed_seats);
                if($event_data["remaining_seat"] <= 0){ 
                    // if($event_data["back_office_status"] != 0){
                    $event_data["event_status"] = "FULL";
                    if($event_data["back_office_status"] >= 4) {
                        $this->defer_sending_of_on_queue_emails($event_id);
                    }
                    // }
                }
            }
            // unset($event_data["avl_seats"], $event_data["rem_seats"]);
        }
        unset($event_data["avl_seats"], $event_data["rem_seats"]);
        //checking for past event
        $event_data["back_office_status"] = $this->recheck_bo_status($event_data);
        if($event_data["back_office_status"] >= 4) {
            $event_data["display_status"] = 0;
            $this->defer_sending_of_on_queue_emails($event_id);
        }

        if(sizeof($event_data)){
            // $event_data["seats_per_subscriber"] = $event_data["quota_number_of_guest"];
            // minus one to the quota_number_of_guest to exclude the subscriber from the counting
            // $event_data["quota_number_of_guest"] = ($event_data["quota_number_of_guest"] > 0)?$event_data["quota_number_of_guest"]-1:$event_data["quota_number_of_guest"];

            $this->db->where("event_id", $event_id);
            $update = $this->db->update("event", $event_data);
            if($update){
                return true;
            }
            return false;
        }
        return false;
    }

    public function delete_event($event_id){
        $this->db->where("event_id", $event_id);
        $update = $this->db->update("event", array("status" => 0));
        //update also all event schedule status to deleted
        $this->db->where("event_id", $event_id);
        $this->db->update("event_schedule", array("back_office_status" => 6));
        return $update;
    }

    private function defer_sending_of_on_queue_emails($event_id){
        $this->db->where("event_id", $event_id);
        $this->db->where_in("email_status", array(0,2,3));
        $this->db->update("event_email_recipient", array("email_status" => 5, "email_date_time" => date('Y-m-d H:i:s')));

        //email schedules must be set to pass
        $this->db->where("event_id", $event_id);
        $this->db->where_in("email_schedule_status", array(1));
        $this->db->update("event_email_schedule", array("email_schedule_status" => 2, "email_schedule_date_added" => date('Y-m-d H:i:s')));
    }

    private function recheck_bo_status($event_data){
        //checking for past event
        if($event_data["start_date_time"] != "") {
            if (strtotime(date("Y-m-d H:i:s")) > strtotime(date($event_data["start_date_time"]))) {
                if(!in_array($event_data["back_office_status"], array(5,0))) { //not yet archived/encours
                    return 4; //closed event
                }
            }
        }else if($event_data["end_date_time"] != ""){
            if (strtotime(date("Y-m-d H:i:s")) > strtotime(date($event_data["end_date_time"]))) {
                if(!in_array($event_data["back_office_status"], array(5,0))) { //not yet archived/encours
                    return 4; //closed event
                }
            }
        }

        return $event_data["back_office_status"];
    }

    public function edit_display_status(){
        $query = $this->db->select('*')
            ->from('event')
            ->get();

        $result = $query->result();
        foreach($result as $row){
            $this->db->where("event_id", $row->event_id);
            if($row->back_office_status == 4) $this->db->update("event", array("display_status" => 0));
            else $this->db->update("event", array("display_status" => 1));
        }
    }

    public function check_bo_status($event_id)
    {
        $query = $this->db->select('seats_per_subscriber, back_office_status')
            ->from('event_schedule')
            ->where('event_id', $event_id)
            ->get()
            ->row();

        if($query->seats_per_subscriber == 0){
            if(!in_array($query->back_office_status, array(0,4))) return 3; // Closed event due to 0 quota per sub            
        }
        
        return $query->back_office_status;
    }

    public function check_event_status($event_id)
    {
        $query = $this->db->select('event_status')
            ->from('event')
            ->where('event_id', $event_id)
            ->get()
            ->row();

        return $query->event_status;
    }

    public function check_seats($event_id)
    {
        $query = $this->db->select('*')
            ->from('event_schedule')
            ->where('event_id', $event_id)
            ->get()
            ->row();
           // return 1;

        if($query->seats_per_subscriber == 0) return 0; // Full
        if($query->remaining_seat > 0){
            return 1; // Book
        } 
        else {
            if($query->quota_waiting_list_seat > 0) return 2; // Book in Waitlist
            else return 0; // Full
       }
    }

    public function check_availability($event_id, $seats_reserved)
    {
        $query = $this->db->select('*')
            ->from('event')
            ->where('event_id', $event_id)
            ->get();

        $row = $query->row();
        if($row->back_office_status == 4) return 4; // Closed
        if($row->remaining_seat >= $seats_reserved) return 1; // Reserver
        else{
            $status = $this->check_waiting_list($event_id, $seats_reserved);
            if($status == 1) return 2; // Reserver or Book on waiting list
            else return 3; // Event Full
        }
    }

    public function check_waiting_list($event_id, $seats_reserved){
        $query = $this->db->select('quota_waiting_list_seat')
            ->from('event')
            ->where('event_id', $event_id)
            ->get()
            ->row();

        if($query->quota_waiting_list_seat >= $seats_reserved) return 1; // There are still seats on the waiting list
        else return 0; // Event Full
    }

    public function check_availability2($event_id)
    {
        $query = $this->db->select('*')
            ->from('event')
            ->where('event_id', $event_id)
            ->get();

        $row = $query->row();
        if($row->back_office_status == 4) return 4; // Closed
        if($row->remaining_seat > 0) return 1; // Reserver
        else{
            $status = $this->check_waiting_list2($event_id);
            if($status == 1) return 2; // Reserver or Book on waiting list
            else return 3; // Event Full
        }
    }

    public function check_waiting_list2($event_id){
        $query = $this->db->select('quota_waiting_list_seat')
            ->from('event')
            ->where('event_id', $event_id)
            ->get()
            ->row();

        if($query->quota_waiting_list_seat > 0) return 1; // There are still seats on the waiting list
        else return 0; // Event Full
    }

    public function check_closed_event($event_id)
    {
        $query = $this->db->select('back_office_status')
            ->from('event')
            ->where('event_id', $event_id)
            ->get()
            ->row();

        if($query->back_office_status == 4) return 0; // Event Closed
        else return 1; // Event Available
    }

    public function update_remaining_seats($event_id)
    {
        $query = $this->db->select('remaining_seat')
            ->from('event')
            ->where('event_id', $event_id)
            ->get()
            ->row();
        return $query->remaining_seat;
    }

    public function open_events(){
        //select and insert to event_log table all the events which are about to be opened
        $this->db->query("INSERT INTO event_log(event_schedule_id, type) SELECT event_schedule_id, 2 FROM event_schedule WHERE reservation_start_date <= CURRENT_TIMESTAMP AND back_office_status IN(1)");
        //then, update their statuses
        $this->db->where("reservation_start_date <= CURRENT_TIMESTAMP");
        $this->db->where("back_office_status", 1);
        $this->db->update("event_schedule", array("back_office_status" => 2, "display_status" => 1));
        return $this->db->affected_rows();
    }

    public function close_events() {
        //select and insert to event_log table all the events which are about to be closed
        //defer sending of onqueue emails
        $this->db->query("UPDATE event_email_recipient eer SET eer.email_status = 5, eer.email_date_time = CURRENT_TIMESTAMP WHERE eer.email_status IN(0,2,3)
        AND eer.event_schedule_id IN(SELECT event_schedule_id FROM event_schedule WHERE start_date_time <= CURRENT_TIMESTAMP AND back_office_status IN(1,2,3))");

        //email sending schedules must be set to pass
        $this->db->query("UPDATE event_email_schedule ees SET ees.email_schedule_status = 2, ees.email_schedule_date_added = CURRENT_TIMESTAMP WHERE ees.email_schedule_status IN(1)
        AND ees.event_schedule_id IN(SELECT event_schedule_id FROM event_schedule WHERE start_date_time <= CURRENT_TIMESTAMP AND back_office_status IN(1,2,3))");

        $this->db->query("INSERT INTO event_log(event_schedule_id) SELECT event_schedule_id FROM event_schedule WHERE start_date_time <= CURRENT_TIMESTAMP AND back_office_status IN(1,2,3)");
        //then, update their statuses
        $this->db->where("start_date_time <= CURRENT_TIMESTAMP");
        $this->db->where_in("back_office_status", array(1,2,3));
        $this->db->update("event_schedule", array("back_office_status" => 4, "display_status" => 0));
        return $this->db->affected_rows();
    }

    public function list_events_for_typeahead($search){
        $this->db->select("event_id, title AS name")
            ->select("DATE_FORMAT(reservation_start_date, '%e/%m/%Y %Hh%m') AS reservation", FALSE);
        $this->db->where_in("back_office_status",array(1,2,3,4,5));
        $this->db->limit(10);
        $this->db->like("title", $search);
        $this->db->order_by("event_id", "desc");
        return $this->db->get("event")->result();
    }

    public function reopen_event($event_schedule_id){
        //insert to event log before reopening an event
        $this->db->query("INSERT INTO event_log(event_schedule_id, type) VALUES(".$event_schedule_id.", 3)");
        //re-open an event
        $this->db->where("event_schedule_id", $event_schedule_id);
        $this->db->update("event_schedule", array("back_office_status" => 2, "display_status" => 1));
    }

    public function get_events_for_waitinglist_email (){ //get_events_with_free_places
        $result = $this->db->query("SELECT
            es.event_id, es.event_schedule_id, es.remaining_seat, es.start_date_time, es.end_date_time,
            ewl.wait_list_id,
            (
                 SELECT 
                    ees.email_schedule_id 
                 FROM event_email_schedule ees
                 LEFT JOIN `event_email_default_setting` eeds 
                      ON `eeds`.`email_tpl_setting_id` = `ees`.`reference` 
                      AND eeds.email_type_id = 2
                 WHERE ees.event_schedule_id = ewl.event_schedule_id 
                 AND ees.email_schedule_status=1
                 AND eeds.email_tpl_setting_status= 1
                 ORDER BY ees.email_schedule_id DESC LIMIT 1
             ) AS email_schedule_id

            FROM event_wait_list ewl
            LEFT JOIN event_schedule es ON es.event_schedule_id = ewl.event_schedule_id
            LEFT JOIN event e ON e.event_id = es.event_id
            WHERE es.remaining_seat > 0
            AND es.event_status = 'AVAILABLE'
            AND e.use_email_template = 1
            AND ewl.status = 1
            AND es.back_office_status IN (2, 3)
            AND es.start_date_time > NOW()
            AND ewl.wait_list_id NOT IN(SELECT eer.reference_id 
                 FROM event_email_recipient eer
                 WHERE 
                 eer.event_schedule_id = ewl.event_schedule_id 
                 AND eer.email_status != 5 
                 AND eer.reference_id IS NOT NULL
                 AND eer.email_type_id = 2 
                 /*AND (CASE
                    WHEN eer.email_sched_reference = 1
                    THEN 
                        (SELECT eeds.email_type_id
                        FROM event_email_schedule ees
                        LEFT JOIN `event_email_default_setting` eeds 
                          ON `eeds`.`email_tpl_setting_id` = `ees`.`reference` 
                          AND eeds.email_type_id = 2
                        WHERE ees.email_schedule_id = eer.email_sched_reference_id
                          AND ees.event_schedule_id = ewl.event_schedule_id
                          AND ees.email_schedule_status= 1
                        LIMIT 1)
                    WHEN eer.email_sched_reference = 2
                    THEN
                        (SELECT eeds.email_type_id
                        FROM event_email_default_setting eeds
                        WHERE eeds.email_tpl_setting_id = eer.email_sched_reference_id
                          AND eeds.email_tpl_setting_status= 1
                          AND eeds.email_type_id = 2
                        LIMIT 1)
                END) = 2*/
                GROUP BY eer.reference_id)
            ")->result();
        return $result;
    }

    public function get_events_for_reminder_email(){
        return $this->db->query("SELECT
            es.event_schedule_id, es.event_id, es.start_date_time
            FROM event_registration er
            LEFT JOIN event_schedule es ON es.event_schedule_id = er.event_schedule_id
            LEFT JOIN event e ON e.event_id = es.event_id AND e.use_email_template = 1
            WHERE er.status = 1
            AND es.back_office_status IN (2, 3)
            AND es.start_date_time > NOW()
            AND e.use_email_template = 1
            AND er.registration_id 
            NOT IN(SELECT eer.reference_id
              FROM event_email_recipient eer
              WHERE eer.event_schedule_id = er.event_schedule_id
              AND eer.email_status !=5 
              AND eer.reference_id IS NOT NULL
              AND eer.email_type_id = 1 
                )
            GROUP BY er.event_schedule_id")->result();
    }
}