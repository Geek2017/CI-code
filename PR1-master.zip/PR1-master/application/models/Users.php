<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Model {

    protected $table = 'accounts';
    protected $table_user = 'users';

    function __construct()
    {
        parent::__construct();
    }
    public function get_user_info($data)
    {
        $query = $this->db->where( $data )
                        ->get($this->table)
                        ;
        return $query;
    }
    public function get_table_user($data){
        $query = $this->db->where( $data )
                ->get($this->table_user)
        ;
        return $query->num_rows() > 0 ? $query : false;

    }
    public function get_user_info_data($data)
    {
        $query = $this->db->where( $data )
                            ->join($this->table_user,'users.user_id = accounts.id')
                            ->get($this->table)
        ;
        return $query;
    }
    public function update_user_info($data, $user_id = null){
        $user_id = $user_id ? $user_id : $this->session->userdata('id') ;
        $query = $this->db->where('id', $user_id )
                        ->update($this->table, $data);
        return $query ? true : false;
    }
    public function get_full_name($user_id, $flag = null)
    {
        $query = $this->db->where('user_id', $user_id)
                            ->get($this->table_user);
        if($query->num_rows() > 0 ) {
            $query = $query->row();
            if($flag)
                return $query->lastname . ', ' . $query->firstname;
            else
                return $query->firstname . ' ' . $query->lastname;
        }
        return false;
    }
    public function with_referent($user_id = null)
    {
        $user_id = $user_id ? $user_id : $this->session->userdata('id') ;
        if($user = $this->get_user_info(['id'=>$user_id])->row()){
            return $user->with_referent;
        }
        return false;
    }
    public function check_email_existing($email, $email_2 = null)
    {
        $query = $this->get_user_info(['username'=>$email]);
        if($email_2)
            return $email == $email_2 ? false : ( $query->num_rows() ? true : false );
        else
            return $query->num_rows() ? true : false;
    }
    public function check_useradd_limit()
    {
        if($org = $this->backoffices->get_company($this->session->userdata('org'))->get()->row()){
            $get_org_users = $this->backoffices->guest_account_by_org($this->session->userdata('org'));
            if($this->session->userdata('role') == ADMIN && $get_org_users->get()->num_rows() >= $org->max_users)
                return 3;
        }
        return false;
    }

    public function add_update_guest_user($user_id = null)
    {
        $username = $this->input->post('email');
        if(!$user_id) {
            if($this->check_useradd_limit() === 3){
                return 3;
            }
            $account_data = [
                'username' => $username,
                'ord_id' => $this->session->userdata('org'),
                'role_id' => USERS,
                'date_created' => date('Y-m-d H:i:s'),
                'active' => "0"
            ];
            $account_query = $this->db->insert($this->table, $account_data);
            $last_id = $this->db->insert_id();
        }else{
            $account_query = $this->update_user_info(['username' => $username],$user_id);
            $last_id = $user_id;
        }
//if($this->input->post('firstname') || $this->input->post('lastname') || $this->input->post('company') || $this->input->post('position')){
           //$user_table = $this->get_table_user(['user_id'=>$last_id]);
            if( $user_id == null ) {
                $user_data = [
                    'user_id' => $last_id,
                    'firstname' => $this->input->post('firstname'),
                    'lastname'  => $this->input->post('lastname'),
                    'company'   => $this->input->post('company'),
                    'position'  => $this->input->post('position')
                ];
                $this->db->insert($this->table_user, $user_data);
            }else{
                $this->db->where('user_id', $user_id )
                    ->update($this->table_user,
                        [
                            'firstname' => $this->input->post('firstname'),
                            'lastname' => $this->input->post('lastname'),
                            'company'   => $this->input->post('company'),
                            'position'  => $this->input->post('position')
                        ]);
            }
//}
        return $account_query ? ( $user_id ? 2 : 1 ): false;
    }
    public function warn_user($interval, $warning, $flag = null)
    {
        $f_days = $this->logs->get_last_interval($interval, $warning);
        $warning = $warning + 1;
        if($f_days->num_rows() > 0 ){
            foreach($f_days->result() as $user){
                if(!$this->user_done($user->user_id)) {
                    if($flag){
                        if($user->warning == 0)
                            $this->update_user_info(['active' => "0"], $user->user_id);
                    }else {
                        $this->update_user_info(['warning' => (string)$warning], $user->user_id);
                        $this->globalmodel->send_email(
                            $this->globalmodel->akeen_mail(),
                            $user->username,
                            "Akeen - Warning",
                            "<p>Bonjour</p>" .
                            "<p>nous constatons que vous ne vous êtes pas connecté sur notre plateforme depuis plus de " . $interval . " jours, ce qui est dommage car ce parcours nécessite de garder un certain rythme. Nous ne pouvons que vous encourager à vous reconnecter afin d'avancer sur votre projet professionnel interne qui vous tient à cœur.</p>" .
                            "<p></p>" .
                            "<p>Bien à vous</p>" .
                            "<p>L'administrateur de la plateforme</p>"

                        );
                    }
                }
            }
        }
    }
    public function user_done($id)
    {
        $percentage = [];
        for($i = 1; $i <= $this->questions->count_this('allsection_floor'); $i++) {
            $percentage[] = $this->questions->getPercentage_($i, $id);
        }
        if(array_key_exists($this->questions->count_this('allsection_floor') - 1 ,$percentage) && $percentage[$this->questions->count_this('allsection_floor') - 1] == 100)
            return true;
        else
            return false;
    }

}


