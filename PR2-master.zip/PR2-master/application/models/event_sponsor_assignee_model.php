<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 
	
class Event_sponsor_assignee_model extends CI_Model {

    var $column_order = array('esa.date_added','esa.sponsor_assignee_id','es.sponsor_id',null); //set column field database for datatable orderable
    var $column_search = array('es.sponsor'); //set column field database for datatable searchable just firstname , lastname , address are searchable
    var $order = array('esa.sponsor_assignee_id' => 'desc'); // default order

    public function __construct() {
        parent::__construct();
    }

    private function _get_datatables_query($data_source, $event_id){
        $this->db->select("
            esa.sponsor_assignee_id,
            esa.sponsor_id,
            esa.event_id,
            es.sponsor_name,
            es.file as file_name,
            es.file_size")
            ->select("(CASE
                  WHEN esa.added_by IS NULL THEN 'Unknown'
                  ELSE (SELECT CONCAT(first_name,' ',last_name) as added_by FROM user WHERE user_id = esa.added_by)
                END) AS added_by", FALSE)
            ->select("DATE_FORMAT(esa.date_added, '%d/%m/%Y %Hh%i') AS date_added", FALSE)
            ->from("event_sponsor_assignee esa")
            ->join('event_sponsor es', 'es.sponsor_id = esa.sponsor_id', 'left')
            ->where("esa.event_id", $event_id)
            ->where("esa.status", 1)
            ->where("es.status", 1);

        $i = 0;
        foreach ($this->column_search as $item) {// loop column
            if ($data_source['search']['value']) {  // if datatable send POST for search
                if ($i === 0) { // first loop
                    $this->db->like($item, $data_source['search']['value']);
                } else {
                    $this->db->or_like($item, $data_source['search']['value']);
                }
            }
            $i++;
        }

        if(isset($data_source['order'])) { // here order processing
            if(isset($data_source['order']['0']['dir']) && !empty($data_source['order']['0']['dir'])) {
                $this->db->order_by($this->column_order[$data_source['order']['0']['column']], $data_source['order']['0']['dir']);
            }
        } else if(isset($this->order)) {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    public function get_events_list_export($data_source,$event_id){
        $this->_get_datatables_query($data_source, $event_id);
        $query = $this->db->get();
        $res = $query->result();
        return $res;
    }

    public function get_datatables($data_source, $event_id){
        $this->_get_datatables_query($data_source, $event_id);
        if($data_source['length'] != -1)
            $this->db->limit($data_source['length'], $data_source['start']);
        $query = $this->db->get();
        return $query->result();
    }

    public function count_filtered($data_source, $event_id){
        $this->_get_datatables_query($data_source, $event_id);
        $query = $this->db->get();
        return $query->num_rows();
    }

    public function count_all($data_source, $event_id){
        $this->_get_datatables_query($data_source, $event_id);
        return $this->db->count_all_results();
    }

    public function add_event_sponsor_assignee($data){
        $this->db->insert("event_sponsor_assignee", $data);
        return $this->db->insert_id();
    }

    public function update_event_sponsor_assignee($sponsor_assignee_id=0, $data=array()){

        if($sponsor_assignee_id && sizeof($data) > 0){
            $this->db->update("event_sponsor_assignee", $data, array("sponsor_assignee_id" => $sponsor_assignee_id));
            $updated = $this->db->affected_rows();
            return $updated;
        } else {
            return false;
        }
    }

    public function delete_event_sponsor_assignee($sponsor_assignee_id=0){

        if($sponsor_assignee_id) {

            $this->db->where("sponsor_assignee_id", $sponsor_assignee_id);
            $this->db->update("event_sponsor_assignee", array("status" => 0));
            return $this->db->affected_rows();
        } else {
            return false;
        }
    }

    public function event_details($user_id, $event_id)
    {
        $query = $this->db->select('`event_sponsor_assignee`.`sponsor_assignee_id`, `event_sponsor_assignee`.`sponsor_id`, `event_sponsor`.`sponsor_name`, `event_sponsor`.`file`, `event_sponsor`.`status`, `event_sponsor_assignee`.`event_id`, `event_sponsor_assignee`.`status`')
            ->from('event_sponsor_assignee')
            ->join('event_sponsor', 'event_sponsor.sponsor_id=event_sponsor_assignee.sponsor_id')
            ->where('event_sponsor_assignee.status', 1)
            ->where('event_sponsor.status', 1)
            ->where('event_sponsor_assignee.event_id', $event_id)
            ->get()
            ->result();

        return $query;
    }
}