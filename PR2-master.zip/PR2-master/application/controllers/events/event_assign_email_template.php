<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Event_assign_email_template extends MY_Controller {

    public function __construct()
    {
        //parent::__construct();
        $this->my_controller_parent_construct();
        $this->check_session_timed_out("bo");

        //load language files
        $this->load_language_backoffice();
        $this->lang->load('backoffice/events', 'fr');
        $this->lang->load('backoffice/events_template_schedule', 'fr');

        //load models
        $this->load->model("event_email_template_mapping_model");
        $this->load->model("event_email_template_mapping_by_event_schedule_model");
    }
    //update radio buttons for default event "YES or NO"
    public function update_set_default_template( $event_id = null )
    {
        return output_to_json($this, array( 
            'updated' => $this->event_email_template_mapping_model->update_set_default_templates( $event_id ) ,
            'mtype' => 'success',
            'message' => "success updated"

            ) );
    }
    //check radio buttons for default event email templates
    public function get_set_default_template( $event_id = null )
    {
        $result = $this->event_email_template_mapping_model->get_set_default_templates( $event_id );

        if( $result[0]->use_email_template > 0 )
           $arr = array( 'active' => true );
        else
           $arr = array( 'active' => false );

        return output_to_json($this, $arr );
    }
    public function remove_template_event_schedule($email_mapping_id, $type)
    {
        switch($type)
        {
            case 'events' :
                return output_to_json($this, array( 
                    'updated' => $this->event_email_template_mapping_model->remove_template_event_schedules( $email_mapping_id) ,
                    'mtype' => 'success',
                    'message' => "success updated"
                ));
                break;
            case 'schedule'  :
                return output_to_json($this, array( 
                    'updated' => $this->event_email_template_mapping_by_event_schedule_model->remove_template_event_schedules( $email_mapping_id) ,
                    'mtype' => 'success',
                    'message' => "success updated"
                ));
                break;
            default :
                echo "No action has been specified.";
                exit(0);
                break;
        };
    }
    //create autocomplete search to choose email templates
    public function search_by_template_id($email_type_id)
    {
        return output_to_json($this, $this->event_email_template_mapping_model->search_by_template_ids($email_type_id));
    }
    //insert or assign email templates for main event or event schedule(per date)
    public function assign_template_event_schedule($type)
    {
        switch($type)
        {
            case 'events' :
                return output_to_json($this, $this->event_email_template_mapping_model->assign_template_events() );
                break;
            case 'schedule'  :
                return output_to_json($this, $this->event_email_template_mapping_by_event_schedule_model->assign_template_events() );
                break;
            default :
                echo "No action has been specified.";
                exit(0);
                break;
        };
    }
    /*public function assign_email_template($type)
    {
        switch($type)
        {
            case 'events' :
                return output_to_json($this, $this->event_email_template_mapping_model->assign_template_events() );
                break;
            case 'schedule'  :
               
                break;
            default :
                echo "No action has been specified.";
                exit(0);
                break;
        };
    }
    */
    //create datatable and list of templates for events or event schedule
    public function by_event($event_id_schedule_id, $type)
    {
        switch($type)
        {
            case 'events' :
                return output_to_json($this, $this->event_email_template_mapping_model->get_table_event($event_id_schedule_id));
                break;
            case 'schedule'  :
                 return output_to_json($this, $this->event_email_template_mapping_by_event_schedule_model->get_table_event($event_id_schedule_id));
               break;

            default :
                echo "No action has been specified.";
                exit(0);
                break;
        };
    }
}