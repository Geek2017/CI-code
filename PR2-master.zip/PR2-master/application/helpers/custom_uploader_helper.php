<?php
function upload_event_files($type, $uploadedFile, $key=-1){
    $destination = origin_folders($type);
    if( (is_dir($destination) && is_writable($destination))) {
        //this happens when uploading an array of files, we need to get the exact file to be uploaded from the tray
        if($key>=0){
            $uploadedFile = array(
                "name" => $uploadedFile["name"][$key],
                "size" => $uploadedFile["size"][$key],
                "tmp_name" => $uploadedFile["tmp_name"][$key],
                "error" => $uploadedFile["error"][$key],
                "type" => $uploadedFile["type"][$key]
            );
        }
       
        if($type=="sponsors"){ //for sponsor pictures
	        $allowed_file_ext = array("jpeg", "gif", "jpg", "png");
	        $allowed_mime_types = array("image");
    	} else if($type=="events") { //for event attachments
    		$allowed_file_ext = array("mp3", "mp4", "png", "jpeg", "avi", "gif", "jpg");
            $allowed_mime_types = array("audio", "video", "image");
    	}

        $file_ext = end( explode(".", $uploadedFile["name"] ) );
        $rename = generate_random_keys(20).'.'.$file_ext;
        $dest_path = $destination.$rename;

        if ($uploadedFile['error'] !== UPLOAD_ERR_OK) {
            output_to_json($this, array(
                "mtype" => "error" , 
                "message" => $this->lang->line("upload_error_code") .$uploadedFile['error']
            ));
        } else if(!is_uploaded_file($uploadedFile['tmp_name'])) {
            output_to_json($this, array(
                "mtype" => "warning" , 
                "message" => "Possible file upload attack from : ".$uploadedFile['tmp_name']
            ));
        } else if(!in_array(strtolower($file_ext), $allowed_file_ext) || !in_array(current( explode("/",$uploadedFile['type'])), $allowed_mime_types)) {
            output_to_json($this, array(
                "mtype" => "warning" , 
                "message" => "The file you are uploading is not allowed!"
            ));
        } else if( move_uploaded_file($uploadedFile['tmp_name'], $dest_path) ) {
            return array( "file_name" =>  $rename, "file_size" => $uploadedFile['size'] ); //process upload
        } else {
            output_to_json($this, array(
                "mtype" => "error" , 
                "message" => "Upload failed! Try again later." 
            ));
        }
    } else {
        output_to_json($this, array(
            "mtype" => "warning" , 
            "message" => "Upload destination directory is not writtable." 
        ));
    }
}