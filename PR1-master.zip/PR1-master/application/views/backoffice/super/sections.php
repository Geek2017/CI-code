<div id="main">
    <div class="table-responsive">
<!--        <div id="tbl"><button type="button" class="btn btn-primary glyphicon glyphicon-plus" id="btnAdd"></button></div>-->
        <br><br>
        <table id="tbl_sections" class="table table-striped table-bordered" cellspacing="0" width="100%">
            <thead>
            <tr>
                <th>ID</th>
                <th>Titre</th>
                <th>Statut</th>
                <th>Actions</th>
            </tr>
            </thead>
        </table>
    </div>
</div>


<div class="modal fade in" id="modal_section">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">Contact dans le cadre d’un bilan de mobilité interne</h4>
            </div>
            <div class="modal-body">
                <form action="" method="POST" role="form" id="edit_section_form" class="section-form">
                    <input type="hidden" name="section_id" id="setion_id">
                    <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                            <div class="form-group-sm">
                                <label for="">Numéro de section</label>
                                <input type="text" class="form-control nxt txtboxNumberOnlyAmount"  name="section_number" id="section_number"  placeholder="" required>
                            </div>
                            <div class="form-group-sm">
                                <label for="">Titre</label>
                                <input type="text" class="form-control nxt"  name="section_title" id="section_title"  placeholder="" required>
                            </div>
                            <div class="form-group-sm">
                                <label for="">Description</label>
                                <textarea class="form-control nxt"  name="section_description" id="section_description"  placeholder="">
                                    </textarea>
                            </div>
                            <div class="form-group-sm">
                                <label for="">Objectifs</label>
                                <textarea class="form-control nxt"  name="section_obj" id="section_obj"  placeholder="">
                                    </textarea>
                            </div>
                            <div class="form-group-sm">
                                <label for="">Instructions</label>
                                <textarea class="form-control nxt"  name="section_ins" id="section_ins"  >
                                    </textarea>
                            </div>
                            <div class="form-group-sm">
                                <label for="">Durée</label>
                                <input type="text" class="form-control nxt numberOnly"  name="section_duration" id="section_duration"  required>
                            </div>
                            <div id="v_sec_upload" class="form-group-sm">
                                <label for="">Télécharger vidéo</label>
                                <input type="file" class="btn btn-primary  " id="upload_video" name="video_file"  accept="video/*">
                            </div>
                             <div id="v_sec_exist" class="form-group-sm">
                                <button class="btn btn-danger glyphicon glyphicon-remove" id="del_sec_video" name="del_sec_video" ></button>   <span id="v_filename"></span>
                            </div>
                            <div class="form-group-sm">
                                <label for="">Statut</label>
                                <select class="form-control nxt"  name="section_status" id="section_status"  required>
                                    <option value="1">Activée</option>
                                    <option value="0">Désactivée</option>
                                </select>
                            </div>
                    </div>


            </div>
            <div class="modal-footer">
                <button type="button" onclick="sections.submit_edit();" id="submit_edit_section" class="btn btn-primary nxt">Soumettre</button>
            </div>
            </form>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
