<!-- Page Content -->
<div class="container static">
    <div class="row">
        <div class="col-lg-10 col-lg-offset-1">
         <?php 
            if(isset($user_role)) {
            	if($this->session->userdata("lastname") != null){?>
                    <a class="align-left" href="<?php echo site_url('main/progress'); ?>"><img src="<?php echo base_url('assets/img/return.png'); ?>"/> Retour</a>
                        <?php } ?>
                             <?php
                        }else{
                            ?>
                          <a class="align-left" href="<?php echo site_url('main/'); ?>"><img src="<?php echo base_url('assets/img/return.png'); ?>"/> Retour</a>
                             <?php
                        }
                        ?>  
            <h1 class="text-center">Nous contacter </h1>
            <p>Vous souhaitez nous contacter pour des questions ou commentaires ? Cliquez ici.<p>
			<p><b>Par email :</b> service-client@akeen.fr</p>
			<p><b>Par t&#233;l&#233;phone :</b>  +33 (0)1 47 33 54 14 (de 10h &#224; 18h du lundi au vendredi) </p>
			<p><b>Par Skype :</b>  priscilla.magdelaine</p>
			<p><b>Notre adresse postale :</b></p>
			<p>AkeeN SAS<br>
			29 rue Bapst<br>
			92600 Asni&#232;res sur seine</p>
        </div>        
    </div>
</div>