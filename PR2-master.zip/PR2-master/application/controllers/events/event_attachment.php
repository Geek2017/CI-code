<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Event_attachment extends MY_Controller {

    public function __construct()
    {
        //parent::__construct();
        $this->my_controller_parent_construct();
        $this->check_session_timed_out("bo");
        //load language files
        $this->load_language_backoffice();
        $this->lang->load('backoffice/events', 'fr');
        //load model
        $this->load->model("user_activity_log_model");
        $this->load->model("event_file_attachment_model");
        $this->destination = origin_folders('events');
    }

    public function add_event_attachment($event_id=0){
        if(!empty($_FILES['uploadedFiles']) && $event_id && $this->input->post() && isset($this->data["logged_in"]["user_id"])){

            //files with errors
            $errors = array();
            
            foreach ($this->input->post("info") as $key=>$value) {

                $data = json_decode($value, true);
                $uploaded = upload_event_files("events",$_FILES['uploadedFiles'], $key);

                if( sizeof($uploaded) > 0 ) {

                    $audio_video = array();

                    //check for autoplay settings : catch if there is one
                    if( isset($data["file_setup"]["autoplay_vaudio"]) ){

                        $audio_video = array(
                            "autoplay_vaudio"   => $data["file_setup"]["autoplay_vaudio"],
                            "preview_default_image"   => (isset($data["file_setup"]["preview_default_image"]))?$data["file_setup"]["preview_default_image"]:0
                        );
                    }
                    
                    $add_status = $this->event_file_attachment_model->add_event_attachment(array(
                        "file_name" =>  $uploaded["file_name"],
                        "event_id"  =>  $event_id,
                        "mime_type" =>  $data["file_setup"]["mime_type"],
                        "description" =>  $data["file_setup"]["file_name"],
                        "attachment_type"   =>  $data["attachment_type"],
                        "file_size"         =>  $uploaded["file_size"],
                        "added_by"          =>  $this->data["logged_in"]["user_id"]
                    ), $audio_video);

                    if( !$add_status ) {
                        array_push($errors, array(
                            "file" => $data["file_setup"]["file_name"]
                        ));
                    }
                }
            } //end of loop

            if( sizeof($errors) <=0 ) {                        
                output_to_json($this, array(
                    "mtype"  => "success",
                    "message" => "File attachment has been added!"
                ));                    
            } else {
                output_to_json($this, array(
                    "mtype"  => "warning",
                    "mdata" => $errors,
                    "message" => "Some files were not uploaded."
                ));
            }

        } else {
            show_404();
        }
    }

    public function update_event_attachment($attachment_id=0){
        if(!empty($_FILES['uploadedFiles']) && !empty($attachment_id) && $this->input->post() && isset($this->data["logged_in"]["user_id"])){

            $uploaded = upload_event_files("events", $_FILES['uploadedFiles']);

            if( sizeof($uploaded) > 0 ) {

                $post = json_decode($this->input->post("info"), true);

                $audio_video = array();

                //check for autoplay settings : catch if there is one
                if( isset($post["file_setup"]["autoplay_vaudio"]) ){

                    $audio_video = array(
                        "autoplay_vaudio"   => $post["file_setup"]["autoplay_vaudio"],
                        "preview_default_image"   => (isset($post["file_setup"]["preview_default_image"]))?$post["file_setup"]["preview_default_image"]:0
                    );
                }

                $update_status = $this->event_file_attachment_model->update_event_attachment($attachment_id, array(
                    "file_name" =>  $uploaded["file_name"],
                    "mime_type" =>  $post["file_setup"]["mime_type"],
                    "description" =>  $post["file_setup"]["file_name"],
                    "attachment_type"   =>  $post["attachment_type"],
                    "file_size"         =>  $uploaded["file_size"],
                    "date_added"        =>  date('Y-m-d H:i:s'),
                    "added_by"          =>  $this->data["logged_in"]["user_id"]
                ), $audio_video );

                if( $update_status ) {

                    $original_file = $this->destination.$post["file_preview"];

                    if(file_exists($original_file)){
                        //delete original file
                        unlink_file($original_file);
                    }
                    output_to_json($this, array(
                        "mtype"  => "success",
                        "message" => "File attachment has been udpated!"
                    ));                    
                } else {
                    output_to_json($this, array(
                        "mtype"  => "error",
                        "message" => "Unable to update attachment!"
                    ));
                }
            }
        } else {
            show_404();
        }
    }

    public function delete_event_attachment($attachment_id=0){
        if(!empty($attachment_id) && $this->input->post() && isset($this->data["logged_in"]["user_id"])){

            $delete_status = $this->event_file_attachment_model->delete_event_attachment($attachment_id);

            if($delete_status){

                $original_file = $this->destination.$this->input->post("file_name");

                if( file_exists($original_file) ) {
                    //delete original file
                    unlink_file($original_file);
                }

                output_to_json($this, array(
                    "mtype"  => "success",
                    "message" => "Attachment has been deleted!"
                ));
            } else {
                output_to_json($this, array(
                    "mtype"  => "error",
                    "message" => "Unable to delete attachment!"
                ));
            }
        } else {
            show_404();
        }
    }

    public function list_event_attachment($event_id){
        if( $event_id && $this->input->post() && isset($this->data["logged_in"]["user_id"])){
            $this->load->model("event_file_attachment_model");

            $list = $this->event_file_attachment_model->get_datatables($this->input->post(), $event_id);
            $data = array();
            $row = array();
            $x = $this->input->post("start");
            foreach ($list as $attachment) {
                $row["attachment_id"] = (int)$attachment->attachment_id;
                $row["attachment_type"] = (int)$attachment->attachment_type;
                $row["file_preview"] = $attachment->file_name;
                $row["description"] = "File name : ".$attachment->description
                                      ."<br/>File size : ".number_format($attachment->file_size/(1024*1024), 2,'.','').'MB'
                                      ."<br/> Author : ".$attachment->added_by
                                      ."<br/> Date added : ".$attachment->date_added;
                // prepare file_setup data
                // $info = ($attachment->file_setup)?explode(",", $attachment->file_setup):false;
                $file_setup = array(
                    // "setup_id" => ($info)?$info[0]:"",
                    "mime_type" => $attachment->mime_type,
                    "file_name" => $attachment->file_name
                    // "autoplay_vaudio" => ($info)?$info[1]:"",
                    // "preview_default_image" => ($info)?$info[2]:""
                );
                $row["file_setup"] = $file_setup;
                array_push($data, $row);
            }
            $output = array(
                "draw" => $_POST['draw'],
                "recordsTotal" => $this->event_file_attachment_model->count_all($this->input->post(), $event_id),
                "recordsFiltered" => $this->event_file_attachment_model->count_filtered($this->input->post(), $event_id),
                "data" => $data,
            );
            //output to json format
            output_to_json($this, $output);
        } else {
            show_404();
        }
    }
}