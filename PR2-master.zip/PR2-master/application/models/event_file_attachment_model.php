<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 
    
class Event_file_attachment_model extends CI_Model {

    var $column_order = array(null, 'attachment_type'); //set column field database for datatable orderable
    var $column_search = array('description'); //set column field database for datatable searchable just firstname , lastname , address are searchable
    var $order = array('attachment_type' => 'asc'); // default order

    public function __construct() {
        parent::__construct();
    }

    private function _get_datatables_query($data_source, $event_id){
        $this->db->select("
            attachment_id,
            event_id,
            description,
            file_name,
            file_size,
            mime_type,
            attachment_type")
            ->select("(CASE
                  WHEN added_by IS NULL THEN 'Unknown'
                  ELSE (SELECT CONCAT(first_name,' ',last_name) as added_by FROM user WHERE user_id = added_by)
                END) AS added_by", FALSE)
            // ->select("(SELECT CONCAT(efas.setup_id,',',efas.autoplay_vaudio,',', efas.preview_default_image) as file_setup
            //      FROM event_file_attachment_setup efas
            //     WHERE efas.attachment_id = attachment_id
            // ) AS file_setup", FALSE)
            // ->select("(SELECT
            //     GROUP_CONCAT(CONCAT('{\"setup_id\":\"',efas.setup_id,
            //     '\", \"autoplay_vaudio\":\"',efas.autoplay_vaudio,
            //     '\", \"preview_default_image\":\"',efas.preview_default_image,'\"}'                
            // ) ORDER BY efas.attachment_id SEPARATOR ',') as file_setup
            //      FROM event_file_attachment_setup efas
            //     WHERE efas.attachment_id = attachment_id
            // ) AS file_setup", FALSE)
            ->select("DATE_FORMAT(date_added, '%d/%m/%Y %Hh%i') AS date_added", FALSE)
            ->from("event_file_attachment")
            ->where("event_id", $event_id)
            ->where("status", 1);

        $i = 0;
        foreach ($this->column_search as $item) {// loop column
            if ($data_source['search']['value']) {  // if datatable send POST for search
                if ($i === 0) { // first loop
                    $this->db->like($item, $data_source['search']['value']);
                } else {
                    $this->db->or_like($item, $data_source['search']['value']);
                }
            }
            $i++;
        }

        if(isset($data_source['order'])) { // here order processing
            if(isset($data_source['order']['0']['dir']) && !empty($data_source['order']['0']['dir'])) {
                $this->db->order_by($this->column_order[$data_source['order']['0']['column']], $data_source['order']['0']['dir']);
            }
        } else if(isset($this->order)) {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    public function get_events_list_export($data_source,$event_id){
        $this->_get_datatables_query($data_source, $event_id);
        $query = $this->db->get();
        $res = $query->result();
        return $res;
    }

    public function get_datatables($data_source, $event_id){
        $this->_get_datatables_query($data_source, $event_id);
        if($data_source['length'] != -1)
            $this->db->limit($data_source['length'], $data_source['start']);
        $query = $this->db->get();
        return $query->result();
    }

    public function count_filtered($data_source, $event_id){
        $this->_get_datatables_query($data_source, $event_id);
        $query = $this->db->get();
        return $query->num_rows();
    }

    public function count_all($data_source, $event_id){
        $this->_get_datatables_query($data_source, $event_id);
        return $this->db->count_all_results();
    }

    public function add_event_attachment($data, $audio_video=array()){

        $this->db->insert("event_file_attachment", $data);
        $attachment_id = $this->db->insert_id();

        if( $attachment_id ){
            //if there is audio or video setup, add an entry to table: event_file_attachment_setup
            if(sizeof($audio_video) > 0){
                $audio_video["attachment_id"] = $attachment_id;
                $this->db->insert("event_file_attachment_setup", $audio_video);
                return $this->db->insert_id();
            }
            return $attachment_id;
        }
        return false;
    }

    public function update_event_attachment($attachment_id=0, $data=array(), $audio_video=array()){

        if($attachment_id && sizeof($data) > 0){

            $this->db->where("attachment_id", $attachment_id);
            $this->db->update("event_file_attachment", $data);
            $updated = $this->db->affected_rows();

            //we need to update the file attachment setup 
            $this->update_file_attachment_setup($attachment_id, $audio_video);

            return $updated;
        } else {
            return false;
        }
    }

    private function update_file_attachment_setup($attachment_id, $audio_video =array()){
        
        $this->db->select("*");
        $this->db->where("attachment_id", $attachment_id);
        $result = $this->db->get("event_file_attachment_setup");
        
        if($result->num_rows() > 0) {
            if( sizeof($audio_video) >0 ) { 
                $this->db->where("attachment_id", $attachment_id);
                $this->db->update("event_file_attachment_setup", $audio_video);
            } else {
                //delete file attachment setup entry
                $this->db->where("attachment_id", $attachment_id);
                $this->db->delete("event_file_attachment_setup");
            }
        } else if( sizeof($audio_video) >0 ) {
            $audio_video["attachment_id"] = $attachment_id;
            $this->db->insert("event_file_attachment_setup", $audio_video);
        }
    }

    public function delete_event_attachment($attachment_id=0){

        if($attachment_id){

            $this->db->where("attachment_id", $attachment_id);
            $this->db->update("event_file_attachment", array("status" => 0));
            return $this->db->affected_rows();

        } else {
            return false;
        }
    }

}