<div class="fin_container">
    <div class="fin_msg">
        Nous vous remercions d’avoir réalisé ce parcours AkeeN sur notre plateforme
    </div>
    <div class="fin_btn_ctn">
        <a href="<?php echo ak_url().'main/my_profile' ?>">
            <button type="button" class="btn btn-primary btn-lg">Fin</button>
        </a>
    </div>
</div>