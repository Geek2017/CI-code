<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/* MY ACCOUNT PAGE */

// Labels
$lang["subscriber_number"] = "Numéro d'abonné";
$lang["location"] = "Localisation";
$lang["mailing_address"] = "Adresse postale";
$lang["city_postal_code"] = "Ville - Code Postale";
$lang["email_address"] = "Adresse e-mail";
$lang["phone"] = "Téléphone";
$lang["event_preferences"] = "Préférences d'événement";

// Update - Messages
$lang["location_updated"] = "Votre location a été mise à jour.";
$lang["mail_updated"] = "Votre adresse postale a été mise à jour.";
$lang["email_updated"] = "Votre adresse e-mail a été mise à jour.";
$lang["telephone_updated"] = "Votre téléphone a été mis à jour.";
$lang["mobile_updated"] = "Votre mobile a été mis à jour.";
$lang["preferences_updated"] = "Vos préférences ont été mises à jour.";
$lang["already_registered"] = "Vous êtes déjà inscrit";
$lang["already_cancelled"] = "Vous avez déjà annulé";
$lang["logged_on_another_device"] = "Vous mettez à jour ces informations avec un autre appareil.";
$lang["button_not_updated"] = "Le bouton n'est pas mis à jour!";
$lang["updated"] = "La mise jour à été effectuée sur un autre appareil";


// Error - Messages
$lang["preferences_error"] = "Choisissez au moins un événement";

// Buttons
$lang["edit"] = "Modifier";
