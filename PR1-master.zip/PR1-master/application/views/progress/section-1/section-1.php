<?php
    if(isset($dat) && count($dat) > 0){
        $data = (json_decode($dat));
        $rows = $data->total_rows;
        $answered = $data->answered;
    }else if( count($dat) < 1) {
        redirect('404');
    }else{
        $rows = 0;
        $answered = 0;
    }  ?>
<!-- Page Content -->
<input type="hidden" id="full_name" value="<?php echo $this->users->get_full_name($this->session->userdata('id'),1); ?>">
<div class="container-fluid sec-bg">
    <div class="s_section">
        <?php
        $view_page = stripos(current_url(),'view') > 0 ? 'view/' : '';
        if(isset($dat) || $c_section == true) {
            $data = (json_decode($dat)); ;
            if ($data->question == false) { ?>
                <h1><?php echo $data->section_title; ?></h1>
                <br>
                <?php if ($data->section_description != false): ?>
                    <?php echo $data->section_description?>
                    <br>
                <?php endif ?>
                <br>
                <?php if ($data->objectives != false): ?>
                    <p><strong>Objectifs</strong> : <?php echo $data->objectives; ?></p>
                    <br>
                <?php endif ?>
                <?php if ($data->instructions_start != false): ?>
                    <p><strong>Instructions</strong> : <?php echo $data->instructions_start; ?></p>
                    <br>
                <?php endif ?>
                <?php if ($data->duration_time != false): ?>
                    <p><strong>Durée : <?php echo $data->duration_time; ?> minutes </strong></p>
                    <br>
                <?php endif; ?>
                <?php
                $uploads = new Uploads();

                $file_def = $uploads->get_default_section_video($this->uri->segment(2));
                $file = json_decode($uploads->get_video($data->section->id,'section_video'));

                echo $file->video == 1 ? '<p class="text-center"><center><video controls="" id="section_video" style="display: inline-block;" src="'.($file->video == 1 ? base_url().'/uploads/video/section_video/'.$file->filename : '').'" width="640" height="480">Your browser does not support HTML5 video.</video></p>' : '<center><p lass="text-center">'.$file_def['filename'].'</p>';
                ?>
                <div class="pull-right sec-btn">
                <?php $percents = $percent[0] > 0 ? "true" : "true" ; ?>
                    <?php if (isset($percents)) : ?>
                        <?php if ($percents == "false") : ?>
                            <a href="<?php echo ak_url().'sections/result/'.$data->id; ?>" class="btn btn-primary btn-lg">
                                Résultats
                            </a>
                        <?php else:
                            $next_section = $data->id;
//                            if($this->questions->getSectionByID($data->id)->row()->sec_status == 0)
//                                $next_section = $data->id.'/1';

                            if($n_section = $this->questions->getSectionByID($data->id)->row()) {
                                $n_section = $n_section->sec_status;
                                $f_s = $this->questions->is_next_disabled($data->id, $n_section);
                                if ($f_s) {
                                    $next_section = $f_s . ($data->section_q ? '/' . $data->section_q : '');
                                    $n_section = $this->questions->getSectionByID($f_s)->row()->sec_status;
                                    if (is_numeric($f_s) && $this->questions->getSectionByID($data->id)->row()->sec_status == 0) {
                                        $next_section = $f_s . ($data->section_q ? '/' . $data->section_q : '');
                                    }
                                }
                            }
                            if($n_section == 0)
                                $next_section = $next_section.'/1';


                            ?>
                            <a href="<?php echo ak_url().'sections/'.$view_page.$next_section; ?>" class="btn btn-primary btn-lg">
                                Suivant
                            </a>
                        <?php endif ?>
                    <?php else: ?>
                        <a href="<?php echo ak_url().'sections/'.$view_page.$data->id.'/'.$data->section_q; ?>" class="btn btn-primary btn-lg">
                            Suivant
                        </a>
                    <?php endif ?>
                    
                </div>
                <?php
            } else {
                if( $rows != 0 ){
                    $percentage = ceil(($answered + 1) / $rows * 100);
                ?>
                <?php if ($percentage <= 100): ?>
                    <form method="post" action="../../Question/step" accept-charset="utf-8" id="step">
                        <input type="hidden" id="sID" name="section_id"
                               value="<?php echo $data->section->section_id; ?>">
                        <input type="hidden" id="uID" name="user_id"
                               value="<?php echo $this->session->userdata('id'); ?>">
                        <input type="hidden" id="percent" name="percentage" value="<?php echo $percentage; ?>">
                    </form>
                <?php endif ?>

                <form method="post"
                      action="<?php echo ak_url(); ?>sections/result/<?php echo floor($data->section->section_id); ?>"
                      id="formQuestions" enctype="multipart/form-data" accept-charset="utf-8">
                    <div class="question-content">
                        <?php
                        if ($data->content && $data->content[0]->fetch_description != 0):
                            $section = $this->questions->getSection($data->content[0]->sec_id)->row();
                            ?>
                            <h1><?php echo $section->section_title; ?></h1>
                            <br>
                            <?php if ($section->section_description != false): ?>
                            <?php echo $section->section_description ?>
                            <br>
                        <?php endif ?>
                            <br>
                            <?php if ($section->objectives != false): ?>
                            <p><strong>Objectifs</strong> : <?php echo $section->objectives; ?></p>
                            <br>
                        <?php endif ?>
                            <?php if ($section->instructions_start != false): ?>
                            <p><strong>Instructions</strong> : <?php echo $section->instructions_start; ?></p>
                            <br>
                        <?php endif ?>
                            <?php if ($section->duration_time != false): ?>
                            <p><strong>Durée : <?php echo $section->duration_time; ?> minutes </strong></p>
                            <br>
                        <?php endif; ?>
                            <?php echo fmod((float)$data->section->section_id, 1) == 0 ? '<p>Video</p>' : ''; ?>
                        <?php endif;
                        echo '<input type="hidden" id="sectionID" value="' . $data->section->section_id . '">';
                        if ($data->content != false) {
                        echo '<input type="hidden" id="qID" name="q_id" value="' . $data->content[0]->q_id . '">';
                        $content = str_replace(['\n', '\r'], "", $data->content[0]->q_content);
                        echo $content;
                        ?>
                    </div>

                    <div class="ln-solid"></div>
                    <div class="pagination">
                        <?php
                        foreach ($data->pagination as $page):
                            echo $page;
                        endforeach;
                        if ($data->last_page && $data->next_section_c) :
                            echo '<button type="Submit" class="btn btn-primary proceed">Suivant</button>';
                        elseif ($data->next_section_c && $data->next_section > 0) :
                            $next_section = $data->next_section;
                            $n_section = $this->questions->getSectionByID($data->next_section)->row()->sec_status;
                            $f_s = $this->questions->is_next_disabled($data->next_section, $n_section);
                            if ($n_section == 0)
                                $next_section = $data->next_section . '/1';
                            if ($f_s) {
                                $next_section = $f_s;
                                if (is_numeric($next_section) && $this->questions->getSectionByID($data->next_section)->row()->sec_status == 0) {
                                    $next_section = $f_s . '/1';
                                }
                            }
                            ?>
                            <a href="<?php echo ak_url() . 'sections/' . $next_section; ?>" rel="next"
                               style="display: inline;">
                                <button type="button" class="btn btn-primary next">Suivant
                                </button>
                            </a>
                        <?php endif; ?>
                        <?php if(  $data->content[0]->display_print_btn == 1 ): ?>
                            <button href="<?php echo ak_url().'main/sresult/'.$data->content[0]->q_id; ?>" onclick="projection.print_single(this)" type="button" class="btn btn-primary btn-md glyphicon glyphicon-print">
                            </button>
                        <?php endif; ?>
                    </div>
                    <?php

                    }
                    ?>
                </form>
                <?php
                }
            }
        }else{} ?>
    </div>
    </div>
</div>
<style>
#viewjobs{
    display: none;
}
#qualifiers_hide{
    display: none;
}
.hide-me{
    display: none;
}
#strenghts_areas td:nth-child(1) {
    background-color: #fff !important;
    color: #000;
    border-color: #ccc !important;
}
#strenghts_areas tr.thead td {
    background-color: #285a89 !important;
    color: #fff;
    border-color: #fff !important;
}
table, table tr, table tr>td{
    border-color: #ccc !important;
}
#success_story tr:first-child{
    background-color: #777 !important;
    color: #fff !important;
}
#success_story tr:first-child span, #success_story tr:first-child a{
    color: #fff !important;
}
    
</style>