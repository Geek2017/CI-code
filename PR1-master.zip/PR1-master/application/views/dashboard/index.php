<div class="col-md-3 l-menu">
    <div class="ak-title">LOREM IPSUM</div>
    <div class="q-count"><span class="q-count-up">0</span>/<span class="q-count-down">15</span></div>
    <div class="q-progressbar" id="container"></div>
</div>
<div class="col-md-9 q-container">
    <div class="ak-title pad-b-10">POINT DE DEPART</div>
    <div class="ak-section_desc pad-b-10">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eligendi non quis exercitationem culpa nesciunt nihil aut nostrum explicabo reprehenderit optio amet ab temporibus asperiores quasi cupiditate. Voluptatum ducimus voluptates voluptas?</div>
    <div class="q-objective pad-b-10">
        Objectif :
        Je vous propose pour démarrer ce parcours de compléter cette première partie pour vous mettre en action vers un changement professionnel interne.
    </div>
    <div class="q-instructions pad-b-10">
        Instructions :
        je vous suggère de répondre aux questions suivantes de façon spontanée et en toute sincérité, encore une fois personne n’a accès à vos réponses.
    </div>
    <div class="q-duration">
        Durée : 15 minutes
    </div>


    <div class="q-footer">
        <button class="q-continue">Continuer</button>
    </div>
</div>
