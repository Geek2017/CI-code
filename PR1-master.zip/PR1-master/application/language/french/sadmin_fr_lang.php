<?php
//no translation messages
$lang["no_translation"] = "pas de traduction";

// basic
$lang["cancel"] = "Annuler";
$lang["validate"] = "Valider";


//roles
$lang["superadmin"] = "super administrateur";
$lang["admin"] = "administrateur";

$lang["home"] = "Tableau de bord";
$lang["user"] = "Utilisateur";
$lang["coach"] = "entraîneur";
$lang["external"] = "externe";

//super adminmenu
$lang['akeen_dashboard'] = "tableau de bord";
$lang['akeen_users'] = "akeen utilisateurs";
$lang["dashboard"] = "dashboard";
$lang["organizations"] = "Gestion des entreprises";
$lang["subsidiary"] = "Société / Filiale";
$lang["accounts"] = "accounts";
$lang["guest"] = "Gestions des utilisateurs";
$lang["personnalisation"] = "Personnalisation";
$lang["sections"] = "Gestions des sections";
$lang["questions"] = "Gestions des questions";
$lang["settings"] = "paramètres";
$lang["logout"] = "Se déconnecter";
$lang["profile"] = "profil";
$lang["user_status"] = "user status";


$lang["email"] = "E-mail professionnel";
$lang["organization"] = "Gestion des Entreprises";
$lang["firstname"] = "Prénom";
$lang["lastname"] = "nom";
$lang["role"] = "rôle";
$lang["contact"] = "Address";
$lang["action"] = "actions";
$lang["status"] = "statut";
$lang["password"] = "Mot de passe";
$lang["new_password"] = "Nouveau mot de passe";
$lang["confirm_password"] = "Confirmer le nouveau mot de passe";
$lang["address_line1"] = "Adresse";
$lang["org_city"] = "Ville";
$lang["zip"] = "Code postal";
$lang["zip_code"] = "Code postal";
$lang["name"] = "Groupe";
$lang["website_url"] = "Site web";
$lang["sector"] = "Secteur";
$lang["org_country"] = "Pays";
$lang["civility"] = "Civilité";
$lang["function"] = "Fonction";
$lang["contact"] = "Téléphone professionnel";
$lang["num_staff"] = "Nombre d'effectifs";

$lang["creation_date"] = "Date de creation";
$lang["nos_user_in_progress"] = "Utilisateur en cours de progression";
$lang["user_created_max_user"] = "Utilisateur / utilisateur possible";
$lang["done_user"] = "Utilisateur qui ont termine";

// admin menu
$lang["users"] = "Utilisateurs";
$lang["companyprofile"] = "Profil";
$lang["editcompanyprofile"] = "Modifier Profil";

// title
$lang["t_inactive_guest"] = "L'utilisateur est inactif";


//superadmin profile
$lang["superprofile"] = "Mon profil";

//superadmin personalization
$lang["spersonalize"] = "Personalisation";

