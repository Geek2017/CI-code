<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Event_resend_email extends MY_Controller {

    public function __construct()
    {
        //parent::__construct();
        $this->my_controller_parent_construct();
        $this->check_session_timed_out("bo");

        //load language file
        $this->load_language_backoffice();
        $this->lang->load('backoffice/event_resend_email', 'fr');

        //load model
        $this->load->model("event_email_recipient_model");
    }

    /*
    * Method for generationg list of 
    * Last Name, First name Email datatable for front end
    */
    public function get_datatable($email_type_id = null, $event_schedule_id = null )
    {
        output_to_json($this,$this->event_email_recipient_model->get_datatable( $email_type_id , $event_schedule_id ));
    }
    /**
    * generate select box for datable
    */
    public function get_email_template_type()
    {
        output_to_json($this, $this->event_email_recipient_model->get_email_template_types());
    }
    /*
    * insert new refence ids for resend
    */
    public function insert_reference_id()
    {
        if( $this->event_email_recipient_model->insert_reference_ids() )
            output_to_json($this, array( 'mtype' => 'success' , 'message' => $this->lang->line("resend_email_success")) );
        else 
             output_to_json($this, array( 'mtype' => 'error' , 'message' => $this->lang->line("resend_email_error")) );

    }


}