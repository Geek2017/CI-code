<!-- Page Content -->
<div class="container static">
    <div class="row">
        <div class="col-lg-10 col-lg-offset-1">
         <?php 
            if(isset($user_role)) {
                if($this->session->userdata("lastname") != null){?>
                    <a class="align-left" href="<?php echo site_url('main/progress'); ?>"><img src="<?php echo base_url('assets/img/return.png'); ?>"/> Retour</a>
                        <?php } ?>
                             <?php
                        }else{
                            ?>
                          <a class="align-left" href="<?php echo site_url('main/'); ?>"><img src="<?php echo base_url('assets/img/return.png'); ?>"/> Retour</a>
                             <?php
                        }
                        ?>  
            <h1 class="text-center">Qui sommes-nous ?</h1>
            <p><b>AkeeN est une start-up où le web se met au service de la mobilité professionnelle interne des collaborateurs. C’est :</b></p>
           	<ul class="static-bullet">
                <li><span><b>Une vision : </b>devenir la plateforme r&#233;f&#233;rente en mati&#232;re de mobilit&#233; professionnelle interne des collaborateurs</span></li>
            	<li><span><b>Une cible claire:</b>  des collaborateurs, autonomes, responsables et motiv&#233;s pour prendre en main leur devenir professionnel et d&#233;finir au sein de leur entreprise un projet professionnel r&#233;aliste et en accord avec leurs priorit&#233;s </span></li>
 				<li><span><b>Un processus digitalisé, structuré et testé :</b> un cheminement au travers de 10 &#233;tapes, test&#233; au travers d&#8217;une b&#233;ta version. Des objectifs et instructions donnés &#224; chaque &#233;tape via des vid&#233;os qui permettent d&#8217;accompagner efficacement et simplement les parcours.  </span></li>
 				<li><span><b>Un dispositif novateur d’accompagnement personnalisé d’un Collaborateur :</b> un processus de bout en bout, du bilan professionnel et personnel &#224; une ouverture sur un r&#233;seau de DRH interne et d&#8217;op&#233;rationnels qui permet au collaborateur de construire son projet professionnel &#224; son rythme, en toute objectivit&#233; et confidentialit&#233;.</span></li>
 				<li><span><b>Une équipe professionnelle et expérimentée :</b> 10 experts de l&#8217;accompagnement ayant tous sign&#233;s la charte d&#233;ontologique AkeeN appuient notre processus d&#8217;accompagnement.  </span></li>
 				<li><span><b>Une « passion contagieuse » :</b> nous aimons ce que nous faisons, qui est d’aider les entreprises à favoriser l’engagement de leurs collaborateurs et de permettre à nos accompagnés de se construire un avenir professionnel en accord avec leurs priorités personnelles.</span></li>
            </ul>
            <br>
        </div>
        	
        <div class="col-lg-10 col-lg-offset-1">
            <div class="col-lg-2">
                <img src="<?php echo base_url('assets/img/priscilla.png')?>" alt="Priscilla ChazotMagdelaine" class="img-responsive">
            </div>

            <div class="col-lg-10">
            	<p><b>Priscilla ChazotMagdelaine a créé AkeeN pour accompagner la performance de ses clients en utilisant à bon escient trois techniques: le conseil, la formation et le coaching, et en s’appuyant sur ses propres expériences :</p>

            	<ul class="static-dashed">
            		<li><b>professionnelles</b> : 6 ans d’audit financier chez Arthur Andersen; 15 ans de conseil dont 13 ans au sein de Capgemini Consulting, et 3 ans en tant que responsable de l’offre finance de SopraConsulting; manager de 20 consultants; plus récemment tutrice, professeur de contrôle de gestion à HEC et coach professionnelle,</li>
            		
                </ul>
                <ul class="static-dashed">
                    <li><b>académiques</b> : un Master en finance Gestion à HEC et un diplôme d’Executive Coaching à l’Université de Cergy Pontoise, </li>
                    <br>
                    <li><b>bénévoles</b> : Marraine à l’Avarap (gestion d’un groupe de 14 cadres en recherche d’un projet professionnel motivant); membre du Comité Economique et Social d’Asnières-sur-Seine; administrateur du DUCPEC; organisatrice d’évènements pour le compte d’HEC-Entreprendre au féminin.</li>
                </ul><br>
            </div>


        </div>
        
       <div class="col-lg-10 col-lg-offset-1">
        	<p>Priscilla a construit ce <b>parcours digitalis&#233; de mobilit&#233; professionnelle complet</b> qui permet de faire un bilan professionnel et personnel, un 360, et in fine de construire son projet professionnel.  Elle est aussi en train de r&#233;diger un <b>livre sur la mobilit&#233; professionnelle :</b> &#171; Faites votre bilan pour redynamiser votre carri&#232;re : A vous de jouer ! &#187; &#224; paraître en 2017 aux &#233;ditions DUNOD.</p><br>
            <p><b>AkeeN a la chance de pouvoir s&#8217;appuyer sur dix coachs exp&#233;riment&#233;s,</b> pluridisciplinaires et compl&#233;mentaires en accord avec la charte d&#233;ontologique AkeeN.</p>
            <img src="<?php echo base_url('assets/img/coaches.png')?>" alt="" class="img-responsive">
        </div>        
    </div>
</div>