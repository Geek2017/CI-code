<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Event_email_schedule_model extends CI_Model {

    var $column_order = array(null, 'e.title', 'e.start_date_time', 'ees.email_schedule_date', 'ees.email_schedule_status', 'email_schedule_author', null, 'ees.email_schedule_date_added'); //set column field database for datatable orderable
    var $column_search = array('e.title','CONCAT(u.first_name, " ", u.last_name)','ees.email_schedule_date_added'); //set column field database for datatable searchable just firstname , lastname , address are searchable
    var $order = array('ees.email_schedule_date' => 'desc'); // default order

    public function __construct() {
        parent::__construct();
    }

    private function _get_datatables_query($data_source){

        $this->db->select("
            ees.email_schedule_id,
            e.event_id,
            e.back_office_status as event_status,
            e.title as event_title,
            ees.email_schedule_status as email_schedule_status_,
            (CASE
              WHEN e.start_date_time > NOW() THEN 'Active'
              WHEN e.start_date_time < NOW() THEN 'Passed'
              ELSE 'Passed'
            END) AS email_schedule_status,
            (CASE
              WHEN ees.email_sched_overwrite_default = 1 THEN 'YES'
              WHEN ees.email_sched_overwrite_default = 2 THEN 'NO'
              ELSE 'NO'
            END) AS email_sched_overwrite_default")
            ->select("DATE_FORMAT(ees.email_schedule_date, '%d/%m/%Y %Hh%i') AS email_schedule_date", FALSE)
            ->select("DATE_FORMAT(e.reservation_start_date, '%d/%m/%Y %H:%i:%s') AS reservation_start_date", FALSE)
            ->select("DATE_FORMAT(e.start_date_time, '%d/%m/%Y %Hh%i') AS start_date_time", FALSE)
            ->select("DATE_FORMAT(e.start_date_time, '%d/%m/%Y %H:%i:%s') AS start_date_time_", FALSE)
            ->select("CONCAT(u.first_name, ' ', u.last_name) as email_schedule_author", FALSE)
            ->select("DATE_FORMAT(ees.email_schedule_date_added, '%d/%m/%Y %Hh%i') AS email_schedule_date_added", FALSE)
            ->select("DATE_FORMAT(ees.email_schedule_date, '%Y-%m-%d %H:%i:%s') AS email_schedule_date_", FALSE)
            ->from("event_email_schedule ees")
            ->join('event e', 'e.event_id = ees.event_id', 'left')
            ->join('user u', 'u.user_id = ees.email_schedule_author', 'left')
            ->where_in("e.back_office_status", array(1, 2, 3, 4, 5, 0, 6))
            ->where_in("ees.email_type_id", array(1))
            ->where_in("ees.email_schedule_status", array(1, 2));

        $i = 0;

        foreach ($this->column_search as $item) {// loop column
            if ($data_source['search']['value']) {  // if datatable send POST for search
                if ($i === 0) { // first loop
                    $this->db->like($item, $data_source['search']['value']);
                } else {
                    $this->db->or_like($item, $data_source['search']['value']);
                }
            }
            $i++;
        }

        if(isset($data_source['order'])) { // here order processing
            if(isset($data_source['order']['0']['dir'])) {
                $this->db->order_by($this->column_order[$data_source['order']['0']['column']], $data_source['order']['0']['dir']);
            }
        } else if(isset($this->order)) {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    public function get_events_list_export($data_source){
        $this->_get_datatables_query($data_source);
        $query = $this->db->get();
        $res = $query->result();
        return $res;
    }

    public function get_datatables($data_source){
        $this->_get_datatables_query($data_source);
        if($data_source['length'] != -1)
            $this->db->limit($data_source['length'], $data_source['start']);
        $query = $this->db->get();
        return $query->result();
    }

    public function count_filtered($data_source){
        $this->_get_datatables_query($data_source);
        $query = $this->db->get();
        return $query->num_rows();
    }

    public function count_all($data_source){
        $this->_get_datatables_query($data_source);
        return $this->db->count_all_results();
    }

    public function list_events_for_typeahead($search){
        $this->db->select("e.event_id, e.title AS name, e.back_office_status as event_status, CONCAT(CURRENT_TIMESTAMP) as date_now")
            ->select("DATE_FORMAT(e.reservation_start_date, '%d/%m/%Y %H:%i:%s') AS reservation_start_date", FALSE)
            ->select("DATE_FORMAT(e.start_date_time, '%d/%m/%Y %H:%i:%s') AS start_date_time", FALSE)
            ->select("(SELECT email_sched_overwrite_default FROM event_email_schedule WHERE event_id = e.event_id
            AND email_type_id=1 AND email_schedule_date >= CURRENT_TIMESTAMP AND email_schedule_status=1 ORDER BY email_schedule_id DESC LIMIT 1) AS email_sched_overwrite_default", FALSE)
            ->from("event e")
            ->where_in("e.back_office_status",array(1,2,3))
            ->where("e.start_date_time > NOW()")
            ->where("e.event_id NOT IN(SELECT event_id FROM event_email_schedule WHERE event_id = e.event_id
            AND email_type_id=1 AND email_schedule_date >= CURRENT_TIMESTAMP AND email_schedule_status=1 ORDER BY email_schedule_id DESC)")
            ->like("e.title", $search)
            ->order_by("e.event_id", "desc")
            ->limit(10);
        return $this->db->get()->result();
    }

    public function add_email_reminder($data){
        if($data) {
            //defer all default settings using the default email sending
            $this->db->where("email_sched_reference", 2);
            $this->db->where("email_sched_reference_id", $data["reference"]);
            $this->db->where_in("email_status",array(0,2,3));
            $this->db->where("event_id", $data["event_id"]);
            $this->db->where("email_type_id", $data["email_type_id"]);
            $this->db->update("event_email_recipient", array("email_status" => 5));

            $this->db->insert("event_email_schedule", $data);
            if ($this->db->affected_rows()) {
                return $this->db->insert_id();
            }
        }
        return false;
    }

    public function update_email_reminder($data){
        if($data) {
            $email_schedule_id = $data["email_schedule_id"];
            unset($data["email_schedule_id"]);
            //overwrite all default settings
            //$this->db->where("email_schedule_date >= CURRENT_TIMESTAMP");
            //$this->db->where("email_schedule_status", 1);
            //$this->db->where("event_id", $data["event_id"]);
            //$this->db->where("reference", $data["reference"]);
            //$this->db->where("email_schedule_id !=", $email_schedule_id);
            //$this->db->update("event_email_schedule", array("email_sched_overwrite_default" => $data["email_sched_overwrite_default"]));

            //if event is changed then defer sending emails to subscribers under the previously selected event for this record.
            if($this->check_changed_of_event($email_schedule_id, $data["event_id"])) {
                $this->db->where("email_sched_reference_id", $email_schedule_id);
                $this->db->where("email_sched_reference", 1);
                $this->db->where("email_type_id", 1);
                $this->db->where_in("email_status", array(0, 2, 3));
                $this->db->update("event_email_recipient", array("email_status" => 5, "email_date_time" => date('Y-m-d H:i:s')));
            }

            $this->db->where("email_schedule_id", $email_schedule_id);
            $update = $this->db->update("event_email_schedule", $data);
            if ($update) {
                return true;
            }
        }
        return false;
    }

    private function check_changed_of_event($email_schedule_id, $event_id){
        $this->db->where("email_sched_reference_id", $email_schedule_id);
        $this->db->where("email_sched_reference", 1);
        $this->db->where("email_type_id", 1);
        $this->db->where("event_id !=", $event_id);
        $this->db->where_in("email_status", array(0,2,3));
        $this->db->limit(1);
        return $this->db->get("event_email_recipient")->num_rows();
    }

    public function delete_email_reminder($email_schedule_id){
        //when an schedule is deleted, the on queue reminder email must be deferred/deleted also to stop from sending emails to subscribers.
        $this->db->where("email_sched_reference_id", $email_schedule_id);
        $this->db->where("email_sched_reference", 1);
        $this->db->where("email_type_id", 1);
        $this->db->where_in("email_status", array(0,2,3));
        $this->db->update("event_email_recipient", array("email_status" => 5, "email_date_time" => date('Y-m-d H:i:s')));

        $this->db->where("email_schedule_id", $email_schedule_id);
        $this->db->update("event_email_schedule", array("email_schedule_status" => 0));
        return $this->db->affected_rows();
    }

    public function get_email_sending_schedule($event){

        //new schedule
        $parameters = $this->get_default_email_schedule($event->event_id, $event->event_schedule_id, 1);

        if(sizeof($parameters) <= 0) {
            return array();
        }
        
        return $this->db->query("
            SELECT 
                eeds.email_tpl_setting_id as email_schedule_id,
                (CASE
                  WHEN eeds.email_tpl_setting_sched_by = 'HOURS' 
                  THEN DATE_SUB('".$event->start_date_time."', INTERVAL eeds.email_tpl_setting_sched+5 HOUR)
                  WHEN eeds.email_tpl_setting_sched_by = 'DAYS' 
                  THEN DATE_SUB('".$event->start_date_time."', INTERVAL eeds.email_tpl_setting_sched+1 DAY)
                  ELSE DATE_SUB('".$event->start_date_time."', INTERVAL eeds.email_tpl_setting_sched+120 MINUTE)
                END) AS email_schedule, 
                2 as email_sched_reference

            FROM event_email_default_setting eeds
            WHERE eeds.email_type_id = 1 
                AND eeds.email_tpl_setting_status = 1
                AND eeds.email_tpl_setting_id 
                    NOT IN(
                    SELECT `ees`.`reference`
                    FROM event_email_schedule ees
                    LEFT JOIN event_schedule es 
                        ON es.event_schedule_id = ees.event_schedule_id
                    WHERE `es`.`event_schedule_id` = '".$event->event_schedule_id."' 
                        AND eeds.email_tpl_setting_id = ees.reference
                        AND es.start_date_time >= NOW()
                        AND ees.email_schedule_status=1
                        AND es.back_office_status IN(1,2,3)
                        GROUP BY ees.reference
                )
                /*AND
                    CONCAT(eeds.reference_id,'_',eeds.email_type_id,'_',eeds.is_default,'_1') 
                    IN(
                        '".($event->event_schedule_id."_1_2_1")."',
                        '".($event->event_id."_1_1_1")."',
                        '".("_1_0_1")."'
                    )*/
                AND
                    eeds.email_tpl_setting_id IN(".((isset($parameters->email_tpl_setting_id) && !empty($parameters->email_tpl_setting_id))?$parameters->email_tpl_setting_id:"").")
                AND 
                (
                SELECT
                    CASE 
                        WHEN CONCAT(eeds.reference_id,'_',eeds.email_type_id,'_',eeds.is_default,'_1') = '".($event->event_schedule_id."_1_2_1")."'
                        THEN 
                            (SELECT CASE
                              WHEN eeds.email_tpl_setting_sched_by = 'HOURS' 
                              THEN DATE_SUB('".$event->start_date_time."', INTERVAL (eeds.email_tpl_setting_sched+5) HOUR)
                              WHEN eeds.email_tpl_setting_sched_by = 'DAYS' 
                              THEN DATE_SUB('".$event->start_date_time."', INTERVAL (eeds.email_tpl_setting_sched+2) DAY)
                              ELSE DATE_SUB('".$event->start_date_time."', INTERVAL (eeds.email_tpl_setting_sched +60) MINUTE)
                            END)
                        
                        WHEN CONCAT(eeds.reference_id,'_',eeds.email_type_id,'_',eeds.is_default,'_1') = '".($event->event_id."_1_1_1")."'
                        THEN 
                            (SELECT CASE
                              WHEN eeds.email_tpl_setting_sched_by = 'HOURS' 
                              THEN DATE_SUB('".$event->start_date_time."', INTERVAL (eeds.email_tpl_setting_sched+5) HOUR)
                              WHEN eeds.email_tpl_setting_sched_by = 'DAYS' 
                              THEN DATE_SUB('".$event->start_date_time."', INTERVAL (eeds.email_tpl_setting_sched+2) DAY)
                              ELSE DATE_SUB('".$event->start_date_time."', INTERVAL (eeds.email_tpl_setting_sched +60) MINUTE)
                            END)

                        WHEN CONCAT(eeds.reference_id,'_',eeds.email_type_id,'_',eeds.is_default,'_1') = '".("_1_0_1")."'
                        THEN 
                            (SELECT CASE
                              WHEN eeds.email_tpl_setting_sched_by = 'HOURS' 
                              THEN DATE_SUB('".$event->start_date_time."', INTERVAL (eeds.email_tpl_setting_sched+5) HOUR)
                              WHEN eeds.email_tpl_setting_sched_by = 'DAYS' 
                              THEN DATE_SUB('".$event->start_date_time."', INTERVAL (eeds.email_tpl_setting_sched+2) DAY)
                              ELSE DATE_SUB('".$event->start_date_time."', INTERVAL (eeds.email_tpl_setting_sched +60) MINUTE)
                            END)

                        ELSE DATE_SUB('".$event->start_date_time."', INTERVAL (eeds.email_tpl_setting_sched +60) MINUTE)
                    END

                ) <= NOW()

            UNION

            SELECT `ees`.`email_schedule_id`, 
                ees.email_schedule_date as email_schedule, 
                1 as email_sched_reference
            FROM `event_schedule` es
            LEFT JOIN `event_email_schedule` ees 
                ON `ees`.`event_schedule_id` = `es`.`event_schedule_id`
                AND ees.email_schedule_status=1
            LEFT JOIN `event_email_default_setting` eeds 
                ON `eeds`.`email_tpl_setting_id` = `ees`.`reference`
                AND eeds.email_type_id = 1
            WHERE `es`.`event_schedule_id` = '".$event->event_schedule_id."' 
                AND es.start_date_time >= NOW() 
                AND es.back_office_status IN(1,2,3)
                AND DATE_SUB(ees.email_schedule_date, INTERVAL 2 DAY) <= NOW()
                
        ORDER BY 
            email_schedule, email_schedule_id ASC LIMIT 1")->result();
    }

    public function check_email_active_processes($email_schedule_id){
        $this->db->where("email_sched_reference_id", $email_schedule_id);
        $this->db->where("email_sched_reference", 1);
        $this->db->where("email_type_id", 1);
        $this->db->where_in("email_status", array(0,2,3));
        $this->db->limit(5);
        return $this->db->get("event_email_recipient")->num_rows();
    }

    public function add_email_schedule_for_waitlist($event_id, $event_schedule_id){
        
        $parameters =$this->get_default_email_schedule($event_id, $event_schedule_id, 2);
        // print_r($parameters);
        
        //update previous email schedule before adding new one
        $this->db->query("
                UPDATE event_email_schedule ees
                LEFT JOIN event_email_default_setting eeds on
                    eeds.email_tpl_setting_id = ees.reference
                set
                    ees.email_schedule_status = 2
                 WHERE
                    eeds.email_type_id = 2
                AND
                    ees.email_schedule_status = 1
                AND
                    ees.event_schedule_id = ".$event_schedule_id."");

        if(sizeof($parameters) > 0){
            //then insert a new one
            $reset_sched_date = date_modify(new DateTime(), "+".$parameters->email_tpl_setting_sched.strtolower($parameters->email_tpl_setting_sched_by));

            $data = array(
                "event_schedule_id"  => $event_schedule_id,
                "reference" => $parameters->email_tpl_setting_id, // parameters
                "email_schedule_date"  => $reset_sched_date->format("Y-m-d H:i:s"), //reset hr
                "email_schedule_status"    => 1
            );
            
            $this->db->insert("event_email_schedule", $data);
            return array(
                "success" => true, 
                "schedule"=> $parameters, 
                "email_schedule_id" => $this->db->insert_id()
                );
        }

        return array("success" => false);
    }

    private function get_default_email_schedule($event_id, $event_schedule_id, $email_type){

        $where_data = array(
                //'if' get the specific schedule per event_schedule_id
                 $event_schedule_id."_2",
                //'else if' get the specific schedule per event_id
                $event_id."_1",
                //'else if' get the default sched if any
                "_0"
                //'else' return false
            );
        $result = array();

        foreach ($where_data as $value){
            $result = $this->db->query("
            SELECT 
                eeds.email_tpl_setting_id,
                eeds.email_tpl_setting_sched,
                eeds.email_tpl_setting_sched_by,
                eeds.email_tpl_number_of_recipients
            FROM event_email_default_setting eeds
            WHERE eeds.email_type_id = ".$email_type." 
                AND eeds.email_tpl_setting_status = 1
                AND "
                .(($value != "_0")
                    ? "CONCAT(eeds.reference_id,'_',eeds.is_default)"
                    : "CONCAT('_',eeds.is_default)")." = '".$value."'"."
            ")->row();
            if(sizeof($result) > 0){
                break;
            }
        }
        return $result;
    }

}