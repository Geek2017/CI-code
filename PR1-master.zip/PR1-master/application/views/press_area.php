<!-- Page Content -->
<div class="container static">
    <div class="row">
        <div class="col-lg-10 col-lg-offset-1">
         <?php 
            if(isset($user_role)) {
                if($this->session->userdata("lastname") != null){?>
                    <a class="align-left" href="<?php echo site_url('main/progress'); ?>"><img src="<?php echo base_url('assets/img/return.png'); ?>"/> Retour</a>
                        <?php } ?>
                             <?php
                        }else{
                            ?>
                          <a class="align-left" href="<?php echo site_url('main/'); ?>"><img src="<?php echo base_url('assets/img/return.png'); ?>"/> Retour</a>
                             <?php
                        }
                        ?>  
            <h1 class="text-center">Espace Presse</h1>

        	<p><b>Les entreprises chercheront leurs talents en interne en 2016</b></p>

            <p><i>Article du journal Dynamique entrepreneuriale de d&#233;cembre / janvier 2016, d&#233;taill&#233; par Didier Pezant, r&#233;dacteur &#224; l'Agence DAJM insiste sur ce point dans les Echos du 10 Novembre 2015</i></p><br>

            <p>&#171; Selon une &#233;tude publi&#233;e par LinkedIn Talent Solution, sur 3 894 DRH interrog&#233;s, 40% placent le recrutement en interne comme le pilier de leur strat&#233;gie de recrutement dans l&#8217;ann&#233;e &#224; venir. Ils sont 28% &#224; assurer que cela devrait &#234;tre la priorit&#233; absolue de leurs entreprises pendant les 12 prochains mois.&#187;</p>

            <p>&#171; <b>Budgets &#224; la baisse, concurrence accrue</b></p>
            Selon cette &#233;tude, cette tendance s'explique par la stagnation des budgets accord&#233;s au recrutement alors que le nombre personnes embauch&#233;es repart franchement &#224; la hausse. Le volume de recrutement a augment&#233; de 28% en 2013 alors qu'il bondit de 59% en 2015. Les entreprises pr&#233;f&#232;rent alors piocher dans leurs propres viviers.</p>
            <p>Autre cause de cet int&#233;r&#234;t pour la mobilit&#233; en interne : la difficult&#233; de recruter en externe les meilleurs talents. Une entreprise sur deux (49%) consid&#232;re comme un &#171; obstacle &#187; la recherche de candidats dans des viviers de talents tr&#232;s sollicit&#233;s. Elles sont 46% &#224; d&#233;clarer que la concurrence avec les autres soci&#233;t&#233;s est rude en mati&#232;re de recrutement. </p>
            <p><b>La mobilité dans l’air du temps</b></p>
            <p>La mobilité professionnelle semble s'inscrire comme une tendance de fond depuis mars 2014 avec la loi « formation professionnelle, emploi et démocratie ». La Gestion prévisionnelle des emplois et des compétences (GPEC) vise aussi à mieux anticiper l'effet des mutations économiques pour les salariés et entreprises. Quant au Compte personnel de formation, il favorise la formation continue des salariés.  </p>
            <p>Il faut aussi dire que la mobilité est un domaine où la France excelle. Certains voient un changement de paradigme dans les entreprises. Les programmes de mobilité interne y sont en effet nettement mieux définis que dans le reste du monde (43 % versus 24 %) grâce à la réforme. »</p>
			
        </div>        
    </div>
</div>