<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/* FRONTOFFICE TEMPLATE*/

// Header Links
$lang['home'] = 'Home';
$lang['my_account'] = 'Mon Compte';
$lang['my_reservations'] = 'Mes réservations';
$lang['login'] = 'Connexion';
$lang['logout'] = 'Déconnexion';
$lang["create_an_account"] = "Créer un compte";

// Footer Links
$lang['legal_notice'] = 'Mentions légales';
$lang['term_of_sales'] = 'Conditions Générales de vente';
$lang['online_store'] = 'Le boutique en ligne';
$lang['contact_us'] = 'Contactez-nous';

// Page Titles
$lang['title_forgot_pass'] = 'Portail Le Monde -- Mot de passe oublié?';
$lang['title_homepage'] = 'Le Monde évènements abonnés';
$lang['title_event_details_page'] = 'Le Monde - Abonnés';

// Error Messages
$lang['not_registered'] = "L'email n'est pas enregistré.";