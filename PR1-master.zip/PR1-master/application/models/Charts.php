<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Charts extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }

    public function results()
    {
        $userid = $this->session->userdata('id');
        $years = array();
        $rate = array();

        $f_data = [];
        $rate2 = [];
        $event = [];
        $event2 = [];
        $this->db->where( "user_id", $userid );
//        $this->db->group_by( "date" );
        $this->db->order_by("id","asc");
        $query = $this->db->get("satisfaction_curve");
        if ($query->num_rows() > 0) {
            foreach($query->result() as $row) {
                $data = [
                    'years' =>  $row->date,
                    'rate'  =>  $row->satisfaction_rate
                ];
                $f_data[] = $row->date;
            }
        }
        $this->db->where( "user_id", $userid );
        $this->db->order_by("STR_TO_DATE(date,'%d/%m/%Y') asc");
        $query = $this->db->get("satisfaction_curve");
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $i => $row) {
                $years[] = $row->date;
                    //date("Y-m-d",$row->date);
//                $search = array_search($row->date, $f_data);
//                if(multiKeyExists($rate,'rate')){
//
//                }
//                $rate[$search] = [
//                    'date'  =>  $row->date,
//                    'rate'  =>  $row->satisfaction_rate
//                ];
                if($row->table_no == 1) {
                    $rate[] = $row->satisfaction_rate;
                    $rate2[] = null;
                    $event[] = "« ".$row->event." – ".$row->reason." »";
                    $event2[] = null;
                }
                else if($row->table_no == 2) {
                    $rate[] = null;
                    $rate2[] = $row->satisfaction_rate;
                    $event[] = null;
                    $event2[] = "« ".$row->event." »";
                        //." – ".$row->reason." »";
                }
            }
        }

        $data = array(
            'years'     =>  $years,
            'rate'      =>  $rate,
            'rate2'     =>  $rate2,
            'event'     =>  $event,
            'event2'    =>  $event2
        );

        echo json_encode( $data );

    }
    public function validateDate($date, $format = 'm/j/y')
    {
        $d = DateTime::createFromFormat($format, $date);
        return $d && $d->format($format) == $date;
    }

}

   
  