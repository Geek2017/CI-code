<!-- Page Content -->
<div class="container welcome">
    <h1 class="text-center">Bienvenue</h1>
    <br>
    <p>Vous avez décidé d’entreprendre un bilan de mobilité professionnelle interne, complet et digitalisé avec AkeeN et nous vous remercions de votre confiance. Cette démarche est la vôtre. Elle a pour objet de vous permettre de prendre le recul nécessaire pour une meilleure connaissance de votre identité professionnelle et personnelle pour élaborer votre projet professionnel réaliste en accord avec les offres en interne et vos priorités personnelles. </p>
    <p><strong>Attention, le fait de construire ce projet professionnel ne signifie pas que vous aurez obligatoirement le poste visé, la décision finale reviendra toujours à l’entreprise pour laquelle vous travaillez.</strong> En revanche nous pouvons nous engager sur le fait que ce parcours va vous permettre de faire l’inventaire de votre patrimoine personnel et professionnel, vous ouvrir à d’autres horizons professionnels, confronter ces pistes aux réalités de l’environnement interne de votre entreprise, et si ce poste est ouvert, vous donner toutes les chances de concrétiser ce projet en un plan d’actions et la mise en relation avec le réseau Interne.</p>
    <p>Le parcours AMPI a été conçu par Priscilla Chazot-Magdelaine pour servir de support au travail de réflexion et d’investigation qui va être le vôtre pendant cette démarche. Ce parcours  n’est ni exhaustif, ni linéaire. Vous pouvez utiliser tout autre support, feuille blanche par exemple, qui vous paraît plus adapté. Un seul conseil, prenez le temps et l’énergie nécessaire pour ce travail personnel de réflexion et d’action. Implication,  exigence, qualité… le succès de ce parcours en dépend. </p><br>
    <h4 class="text-center">Toutes les informations capitalisées resteront bien sûr confidentielles, <br>seuls les compétences, succès, projet professionnel et pitch seront accessibles aux RH.</h4>  
    
    <br><br>
    <div class="pull-right sec-btn">
<!-- Page Content -->
        <a type="button" class="btn btn-primary" href="progress">Suivant</a>
    </div>
    <a class="btn btn-primary" data-toggle="modal" id="pre-reg-btn" href='#pre-reg'>Trigger modal</a>

<div class="modal fade" id="pre-reg">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header header-form">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true" value="Refresh" onClick="history.go()">&times;</button>
                <h2 class="text-center modal-title">Profile</h2>
            </div>
        
            <div class="modal-body">
                <div class="container wc-form">
    
                    <form id="profile" role="form">
                    <div class="col-md-6">
                        <div class="form-group-sm">
                            <label>Nom</label>
                            <input type="text" class="form-control nxt" id="lname" placeholder="Nom" value="<?php echo $firstname; ?>">
                        </div>
                        <div class="form-group-sm">
                            <label>Prénom</label>
                            <input type="text" class="form-control nxt" id="fname" placeholder="Prénom" value="<?php echo $lastname; ?>">
                        </div>
                        <div class="form-group-sm">
                            <label>Date de naissance</label>
                            <input type="text" class="form-control nxt" id="bday" placeholder="Date de naissance">
                        </div>
                        <div class="form-group-sm">
                            <label>Téléphone Portable</label>
                            <input type="text" class="form-control nxt" id="contact" placeholder="Téléphone Portable">
                        </div>
                        <div class="form-group-sm">
                            <label>Adresse Mail</label>
                            <input type="email" class="form-control nxt" id="email" value="<?php echo $user_email; ?>" placeholder="Adresse Mail">
                        </div>          
                        <div class="form-group-sm">
                            <label>Adresse</label>
                            <input type="text" class="form-control nxt" id="address" placeholder="Adresse">
                        </div>
                        <div class="form-group-sm">
                            <label>Code postal</label>
                              <span style="position: relative; z-index: 24;">
                            <input type="text" maxlength="5" onblur="postalCodeLookup('FR');"  class="form-control nxt" id="zip" onkeypress="return app.numbers(event);"  placeholder="Code postal">
                            <span style="position: absolute; top: 20px; left: 0px; z-index:25;visibility: hidden;" id="suggestBoxElement"></span></span>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group-sm">
                            <label>Ville</label>
                            <input type="text"  onblur="closeSuggestBox();" class="form-control nxt" id="city" placeholder="Ville">
                        </div>
                        <div class="form-group-sm">
                            <label>Pays</label>
                            <input type="text" class="form-control nxt" id="country" placeholder="Pays">
                        </div>
                        <div class="form-group-sm">
                            <label>Mot de passe</label>
                            <input type="password" class="form-control nxt" id="passwords" placeholder="Mot de passe">
                        </div>
                        <div class="form-group-sm">
                            <label>Mot de passe  (pour validation)</label>
                            <input type="password" class="form-control nxt" id="c_password" placeholder="Mot de passe  (pour validation)">
                        </div>
                        <div class="form-group-sm">
                            <label>Métier ou Poste actuel </label>
                            <input type="text" class="form-control nxt" id="current_position" value="<?php echo $position; ?>" placeholder="Métier ou Poste actuel ">
                        </div>
                        <div class="form-group-sm">
                            <label>Nombre d’années dans ce dernier poste</label>
                            <input type="text" class="form-control nxt" id="number_years_position" onkeypress="return app.numbers(event);" placeholder="Nombre d’années dans ce dernier poste">
                        </div>
                        <div class="form-group-sm">
                            <label>Date de démarrage de la mobilité AkeeN</label>
                            <input type="text" class="form-control" id="started_date" disabled=disabled value="<?php echo date("d-m-Y", strtotime('today GMT'))?>" placeholder="Date de démarrage de la mobilité AkeeN">
                        </div>
                    </div>
                    <div class="col-md-6 col-md-offset-3">
                        <br>
                        <button onclick="validate_profile();" type="button" class="btn btn-primary btn-sm valider nxt">Valider</button>
                    </div>
                    </form>
                </div>
                
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
</div>

