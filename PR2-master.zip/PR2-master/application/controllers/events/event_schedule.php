<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Event_schedule extends MY_Controller {

    public function __construct()
    {
    	        //parent::__construct();
        $this->my_controller_parent_construct();
        $this->check_session_timed_out("bo");
        //load language files
        $this->load_language_backoffice();
        $this->lang->load('backoffice/events', 'fr');
        //load model
        $this->load->model("user_activity_log_model");
        $this->load->model("event_schedule_model");
    }

    public function list_event_schedule($event_id){
        if($this->input->post() && isset($this->data["logged_in"]["user_id"])){
            $list = $this->event_schedule_model->get_all_event_schedule($event_id);
            $data = array();
            $row = array();
            foreach ($list as $event_sched) {
                $row["event_schedule_id"] = $event_sched->event_schedule_id;
                $row["start_date_time"] = $event_sched->start_date_time;
                $row["end_date_time"] = $event_sched->end_date_time;
                $row["reservation_start_date"] = $event_sched->reservation_start_date;
                $row["reservation_end_date"] = $event_sched->reservation_end_date;
                $row["event_status"] = $event_sched->event_status;
                $row["back_office_status"] = $event_sched->back_office_status;
                $row["total_available_seat"] = $event_sched->total_available_seat;
                $row["quota_waiting_list_seat"] = $event_sched->quota_waiting_list_seat;
                $row["seats_per_subscriber"] = $event_sched->seats_per_subscriber;
                $row["action"] = array(
                    "event_id" => $event_sched->event_id,
                    "event_schedule"  => array(
                            "avl_seats" => $event_sched->avl_seats,
                            "rem_seats" =>  $event_sched->rem_seats
                    )
                );
                array_push($data, $row);
            }
            $output = array(
                "draw" => $_POST['draw'],
                "data" => $data,
            );
            //output to json format
            output_to_json($this, $output);
        } else {
            show_404();
        }
    }

    public function add_event_schedule($event_id){
    	if($this->input->post() && isset($this->data["logged_in"]["user_id"])){
	        print_r($this->input->post());
	        if($this->input->post("event_schedule")){

                $event_schedule = $this->input->post("event_schedule");

                if(sizeof($event_schedule) > 0){
                    $result = $this->event_schedule_model->add_new_event_schedule($this->data["logged_in"]["user_id"], $event_id, $event_schedule);
                    if(!$result){
	                   output_to_json($this, array(
	                        "mtype" => "warning",
	                        "message" => $this->lang->line("unknown_error")
	                    ));
	                    exit();
	                }
                
                } else {
                    output_to_json($this, array(
                        "mtype" => "warning",
                        "message" => $this->lang->line("unknown_error")
                    ));
                    exit();
                }
            }
        } else {
            show_404();
        }     
    }

    public function update_event_schedule($event_schedule_id){
    	if($this->input->post() && isset($this->data["logged_in"]["user_id"])){
	        print_r($this->input->post());
	        print_r($event_schedule_id);
	        echo "hahaha no one can stop me";
        } else {
            show_404();
        }
    }

    public function delete_event_schedule($event_schedule_id){
    	if($event_schedule_id && isset($this->data["logged_in"]["user_id"])){
	        // print_r($this->input->post());
	        print_r($event_schedule_id);
	        echo "hahaha no one can stop me";
	    } else {
            show_404();
        }
    }
}