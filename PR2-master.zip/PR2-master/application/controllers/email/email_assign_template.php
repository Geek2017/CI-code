<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Email_assign_template extends MY_Controller {

    public function __construct()
    {
        $this->my_controller_parent_construct();
        $this->check_session_timed_out("bo");
        //load language files
        $this->load_language_backoffice();
        $this->lang->load('backoffice/email', 'fr');
        //load model
        $this->load->model("event_email_template_map_model");
        $this->load->model("user_activity_log_model");
        $this->load->helper('htmlpurifier');
    }

    public function get_email_assign_template_list(){
        if($this->input->post() && isset($this->data["logged_in"]["user_id"])){
            $list = $this->event_email_template_map_model->get_datatables($this->input->post());
            $data = array();
            $row = array();
            $x = $this->input->post("start");
            foreach ($list as $assign_template) {
                $row["email_tpl_order"] = ++$x;
                $row["email_type"] = $assign_template->email_type;
                $row["email_tpl_name"] = $assign_template->email_tpl_name;
                $row["events_title"] = $assign_template->events_title;
                $row["email_map_status"] = $assign_template->email_map_status;
                $row["action"] = array(
                    "email_tpl_id" => $assign_template->email_tpl_id,
                    "email_type_id" => $assign_template->email_type_id,
                    "email_map_id" => $assign_template->email_map_id,
                    "events_ids" => $assign_template->events_ids
                );
                array_push($data, $row);
            }
            $output = array(
                "draw" => $_POST['draw'],
                "recordsTotal" => $this->event_email_template_map_model->count_all($this->input->post()),
                "recordsFiltered" => $this->event_email_template_map_model->count_filtered($this->input->post()),
                "data" => $data,
            );
            //output to json format
            output_to_json($this, $output);
        } else {
            show_404();
        }
    }

    public function assign_email_template(){
        if($this->input->post() && isset($this->data["logged_in"]["user_id"])) {
            //insert data
            $email_template_map = $this->event_email_template_map_model->add_email_template_map(array(
                "email_tpl_id" => $this->input->post("email_tpl_id"),
                "email_map_author" => $this->data["logged_in"]["user_id"]
                ));
            if($email_template_map) {
                $assigned_email_template = $this->event_email_template_map_model->assign_email_template(array(
                    "email_map_id" => $email_template_map,
                    "event_id" => $this->input->post("event_id")
                ));
                if ($assigned_email_template) {
                    output_to_json($this, array(
                        "mtype" => "success",
                        "message" => $this->lang->line("save_template_assignment")
                    ));
                } else {
                    output_to_json($this, array(
                        "mtype" => "error",
                        "message" => $this->lang->line("unknown_error")
                    ));
                }
            } else {
                output_to_json($this, array(
                    "mtype" => "error",
                    "message" => $this->lang->line("unknown_error")
                ));
            }
        } else {
            show_404();
        }
    }

    public function update_assign_email_template($email_map_id){
        if($this->input->post() && isset($this->data["logged_in"]["user_id"]) && $email_map_id > 0) {
            $_POST["email_tpl_sched_author"] = $this->data["logged_in"]["user_id"];
            //udpate data
            $update_assign_template = $this->event_email_template_map_model->update_assign_email_template($email_map_id, $this->input->post());
            if ($update_assign_template) {
                output_to_json($this, array(
                    "mtype" => "success",
                    "message" => $this->lang->line("assign_template_updated")
                ));
            } else {
                output_to_json($this, array(
                    "mtype" => "error",
                    "message" => $this->lang->line("unknown_error")
                ));
            }
        } else {
            show_404();
        }
    }
    //check dependencies before deleting
    public function delete_assign_email_template($email_map_id){
        if(isset($this->data["logged_in"]["user_id"]) && $email_map_id > 0) {
            $deleted_assign_email_template = $this->event_email_template_map_model->delete_assign_email_template($email_map_id);
            if ($deleted_assign_email_template) {
                output_to_json($this, array(
                    "mtype" => "success",
                    "message" => $this->lang->line("assign_template_deleted")
                ));
            } else {
                output_to_json($this, array(
                    "mtype" => "error",
                    "message" => $this->lang->line("unknown_error")
                ));
            }
        } else {
            show_404();
        }
    }
}