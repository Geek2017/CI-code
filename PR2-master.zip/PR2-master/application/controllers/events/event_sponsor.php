<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Event_sponsor extends MY_Controller {

    public function __construct()
    {
        //parent::__construct();
        $this->my_controller_parent_construct();
        $this->check_session_timed_out("bo");
        //load language files
        $this->load_language_backoffice();
        $this->lang->load('backoffice/events', 'fr');
        //load model
        $this->load->model("user_activity_log_model");
        $this->load->model("event_sponsor_model");
        $this->load->model("event_sponsor_assignee_model");
        $this->destination = origin_folders('sponsors');
    }

    public function add_event_sponsor($event_id=0){
        if(!empty($_FILES['uploadedFiles']) && !empty($event_id) && $this->input->post() && isset($this->data["logged_in"]["user_id"])){

            //files with errors
            $errors = array();
            
            foreach ($this->input->post("info") as $key=>$value) {

                $data = json_decode($value, true);
                $uploaded = upload_event_files("sponsors", $_FILES['uploadedFiles'], $key);

                if( sizeof($uploaded) > 0 ) {
                    
                    $sponsor_id = $this->event_sponsor_model->add_event_sponsor(array(
                        "file"         =>  $uploaded["file_name"],
                        "sponsor_name" =>  $data["file_setup"]["file_name"],
                        "file_size"    =>  $uploaded["file_size"],
                        "added_by"     =>  $this->data["logged_in"]["user_id"]
                    ));

                    if( !$sponsor_id ) {
                        array_push($errors, array(
                            "file" => $data["file_setup"]["file_name"]
                        ));
                    } else {
                        //assign sponsor to event
                        $sponsor_assignee_id = $this->event_sponsor_assignee_model->add_event_sponsor_assignee(
                            array(
                                "sponsor_id"    =>  $sponsor_id,
                                "event_id"      =>  $event_id,
                                "added_by"     =>  $this->data["logged_in"]["user_id"]
                            )
                        );

                        if(!$sponsor_assignee_id){
                            array_push($errors, array(
                                "file" => $data["file_setup"]["file_name"]
                            ));
                        }
                    }
                }
            } //end of loop

            if( sizeof($errors) <=0 ) {                        
                output_to_json($this, array(
                    "mtype"  => "success",
                    "message" => "Event sponsor has been added!"
                ));                    
            } else {
                output_to_json($this, array(
                    "mtype"  => "warning",
                    "mdata" => $errors,
                    "message" => "Some files were not uploaded successfully."
                ));
            }

        } else {
            show_404();
        }
    }

    public function update_event_sponsor($sponsor_assignee_id=0){
        if(!empty($_FILES['uploadedFiles']) && !empty($sponsor_assignee_id) && $this->input->post() && isset($this->data["logged_in"]["user_id"])){

            $uploaded = upload_event_files("sponsors", $_FILES['uploadedFiles']);

            if( sizeof($uploaded) > 0 ) {

                $post = json_decode($this->input->post("info"), true);

                $update_sponsor = $this->event_sponsor_model->update_event_sponsor($post["file_setup"]["sponsor_id"], array(
                    "file"         =>  $uploaded["file_name"],
                    "sponsor_name" =>  $post["file_setup"]["file_name"],
                    "file_size"    =>  $uploaded["file_size"],
                    "date_added"   =>  date('Y-m-d H:i:s'),
                    "added_by"     =>  $this->data["logged_in"]["user_id"]
                ));

                $update_sponsor_assignee = $this->event_sponsor_assignee_model->update_event_sponsor_assignee($sponsor_assignee_id, array(
                    "date_added"   =>  date('Y-m-d H:i:s'),
                    "added_by"     =>  $this->data["logged_in"]["user_id"]
                ));

                if($update_sponsor){

                    if( $update_sponsor_assignee ) {

                        $original_file = $this->destination.$post["file_preview"];

                        if(file_exists($original_file)){
                            //delete original file
                            unlink_file($original_file);
                        }
                        output_to_json($this, array(
                            "mtype"  => "success",
                            "message" => "Event sponsor has been updated!"
                        ));                    
                    } else {
                        output_to_json($this, array(
                            "mtype"  => "error",
                            "message" => "Unable to update sponsor!"
                        ));
                    }
                } else {
                    output_to_json($this, array(
                        "mtype"  => "error",
                        "message" => "Unable to update sponsor!"
                    ));
                }
            }
        } else {
            show_404();
        }
    }

    public function delete_event_sponsor($sponsor_assignee_id=0){
        if(!empty($sponsor_assignee_id) && $this->input->post() && isset($this->data["logged_in"]["user_id"])){

            $delete_sponsor = $this->event_sponsor_model->delete_event_sponsor($this->input->post("sponsor_id"));

            if($delete_sponsor){

                //delete sponsor assignee
                $delete_sponsor_assignee = $this->event_sponsor_assignee_model->delete_event_sponsor_assignee($sponsor_assignee_id);

                if($delete_sponsor_assignee) {
                    $original_file = $this->destination.$this->input->post("file_name");

                    if( file_exists($original_file) ) {
                        //delete original file
                        unlink_file($original_file);
                    }

                    output_to_json($this, array(
                        "mtype"  => "success",
                        "message" => "Event sponsor has been deleted!"
                    ));
                } else {
                    output_to_json($this, array(
                        "mtype"  => "error",
                        "message" => "Unable to delete sponsor!"
                    ));
                }
            } else {
                output_to_json($this, array(
                    "mtype"  => "error",
                    "message" => "Unable to delete sponsor!"
                ));
            }
        } else {
            show_404();
        }
    }

    public function list_event_sponsor($event_id){
        if( $event_id && $this->input->post() && isset($this->data["logged_in"]["user_id"])){

            $list = $this->event_sponsor_assignee_model->get_datatables($this->input->post(), $event_id);
            $data = array();
            $row = array();
            $x = $this->input->post("start");
            foreach ($list as $sponsor) {
                $row["sponsor_assignee_id"] = (int)$sponsor->sponsor_assignee_id;
                $row["file_preview"] = $sponsor->file_name;
                $row["description"] = "File name : ".$sponsor->sponsor_name
                                      ."<br/>File size : ".number_format($sponsor->file_size/(1024*1024), 2,'.','').'MB'
                                      ."<br/> Author : ".$sponsor->added_by
                                      ."<br/> Date added : ".$sponsor->date_added;
                $file_setup = array(
                    "sponsor_id" => (int)$sponsor->sponsor_id,
                    "file_name" => $sponsor->file_name
                );
                $row["file_setup"] = $file_setup;
                array_push($data, $row);
            }
            $output = array(
                "draw" => $_POST['draw'],
                "recordsTotal" => $this->event_sponsor_assignee_model->count_all($this->input->post(), $event_id),
                "recordsFiltered" => $this->event_sponsor_assignee_model->count_filtered($this->input->post(), $event_id),
                "data" => $data,
            );
            //output to json format
            output_to_json($this, $output);
        } else {
            show_404();
        }
    }
}

/*
 search for move_upload_flaws, error detection, loading time
 xhr loading time when uploading large files

*/