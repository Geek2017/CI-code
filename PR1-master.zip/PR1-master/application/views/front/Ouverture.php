<div id="ov_content">
<style>
    .ov_label {
        margin-left:40px;
        font-weight: bold;
        padding-top:10px;
    }
    .cv_ov h3{
        text-align: center;
        font-family: "OpenSans-Bold" !important;
        font-size: 16pt;
    }
    .question-content {
        margin: 1px !important;
    }
</style>
<div>
<p class="ov_label"> </p>
    <div class="cv_ov">
        <?php
        $file = $this->uploads->cvlist();
        ?>
        <div class="panel panel-default">
            <div class="panel-heading">
                <h3 class="panel-title">
                    <a data-toggle="collapse" data-parent="#result_q" href="#cv">
                        CV
                </h3>
                <center class="preview">Prévisualiser</center></a>
                <a></a>
            </div>
            <div id="cv" class="panel-collapse collapse">
                <div class="panel-body">
                    <embed width="100%" height="500" src="<?php echo base_url().'uploads/'.$file['filename_orig']; ?>" type="application/pdf"></embed>
                </div>
            </div>

        </div>
    </div>
</div>
<p class="ov_label"> </p>
<div>
    <table class="table" border="1" id="cmpt" cellpadding="1" cellspacing="1" style="width:800px">
        <tbody>
        <tr class="thead">
            <td>&nbsp;</td>
            <td><strong class="global-hide">Verbes de comp&eacute;tences</strong></td>
            <td><strong>Notation</strong></td>
        </tr>
        </tbody>
    </table><br/>
</div>
<p class="ov_label"> </p>
<div>
    <table border="1" cellpadding="1" cellspacing="1" id="success_story" style="width:100%">
        <thead>
        <tr>
            <td style="text-align:center">Nb</td>
            <td>
                <p style="text-align:center"><strong>Contexte (date, poste,..)Probl&egrave;me/Mission / Objectifs personnels</strong></p>
            </td>
            <td>
                <p style="text-align:center"><strong>Evaluation personnelle de la situation</strong></p>
            </td>
            <td style="width:130px">
                <p style="text-align:center"><strong>Actions men&eacute;es</strong></p>
                <p style="text-align:center">Solutions apport&eacute;es, strat&eacute;gie, et moyens mis en &oelig;uvre;</p>
            </td>
            <td style="width:130px">
                <p style="text-align:center"><strong>R&eacute;sultats obtenus</strong></p>
                <p style="text-align:center">Quantitatifs et qualitatifs</p>
            </td>
            <td>
                <p style="text-align:center"><strong>Aptitudes r&eacute;v&eacute;l&eacute;es</strong></p>
                <p style="text-align:center">Savoir, savoir-faire, savoir &ecirc;tre Mettre des verbes &agrave; l&rsquo;infinitif Je peux &hellip;.</p>
                <p style="text-align:center"> <a href="../../main/glosaire#exemples" target="_blank">( Glossaire)</a></p>
            </td>
        </tr>
        </thead>
        <tbody>
        <tr>
        </tr>
        </tbody>
    </table>
    <p><br /></p>
    <p>&nbsp;</p>

</div>
<p class="ov_label"> </p>
<div id="piste-table">
    <table id="piste_list" class="table table-striped table-hover" border="1" cellpadding="1" cellspacing="1">
        <thead>
        <tr class="thead"><th>Titre de la piste</th>
            <th>Secteur</th>
            <th>Métier (choisir parmi la liste entreprise)</th>
            <th>Titre / fonction</th>
            <th>Missions / Objectifs</th>
            <th>Activités principales</th>
        </tr>
        </thead>
        <tbody id="body_piste">
        </tbody>
    </table>
</div>
<p class="ov_label"></p>
<div>
    <table style="width:800px" id="pitch" cellspacing="1" cellpadding="1" border="1">
        <tbody>
        <tr class="thead" style="padding: 7px !important">
            <td style="padding: 7px !important"><strong>Catégories</strong></td>
            <td style="padding: 7px !important"><strong>Définition</strong></td>
            <td style="padding: 7px !important">&nbsp;</td>
        </tr>
        <tr style="padding: 7px !important">
            <td style="padding: 7px !important"><strong>Je propose mes services en qualité de…..</strong></td>
            <td style="padding: 7px !important">Quel secteur ? Quel métier ? Quelle fonction ?</td>
            <td style="padding: 7px !important"><textarea required="" class="required_field" disabled="disabled" name="section9-1_question106_1"></textarea></td>
        </tr>
        <tr style="padding: 7px !important">
            <td style="padding: 7px !important">Mon objectif</td>
            <td style="padding: 7px !important">Quelles réponses apporter aux attentes du poste ? Quelles activités sont attendues ?</td>
            <td style="padding: 7px !important"><textarea required="" class="required_field" disabled="disabled" name="section9-1_question106_2"></textarea></td>
        </tr>
        <tr style="padding: 7px !important">
            <td style="padding: 7px !important">Mon profil, mes atouts</td>
            <td style="padding: 7px !important">Quels apports en termes d’expérience professionnelle, de formation, de compétences ?</td>
            <td style="padding: 7px !important"><textarea required="" class="required_field" disabled="disabled" name="section9-1_question106_3"></textarea></td>
        </tr>
        <tr style="padding: 7px !important">
            <td style="padding: 7px !important">Ma personnalité</td>
            <td style="padding: 7px !important">Quels apports en termes d’atouts personnels, de moteurs, de valeurs ?</td>
            <td style="padding: 7px !important"><textarea required="" class="required_field" disabled="disabled" name="section9-1_question106_4"></textarea></td>
        </tr>
        <tr style="padding: 7px !important">
            <td style="padding: 7px !important"><strong>Si mon offre vous intéresse, vous pouvez me contacter au….</strong></td>
            <td style="padding: 7px !important">Poste actuel, Direction, Adresse mail, Téléphone</td>
            <td style="padding: 7px !important"><textarea required="" class="required_field" disabled="disabled" name="section9-1_question106_5"></textarea></td>
        </tr>
        </tbody>
    </table>
</div>
<p class="ov_label"> </p>
    <div id="res_film"></div>
<p>&nbsp;</p>
</div>