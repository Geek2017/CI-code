<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Event_email_recipient_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->array = [];
    }

    public function update_recipient_email_status($data, $type){
        switch($type){
            case 1 :
                return $this->update_reminder_email_status($data);
                break;
            case 2 :
                return $this->update_reinvitation_email_status($data);
                break;
            case 3 :
                return $this->update_push_event_email_status($data);
                break;
            default :
                echo "No action has been specified.";
                exit(0);
                break;
        };
    }

    public function update_reminder_email_status($data){
        if(isset($data) && !empty($data)) {
            $update_emails = array_merge($data["sent_emails"], $data["failed_emails"]);
            $this->db->trans_start();
            $this->db->update_batch('event_email_recipient', $update_emails, 'email_recipient_id');
            $this->db->trans_complete();
            return ($this->db->trans_status() === FALSE)? FALSE:TRUE;
        }
        return false;
    }

    public function update_reinvitation_email_status($data){
        if(isset($data) && !empty($data)) {
            $update_emails = array_merge($data["sent_emails"], $data["failed_emails"]);
            $this->db->trans_start();
            $this->db->update_batch('event_email_recipient', $update_emails, 'email_recipient_id');
            $this->db->trans_complete();
            return ($this->db->trans_status() === FALSE)? FALSE:TRUE;
        }
        return false;
    }

    public function update_push_event_email_status($data){
        if(isset($data) && !empty($data)) {
            $update_emails = array_merge($data["sent_emails"], $data["failed_emails"]);
            $this->db->trans_start();
            $this->db->update_batch('event_email_custom_recipient', $update_emails, 'email_recipient_id');
            $this->db->trans_complete();
            return ($this->db->trans_status() === FALSE)? FALSE:TRUE;
        }
        return false;
    }
    /**
    * Insert new reference ids for que
    */
    public function insert_reference_ids()
    {
        $event_schedule_id = $this->input->post('event_schedule_id');
        $email_type_id = $this->input->post('email_type_id');
        $stop = 0;
        $size = sizeof( $this->input->post('reference_id') );
       
        if( is_array($this->input->post('reference_id')) 
         || is_object($this->input->post('reference_id'))){

          for( $i = $stop; $i < $size; $i++) 
             {
                 array_push($this->array,  array(
                        'event_schedule_id' => $event_schedule_id,
                        'reference_id' => $this->input->post('reference_id')[$i],
                        'email_type_id' => $email_type_id,
                        'email_status' => '0'
                 ));
             }
            $this->db->insert_batch('event_email_recipient',$this->array);
            $this->db->trans_complete();
            return ($this->db->trans_status() === FALSE)? FALSE:TRUE;
        }else{
            return false;
        }
    }
    /**
    * Create email template select option
    */
    public function get_email_template_types()
    {
        return $this->db->query("
            SELECT email_type_id, email_type, sort_order 
            FROM event_email_template_type 
            ORDER BY sort_order 
            ASC
        ")->result_array();
    }
    /*
    * Return main query for datatable
    */
    public function get_datatable($email_type_id , $event_schedule_id)
    {
       $this->result = $this->db->query($this->query_table($email_type_id, $event_schedule_id, $_POST));

       $this->cnt = 0;

        if ($this->result->num_rows() > 0) 
        {
             foreach ($this->result->result_array() as $value) {
                array_push($this->array, 
                    array
                    (
                        "no" => ++$this->cnt,
                        "first_name" => $value['first_name'],
                        "last_name" => $value['last_name'],
                        "reference_id" => $value['reference_id'],
                        "email" => $value['email'],
                        "email_status" => $value['email_status'],
                    )
                );
             }
             return array( 
                'draw' => intval( $_POST['draw'] ),
                'recordsTotal' => $this->db->count_all_results(),
                'recordsFiltered' => $this->result->num_rows(),
                'data' => $this->array 
            );
        }
    }
    /**
    *
    *  Returns Query for following lists
    *
    *
    * 1 = Event reminder
    * 2 = Reinvitation Wait List
    * 3 = Booking Confirmation/Reservation
    * 4 = Push Event
    * 5 = Booking Cancellation
    * 6 = Waitlist - Confirmation
    *
    */

    private function query_table($email_type_id , $event_schedule_id ,$post )
    {
        $sql = "";
        $limit = "";

        if( !empty($post['search']['value']) ){  
           $sql .="AND CONCAT(u.first_name,' ',u.last_name,' ',u.email_address) LIKE '%".$post['search']['value']."%' ";
        }

        //if( !empty( $post['length'] ) ){
             //$this->db->limit($_POST['length'], $_POST['start']);
            // $limit .="LIMIT ".$post['start'].",".$post['length']."";
        //}
           

        switch ($email_type_id) {

            case 1: //Event Reminder
            case 3: //Booking Confirmation/Reservation
            return "
               SELECT
                    u.email_address as email,
                    er.registration_id as reference_id,
                    u.first_name, 
                    u.last_name, 
                    er.subscriber,
                        (
                            SELECT eer.email_status
                            FROM   event_email_recipient eer
                            WHERE eer.reference_id = er.registration_id
                            AND  eer.email_type_id = ".$email_type_id."
                            AND eer.event_schedule_id = ".$event_schedule_id."
                            GROUP BY eer.reference_id
                        ) as email_status
                FROM event_registration er
                LEFT JOIN user u ON u.user_id = er.subscriber
                WHERE er.status = 1
                AND   er.event_schedule_id = ".$event_schedule_id."  
                ".$sql."
                GROUP BY er.subscriber ".$limit."
                
                
            ";
            break;

            case 4: //Push Event
            return "";
            
            // return "
            //      SELECT
            //         u.email_address as email,
            //         er.registration_id as reference_id,
            //         u.first_name, 
            //         u.last_name, 
            //         er.subscriber,
            //             (
            //                 SELECT eer.email_status
            //                 FROM   event_email_custom_recipient eecr
            //                 LEFT JOIN event_email_template eet 
            //                 ON eet.email_tpl_id = eecr.email_tpl_id
            //                 WHERE eecr.subscriber_id = u.user_id
            //                 AND  eet.email_type_id = ".$email_type_id."
            //                 AND eecr.event_schedule_id = ".$event_schedule_id."
            //                 GROUP BY eecr.reference_id
            //             ) as email_status
            //     FROM event_registration er
            //     LEFT JOIN user u ON u.user_id = er.subscriber
            //     WHERE er.status = 1
            //     AND   er.event_schedule_id = ".$event_schedule_id."  
           
            //     GROUP BY er.subscriber
            //     ".$sql."
                
            // ";
            break;

            case 5: //Booking Cancelation
            return "
                SELECT
                    u.email_address as email,
                    ed.deregistration_id as reference_id,
                    u.first_name, 
                    u.last_name, 
                    ed.subscriber,
                        (
                            SELECT eer.email_status
                            FROM   event_email_recipient eer
                            WHERE eer.reference_id = ed.deregistration_id
                            AND  eer.email_type_id = ".$email_type_id."
                            AND eer.event_schedule_id = ".$event_schedule_id."
                            GROUP BY eer.reference_id

                        ) as email_status
                    FROM event_deregistration ed
                    LEFT JOIN user u ON u.user_id = ed.subscriber
                    WHERE ed.subscriber 
                        NOT IN (SELECT er.subscriber 
                            FROM event_registration er                   
                            WHERE er.subscriber = ed.deregistration_id                    
                            AND er.status = 1 
                            AND er.event_schedule_id = ".$event_schedule_id."
                        )
                    AND  ed.event_schedule_id =".$event_schedule_id." 
                      ".$sql."
                    GROUP BY ed.subscriber  ".$limit."
                     
            ";  
            break;

            case 2: //Reinvitaion/waitlist
            case 6: //Wailist Confirmation
                return "
                    SELECT
                    u.email_address as email,
                    wl.wait_list_id as reference_id,
                    u.first_name, 
                    u.last_name, 
                    wl.wait_list_subscriber,
                        (
                            SELECT eer.email_status
                            FROM   event_email_recipient eer
                            WHERE eer.reference_id = wl.wait_list_id
                            AND  eer.email_type_id = ".$email_type_id."
                            AND eer.event_schedule_id = ".$event_schedule_id."
                            GROUP BY eer.reference_id
                        ) as email_status
                    FROM event_wait_list wl
                    LEFT JOIN user u ON u.user_id = wl.wait_list_subscriber
                    WHERE wl.status = 1
                    AND   wl.event_schedule_id = ".$event_schedule_id." 
                      ".$sql." 
                    GROUP BY wl.wait_list_subscriber  ".$limit."

                ";     
            break;
            
        }
    }
}