<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Reservations extends MY_Controller {
    
    public function __construct()
    {
        //parent::__construct();
        $this->my_controller_parent_construct();
        $this->check_session_timed_out("fo");
        $this->load_language_frontoffice();        
        $this->load->model("event_model");
    }

    public function filter_reservations()
    {
    	$this->load->model("event_registration_model");
        $client_session = $this->data['logged_in'];
        $user_id = $client_session['user_id'];
    	$month = $this->input->post('month');
        // $type = $this->input->post('type');
        $city = $this->input->post('city');
        
        $event_reservations = $this->event_registration_model->filter_reservations($user_id, $month, $city);

        $result = array (
            'mtype' => "success",
            'message' => "Data Pulled Successfully",
            'mdata' => array('events' => $event_reservations)
        );
        output_to_json($this, $result);
    }

}