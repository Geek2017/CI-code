<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Training extends CI_Controller {

    function __construct()
    {
        parent::__construct();
    }
  
    public function get_data()
    {
      $this->trainings->get_datas();
    }
    public function get_data_initial()
    {
        $this->trainings->get_datas_initial($this->input->get('initial'));
    }
    public function post_data()
    {
      $this->trainings->post_datas();
    }
    public function delete()
    {
      $this->trainings->deletes();
    }
     public function get_training()
    {
      $this->trainings->get_trainings();
    }
    public function update_data()
    {
      $this->trainings->update_datas();
    }
    public function count_training()
    {
      $this->trainings->count_trainings();
    }
}
