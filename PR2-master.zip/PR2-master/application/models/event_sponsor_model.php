<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 
	
class Event_sponsor_model extends CI_Model {

    function __construct(){
        parent::__construct();
    }

    public function add_event_sponsor($data){
        $this->db->insert("event_sponsor", $data);
        return $this->db->insert_id();
    }

    public function update_event_sponsor($sponsor_id, $data){
        $this->db->update("event_sponsor", $data, array('sponsor_id' => $sponsor_id));
        return $this->db->affected_rows();
    }

    public function delete_event_sponsor($sponsor_id){
        $this->db->update("event_sponsor", array("status" => 0), array('sponsor_id' => $sponsor_id));
        return $this->db->affected_rows();
    }
}