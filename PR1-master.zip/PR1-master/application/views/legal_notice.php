<!-- Page Content -->
<div class="container static">
    <div class="row">
        <div class="col-lg-10 col-lg-offset-1">
         <?php 
            if(isset($user_role)) {
            	if($this->session->userdata("lastname") != null){?>
                    <a class="align-left" href="<?php echo site_url('main/progress'); ?>"><img src="<?php echo base_url('assets/img/return.png'); ?>"/> Retour</a>
                        <?php } ?>
                             <?php
                        }else{
                            ?>
                          <a class="align-left" href="<?php echo site_url('main/'); ?>"><img src="<?php echo base_url('assets/img/return.png'); ?>"/> Retour</a>
                             <?php
                        }
                        ?>  
            <h1 class="text-center">Mentions l&#233;gales</h1>
        	<p>Vous &#234;tes actuellement connect&#233; au site internet <a href="<?php echo site_url('#'); ?>">www.akeeN.fr</a>. En vertu de l&#8217;article 6 de la loi n&#176; 2004-575 du 21 juin 2004 pour la Confiance dans l&#8217;&#233;conomie num&#233;rique, il est pr&#233;cis&#233; aux utilisateurs les informations suivantes :</p>
        	<p><b>&#201;diteur</b><br>
			Le site est &#233;dit&#233; par<br>
			<b>H&#233;bergeur</b></br>
			Le Site est h&#233;berg&#233; par au capital de <br>RCS<br> Si&#232;ge social : </p>
      <br>

			<p><b>Politique relative aux cookies</b><br>
			La navigation sur le site AkeeN est susceptible de provoquer, sur l&#8217;ordinateur de l&#8217;utilisateur, l&#8217;installation de cookie(s), qui enregistre(nt) des informations relatives &#224; la navigation sur le site. Les donn&#233;es ainsi obtenues visent &#224; faciliter la navigation ult&#233;rieure sur le site, et ont &#233;galement vocation &#224; permettre diverses mesures de fr&#233;quentation. Le refus d&#8217;installation d&#8217;un cookie peut dans certains cas entra&#238;ner l&#8217;impossibilit&#233; d&#8217;acc&#233;der &#224; certains services. L&#8217;utilisateur peut toutefois configurer son ordinateur pour refuser l&#8217;installation des cookies.</p><br>

			<p><b>Droit d&#8217;acc&#232;s et de rectification</b><br>
			L&#8217;utilisateur du site AkeeN reconna&#238;t disposer de la comp&#233;tence et des moyens n&#233;cessaires pour acc&#233;der et utiliser ce site. Les informations recueillies font l&#8217;objet d&#8217;un traitement informatique destin&#233; &#224; l&#8217;administration de AkeeN.<br>
			Conform&#233;ment &#224; la loi &#171; Informatique et Libert&#233;s &#187; du 6 janvier 1978 modifi&#233;e en 2004 relative &#224; l&#8217;informatique, aux fichiers et aux libert&#233;s, l&#8217;utilisateur dispose d&#8217;un droit d&#8217;acc&#232;s, de modification, de rectification et de suppression des donn&#233;es qui le concernent (article 38 et suivants de la loi &#171; Informatique et Libert&#233;s &#187; ). Pour l&#8217;exercer, l&#8217;utilisateur peut s&#8217;adresser au Service Juridique&#8230;&#8230;,<br>
			Le traitement automatis&#233; des donn&#233;es nominatives r&#233;alis&#233; &#224; partir du site Internet &#171; AkeeN &#187; a fait l&#8217;objet d&#8217;une d&#233;claration aupr&#232;s de la Commission nationale de l&#8217;informatique et des libert&#233;s (CNIL) sous le n&#176;&#8230;. </p><br>

			<p><b>Contenu Illicite</b><br>
			Tout internaute peut signaler un contenu qu&#8217;il estime illicite &#224; service-client@akeen.fr. A chaque activit&#233; est automatiquement associée un nom et un lieu permettant aux internautes de rapporter tout contenu illicite. Toute notification incompl&#232;te ou ne satisfaisant pas aux conditions impos&#233;es par l&#8217;article 6-1-5 de la Loi pour la confiance dans l&#8217;&#233;conomie num&#233;rique du 21 juin 2004 ne pourra &#234;tre consid&#233;r&#233;e comme valable. Toute notification abusive peut engager la responsabilit&#233; de son auteur. </p><br>

			<p><b>Marques et Propri&#233;t&#233; Intellectuelle</b><br>
			L&#8217;ensemble de ce site rel&#232;ve des l&#233;gislations fran&#231;aise et internationale sur le droit d&#8217;auteur et la propri&#233;t&#233; intellectuelle. Tous les droits de reproduction sont r&#233;serv&#233;s, y compris pour les documents iconographiques et photographiques. </p><br>

			<p><b>Politique de confidentialit&#233;</b></p>
        </div>        
    </div>
</div>