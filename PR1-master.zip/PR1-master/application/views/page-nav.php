<!-- Sidebar -->
<?php
$model = new Backoffices();
$personalize = $model->has_logo($this->session->userdata('org')) ? $model->has_logo($this->session->userdata('org')) : null;
$color = $personalize ? json_decode($personalize->style) : null;
?>
        <div id="sidebar-wrapper" style="<?php echo $color ? 'background:#'.$color->right_menu_bg.'; color:#'.$color->right_menu_text : ''; ?>">
            
            <div class="modal-header">
                <span id="menu-close" class="close"><a href="#" title=""><img src="<?php echo base_url('assets/img/close.png'); ?>" alt="Close"/></a></span>        
                    <img src="<?php echo $personalize ? ( file_exists('./uploads/logo/'.$personalize->logo) ? base_url().'uploads/logo/'.$personalize->logo : base_url('assets/img/logo_blue.png') ) : base_url('assets/img/logo_blue.png'); ?>"  class="modal-logo img-responsive" id="site-logo" alt="Akeen logo"/>
                </div>
                <div class="menu">
                    <ul class="main-menu">
                        <?php 
                            $menu_list = array(
                                         array('type' => 'home' , array( site_url() => mb_strtoupper('accueil') )  ) ,
                                         array('type'  => 'unset' , array( '#login' => mb_strtoupper('Se connecter') ) ),
                                         array('type'  => 'isset' , array( site_url('main/progress') => mb_strtoupper('Mon parcours') )  ),
                                         array('type'  => 'isset' , array( site_url('main/my_profile') => mb_strtoupper('Mon profil'))  ),
                                         array('type'  => 'isset' , array( site_url('referent/lists') => mb_strtoupper('Mes référents') ) ),
                                         array('type'  => 'isset' , array( site_url('main/glosaire') => mb_strtoupper('Le glossaire')) ),
                                         array('type'  => 'isset' , array( '#edit_profile' => mb_strtoupper('Mon compte') ) ),
                                         array('type'  => 'isset' , array( '#' => mb_strtoupper('Se déconnecter') ) )     
                            );

                            foreach( $menu_list as $key => $menu )
                            {
                                if ( is_array( $menu ) ) 
                                {
                                    if( $menu['type'] === 'home' || $menu['type'] === ( ( isset( $user_role ) ? 'true' : 'false' ) == 'true' ? 'isset' : 'unset' ) ){
                                        foreach ($menu[0] as $key => $value) {
                                             $logout = $value == mb_strtoupper('Se déconnecter') ? "onclick='Auth.logout();'" : "";
                                             echo "<li><a ".$logout." data-toggle=modal href=".$key.">".$value."</a></li>";
                                        }
                                    } 
                                }
                            }
                           
                        ?>  
                    </ul>

                   <ul class="social_media">
                        <li><a href="https://www.linkedin.com/"><img src="<?php echo base_url('assets/img/linkedin.png'); ?>"  class="img-responsive " alt="Linked in Logo"/></a></li>
                        <li><a href="https://twitter.com/"><img src="<?php echo base_url('assets/img/twitter.png'); ?>"  class="img-responsive " alt="Twitter Logo"/></a></li>
                        <li><a href="https://plus.google.com/"><img src="<?php echo base_url('assets/img/google-plus.png'); ?>"  class="img-responsive " alt="g+ Logo"/></a></li>
                    </ul>
                </div>
        </div>
        <!-- /#sidebar-wrapper -->
<!-- Navigation -->
    <div class="container-fluid page-nav" style="<?php echo $color ? 'background:#'.$color->header_bg.'; color:#'.$color->header_text : ''; ?>">

        <div class="container">
            <div class="row">
                <nav class="navbar" role="navigation">
                    <div class="container">
                    <div class="row">
                        <!-- Brand and toggle get grouped for better mobile display -->
                        <div class="navbar-header">
                         <?php $link = ($this->session->userdata('id')) > 0 ?  base_url('index.php/main/progress') :  base_url() ; ?>
                            <a class="navbar-brand" href="<?php echo $link; ?>"><img src="<?php echo $personalize ? ( file_exists('./uploads/logo/'.$personalize->logo) ? base_url().'uploads/logo/'.$personalize->logo : base_url('assets/img/logo_blue.png') ) : base_url('assets/img/logo_blue.png'); ?>"  class="img-responsive " id="site-logo" alt="Akeen Logo"/></a>
                        </div>
                        <!-- Collect the nav links, forms, and other content for toggling -->
                        <div class="nav navbar-nav navbar-right">
                            <a href="#" id="menu-toggle"><img src="<?php echo base_url('assets/img/menu_black.png'); ?>" alt="Menu"/></a>
                            
                        </div>
                        <!-- /.navbar-collapse -->
                        </div>
                    </div>
                    <!-- /.container -->
                </nav>
            </div>
        </div>
    </div>

    <!-- Login -->
    <div id="login" class="modal fade" role="dialog">
      <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header header-form">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true" value="Refresh">&times;</button>
                <h2 class="text-center modal-title">AKEEN</h2>
            </div>
            <div class="modal-body">
                <div class="contianer">
                    <form id="frm-login" role="form" autocomplete="off">
                        <div class="col-sm-12">
                            <div class="form-group text-center">
                               <img src="<?php echo base_url('assets/img/Photo.png'); ?>" alt="User"/>
                            </div>


                            <div class="form-group">
                                    <input type="email" id="username_first" class="form-control email nxt" required data-smk-icon="glyphicon-asterisk"
                                     value="<?php echo (  get_cookie('username') != "" ) ?  get_cookie('username') : "" ;?>"
                                     placeholder="Votre adresse e-mail">
                            </div>

                            <button type="button" id="btn-load" data-loading-text="SE CONNECTER.."  class="btn btn-primary login nxt" onclick="Auth.email_login();">SUIVANT</button>
                        </div>
                        <div class="clearfix"></div>
                    </form>
                </div>
            </div>
        </div><!-- /.modal-content -->

      </div>
    </div>
    <!-- Password -->
    <div id="password_login" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header header-form">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true" value="Refresh">&times;</button>
                    <h2 class="text-center modal-title">AKEEN</h2>
                </div>
                <div class="modal-body">
                    <div class="contianer">
                        <form id="frm-login" role="form" autocomplete="off">
                            <div class="col-sm-12">
                                <span class="glyphicon glyphicon-menu-left" onclick="Auth.back_login()"></span>
                                <div class="form-group text-center">
                                    <img src="<?php echo base_url('assets/img/Photo.png'); ?>" alt="User"/>
                                </div>


                                <div class="user_info_con">
                                    <div class="user_fullname">ace</div>
                                    <div class="user_emailadd">lab</div>
                                </div>
                                <div class="form-group">
                                    <input type="hidden" id="username" class="form-control email nxt" required data-smk-icon="glyphicon-asterisk"
                                           value="<?php echo (  get_cookie('username') != "" ) ?  get_cookie('username') : "" ;?>"
                                           placeholder="Votre adresse e-mail">
                                    <input type="password" id="password" class="form-control pwd nxt" required data-smk-icon="glyphicon-asterisk"
                                           value="<?php echo (  get_cookie('password') != "" ) ?  get_cookie('password') : "" ;?>"
                                           placeholder="Votre mot de passe">
                                </div>

                                <div class="form-group">
                                    <input id="remember" name="remember"  class="nxt"
                                        <?php echo (  get_cookie('remember') != "" ) ?  "checked='checked'" : "" ;?> type="checkbox" /> Se souvenir de moi</label>
                                    <a class="right nxt" onclick="Auth.forgot_password()" href="#">Mot de passe oublié?</a>
                                </div>

                                <button type="button" id="btn-load" data-loading-text="SE CONNECTER.."  class="btn btn-primary login nxt" onclick="Auth.login();">SE CONNECTER</button>
                            </div>
                            <div class="clearfix"></div>
                        </form>
                    </div>
                </div>
            </div><!-- /.modal-content -->

        </div>
    </div>
    <!-- Forgot Password -->
    <div id="forgot_password_modal" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header header-form">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h2 class="text-center modal-title">Mot de passe oublié</h2>
                </div>
                <div class="modal-body">
                    <div class="contianer">
                        <form id="forgotpass_form" role="form" autocomplete="off">
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <input type="email" id="email_forgot" class="form-control email nxt" required data-smk-icon="glyphicon-asterisk"

                                           placeholder="Votre adresse e-mail">
                                </div>

                                <button type="button" id="btn_forgot" data-loading-text="ENVOYER"  class="btn btn-primary login nxt" onclick="Auth.forgot_submit();">ENVOYER</button>
                            </div>
                            <div class="clearfix"></div>
                        </form>
                    </div>
                </div>
            </div><!-- /.modal-content -->

        </div>
    </div>
    <!-- Forgot Password -->
    <?php
    if(isset($forgot_password_token)) : ?>
    <div id="forgot_password_modal_t" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header header-form">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h2 class="text-center modal-title">Mot de passe oublié</h2>
                </div>
                <div class="modal-body">
                    <div class="contianer">
                        <form id="forgotpass_form_t" role="form" autocomplete="off">
                            <input type="hidden" id="token_forgot" value="<?php echo $forgot_password_token; ?>">
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label>Entrez votre nouveau mot de passe</label>
                                    <input type="password" id="password_1" class="form-control nxt" required data-smk-icon="glyphicon-asterisk"
                                           placeholder="">
                                </div>
                                <div class="form-group">
                                    <label>Confirmez le nouveau mot de passe</label>
                                    <input type="password" id="password_2" class="form-control nxt" required data-smk-icon="glyphicon-asterisk"
                                           placeholder="">
                                </div>
                                <button type="button" id="btn_forgot_t" data-loading-text="ENVOYER"  class="btn btn-primary login nxt" onclick="Auth.forgot_submit_t();">ENVOYER</button>
                            </div>
                            <div class="clearfix"></div>
                        </form>
                    </div>
                </div>
            </div><!-- /.modal-content -->

        </div>
    </div>
        <?php endif; ?>

<?php
$this->db->select('*');
$this->db->from('users');
$this->db->where('user_id',$this->session->userdata('id'));
$query = $this->db->get();

if(isset($user_role) && $this->session->userdata("lastname") != null && $query->num_rows() > 0) {
    $this->db->select('*');
    $this->db->from('users');
    $this->db->join('accounts', 'accounts.id = users.user_id');
    $this->db->where('user_id',$this->session->userdata('id'));
    $query = $this->db->get();
    $user = $query->result();
    $user = $user[0];
      ?>
<div class="modal fade" id="edit_profile">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header header-form">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true" >&times;</button>
                <h2 class="text-center modal-title">MON COMPTE</h2>
            </div>

            <div class="modal-body">
                <div class="container wc-form">
                     <div class='col-xs-5 col-md-4'>
                       <ul class="nav nav-pills nav-stacked" id="myTab">
                                <li class="active"><a href="#tab1" data-toggle="tab">Informations Personnelles</a></li>
                                <li><a href="#tab2" data-toggle="tab">Adresse</a></li>
                                <li><a href="#tab3" data-toggle="tab">Mot de passe</a></li>
                                <li><a href="#tab4" data-toggle="tab">Informations sur l'emploi</a></li>
                        </ul>
                        <div class="navDivider"></div>

                    </div>

                     <div class='col-xs-7 col-md-8 mg'>
                    <form id="formEditProfile" role="form">

                            <div class="tab-content">
                                <div class="tab-pane active" id="tab1">
                                    <div class="form-group-sm">
                                        <label>Nom :</label>
                                        <input type="text" class="form-control nxt" id="lname" placeholder="Nom" value="<?php echo $user->lastname; ?>">
                                    </div>
                                    <div class="form-group-sm">
                                        <label>Prénom :</label>
                                        <input type="text" class="form-control nxt" id="fname" placeholder="Prénom" value="<?php echo $user->firstname; ?>">
                                    </div>
                                    <div class="form-group-sm">
                                        <label>Date de naissance :</label>
                                        <input type="text" class="form-control nxt" id="bday" value="<?php echo $user->bday; ?>">
                                    </div>
                                    <div class="form-group-sm">
                                        <label>Téléphone Portable :</label>
                                        <input type="text" class="form-control nxt" id="contact" placeholder="0X XX XX XX XX" value="0<?php echo $user->contact; ?>">
                                    </div>
                                    <div class="form-group-sm">
                                        <label>Adresse Mail :</label>
                                        <input type="email" class="form-control nxt" id="email" placeholder="Adresse Mail" value="<?php echo $user->username; ?>">
                                    </div>
                                   
                                </div>
                                <div class="tab-pane" id="tab2">
                                     <div class="form-group-sm">
                                        <label>Adresse :</label>
                                        <input type="text" class="form-control nxt" id="address" placeholder="Adresse" value="<?php echo $user->address; ?>">
                                    </div>
                                    <div class="form-group-sm">
                                        <label>Code postal :</label>
                                        <input maxlength="5"  onblur="postalCodeLookup('FR');" type="text" class="form-control nxt" id="zip" placeholder="Code postal" onkeypress="return app.numbers(event);" value="<?php echo $user->zip; ?>">
                                        <span style="position: absolute; top: 20px; left: 0px; z-index:25;visibility: hidden;" id="suggestBoxElement"></span></span>
                                    </div>
                                     <div class="form-group-sm">
                                        <label>Ville :</label>
                                        <input onblur="closeSuggestBox();" type="text" class="form-control nxt" id="city" placeholder="Ville" value="<?php echo $user->city; ?>">
                                     </div>
                                    <div class="form-group-sm">
                                        <label>Pays :</label>
                                        <input type="text" class="form-control nxt" id="country" placeholder="Pays" value="<?php echo $user->country; ?>">
                                    </div>
                                </div>
                                <div class="tab-pane" id="tab3">
                                    <div class="form-group-sm">
                                        <label>Mot de passe :</label>
                                        <input type="password" class="form-control nxt" id="passwords" placeholder="Mot de passe" value="">
                                    </div>
                                    <div class="form-group-sm">
                                        <label>Mot de passe  (pour validation) :</label>
                                        <input type="password" class="form-control nxt" id="c_password" placeholder="Mot de passe  (pour validation)" value="">
                                    </div>
                                </div>
                                <div class="tab-pane" id="tab4">
                                    <div class="form-group-sm">
                                        <label>Métier ou Poste actuel :</label>
                                        <input type="text" class="form-control nxt" id="current_position" placeholder="Métier ou Poste actuel " value="<?php echo $user->position; ?>">
                                    </div>
                                    <div class="form-group-sm">
                                        <label>Nombre d’années dans ce dernier poste :</label>
                                        <input type="text" class="form-control nxt" onkeypress="return app.numbers(event);" id="number_years_position" placeholder="Nombre d’années dans ce dernier poste" value="<?php echo $user->number_year; ?>">
                                    </div>
                                    <div class="form-group-sm">
                                        <label>Date de démarrage de la mobilité AkeeN :</label>
                                        <input type="text" class="form-control" id="started_date" disabled=disabled placeholder="Date de démarrage de la mobilité AkeeN" value="<?php echo $user->started_date; ?>">
                                    </div>
                                </div>
                               
                            </div> 
                            <div class="col-md-6 col-md-offset-3 mg">
                            <br>
                            <button onclick="validate_profile();" type="button" class="btn btn-primary valider nxt">Valider</button>
                        </div>
                    </form>
                    </div>
                </div>

            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<?php } ?>

<link href="<?php echo base_url();?>assets/css/geocode.css" rel="stylesheet">
<!-- Load geonames -->
<script type="text/javascript" src="http://api.geonames.org/export/geonamesData.js?username=akeen.12345"></script>
<script type="text/javascript" src="http://api.geonames.org/export/jsr_class.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/geocode.js"></script>