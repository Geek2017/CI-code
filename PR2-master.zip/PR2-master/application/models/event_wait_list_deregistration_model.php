<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Event_wait_list_deregistration_model extends CI_Model {

	public function __construct() {
        parent::__construct();
    }

    public function deregister_waitlist($user_id, $login_id, $event_schedule_id, $user_agent)
    {
    	// Get number of reserved seats
		$reserved_seats = $this->db->select('wait_list_id, number_of_places')
			->from('event_wait_list')
			->where('event_schedule_id', $event_schedule_id)
			->where('wait_list_subscriber', $user_id)
			->where('status', 1)
			->get()
			->row();

    	$this->db->insert('event_wait_list_deregistration',
            array(
                'wait_list_id' => $reserved_seats->wait_list_id,
                'event_schedule_id' => $event_schedule_id,
                'wait_list_subscriber' => $user_id,
                'seats_reserve' => $reserved_seats->number_of_places,
                'number_of_place' => $reserved_seats->number_of_places,
                'user_agent' => $user_agent
            )
        );
		
		// Change subscriber status
    	$info = array('event_schedule_id' => $event_schedule_id, 'wait_list_subscriber' => $user_id);
		$this->db->where($info);
		$this->db->update('event_wait_list', array('status' => 0));

		// Cancel Guests
		$this->db->where('inviter_id', $user_id);
		$this->db->where('event_schedule_id', $event_schedule_id);
		$this->db->update('event_subscriber_guest', array('status' => 0));

		// Free reserved seats from taken seats
		$freed_seats = 'quota_waiting_list_seat+'.$reserved_seats->number_of_places;
		$this->db->set('quota_waiting_list_seat', $freed_seats, FALSE);
		$this->db->where('event_schedule_id', $event_schedule_id);
		$this->db->update('event_schedule');

		// Update event_status
		$check_seats = $this->db->select('quota_waiting_list_seat')
								->from('event_schedule')
								->where('event_schedule_id', $event_schedule_id)
								->get()
								->row();

		if($check_seats->quota_waiting_list_seat > 0){
			$this->db->where('event_schedule_id', $event_schedule_id);
			$this->db->update('event_schedule', array('event_status' => "AVAILABLE", 'back_office_status' => 2));
		}

		// Update event concurrent process
        $this->db->set('process_status', 0);
        $this->db->where('login_id', $login_id);
        $this->db->where('process_type', 4);
        $this->db->update('event_concurrent_process');
    }

}