<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/* CONTACTS PAGE */

// Labels
$lang['contact_customer_service'] = "Contacter le service client";
$lang['indicate_request'] = "Veuillez nous indiquer l'objet de votre demande";
$lang['select_request'] = 'Sélectionnez votre demande';
$lang['send'] = "Envoyer";