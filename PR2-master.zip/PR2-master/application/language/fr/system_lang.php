<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/* LOGIN PAGE */
$lang["login"]["username"] ="Identifiant";
$lang["login"]["email"] ="Email";
$lang["login"]["pwd"] ="Mot de passe";
$lang["login"]["btn"] = "Connexion";
$lang["login"]["remember_me"] = "Se souvenir de moi";
$lang["login"]["forgot_pwd"] = "Mot de passe perdu";
$lang["login"]["send"] = "Envoyer";
$lang["login"]["back_to_homepage"] = "Retour à la page de connexion";
$lang["login"]["enter_email"] = "Entrez votre adresse e-mail";
$lang["login"]["forgot_pass_note"] = "Indiquez ci-dessous l'e-mail avec lequel vous vous êtes inscrit ; vous recevrez un e-mail contenant un lien vous permettant de renseigner votre nouveau mot de passe";
$lang["login"]["account_activated_redirect_to_preference"] = "Votre compte est validé. Redirection vers la page de préférence en cours.";
$lang["login"]["not_lemonde_user"] = "Vous n'êtes pas un utilisateur Le Monde. Inscrivez-vous si vous ne l'avez pas déjà fait.";
$lang["login"]["email_not_registered"] = "Entré Email est pas enregistré";
$lang["login"]["email_registered"] = "Email registered.";
$lang["login"]["forgot_un_pwd"] = "Entré Email est pas enregistré";
$lang["login"]["pwd_reset_notif"] = "Réinitialisation de mot de passe";
$lang["login"]["enter_reset_code"] = "Entrez le code de réinitialisation";
$lang["login"]["fo_login_page_title"] = "Portail Le Monde -- Mot de passe oublié?";
$lang["login"]["bo_login_page_title"] = "Portail Back Office Le Monde - Mot de passe oublié?";

/* LOGIN : Front-side */
$lang["login"]["js"]["pwd_required"] = "Mot de passe requis.";
$lang["login"]["js"]["username_required"] = "Nom d'utilisateur requis.";
$lang["login"]["js"]["email_request"] = "Un email est obligatoire";
$lang["login"]["js"]["err_request"] = "Erreur dans le traitement des requêtes.";
$lang["login"]["js"]["back_to_homepage"] = "Retour à la page de connexion";

/* LOGIN : Server-side */
$lang["login"]["login_successful"] = "Redirection vers la page d'accueil . S'il vous plaît, attendez...";
$lang["login"]["invalid_account_bo"] = "Nom d'utilisateur ou mot de passe invalide.";
$lang["login"]["invalid_account_fo"] = "Adresse e-mail ou mot de passe invalide.";
$lang["login"]["redirect_to_settings"] = "Redirection vers les paramètres . S'il vous plaît, attendez...";
$lang["login"]["account_deactivated"] = "Ce compte a été désactivé.";
$lang["login"]["account_not_subscribed_yet"] = "Vous n'êtes pas encore abonné à Le Monde, veuillez vous abonner pour accéder à l'application événementiels.";

/* LOGIN : Forgot Password */
$lang["login"]["code_expired"] = "Le code n'est plus valide.";
$lang["login"]["code_valid"] = "Le code est correct. Réinitialiser votre mot de passe";
$lang["login"]["code_invalid"] = "Le code n'est pas valide. Saisir le code indiqué dans votre courriel.";
$lang["login"]["invalid_email"] = "Votre adresse email est invalide!";
$lang["login"]["enter_code"] = "Entrer le code";

/* LOGIN : Set Preferences */
$lang["preferences_set"] = "Les préférences sont définies.Redirection vers la page d'accueil...";

/* Buttons, Modals, Notifications */
$lang["account_created"] = "Le compte client est crée!";
$lang["js"]["msg"]["first_name"] = "Prénom";
$lang["js"]["msg"]["last_name"] = "Nom de famille";
$lang["js"]["msg"]["last_name_2"] = "Nom";
$lang["js"]["msg"]["guests"] = "Les invités";
$lang["js"]["msg"]["guest_details"] = "Informations des invités";
$lang["js"]["btn"]["_close"] = "Fermer";
$lang["js"]["btn"]["_confirm"] = "Confirmer";
$lang["js"]["btn"]["_continue"] = "Continuer";
$lang["js"]["btn"]["_book"] = "Réserver";
$lang["js"]["btn"]["_full"] = "Complet";
$lang["js"]["btn"]["_closed"] = "Passé";
$lang["js"]["btn"]["_cancel"] = "Annuler";
$lang["js"]["btn"]["book_waitlist"] = "S’inscrire sur la liste d’attente";
$lang["js"]["btn"]["cancel_waitlist"] = "Annuler mon inscription sur la liste d’attente";
$lang["js"]["btn"]["coming_soon"] = "Prochainement";
$lang["js"]["btn"]["open_to_registration"] = "Ouvert aux réservations";
$lang["js"]["modal"]["cma_title"] = "Confirmer Action";
$lang["js"]["modal"]["book_title"] = "Confirmation";
$lang["js"]["modal"]["msg"]["confirm_subscribe"] = "Voulez-vous inscrire à cet événement ?";
$lang['js']['modal']['msg']['confirm_unsubscribe'] = "Vous souhaitez vous désabonner de cet événement ?";
$lang['js']['modal']['msg']['confirm_subscribe_redirect_waitlist'] = "Available seats are already full. Do you want to register on the waitlist? <i style='color: red'>There is no guarantee that a seat will be freed up for the event.</i>";
$lang['js']['modal']['msg']['confirm_register_waitlist'] = "Il ne reste plus de places disponibles mais il vous est possible de vous inscrire sur la liste d'attente. Il n'y a pas de garantie qu'une place se libère pour l'événement. Voulez-vous vous inscrire à la liste d'attente?";
$lang['js']['modal']['msg']['confirm_unsubscribe_waitlist'] = "Êtes-vous certain de vouloir annuler votre inscription sur la liste d'attente?";
$lang['js']['modal']['msg']['cancel_event_subscription'] = "Les invités seront aussi retirés de la liste des inscrits à l'événement lorsque vous annulez votre inscription à l'évenement ";
$lang['js']['modal']['title']['register_title'] = "Réserver pour :";
$lang['js']['modal']['title']['cancellation_title'] = "Confirmer L'annulation";
$lang['js']['modal']['title']['register_waitlist_title'] = "Confirmer Votre Résevation en liste d'attente :";
$lang['js']['modal']['title']['cancel_registration_title'] = "Annuler votre réservation";
$lang["js"]["notif"]["sys_msg"] = "Message système";
$lang["js"]["notif"]["not_connected"] = "Vous n'êtes pas connecté";
$lang["js"]["notif"]["loading"] = "Veuillez patienter...";
$lang["js"]["notif"]["already_registered"] = "Vous êtes déjà inscrit";
$lang["js"]["notif"]["already_cancelled"] = "Vous avez déjà annulé";

/* CONFIRMATION MESSAGE */
$lang["js"]["cma_msg"]["save_changes"] = "Voulez-vous enregistrer les modifications sur cette entrée ?";
$lang["js"]["cma_msg"]["note"] = "Note: Cette action ne peut pas être annulée.";
$lang["js"]["action"]["_edit"] = "Modifier";
$lang["js"]["action"]["_attachment"] = "Attachment";
$lang["js"]["action"]["_email"] = "Set Email Template";
$lang["js"]["action"]["_delete"] = "Supprimer";
$lang["js"]["action"]["_openpreview"] = "Prévisualiser";
$lang["js"]["action"]["_export"] = "Exporter";
$lang["js"]["account"]["activated"] = "Activé";
$lang["js"]["account"]["deactivated"] = "Désactivé";
$lang["js"]["account"]["pwd_did_not_match"] = "Nouveau mot de passe et confirmer le nouveau mot de passe ne correspond !";
/* BUTTONS FOR FRONT-END */
$lang["btn"]["save_changes"] = "Sauvegarder les modifications";

//LINKS
$lang["edit"] = "Modifier";
$lang["attachment"] = "Attachment";
$lang["delete"] = "Supprimer";
$lang["preview"] = "Prévisualiser";
$lang["js"]["read_more"] = "En savoir plus";

/* BUTTONS FOR FRONT-END */
$lang["title"]["click_to_edit"] = "Cliquez pour modifier cette entrée .";
$lang["title"]["click_to_delete"] = "Cliquez pour supprimer cette entrée de façon permanente.";

/* SESSION TIMEOUT */
$lang["session_timeout"] = "Votre session a expiré. Redirection vers la page de connexion ...";

/* SERVER-SIDE ERROR MESSAGE FOR USER ACCOUNT AND USER PROFILE */
$lang["check_input"] = "Impossible d'enregistrer les données. Remplissez les champs pour continuer.";
$lang["saving_act_logs_err"] = "Impossible d'enregistrer les journaux d'activité en raison d'erreurs rencontrées .";
$lang["unknown_error_on_act_logs"] = "Impossible d'enregistrer des données dues à des erreurs rencontrées .";
$lang["unknown_error"] = "Une erreur inconnue a été rencontrée";

$lang["change_username"] = "Nom d'utilisateur a été changé";
$lang["change_pwd"] = "Le mot de passe a été changé";
$lang["change_employee_name"] = "Nom de l'employé a été changé";
$lang["change_email"] = "Adresse e-mail existe déjà";
$lang["pwd_did_not_match"] = "Mot de passe et confirmation ne correspondent pas";
$lang["username_exist"] = "Nom d'utilisateur existe déjà";
$lang["email_exist"] = "Adresse e-mail existe déjà";

/* GRID OR TABLE */
$lang['js']['no_results_found'] = 'Aucun résultat trouvé';
$lang['js']['no_match_found'] = 'Aucun événement ne correspond à vos préférences sélectionnées.';
$lang["no_records_found"] = "AUCUN ENREGISTREMENT TROUVÉ.";


/*TABLE COLUMNS*/
$lang["city_location"] = "Ville";
$lang["actions"] = "Actions";
$lang["lemonde_user"] = "Utilisateur";
$lang["admin"] = "Administrateur";
$lang["activated"] = "Activé";
$lang["deactivated"] = "Désactivé";
$lang["deactivated_permanently"] = "Supprimé définitivement";
$lang["available"] = "Disponible";
$lang["being_created"] = "En cours de création";
$lang["published"] = "Publié";
$lang["open"] = "Ouvert";
$lang["status"] = "Statut";
$lang["location"] = "Localisation";
$lang["locked"] = "Verrouillé";
$lang["closed"] = "Fermé";
$lang["archived"] = "Archivé";
$lang["terminee"] = "Terminee";
$lang["full"] = "Complet";
$lang["token"] = "Token";



/* End of file main_lang.php */
/* Location: ./application/language/main_lang.php */
