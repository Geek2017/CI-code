<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Languages extends CI_Model
{
    function __construct()
    {
        parent::__construct();
        $this->lang->load("sadmin_fr","french");
    }

    public function lang($msg) 
    {
       return $this->lang->line($msg) != "" ? ucwords( $this->lang->line($msg) ) : ucwords( $this->lang->line('no_translation') ) ;
    }
    public function populate_languages()
    {
    	 $id = $this->session->userdata('id');
         $results = $this->db->query("SELECT * FROM languages WHERE user_id='$id' order by id asc")->result_array();
         echo json_encode( $results  );
    }
    public function delete_languages()
    {
         $this->db->where('id', $this->input->post('id') );
        $this->db->delete('languages');

         echo json_encode( array(
                'message' => 'Supprimé avec succès'
         ) );
    }
    public function get_data_ids()
    {
        $data = array();

        $this->db->where('id', $this->input->post('id') );
        $query = $this->db->get("languages");
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
        }

        echo json_encode( $data );
    }
    public function add_languages()
    {

         if( trim($this->input->post('language')) == null )
         {
         	echo json_encode( array(
         		'message' => "Langue obligatoire", 
         		'refresh' => false,
         		'focus_to' => 'language'
	         	) );
         }
         // else if( $this->input->post('written') == null  )
         // {
         // 	echo json_encode( array(
         // 		'message' => "Ecrit obligatoire", 
         // 		'refresh' => false,
         // 		'focus_to' => 'written'
	        //  	) );
         // }
         // else if(  $this->input->post('oral') == null )
         // {
         // 	echo json_encode( array(
         // 		'message' => "Oral obligatoire", 
         // 		'refresh' => false,
         // 		'focus_to' => 'oral'
	        //  	) );
         // }
         // else if( (int)$this->input->post('written') > 5 )
         // {
         // 	echo json_encode( array(
         // 		'message' => "Écrit ne doit pas dépasser 5", 
         // 		'refresh' => false,
         // 		'focus_to' => 'written'
	        //  	) );
         // }
         // else if(  (int)$this->input->post('oral') > 5 )
         // {
         // 	echo json_encode( array(
         // 		'message' => "Oral ne doit pas dépasser 5", 
         // 		'refresh' => false,
         // 		'focus_to' => 'oral'
	        //  	) );
         // }
         else
         {
         	$success = $this->db->insert('languages', array( 
	         	'user_id' =>  $this->session->userdata('id') , 
	         	'language' => $this->input->post('language'), 
	         	'written' => $this->input->post('written'), 
	         	'oral' =>$this->input->post('oral'), 
	         	'native' => $this->input->post('native_') == 0 ? 0 : 1
         	));

         	if( $success ){
	         	echo  json_encode( array(
	         		'message' => "Langue ajoutée avec succès", 
	         		'refresh' => true
	         	) );
         	}
         }       
    }
    public function update_languages()
    {


         if( trim($this->input->post('language')) == null )
         {
            echo json_encode( array(
                'message' => "Langue obligatoire", 
                'refresh' => false,
                'focus_to' => 'language'
                ) );
         }
         // else if( $this->input->post('written') == null  )
         // {
         //    echo json_encode( array(
         //        'message' => "Ecrit obligatoire", 
         //        'refresh' => false,
         //        'focus_to' => 'written'
         //        ) );
         // }
         // else if(  $this->input->post('oral') == null )
         // {
         //    echo json_encode( array(
         //        'message' => "Oral obligatoire", 
         //        'refresh' => false,
         //        'focus_to' => 'oral'
         //        ) );
         // }
         // else if( (int)$this->input->post('written') > 5 )
         // {
         //    echo json_encode( array(
         //        'message' => "Écrit ne doit pas dépasser 5", 
         //        'refresh' => false,
         //        'focus_to' => 'written'
         //        ) );
         // }
         // else if(  (int)$this->input->post('oral') > 5 )
         // {
         //    echo json_encode( array(
         //        'message' => "Oral ne doit pas dépasser 5", 
         //        'refresh' => false,
         //        'focus_to' => 'oral'
         //        ) );
         // }
         else
         {
            $data = array( 
                'language' => $this->input->post('language'), 
                'written' => $this->input->post('written'), 
                'oral' =>$this->input->post('oral'), 
                'native' => $this->input->post('native_') == 0 ? 0 : 1
            );

            $this->db->where('id', $this->input->post('id'));
            $update = $this->db->update('languages', $data);

           
            echo  json_encode( array(
                'message' => "Langue ajoutée avec succès", 
                'refresh' => true
            ) );
            
         }       
    }
    public function check_empties()
    {
        $this->db->where('user_id', $this->session->userdata('id') );
        $query = $this->db->get("languages");
        echo json_encode( array( 'total' => $query->num_rows() ));
    }
    public function get_highest($native)
    {
        $this->db->where('user_id', $this->session->userdata('id') );
        $query = $this->db
                ->where('native',$native)
                ->order_by('id','desc')
                ->get("languages");
        $total_arr = [];
        foreach($query->result() as $q){
            $total_arr[] = [
                'language'  =>  $q->language,
                'total'     =>  $q->written + $q->oral
            ];
        } 
        $data = array_reduce($total_arr, function ($a, $b) {
            return @$a['total'] > $b['total'] ? $a : $b ;
        });
        echo json_encode($data);
    }
}