<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

//menus
$lang["banner_description"] = "Banner and description";
$lang["mentions_legales"] = "Mentions legales";
$lang["registration_f"] = "Registration form";
$lang["event_logo"] = "Event logo";

//template buttons defaults
$lang["upload_new"] = "Upload banner and edit description";
$lang["upload_new_banner"] = "Upload new banner";
$lang["save"] = "Save";
$lang["close"] = "Close";
$lang["apply"] = "Apply";
$lang["update"] = "Update";

//update messages
$lang["update_successful"] = "Successfully updated";
$lang["update_error"] = "Error occur";


//logo messages
$lang["upload_error_code"] = "Upload Failed with error code";
$lang["unable_determine_image_type"] = "Unable to determine image type of uploaded file";
$lang["upload_extensions_like"] = "Please upload an image with these extensions a gif/jpeg/png";
$lang["success_upload"] = "Successully uploaded";