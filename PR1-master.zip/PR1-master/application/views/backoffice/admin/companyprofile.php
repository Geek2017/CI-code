<link href="<?php echo base_url();?>assets/css/admin/companyprofile.css" rel="stylesheet">
<div id="main">
    <?php $edit_comp = $this->uri->segment(3) == 'edit' ? true : false;  ?>
    <?php if($edit_comp): echo form_open('',['id'=>'company_edit_form']);?><?php endif ?>
    <div class="admin_header">
        <div class="admin_title"><h2><?php echo $this->languages->lang('companyprofile') ?></h2></div>

        <div class="admin_button">
            <?php if($edit_comp) : ?>
                <input id="company_edit_submit" onclick="Users.update_profile(event)" class="btn btn-primary nxt" value="<?php echo $this->languages->lang('validate') ?>" style="border: 1px solid #ccc" type="submit">
                <a href="./"><button type="button" class="btn btn-primary nxt"><?php echo $this->languages->lang('cancel') ?></button></a>
            <?php else: ?>
                <a href="<?php echo ak_url().'admin/companyprofile/edit' ?>"><button class="edit_comp btn btn-primary glyphicon glyphicon-pencil"></button></a>
            <?php endif ?>
        </div>
    </div>
    <div class="row company_container">
        <?php $i = 0; ?>
        <?php foreach($data as $key => $company) : ?>
            <?php echo $edit_comp && $i == 0 ? '<input type="hidden" name="id" value="'.$company.'">' : '' ?>
            <?php if($i!=0): ?>
                    <?php echo $i % ($edit_comp ? 9 : 7) ==1 ? '<div class="col-md-6">' : '' ?>
                    <div class="<?php echo $key; ?>_c info_container">
                        <span class="<?php echo $key; ?>_label info_label">
                            <?php echo $key == 'username' ? $this->languages->lang('email') : ucwords($this->languages->lang($key)); ?>
                        </span>
                        <div class="<?php echo $key; ?> info_name <?php echo $edit_comp ? 'info_name_edit' : '' ?>">
                            <?php echo $edit_comp ?
                                '<input type="'.(strpos($key,"password") !== false ? 'password' : 'text').'" name="'.$key.'" value="'.($post ? $post[$key] :$company).'">'
                                : ( $company); ?>
                        </div>
                    </div>
                    <?php echo $i % ($edit_comp ? 9 : 7) == 0 ? '</div>' : '' ?>
                <?php endif ?>
            <?php $i++; ?>
        <?php endforeach ?>
        <div class="col-md-6">

        </div>
    </div>
        <?php if($edit_comp): ?></form><?php endif ?>
</div>