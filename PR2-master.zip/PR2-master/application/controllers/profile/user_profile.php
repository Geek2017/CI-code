<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class User_profile extends MY_Controller {

    public function __construct()
    {
        //parent::__construct();
        $this->my_controller_parent_construct();
        $this->check_session_timed_out("bo");
        //load language file
        $this->load_language_backoffice();
        $this->lang->load('backoffice/my_profile', 'fr');

        $this->load->model("user_model");
        $this->load->model("user_activity_log_model");
    }

	public function update() {
        if($this->input->post()) {
            $data = array();
            $data["mdetail"] = array();

            //old pass
            $pwd = $this->validate($_POST, "pwd");
            $new_pwd = $this->validate($_POST, "new_pwd");
            $username = $this->validate($_POST, "username");
            $email = $this->validate($_POST, "email");

            if($pwd["error"] || $new_pwd["error"] || $email["error"]) {
                if($pwd["error"]){
                    array_push($data["mdetail"], array("field" => "old_password", "message" => $pwd["message"]));
                }
                if($new_pwd["error"]){
                    array_push($data["mdetail"], array("field" => "new_password", "message" => $new_pwd["message"]));
                }
                if($username["error"]){
                    array_push($data["mdetail"], array("field" => "username", "message" => $username["message"]));
                }
                if($email["error"]){
                    array_push($data["mdetail"], array("field" => "email_address", "message" => $email["message"]));
                }

                $data["mtype"] = "error";
                $data["message"] = $this->lang->line("check_input");

                output_to_json($this, $data);
            }else{
                //no error so save the updates
                $insert = $this->user_model->update_user_profile($this->data["logged_in"], $_POST);
                if($insert){
                    $logs = $this->save_activity_logs($_POST);
                    if(!$logs["success"]) {
                        output_to_json($this, array(
                            "mtype" => "error",
                            "message" => $this->lang->line("unknown_error_on_act_logs")
                        ));
                    }else{
                        $this->update_session($_POST, $logs["changes"]);
                        output_to_json($this, array(
                            "mtype" => "success",
                            "message" => $this->lang->line("updated_profile_info")
                        ));
                    }
                }else{
                    output_to_json($this, array(
                        "mtype" => "error",
                        "message" => $this->lang->line("saving_act_logs_err")
                    ));
                }
            }
        }else{
            show_404();
        }
	}

    private function save_activity_logs($data){
        $activity_logs = "";
        $changes = array();

        if($data["new_password"]!= "" && $data["confirm_new_password"] != ""){
            //udpated password
            $activity_logs .=" - ".$this->lang->line("change_pwd")."<br/>";
            array_push($changes, "new_password");
        }
        if(!$this->user_model->check_if_something_is_changed($this->data["logged_in"]["user_id"], $data["username"], "username")){
            //udpated username
            $activity_logs .=" - ".$this->lang->line("change_username")."<br/>";
            array_push($changes, "username");
        }
        if(strtolower($this->data["logged_in"]["email_address"]) != strtolower($data["email_address"])){
            //udpated email address
            $activity_logs .=" - ".$this->lang->line("change_email")."<br/>";
            array_push($changes, "email_address");
        }
        if(strtolower($this->data["logged_in"]["fullname"]) != strtolower($data["first_name"]." ".$data["last_name"])){
            //udpated full name
            $activity_logs .=" - ".$this->lang->line("change_employee_name")."<br/>";
            array_push($changes, "fullname");
        }

        if($activity_logs != ""){

           return array("success" => $this->user_activity_log_model->add_activity_log(array(
                "description" => $activity_logs,
                "user_id"     => $this->data["logged_in"]["user_id"],
                "action"      => "EDIT",
                "table_origin"=> "user",
                "reference_id"=> $this->data["logged_in"]["user_id"]
            )),"changes" => $changes);
        }

        return array("success" => 1, "changes" => $changes);
    }
	
	private function validate($data, $query){

		$result = array("error"	=> false);
		
		switch($query){
			case "pwd" :
				$check_pwd = $this->user_model->check_password($this->data["logged_in"]["user_id"], $data["old_password"]);
				if(!$check_pwd){
					$result["error"] = true;
					$result["message"] = $this->lang->line("old_pwd_didnt_match");
				}
			break;
			
			case "new_pwd" :
				if(($data["new_password"]!= "" && $data["confirm_new_password"] != "") && (strtolower($data["new_password"]) != strtolower($data["confirm_new_password"]))){
					$result["error"] = true;
					$result["message"] = $this->lang->line("old_new_pwd_didnt_match");
				} else if(($data["new_password"] == "" && $data["confirm_new_password"] != "") || ($data["new_password"] != "" && $data["confirm_new_password"] == "")){
                    $result["error"] = true;
                    $result["message"] = $this->lang->line("old_new_pwd_didnt_match");
                }
			break;
			
			case "fullname" :
				$check_name = $this->user_model->check_password($this->data["logged_in"]["user_id"], $this->data["logged_in"]["role_id"], $data["first_name"], $data["last_name"]);
				if($check_name){
					$result["error"] = true;
					$result["message"] = $this->lang->line("full_name_didnt_match");
				}
			break;

            case "username" :
                $check_name = $this->user_model->check_username($data["username"], $this->data["logged_in"]["user_id"]);
                if($check_name){
                    $result["error"] = true;
                    $result["message"] = $this->lang->line("username_exist");
                }
                break;

            case "email" :
                $check_name = $this->user_model->check_email($data["email_address"], $this->data["logged_in"]["user_id"], array(1,2));
                if($check_name){
                    $result["error"] = true;
                    $result["message"] = $this->lang->line("email_exist");
                }
                break;
			
			default :
				$result["error"] = false;
			break;	
		}

        return $result;
	}    

    private function update_session($data, $changes){
        //get active session
        $employee_session = $this->data['logged_in'];
        // Update Session
        foreach($changes as $row){
            if($row == "fullname"){
                $employee_session["fullname"] = $data["first_name"]." ".$data["last_name"];
            }else {
                $employee_session[$row] = $data[$row];
            }
        }
        $this->session->set_userdata(array("logged_in" => $employee_session));
    }
}