 <div id="main"> 
     <div class="admin_header">
        <div class="admin_title"><h2><?php echo $this->languages->lang('spersonalize') ?></h2></div>
    </div>

    <select  class="form-control" id="choose_content" style="width : 100px; float: right;">
      <option>--select--</option>
      <option value="1">glosary</option>
      <option value="2">footer</option>
    </select><br /><br />

     <button onclick="superpersonalize.editor_savecontent(event);" class="btn btn-primary apply_changes" style="display:none;">Save Changes</button>
    <br /><br />

    <div id="editor-container">
       <div id="editor-personalized"></div>
    </div>

</div>