<?php
defined('BASEPATH') OR exit('No direct script access allowed');
include_once (dirname(__FILE__) . "/Main.php");
class Question extends Main {

    public function __construct()
    {
        parent::__construct();
   
        $this->session_checker->session_filled();
        $this->session_checker->is_user();
    }

    public function save_question_zero(){
        if($this->questions->save_questions_zero( $this->input->post("question_0") )){
            echo json_encode(array( 
                'mcontent' => 'success'
             ));
        }
    }
    public function getSectionQuestion($sectionID, $question = null)
    {
        $this->session_checker->session_filled();
        $section = $this->questions->getSectionByID($sectionID);
        $this->globalmodel->is_section_allow((int)$sectionID);
        if($section->num_rows() > 0) {
            $c_section = true;
            $view_page = stripos(current_url(),'view');
            $view_param = $view_page > 0 ? 'view/' : '';
            $segment = $view_page > 0 ? 4 : 3;
            $segment2 = $view_page > 0 ? 3 : 2;
            $logid = $this->logs->last_activity()->id;
            if($this->logs->get_startlog($logid, $section->row()->id, null)->num_rows() < 1){
                $this->logs->insert_startlog($logid,$section->row()->id, date('Y-m-d H:i:s'));
            }
            if (!$question) {
                $sec = $section->row();
                if(floor($sec->section_id) == 6 && $this->users->with_referent() == 0){
//                    $g_s = $this->globalmodel->is_section_allow($sec->section_id, 'referent');
//                    redirect('sections/' .$g_s['section_param']. '/'.$g_s['last_answered']);
                    redirect('sections/7');
                }
                $section_id = $this->questions->countQuestionBySection($sec->section_id) > 0 ? $sec->section_id : $this->questions->getNextItem($sec->section_id);
                    //$this->questions->getNextItem($this->questions->getSectionByID($sec->section_id)->row()->id);
                $section_q = $this->questions->countQuestionBySection($sec->section_id) > 0 ? 1 : '';

                $dat = json_encode([
                    'question'              => false,
                    'id'                    => $section_id,
                    'section_title'         => $sec->section_title,
                    'section_description'   => $sec->section_description,
                    'duration_time'         => $sec->duration_time,
                    'objectives'            => $sec->objectives,
                    'instructions_start'    => $sec->instructions_start,
                    'instructions_end'      => $sec->instructions_end,
                    'total_rows'            => 0,
                    'answered'              => 0,
                    'section_q'             => $section_q,
                    'section'               => $sec,
                ]);

            } else {
                $s_question = $this->questions->getQuestionBySection($sectionID);
                $s_question_count       = $s_question->num_rows();
                $config['base_url']     = site_url('sections/' . $view_param . $sectionID . '/');
                $config['total_rows']   = $s_question_count;
                $config['first_url']    = '1';
                $config['per_page']     = 1;
                $config['use_page_numbers'] = TRUE;
                $config['num_links']    = $s_question_count;
                $config['next_link']    = '<button type="button" class="btn btn-primary next">Suivant</button>';
                $config['prev_link']    = '<button type="button" class="btn btn-primary prev">Précédent</button>';
                $this->pagination->initialize($config);
                $page = $this->uri->segment($segment) ? ($this->uri->segment($segment)) : 1;
                $str_links = $this->pagination->create_links();
                $last_page =  floor($this->questions->getNextItem($sectionID))
                                > floor($this->uri->segment($segment2))
                            ||
                                floor($this->questions->getNextItem($sectionID))
                                == 0
                                ? true : false;
                $next_section = $this->questions->getNextItem($sectionID);
                $next_section_c = $page == $s_question_count ? true: false;

                $dat = json_encode([
                    'question' => true,
                    'pagination' => explode('&nbsp;', $str_links),
                    'last_page' => $last_page,
                    'total_rows' => $s_question_count,
                    'answered' => $this->questions->countAnsweredQuestion($sectionID, $this->session->userdata('id')),
                    'content' => $this->questions->fetch_data($config["per_page"], $page , $sectionID),
                    'section' => $this->questions->getSectionByID($sectionID)->row(),
                    'next_section' => $next_section,
                    'next_section_c' => $next_section_c,
                    'data' => $s_question->row()
                ]);
            }
        }else{
            $c_section = false;
            $dat = [];
        }
        $data = [
            'content'   => 'progress/section-1/section-1',
            'nav_menu'  => 'page-nav',
            'sidebar'   => 'progress/sidebar',
            'progress'  => 'progress/progress-state',
            'user_role' => $this->session->userdata('role'),
            'dat'       => $dat,
            'percent'   => $this->questions->getPercentage($this->uri->segment(2)),
            'c_section' => $c_section
        ];
        $this->load->view('progress/sec-template', $data);

    }

    public function ajax()
    {
        $type = $this->input->get("type");

        switch($type){
            case 'getQuestion':
            {
                $question = $this->input->get("id");
                $s_question = $this->db->query("SELECT * FROM questionaires where q_id='".$question."' order by q_id ASC");
                $qq = $s_question->row();
                echo json_encode($qq);
                break;
            }

            // TODO: Put backend validation [Ace]
            case 'submitAnswer':
            {
                $answer = [];
                $answer_name = [];
                foreach($this->input->post() as $name => $val){
                    array_push($answer, $val);
                    array_push($answer_name, $name);
                }
                $question_id = $answer[0];
                $final_answer = [];
                foreach($answer as $i => $val){
                    if($i != 0) {
                            $data_2 = [
                                'answer_title'       => $answer_name[$i],
                                'answer_caption'     => strlen(trim($val)) > 0 ? $val : null,
                            ];
                            array_push($final_answer, $data_2);
                    }
                }
                echo $this->questions->postAnswers($question_id, json_encode($final_answer));
                break;
            }
            /**
             * flag = 1 or 0
             * 1 = submit for referents page
             * 0 = for answering referent @ section
             */
            case 'submitReferents':
            {
                if($this->users->with_referent() != 0) {
                    $flag = $this->input->get('flag') ? 1 : 0;
                    $input = $flag ? array_values($this->input->get()) : array_values($this->input->post());
                    $x = 0;
                    $input_ten = $input[10];
                    if ($flag) {
                        unset($input[0]);
                        unset($input[1]);
                        $flag = $input_ten ? 1 : 0;
                        $this->questions->postReferents(array_values($input), 1, $flag);
                    } else {
                        for ($i = 0; $i < count($input) - 1; $i++) {
                            if (is_array($input[$i]) && count(array_filter($input[$i])) == count($input[1])) {
                                $this->questions->postReferents($input[$i], $x, $flag);
                                $x++;
                            }
                        }
                    }
                }else
                    echo ak_return('error',"Vous ne pouvez effectuer cette action suite au refus d'avis des référents");
                break;
            }
            case 'submitDisapp':
            {
                $this->questions->postDisapp($this->input->post());
                break;
            }
            case 'getDisapp':
            {
                echo ak_return('success',$this->questions->getDisapp());
                break;
            }
            case 'countSectionAnsweredQuestion':
            {
                echo ak_return('success',$this->questions->countAnsweredQuestion($this->input->get('section_id'), $this->session->userdata('id')));
                break;
            }
            case 'getAnswer':
            {
                if(is_numeric($this->input->get('id'))) {
                    $q_b = [115]; // 81
                    $result =
                        $this->questions->getAnswer(
                            in_array($this->input->get('id'), $q_b) ? $this->input->get('id') - 1
                                : $this->input->get('id'), $this->session->userdata('id')
                            , $this->input->get('option'));
                    $data_r = [];
                    if ($this->input->get('option') == 2) {
                        foreach ($result->result() as $res) {
                            if (count($res->answer_caption) > 0) {
                                foreach (json_decode($res->answer_caption) as $ans) {
                                    $data = [
                                        'answer_title' => $ans->answer_title,
                                        'answer_caption' => $ans->answer_caption != null ? $ans->answer_caption : ''
                                    ];
                                    array_push($data_r, $data);
                                }
                            }
                        }
                        $answer = json_encode($data_r);
                    } else {
                        $answer = 'null';
                        if($result = $result->row())
                            $answer = $result->answer_caption != null ? $result->answer_caption : '';
                    }
                    echo $answer;
                }
                break;
            }
            case 'getReferents':
            {
                $id = $this->input->get('id');
                if($id) {
                    $ref = $this->questions->get_referents($id)->row();
                    $data = [
                        $ref->sector,
                        $ref->company,
                        $ref->job,
                        $ref->function,
                        $ref->last_name,
                        $ref->first_name,
                        $ref->link,
                        $ref->email
                    ];
                    echo json_encode($data);
                }else{
                    $referents = $this->questions->get_referents()->result();
                    $refs = [];
                    foreach ($referents as $ref) {
                        $data = [
                            'secteur' => $ref->sector,
                            'company' => $ref->company,
                            'job' => $ref->job,
                            'function' => $ref->function,
                            'l_name' => $ref->last_name,
                            'f_name' => $ref->first_name,
                            'link' => $ref->link,
                            'mail' => $ref->email
                        ];
                        $refs[] = array_values($data);
                    }
                    echo json_encode(call_user_func_array('array_merge', $refs));
                }
                break;
            }
            case 'getReferentsList':
            {
                $pending = $this->questions->get_referents(null,1);
                $dtResult = GlobalModel::setDatatable($pending, array(
                    'sector',
                    'company',
                    'job',
                    'function',
                    'last_name',
                    'first_name',
                    'link',
                    'email',
                    'validation'
                    ),
                    'id');
                foreach ($dtResult['objResult'] as $aRow) {
                    $responded = $this->referents->get_referent_answers($aRow->id,true);
                    $data = array(
                        $aRow->sector,
                        $aRow->company,
                        $aRow->job,
                        $aRow->function,
                        $aRow->last_name,
                        $aRow->first_name,
                        $aRow->link,
                        $aRow->email,
                        $aRow->validation >= 1 ? "<span class=\"ref_validate glyphicon glyphicon-ok-sign\"></span>" : "<span class=\"ref_validate glyphicon glyphicon-remove-sign\"></span>",
                        $responded ? "<span class=\"ref_validate glyphicon glyphicon-ok-sign\"></span>" : "<span class=\"ref_validate glyphicon glyphicon-remove-sign\"></span>",
                        '<button class="edit_ref btn btn-primary glyphicon glyphicon-pencil" data-id='.$aRow->id.'></button> <button class="del_ref btn btn-primary glyphicon glyphicon-trash" data-id='.$aRow->id.' ></button> '
                    );
                    $dtResult['aaData'][] = $data;
                }
                unset($dtResult['objResult']);
                echo json_encode($dtResult);
                break;
            }
            case 'delete_referents' :
            {
                if( $this->questions->delete_referents() ){
                    echo json_encode( array( 'msg' => "Référent supprimé avec succès" ) );
                }
             break;
            }
            case 'with_referent' :
            {
                if($this->users->with_referent() == 0)
                    echo ak_return('error',"Vous ne pouvez effectuer cette action suite au refus d'avis des référents");
                else
                    echo ak_return(true,'');
                break;
            }
            case 'submit_serie' :
            {
                $data = $this->input->get();
                unset($data['type']);
                unset($data['q_id']);
                $this->questions->submit_serie($data);
                break;
            }
            case 'fetch_serie':
            {
                echo json_encode($this->questions->fetch_serie());
                break;
            }
            case 'fetch_serie_result':
            {
                echo json_encode($this->questions->fetch_serie_result());
                break;
            }
            case 'answer_left_questions':
            {
                $this->questions->answer_left_questions();
                break;
            }
            case 'ouverture':
            {
                return $this->load->view('front/Ouverture');
                break;
            }
            case 'count_ref_answers':
            {
                echo $this->users->with_referent() == 1 ? $this->referents->get_ref_answer()->num_rows() : 1;
                break;
            }
            case 'count_validated_ref_answers':
            {
                echo $this->users->with_referent() == 1 ? count($this->referents->get_referents_validated_list()) : 1;
                break;
            }
        }
    }
    public function step(){
            $this->db->where('user_id', $this->input->post('user_id'));
            $this->db->where('section_id', $this->input->post('section_id'));
            $count = $this->db->get('step');
            if ($count->num_rows() == 0) {
                $data = array(
                        'section_id' => $this->input->post('section_id'),
                        'user_id' => $this->input->post('user_id'),
                        'percentage' => $this->input->post('percentage')
                );
                if($this->input->post('section_id') != null)
                $this->db->insert('step', $data);
            }else{
                $data = array(
                        'section_id' => $this->input->post('section_id'),
                        'user_id' => $this->input->post('user_id'),
                        'percentage' => $this->input->post('percentage')
                );
                $this->db->where('user_id', $this->input->post('user_id'));
                $this->db->where('section_id', $this->input->post('section_id'));
                $this->db->update('step', $data);

            }
    }
}
