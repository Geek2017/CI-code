<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Event_type extends MY_Controller {
    public function __construct()
    {
        //parent::__construct();
        $this->my_controller_parent_construct();
        $this->check_session_timed_out("bo");
        //load language file
        $this->load_language_backoffice();
        $this->lang->load('backoffice/system_config', 'fr');

        $this->load->model("event_type_model");
        $this->load->model("user_activity_log_model");
    }

    public function add_event_type(){
        if($this->input->post()) {
            if($this->event_type_model->check_event_type($this->input->post('event_type'), "")){
                output_to_json($this, array(
                    "mtype" => "error",
                    "message" => $this->lang->line("event_pref_exist"),
                    "mdetail" => array(array("field" => "event_type", "message" => $this->lang->line("event_pref_exist")))
                ));
            } else {
                $insert_new_event_type = $this->event_type_model->add_event_type($this->input->post('event_type'));

                if($insert_new_event_type) {

                    $act_log = $this->user_activity_log_model->add_activity_log(array(
                        "description" => $this->lang->line("added_new_event_pref_log")." - ".$this->input->post('event_type'),
                        "user_id"   =>  $this->data["logged_in"]["user_id"],
                        "action"    =>  "ADD",
                        "table_origin" => "event_type",
                        "reference_id" => $insert_new_event_type
                    ));

                    if($act_log){
                        output_to_json($this, array(
                            "mtype" => "success",
                            "message" => $this->lang->line("new_event_pref_added")
                        ));
                    } else {
                        output_to_json($this, array(
                            "mtype" => "warning",
                            "message" => $this->lang->line("unknown_error")
                        ));
                    }
                } else {
                    output_to_json($this, array(
                        "mtype" => "error",
                        "message" => $this->lang->line("unable_to_save_data")
                    ));
                }
            }
        } else {
            show_404();
        }
    }

    public function edit_event_type($event_type_id){
        if($this->input->post()) {
            if($this->event_type_model->check_event_type($this->input->post('event_type'), $event_type_id)) {
                output_to_json($this, array(
                    "mtype" => "error",
                    "message" => $this->lang->line("event_pref_exist"),
                    "mdetail" => array(array("field" => "event_type", "message" => $this->lang->line("event_pref_exist")))
                ));
            } else {
                $update_event_type = $this->event_type_model->edit_event_type($event_type_id, $this->input->post('event_type'));

                if($update_event_type) {

                    $act_log = $this->user_activity_log_model->add_activity_log(array(
                        "description" => $this->lang->line("updated_event_pref")." - ".$this->input->post('event_type'),
                        "user_id"   =>  $this->data["logged_in"]["user_id"],
                        "action"    =>  "EDIT",
                        "table_origin" => "event_type",
                        "reference_id" => $event_type_id
                    ));

                    if($act_log) {
                        output_to_json($this, array(
                            "mtype" => "success",
                            "message" => $this->lang->line("event_updated")
                        ));
                    } else {
                        output_to_json($this, array(
                            "mtype" => "warning",
                            "message" => $this->lang->line("unknown_error")
                        ));
                    }
                } else {
                    output_to_json($this, array(
                        "mtype" => "error",
                        "message" => $this->lang->line("unable_to_update")
                    ));
                }
            }
        } else {
            show_404();
        }
    }

    public function delete_event_type($event_type_id){
        if($this->input->post() && $event_type_id) {
            $delete_event_type = $this->event_type_model->delete_event_type($event_type_id);
            if($delete_event_type) {
                $act_log = $this->user_activity_log_model->add_activity_log(array(
                    "description" => $this->lang->line("deleted_event_pref_log")." - ".$event_type_id,
                    "user_id" => $this->data["logged_in"]["user_id"],
                    "action" => "DELETE",
                    "table_origin" => "event_type",
                    "reference_id" => $event_type_id
                ));

                if ($act_log) {
                    output_to_json($this, array(
                        "mtype" => "success",
                        "message" => $this->lang->line("deleted_event_pref")
                    ));
                } else {
                    output_to_json($this, array(
                        "mtype" => "warning",
                        "message" => $this->lang->line("unknown_error")
                    ));
                }
            }
        } else {
            show_404();
        }
    }

    public function get_event_preference_list(){
        if($this->input->post() && $this->data["logged_in"]["user_id"]) {
            $list = $this->event_type_model->get_datatables($this->input->post());
            $data = array();
            $row = array();
            $x = $this->input->post("start");

            foreach ($list as $eventpref) {
                $row["event_type_order"] = ++$x;
                $row["event_type"] = $eventpref->event_type;
                $row["action"] = $eventpref->event_type_id;
                array_push($data, $row);
            }
            $output = array(
                "draw" => $_POST['draw'],
                "recordsTotal" => $this->event_type_model->count_all($this->input->post()),
                "recordsFiltered" => $this->event_type_model->count_filtered($this->input->post()),
                "data" => $data,
            );
            //output to json format
            output_to_json($this, $output);
        } else {
            show_404();
        }
    }
}