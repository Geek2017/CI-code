<link href="<?php echo base_url();?>assets/css/admin/companyprofile.css" rel="stylesheet">
<div id="main">
    <div class="admin_header">
        <div class="admin_title"><h2><?php echo $this->languages->lang('superprofile') ?></h2></div>
        <div class="admin_button">
             <button onclick="sadmin_profile.get_form_super_admin();" class="btn btn-primary glyphicon glyphicon-pencil"></button>
        </div>
    </div>
    <div class="row company_container">
	 <table id="samin_profile" class="table table-striped table-hover" style="width:50%">
	        <thead>
	            <tr>
	                <th></th>
	            </tr>
	        </thead>
	        <tbody>
	        	<tr>
	        		<td>Nom Prenom :</td><td id="first_lastname"><td></td>
	        	</tr>
	        	<tr>
	        		<td>Email Adresse :</td><td id="email"></td>
	        	</tr>
	        	<tr>
	        		<td>Fonction :</td><td id="fonction"></td>
	        	</tr>
	        	<tr>
	        		<td>Identifiant :</td><td id="username"></td>
	        	</tr>
	        	<tr>
	        		<td>Mot de passe :</td><td id="password"></td>
	        	</tr>
	        </tbody>
	     <table>
    </div>
</div>


<!-- Modal -->
<div class="modal fade" id="super_profile_modal" tabindex="-1" role="dialog"
     aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <!-- Modal Header -->
            <div class="modal-header" style="background-color:#337AB7; color:#FFFFFF;">
                <button type="button" class="close"
                        data-dismiss="modal">
                    <span aria-hidden="true">&times;</span>
                    <span class="sr-only">Annuler</span>
                </button>
                <h4 class="modal-title" id="myModalLabel">
                    Formulaire d'un profil
                </h4>
            </div>
            <!-- End Modal Header -->

            <!-- Modal Body -->
            <div class="modal-body profile-modal">
                <form class="form-horizontal" role="form" id="s_update_form">
                    <div class="form-group">
                        <label class=" control-label" for="firstname" >Nom</label>
                        <div class="">
                            <input  type="text" class="form-control" id="firstname" name="firstname"  placeholder=""/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class=" control-label" for="lastname" >Prénom</label>
                        <div class="">
                            <input  type="text" class="form-control" id="lastname" name="lastname"  placeholder=""/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class=" control-label" for="email" >E-mail professionnel</label>
                        <div class="">
                            <input type="text" class="form-control" id="email" name="email"  placeholder=""/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class=" control-label" for="username" >* Identifiant</label>
                        <div class="">
                            <input  type="text" class="form-control" id="username" name="username"  placeholder=""/>
                        </div>
                    </div>
                      <div class="form-group">
                        <label class=" control-label" for="password" >* Mot de passe</label>
                        <div class="">
                            <input  type="password" class="form-control" id="password" name="password"  placeholder=""/>
                        </div>
                    </div>
                     <div class="form-group">
                        <label class=" control-label" for="npass" >Nouveau mot de passe</label>
                        <div class="">
                            <input  type="password" class="form-control" id="npass" name="npass"  placeholder=""/>
                        </div>
                    </div>
                     <div class="form-group">
                        <label class=" control-label" for="cpass" >Confirmer le nouveau mot de passe</label>
                        <div class="">
                            <input  type="password" class="form-control" id="cpass" name="cpass"  placeholder=""/>
                        </div>
                    </div>
                </form>
            </div>
            <!-- End Modal Body -->

            <!-- Modal Footer -->
            <div class="modal-footer">
                <center>
                    <button type="button" class="btn btn-primary" onclick="sadmin_profile.submit_super_admin();">
                       Enregistrer les modifications
                    </button>
                    <button type="button" class="btn btn-default" data-dismiss="modal">
                       Annuler
                    </button>
                </center>

            </div>
            <!-- End Modal Footer -->

        </div>
    </div>
</div>
