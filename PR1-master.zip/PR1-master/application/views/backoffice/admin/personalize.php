<?php
 $color = $personalize ? json_decode($personalize->style) : null;
?>
<div id="main">
    <div class="row">
        <h3>Personnalisation</h3>
        <div class="table-personalize">
            <form id="personalize_form" method="post" enctype="multipart/form-data">
            <div class="table-cell-personalize logo">
                <div class="org-logo-label">Logo</div>
                <div class="logo-upload">
                    <input onchange="personalize.logo_onchange(this)" type="file" class="btn btn-primary " id="logo_file" name="logo_file"  accept="image/*" style="display:none;">
                    <button id="upload" type="button" class="btn btn-primary">Feuilleter</button>
                </div>
                <div class="org-logo">
                    <img src="<?php echo $personalize ? ( file_exists('./uploads/logo/'.$personalize->logo) ? base_url().'uploads/logo/'.$personalize->logo : base_url('assets/img/logo_blue.png') ) : base_url('assets/img/logo_blue.png'); ?>" class="img-responsive " alt="Akeen Logo">
                </div>
            </div>
            <div class="table-cell-personalize personalize-color">
                <table class="table table-striped table-hover" >
                    <thead>
                    <tr>
                        <th></th>
                        <th>Couleur de fond</th>
                        <th>Couleur du texte</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td>Entête</td>
                        <td><input name="header_bg" class="person-color jscolor {onFineChange:'update_preview_color(0,1,this)',value:'<?php echo $color ? $color->header_bg : 'ffffff'; ?>'}"></td>
                        <td><input name="header_text" class="person-color jscolor {onFineChange:'update_preview_color(0,0,this)',value:'<?php echo $color ? $color->header_text : '000000'; ?>'}"></td>
                    </tr>
                    <tr>
                        <td>Menu de Gauche</td>
                        <td><input name="left_menu_bg" class="person-color jscolor {onFineChange:'update_preview_color(1,1,this)',value:'<?php echo $color ? $color->left_menu_bg : '235079'; ?>'}"></td>
                        <td><input name="left_menu_text" class="person-color jscolor {onFineChange:'update_preview_color(1,0,this)',value:'<?php echo $color ? $color->left_menu_text : 'ffffff'; ?>'}"></td>
                    </tr>
                    <tr>
                        <td>Menu de droite</td>
                        <td><input name="right_menu_bg" class="person-color jscolor {onFineChange:'update_preview_color(2,1,this)',value:'<?php echo $color ? $color->right_menu_bg : 'ffffff'; ?>'}"></td>
                        <td><input name="right_menu_text" class="person-color jscolor {onFineChange:'update_preview_color(2,0,this)',value:'<?php echo $color ? $color->right_menu_text : '000000'; ?>'}"></td>
                    </tr>
                    <tr>
                        <td>Pied de page</td>
                        <td><input name="footer_bg" class="person-color jscolor {onFineChange:'update_preview_color(3,1,this)',value:'<?php echo $color ? $color->footer_bg : '235079'; ?>'}"></td>
                        <td><input name="footer_text" class="person-color jscolor {onFineChange:'update_preview_color(3,0,this)',value:'<?php echo $color ? $color->footer_text : 'ffffff'; ?>'}"></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                        <td><button type="button" onclick="personalize.update();" class="btn btn-primary">Mettre à jour</button></td>
                    </tr>
                    </tbody>
                </table>
        </div>
            </form>
    </div>
        <div class="preview-logo-label">Aperçu</div>
        <div class="row preview-main-con">
            <div id="header-preview" class="col-sm-12 head-foot" style="background: #<?php echo $color ? $color->header_bg : 'ffffff'; ?> none repeat scroll 0% 0%; color: #<?php echo $color ? $color->header_text : '000000'; ?>;">
                <div  class="preview-logo-con"><img src="" alt="Logo"></div>
                Entête
            </div>
            <div class="col-sm-12" style="padding: 0px;">
                <div id="left-m-preview" class="col-sm-4 preview-menu left-p" style="background: #<?php echo $color ? $color->left_menu_bg : '235079'; ?> none repeat scroll 0px 0px;  color: #<?php echo $color ? $color->left_menu_text : 'ffffff'; ?>;">
                    Menu de Gauche
                </div>
                <div class="col-sm-6">
                </div>
                <div id="right-m-preview" class="col-sm-3 preview-menu right-p" style="background: #<?php echo $color ? $color->right_menu_bg : 'ffffff'; ?> none repeat scroll 0% 0%; color: #<?php echo $color ? $color->right_menu_text : '000000'; ?>;">
                    Menu de droite
                </div>
            </div>
            <div class="clearfix"></div>
            <div id="footer-preview" class="col-sm-12 head-foot" style="background: #<?php echo $color ? $color->footer_bg : '235079'; ?> none repeat scroll 0% 0%;  color: #<?php echo $color ? $color->footer_text : 'ffffff'; ?>;">
                Pied de page
            </div>
        </div>

        <!-- Footer and Glossaire-->
           <select  class="form-control" id="choose_content" style="width : 100px; float: right;">
              <option>--select--</option>
              <option value="1">glosary</option>
              <option value="2">footer</option>
            </select><br /><br />
             <button onclick="superpersonalize.editor_savecontent(event);" class="btn btn-primary apply_changes" style="display:none;">Save Changes</button>
            <br /><br />

            <div id="editor-container">
               <div id="editor-personalized"></div>
            </div>
        <!-- End Footer and Glosaire-->
</div>
<script type="text/javascript">
$("#upload").click(function(){
    $("#logo_file").click(); 
    return false;
});
</script>


