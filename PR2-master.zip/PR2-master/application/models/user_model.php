<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class User_model extends CI_Model {

    protected $column_order = array('subscriber','u.email_address','telephone_number','mobile_number', 'location', 'status'); //set column field database for datatable orderable
    protected $column_search = array('CONCAT(u.first_name, " ", u.last_name)','u.email_address','us.location'); //set column field database for datatable searchable just firstname , lastname , address are searchable
    protected $order = array('id' => 'desc'); // default order

    public function __construct() {
        parent::__construct();
    }

    public function set_datatable_columns(){
        $this->column_order = array(null, 'employee','u.email_address','u.username','ur.name','u.status', null); //set column field database for datatable orderable
        $this->column_search = array('CONCAT(u.first_name, " ", u.last_name)','u.email_address','u.username', 'ur.name', 'u.status'); //set column field database for datatable searchable just firstname , lastname , address are searchable
        $this->order = array('u.user_id' => 'desc'); // default order
    }

    private function subscribers_list_query(){
        return "SELECT
          u.first_name,
          u.last_name,
          u.email_address,
          CONCAT(u.first_name, ' ', u.last_name) as subscriber,
          u.user_id as subscriber_id,
          us.subscriber as sub_id,
          u.email_address,
          (CASE
              WHEN u.status = 1 THEN 'Activé'
              ELSE 'Désactivé'
            END) AS status,
          us.mailing_address as address_1, us.location as city,
          (SELECT GROUP_CONCAT(et.event_type ORDER BY et.event_type ASC SEPARATOR ', ') AS event_preference
            FROM user_subscriber_event_preference usep, event_type et
            WHERE usep.subscriber_id = us.subscriber_id AND usep.event_preference = et.event_type_id) AS event_preference,
          us.email_address as sub_email_address, us.telephone_number,
          us.mobile_number, DATE_FORMAT(us.subscription_date, '%d/%m/%Y %Hh%m') as subscription_date_op, us.subscriber_id,
          (SELECT COUNT(registration_id) as number_of_registration FROM event_registration WHERE subscriber = u.user_id and status = 1) AS number_of_registration,
          (SELECT ROUND((SUM(number_of_guest+1) / COUNT(registration_id)), 2) AS avg_number_of_registration FROM event_registration WHERE subscriber = u.user_id and status = 1) AS avg_number_of_registration,
          (SELECT SUM(number_of_guest+1) AS number_of_user_and_guest FROM event_registration WHERE subscriber = u.user_id and status = 1) AS number_of_user_and_guest
          FROM user u
          LEFT JOIN user_role ur on ur.role_id = u.role_id
          LEFT JOIN user_subscriber us on us.subscriber = u.user_id
          WHERE u.status != 0
          AND u.role_id = 3 ";
    }

    private function lemonde_users_list_query(){
        return "SELECT
          u.user_id,
          u.first_name,
          u.last_name,
          u.username,
          ur.name as role_name,
          u.email_address,
          u.status as user_status,
          CONCAT((u.first_name), (' '),( u.last_name)) AS employee,
          (CASE
              WHEN u.status = 1 THEN 'Activé'
              ELSE 'Désactivé'
            END) AS status
            FROM user u
            LEFT JOIN user_role ur on ur.role_id = u.role_id
            WHERE u.status != 0
            AND u.role_id !=3
            AND u.user_id != ?";
    }

    public function _get_datatables_query($user_id, $data_source, $user_type){
        $_query = ""; $_search = ""; $_ordey_by = ""; $data = array();

        if($user_type == 3){
            $_query = $this->subscribers_list_query();
        } else {
            $_query = $this->lemonde_users_list_query();
            array_push($data, $user_id);
        }

        // if datatable send POST for search
        if($data_source['search']['value']) {
            $i = 0;
            foreach ($this->column_search as $item) {// loop column
                if($i===0){ // first loop
                    array_push($data, "%".$data_source['search']['value']."%");
                    $_search .= " AND ( ".$item." LIKE ? ";
                } else {
                    array_push($data, "%".$data_source['search']['value']."%");
                    $_search .= " OR ".$item." LIKE ? ";
                }
                $i++;
           }
            $_search .= ")";
        }

        if(isset($data_source['order'])) { // here order processing
            if(isset($data_source['order']['0']['dir'])) {
                $_ordey_by .= " ORDER BY ".$this->column_order[$data_source['order']['0']['column']]." ".$data_source['order']['0']['dir'];
            }
        } else if(isset($this->order)) {
            $_ordey_by .= " ORDER BY ".key($this->order)." ".$this->order[key($this->order)];
        }else{
            $_ordey_by="";
        }

        return array("query"=>$_query.$_search.$_ordey_by, "data" =>$data);
    }

    public function get_subscriber_information_list_export($user_id, $data_source, $user_type){
        $_query = $this->_get_datatables_query($user_id, $data_source, $user_type);
        $res= $this->db->query($_query["query"], $_query["data"])->result();
        return $res;
    }

    public function get_datatables($user_id, $data_source, $user_type){
        if($user_type!=3) { //not a subscriber
            $this->set_datatable_columns(); //initialize columns
        }
        $_query = $this->_get_datatables_query($user_id, $data_source, $user_type);

        if($data_source['length'] != -1){
            $_query["query"] .= " LIMIT ".$data_source['start'].", ".$data_source['length'];
        }
        $data = $this->db->query($_query["query"], $_query["data"]);
        return $data->result();
    }

    public function count_filtered($user_id, $data_source, $user_type){
        if($user_type!=3) { //not a subscriber
            $this->set_datatable_columns(); //initialize columns
        }
        $_query = $this->_get_datatables_query($user_id, $data_source, $user_type);
        return $this->db->query($_query["query"], $_query["data"])->num_rows();
    }

    public function count_all($user_id, $data_source, $user_type){
        if($user_type!=3) { //not a subscriber
            $this->set_datatable_columns(); //initialize columns
        }
        $_query = $this->_get_datatables_query($user_id, $data_source, $user_type);
        return $this->db->query($_query["query"], $_query["data"])->num_rows();
    }

    public function authenticate($username, $password, $utype)
    {
        $user = (sizeof($utype) > 1)?"username":"email_address";
        $where = "(password = '".$password."' OR password = sha1('".$password."'))";
        
        $this->db->select('*');
        $this->db->where($user, $username);
        //password will be checked only for lemonde emplyees
        if(!in_array(3, $utype)) {
            $this->db->where($where);
        }
        $this->db->where_in("role_id", $utype);
        //$this->db->where('status', 1);
        $this->db->limit(1);
        // print_r($result); exit;
        $query = $this->db->get("user");
        if($query->num_rows() == 1) {
            return $query->row();
        } else {
            return false;
        }
    }

    public function get_userinfo_by_email($email, $utype)
    {
        $this->db->select('*');
        $this->db->where("email_address", $email);
        $this->db->where_in("role_id", $utype);
        $this->db->limit(1);
        // print_r($result); exit;
        $query = $this->db->get("user");
        if($query->num_rows() == 1) {
            return $query->row();
        } else {
            return false;
        }
    }


    public function authenticate_remember_me($username, $password, $utype)
    {
        $user = (sizeof($utype) > 1)?"username":"email_address";
        $where = "(password = '".$password."' OR password = sha1('".$password."'))";
        
        $this->db->select('*');
        $this->db->where($user, $username);
        $this->db->where($where);
        $this->db->where_in("role_id", $utype);
        $this->db->limit(1);
        // print_r($result); exit;
        $query = $this->db->get("user");
        if($query->num_rows() == 1) {
            return $query->row();
        } else {
            return false;
        }
    }
    public function authenticate_token($user_id, $utype)
    {
        $this->db->select('*');
        $this->db->where('user_id',$user_id);
        $this->db->where_in("role_id", $utype);
        $this->db->limit(1);
        // print_r($result); exit;
        $query = $this->db->get("user");
        if($query->num_rows() == 1) {
            return $query->row();
        } else {
            return false;
        }
    }
    public function token_user_id_exist($user_id)
    {
        $this->db->select('user_id');
        $this->db->where('user_id',$user_id);
        $this->db->limit(1);
        $query  = $this->db->get('user');
        if($query->num_rows() > 0) 
            return true;
        else
            return false;
    }
    public function insert_access_token($tokens = array())
    {
         $this->db->insert("user_access_token", $tokens);
        return $this->db->insert_id();
    }
    public function update_access_token( $access_token = null )
    {
        $this->db->where("access_token", $access_token );
        $update = $this->db->update("user_access_token", [
                "date_logout"       =>  date('Y-m-d h:i:s a', time()),
                "is_active"        =>  0
            ]);
    }
    public function get_user_data($user_id, $role_id)
    {
        $this->db->select('*');
        $this->db->where('user_id', $user_id);
        $this->db->where('role_id', $role_id);
        $this->db->where('status', 1);
        $this->db->limit(1);
        $query = $this->db->get("user");
        if($query->num_rows() == 1) {
            return $query->row();
        } else {
            return false;
        }
    }

    public function check_password($user_id, $old_password){
        //check if old password is correct
        $this->db->where("user_id", $user_id);
        $this->db->where("password", sha1($old_password));
        $this->db->where("status !=", 0);
        $this->db->limit(1);
        $check_pwd = $this->db->get("user")->num_rows();
        return $check_pwd;
    }

    public function check_fullname($user_id, $role_id, $first_name, $last_name){
        $this->db->where("user_id !=", $user_id);
        $this->db->where("role_id", $role_id);
        $this->db->where("first_name", $first_name);
        $this->db->where("last_name", $last_name);
        $this->db->limit(1);
        return $this->db->get("user")->num_rows();
    }

    public function client_checkdb($email, $password)
    {
        $this->db->select("*");
        $this->db->where("email_address", $email);
        $this->db->where("password", sha1($password));
        $this->db->where("status !=", 0);
        if(isset($user_id) && !empty($user_id)){
            $this->db->where("user_id !=", $user_id);
        }
        $this->db->limit(1);
        $query = $this->db->get("user");

        if($query->num_rows() == 1) {
            return true;
        } else {
            return false;
        }
    }

    public function check_email($email, $user_id=null, $user_type=array())
    {
        $this->db->select("email_address");
        $this->db->where("email_address", $email);
        $this->db->where("status !=", 0);
        if(isset($user_id) && !empty($user_id)){
            $this->db->where("user_id !=", $user_id);
        }
        if(sizeof($user_type) > 0){
            $this->db->where_in("role_id", $user_type);
        }
        $this->db->limit(1);
        $result = $this->db->get("user")->num_rows();

        if($result > 0) {
            return true;
        } else {
            return false;
        }
    }

    public function identify_email($email, $user_role)
    {
        $this->db->select("role_id");
        $this->db->where("email_address", $email);
        $this->db->where("status !=", 0);
        $this->db->where_in("role_id", $user_role);
        $this->db->limit(1);
        $result = $this->db->get("user");

        if($result->num_rows() > 0){
            $row = $result->row();
            return $row->role_id;
        }else{
            return 0;
        }
    }

    public function check_username($username, $user_id=null)
    {
        $this->db->select("username");
        $this->db->where("username", $username);
        if(isset($user_id) && !empty($user_id)){
            $this->db->where("user_id !=", $user_id);
        }
        $this->db->where("status !=", 0);
        $this->db->limit(1);
        $query = $this->db->get("user");

        if($query->num_rows() == 1) {
            return true;
        } else {
            return false;
        }
    }

    public function check_if_something_is_changed($user_id, $data, $where_field_is)
    {
        $this->db->where("user_id", $user_id);
        $this->db->where($where_field_is, $data);
        $this->db->where("status !=", 0);
        $this->db->limit(1);
        $query = $this->db->get("user");
        if($query->num_rows() == 1){
            return true;
        } else {
            return false;
        }
    }

    public function check_if_fullname_is_changed($user_id, $first_name, $last_name)
    {
        $this->db->where("user_id", $user_id);
        $this->db->where("first_name", $first_name);
        $this->db->where("last_name", $last_name);
        $this->db->where("status !=", 0);
        $this->db->limit(1);
        $query = $this->db->get("user");
        if($query->num_rows() == 1){
            return true;
        } else {
            return false;
        }
    }

    public function update_user_profile($sess_data, $data){
        $update_data = array(
            "first_name"    =>  ucwords($data["first_name"]),
            "last_name"     =>  ucwords($data["last_name"]),
            "email_address" =>  $data["email_address"]
        );

        //check for change in password
        if($data["new_password"]!= "" && $data["confirm_new_password"] != ""){
            //udpate password
            $update_data["password"] = sha1($data["confirm_new_password"]);
        }
        //check for change in username
        if(!$this->user_model->check_if_something_is_changed($sess_data["user_id"], $data["username"], "username")){
            //udpate username
            $update_data["username"] = $data["username"];
        }

        $this->db->where("user_id", $sess_data["user_id"]);
        $update = $this->db->update("user", $update_data);

        return $update;
    }

    public function get_user_information_list($user_id, $role){
        $result = $this->db->query("
        SELECT
          u.user_id,
          u.first_name,
          u.last_name,
          u.username,
          u.email_address,
          ur.name as role_name,
          ur.role_id as role,
          u.status
        FROM
          user u
        LEFT JOIN
          user_role ur ON u.role_id = ur.role_id
        WHERE
          u.user_id != ".$user_id."
        AND u.status != 0
        AND u.role_id IN('" . implode("', '", $role) . "')");

        return $result->result();
    }

    public function get_user_information_by_user_id($user_id, $role){
        $result = $this->db->query("
        SELECT
          u.user_id,
          u.first_name,
          u.last_name,
          u.username,
          u.email_address,
          ur.name as role_name,
          u.status
        FROM
          user u
        LEFT JOIN
          user_role ur ON u.role_id = ur.role_id
        WHERE
          u.user_id = ".$user_id."
        AND
          u.role_id IN('" . implode("', '", $role) . "')
        LIMIT 1");

        return $result->row();
    }

    public function check_fullname_by_user_role($first_name, $last_name){
        $this->db->where("role_id", array(1,2));
        $this->db->where("first_name", $first_name);
        $this->db->where("last_name", $last_name);
        $this->db->where("status !=", 0);
        $this->db->limit(1);
        return $this->db->get("user")->num_rows();
    }

    public function add_new_user($data){

        $this->db->insert("user",
            array(
                "first_name"    =>  ucwords($data["first_name"]),
                "last_name"     =>  ucwords($data["last_name"]),
                "username"      =>  $data["username"],
                "email_address" =>  $data["email_address"],
                "password"      =>  sha1($data["password"]),
                "role_id"       =>  2,
                "status"        =>  1
            ));
        return $this->db->insert_id();
    }

    public function create_new_user($data){

        $this->db->insert("user",$data);
        return $this->db->insert_id();
    }

    public function edit_user_account($user_id, $data){

        $update_data = array(
            "first_name"    =>  ucwords($data["first_name"]),
            "last_name"     =>  ucwords($data["last_name"]),
            "role_id"       =>  2,
            "status"        =>  1
        );

        if(isset($data["username"]) && !empty($data["username"])){
            $update_data["username"] = $data["username"];
        }
        if(isset($data["password"]) && !empty($data["confirm_password"])){
            $update_data["password"] = sha1($data["password"]);
        }
        if(isset($data["email_address"]) && !empty($data["email_address"])){
            $update_data["email_address"] = $data["email_address"];
        }

        $this->db->where("user_id", $user_id);
        $update = $this->db->update("user",$update_data);
        return $update;
    }

    public function delete_user_account($user_id){
        $this->db->where("user_id", $user_id);
        $delete_account = $this->db->update("user", array("status" => 0));
        return $delete_account;
    }

    public function deactivate_activate_user_account($user_id,$action){
        $this->db->where("user_id", $user_id);
        $deactivate_activate = $this->db->update("user", array("status" => $action));
        return $deactivate_activate;
    }

    public function new_password($email, $password, $user_role=array(3))
    {
        $entry = array('password' => sha1($password));
        $this->db->where('email_address', $email);
        $this->db->where_in('role_id', $user_role);
        $this->db->update('user', $entry);
    }

    public function create_client_account($first, $last, $email, $username, $password)
    {
        $this->db->insert('user',
            array(
                'first_name' => ucwords($first),
                'last_name' => ucwords($last),
                'email_address' => $email,
                'role_id' => 3,
                'username' => $username,
                'password' => sha1($password)
            )
        );
        return $this->db->insert_id();
    }

    public function check_if_session_is_active($login_id, $user_id, $role_id){
        //check on history table
        if($role_id != 3) {
            $this->db->select("history_id");
            $this->db->where("history_id", $login_id);
            $this->db->where("user_id", $user_id);
            $this->db->where("description", "LOGIN");
            $this->db->where("status", 1);
            $result = $this->db->get("user_login_history");
            return $result->num_rows();
        } else if($role_id == 3) {
            //check if login_id/session has been logged out/expired already
            $this->db->where("user_id", $user_id);
            $this->db->where("description", "LOGOUT");
            $this->db->where("login_id", $login_id);
            $check_logout_session = $this->db->get("user_login_history")->num_rows();

            //check if login is active
            $this->db->where("user_id", $user_id);
            $this->db->where("description", "LOGIN");
            $this->db->where("login_id", $login_id);
            $check_login_session = $this->db->get("user_login_history")->num_rows();

            if($check_logout_session){
                //session is logged out
                return false;
            } else if($check_login_session > 0){
                //session is logged out
                return false;
            } else {
                return true;
            }
        }
        return false;
    }

    public function user_details($user_id)
    {
        $query = $this->db->select('*')
            ->from('user')
            ->where('user_id', $user_id)
            ->get()
            ->row();

        return $query;
    }

    public function remember_me($user_id, $role_id)
    {
        $user = ($role_id == 3)?"email_address":"username";
        $query = $this->db->select($user.', password')
            ->from('user')
            ->where('user_id', $user_id)
            ->where('role_id', $role_id)
            ->get()
            ->row();

        return $query;
    }
    public function delete_subscribers( $user_id = null, $status = array() )
    {
         $this->db->where("user_id", $user_id );
         $this->db->update("user" , $status );
         return $this->db->affected_rows();
    }
    public function get_subscribers($s_id = null)
    {
        $this->db->select('
        user.status, user.email_address, user.first_name, user.last_name, 
        user_subscriber.location , user_subscriber.telephone_number, user_subscriber.mobile_number,  
        user_subscriber.mailing_address, user_subscriber.subscriber')
        ->from('user')
        ->where('subscriber', $s_id)
        ->join('user_subscriber', 'user.user_id = user_subscriber.subscriber');

        $result = $this->db->get();
        if($result->num_rows() > 0){
            return $result->row();
         }
    }
    public function put_subscribers()
    {
        $user_id_subscriber_id = $this->input->post("subscriber");

        $user = array(
            'first_name' => $this->input->post("first_name"),
            'last_name' =>  $this->input->post("last_name"),
            'email_address' =>  $this->input->post("email_address"),
            'status' => $this->input->post("status")
        );

        $user_subscriber = array(
            'location' => $this->input->post("location"),
            'mailing_address' => $this->input->post("mailing_address"),
            'telephone_number' => $this->input->post("telephone_number"),
            'mobile_number' => $this->input->post("mobile_number")
        );

        $this->db->where("user_id", $user_id_subscriber_id );
        $this->db->update("user" , $user );

        $this->db->where("subscriber", $user_id_subscriber_id );
        $this->db->update("user_subscriber" , $user_subscriber );

    }

    public function check_admin_subscriber_status($user){
		$query = "select * from user_login_history ulh join user_access_token uat where  ulh.user_id='$user' and ulh.status='1' and uat.is_active='1' and ulh.description = 'LOGIN'";
		$result = $this->db->query($query);
	    if($result->num_rows() > 0){
		    return true;
	    }else{
	    	return false;
	    }
    }

}