<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 

/**
* This Class handles the sending of emails of Backoffice and Frontoffice
* Api : Mailjet
*/

require 'mailjet/vendor/autoload.php';
use \Mailjet\Resources;

class Mailjet_libr {

    protected $search = [];
    protected $replacements = [];
    
    public function __construct(){
        //$apikey = getenv('MJ_APIKEY_PUBLIC');
        //$apisecret = getenv('MJ_APIKEY_PRIVATE');

        $apikey = "f769b3e6e813f1efac4efbe21d3c56d9";
        $apisecret = "f04292fcc0d14c81d4b3e9b373b664b8";

        $this->mj = new \Mailjet\Client($apikey, $apisecret);
        // $this->mj = new \Mailjet\Client(getenv('MJ_APIKEY_PUBLIC'), getenv('MJ_APIKEY_PRIVATE'));
        $_config = array(
            "sender" => "evenements-abonnes@lemonde.fr", //kcorral@wylog.com",
            "fromName" => "Le Monde Evénements abonnés",
        );
        $this->cfg = $_config;

        $CI =& get_instance();
        $CI->lang->load('frontoffice/subscribe', 'fr');
    }

    public function fo_send_template_email($maildata) {
        //initialize vars
        $maildata["vars"] = $this->initialize_event_vars($maildata["vars"]);

        $body = [
            'FromEmail' => $this->cfg["sender"],
            'FromName' => $this->cfg["fromName"],
            'Subject' => str_replace($this->search, $this->replacements, $maildata["message"]->email_tpl_subject),
            'Html-part' => urldecode($maildata["message"]->email_tpl_detail),
            'Recipients' => [
                [
                    'Email' => $maildata["vars"]->email_address,
                    'Name'  =>  $maildata["vars"]->subscriber,
                    'Vars'  => (array) $maildata["vars"]
                ]
            ]
        ];
        $response = $this->mj->post(Resources::$Email, ['body' => $body]);
        if($response->success()) {
            
            $msgSent = (object) $response->getData();
            $processed_email = array_column($msgSent->Sent, 'MessageID', 'Email');
            
            if(isset($processed_email[$maildata["vars"]->email_address]) && !empty($processed_email[$maildata["vars"]->email_address])){

                return array(
                    "email_reference_id"    =>  $processed_email[$maildata["vars"]->email_address],
                    "email_number_of_send_attempt" => 1,
                    "email_status"  =>  1,
                    "email_description"     => "Sent!"
                    );
            } else {
                return false;
            }
        }
        else 
            return $response->getStatus();
    }

    public function fo_send_default_email($maildata) {
        
        $body = [
            'FromEmail' => $this->cfg["sender"],
            'FromName' => $this->cfg["fromName"],
            'Subject' => $maildata["subject"],
            'Html-part' => urldecode($maildata["message"]),
            'Recipients' => [
                [
                    'Email' => $maildata["recipient"],
                ]
            ]
        ];
        $response = $this->mj->post(Resources::$Email, ['body' => $body]);
        if($response->success()) {
            return $response->getData();
        }
        else 
            return $response->getStatus();
    }

    function send($data, $type){

        switch($type){
            case 1 :
                 return $this->send_reminder_email($data);
                break;
            case 2 :
                 return $this->send_waiting_list_reinvitation_email($data);
                break;
            case 3 :
                 return $this->send_push_event_emails($data);
                break;
            default :
                echo "No action has been specified.";
                exit(0);
                break;
        };
    }

    private function send_reminder_email($maildata){
        $emails = array();
        $sent_emails = array();
        $failed_emails = array();
        $mjLog = "";

        foreach ($maildata["maildata"] as $key => $value) {

            //initialize variables
            $value["event"] = $this->initialize_event_vars($value["event"]);

            $mjBODY = array(
                'FromEmail' => $this->cfg["sender"],
                'FromName' => $this->cfg["fromName"],
                'Subject' => str_replace($this->search, $this->replacements, $value["event_email_tpl"]->email_tpl_subject),
                'Html-part' => urldecode($value["event_email_tpl"]->email_tpl_detail),
                'Vars' => (array) $value["event"]
            );

            $mjBODY['Vars'] = array_merge($mjBODY['Vars'], $maildata["addVars"]);
            $mjBODY['Vars']['event_url'] = $mjBODY['Vars']['event_url'].$value["event"]->event_id;
            $mjBODY['Vars']['event_picture'] = $maildata["addVars"]['event_picture'].$value["event"]->event_picture;
            $mjBODY['Recipients'] = array();

            foreach ($value["subscribers"] as $index => $subscriber) {
                array_push($mjBODY['Recipients'], array(
                    'Email' => $subscriber->email_address,
                    'Name' => $subscriber->subscriber,
                    'Vars' => array(
                        'subscriber' => $subscriber->subscriber,
                        'new_tab_url' => $mjBODY['Vars']["base_url"]."e/r/".base64_encode($subscriber->email_recipient_id."_".$subscriber->subscriber_id)."/",
                        'email_address' => $subscriber->email_address
                    )
                ));

                //prepare processed emails
                array_push($emails, array(
                    "email_recipient_id" => $subscriber->email_recipient_id,
                    "email_address" => $subscriber->email_address,
                    "email_reference_id" => null,
                    "email_date_time" => date('Y-m-d H:i:s'),
                    "email_tpl_id" => $value["event_email_tpl"]->email_tpl_id,
                    "email_number_of_send_attempt" => $subscriber->email_number_of_send_attempt,
                    "email_status" => 0,
                ));
            }

            $sent = 0;
            $failed = 0;
            $response = $this->mj->post(Resources::$Email, array('body' => $mjBODY));
            if ($response->success()) {
                $msgSent = (object) $response->getData();
                if($msgSent->Sent){
                    $processed_emails = array_column($msgSent->Sent, 'MessageID', 'Email');
                    foreach($emails as $idx => $val){
                        //sent emails
                        if(isset($processed_emails[$val["email_address"]]) && !empty($processed_emails[$val["email_address"]])){
                            $val["email_reference_id"] = $processed_emails[$val["email_address"]];
                            $val["email_number_of_send_attempt"] +=1;
                            $val["email_status"] = 1;
                            $val["email_description"] = "Sent!";
                            unset($val["email_address"]);
                            $sent++;
                            array_push($sent_emails, $val);
                        } else { //failed emails
                            $val["email_number_of_send_attempt"] += 1;
                            $val["email_status"] = 0;
                            $val["email_description"] = "Failed!";
                            unset($val["email_address"]);
                            $failed++;
                            array_push($failed_emails, $val);
                        }
                    }
                    unset($processed_emails);
                    $emails = array();
                    $mjLog .="Email type : Reminder, Sent : ".$sent.", Failed : ".$failed.", Event_id : ".$value["event"]->event_id.", Event_schedule_id : ".$value["event"]->event_schedule_id."\n";
                } else {
                    $mjLog .="Email type : Reminder, Mj E-Code : ".$response->getStatus()." Event_id : ".$value["event"]->event_id.", Event_schedule_id : ".$value["event"]->event_schedule_id."\n";
                }
            } else {
                $mjLog .="Email type : Reminder, Mj E-Code : ".$response->getStatus()." Event_id : ".$value["event"]->event_id.", Event_schedule_id : ".$value["event"]->event_schedule_id."\n";
            }
            unset($response);
        } //end of main loop

        return array("success" => true, "sent_emails" => $sent_emails, "failed_emails" => $failed_emails, "logs" => $mjLog);
    }

    private function send_waiting_list_reinvitation_email($maildata){
        $emails = array();
        $sent_emails = array();
        $failed_emails = array();
        $mjLog = "";
        
        foreach ($maildata["maildata"] as $key => $value) {
           
            //initialize variables
            $value["event"] = $this->initialize_event_vars($value["event"]);

            $mjBODY = array(
                'FromEmail' => $this->cfg["sender"],
                'FromName' => $this->cfg["fromName"],
                'Subject' => str_replace($this->search, $this->replacements, $value["event_email_tpl"]->email_tpl_subject),
                'Html-part' => urldecode($value["event_email_tpl"]->email_tpl_detail),
                'Vars' => (array) $value["event"]
            );

            $mjBODY['Vars'] = array_merge($mjBODY['Vars'], $maildata["addVars"]);
            $mjBODY['Vars']['event_url'] = $mjBODY['Vars']['event_url'].$value["event"]->event_id;
            $mjBODY['Vars']['event_picture'] = $maildata["addVars"]['event_picture'].$value["event"]->event_picture;
            $mjBODY['Recipients'] = array();

            foreach ($value["subscribers"] as $index => $subscriber) {
                array_push($mjBODY['Recipients'], array(
                    'Email' => $subscriber->email_address,
                    'Name' => $subscriber->subscriber,
                    'Vars' => array(
                        'subscriber' => $subscriber->subscriber,
                        'new_tab_url' => $mjBODY['Vars']["base_url"]."e/wri/".base64_encode($subscriber->email_recipient_id."_".$subscriber->subscriber_id)."/",
                        'email_address' => $subscriber->email_address
                    )
                ));

                //prepare processed emails
                array_push($emails, array(
                    "email_recipient_id" => $subscriber->email_recipient_id,
                    "email_address" => $subscriber->email_address,
                    "email_reference_id" => null,
                    "email_date_time" => date('Y-m-d H:i:s'),
                    "email_tpl_id" => $value["event_email_tpl"]->email_tpl_id,
                    "email_number_of_send_attempt" => $subscriber->email_number_of_send_attempt,
                    "email_status" => 0,
                ));
            }

            $sent=0;
            $failed = 0;
            $response = $this->mj->post(Resources::$Email, array('body' => $mjBODY));
            if ($response->success()) {
                $msgSent = (object) $response->getData();
                if($msgSent->Sent){
                    $processed_emails = array_column($msgSent->Sent, 'MessageID', 'Email');
                    foreach($emails as $idx => $val){
                        //sent emails
                        if(isset($processed_emails[$val["email_address"]]) && !empty($processed_emails[$val["email_address"]])){
                            $val["email_reference_id"] = $processed_emails[$val["email_address"]];
                            $val["email_number_of_send_attempt"] +=1;
                            $val["email_status"] = 1;
                            $val["email_description"] = "Sent!";
                            unset($val["email_address"]);
                            $sent++;
                            array_push($sent_emails, $val);
                        } else { //failed emails
                            $val["email_number_of_send_attempt"] += 1;
                            $val["email_status"] = 0;
                            $val["email_description"] = "Failed!";
                            unset($val["email_address"]);
                            $failed++;
                            array_push($failed_emails, $val);
                        }
                    }
                    unset($processed_emails);
                    $emails = array();
                    $mjLog .="Email type : Waitinglist Reinvitation, Sent : ".$sent.", Failed : ".$failed.", Event_id : ".$value["event"]->event_id.", Event_schedule_id : ".$value["event"]->event_schedule_id."\n";
                } else {
                    $mjLog .="Email type : Waitinglist Reinvitation, Mj E-Code : ".$response->getStatus()." Event_id : ".$value["event"]->event_id.", Event_schedule_id : ".$value["event"]->event_schedule_id."\n";
                }
            } else {
                $mjLog .="Email type : Waitinglist Reinvitation, Mj E-Code : ".$response->getStatus()." Event_id : ".$value["event"]->event_id.", Event_schedule_id : ".$value["event"]->event_schedule_id."\n";
            }
            unset($response);
        } //end of main loop

        return array("success" => true, "sent_emails" => $sent_emails, "failed_emails" => $failed_emails, "logs" => $mjLog);
    }

    private function send_push_event_emails($maildata){
        $emails = array();
        $sent_emails = array();
        $failed_emails = array();
        $mjLog = "";
        foreach ($maildata["maildata"] as $key => $value) {
            
            //initialize variables
            $value["event"] = $this->initialize_event_vars($value["event"]);

            $mjBODY = array(
                'FromEmail' => $this->cfg["sender"],
                'FromName' => $this->cfg["fromName"],
                'Subject' => str_replace($this->search, $this->replacements, $value["event_email_tpl"]->email_tpl_subject),
                'Html-part' => urldecode($value["event_email_tpl"]->email_tpl_detail),
                'Vars' => (array) $value["event"]
            );

            $mjBODY['Vars'] = array_merge($mjBODY['Vars'], $maildata["addVars"]);
            $mjBODY['Vars']['event_url'] = $mjBODY['Vars']['event_url'].$value["event"]->event_id;
            $mjBODY['Vars']['event_picture'] = $maildata["addVars"]['event_picture'].$value["event"]->event_picture;
            $mjBODY['Recipients'] = array();

            foreach ($value["subscribers"] as $index => $subscriber) {
                array_push($mjBODY['Recipients'], array(
                    'Email' => $subscriber->email_address,
                    'Name' => $subscriber->subscriber,
                    'Vars' => array(
                        'subscriber' => $subscriber->subscriber,
                        'new_tab_url' => $mjBODY['Vars']["base_url"]."e/epe/".base64_encode($subscriber->email_recipient_id."_".$subscriber->subscriber_id)."/",
                        'email_address' => $subscriber->email_address
                    )
                ));
                
                //prepare processed emails
                array_push($emails, array(
                    "email_recipient_id" => $subscriber->email_recipient_id,
                    "email_address" => $subscriber->email_address,
                    "email_date_time" => date('Y-m-d H:i:s'),
                    "email_tpl_id" => $value["event_email_tpl"]->email_tpl_id,
                    "email_number_of_send_attempt" => $subscriber->email_number_of_send_attempt,
                    "email_status" => 0,
                ));
            }

            $sent=0;
            $failed = 0;
            $response = $this->mj->post(Resources::$Email, array('body' => $mjBODY));
            if ($response->success()) {
                $msgSent = (object) $response->getData();
                if($msgSent->Sent){
                    $processed_emails = array_column($msgSent->Sent, 'MessageID', 'Email');
                    foreach($emails as $idx => $val){
                        //sent emails
                        if(isset($processed_emails[$val["email_address"]]) && !empty($processed_emails[$val["email_address"]])){
                            $val["email_reference_id"] = $processed_emails[$val["email_address"]];
                            $val["email_number_of_send_attempt"] +=1;
                            $val["email_status"] = 1;
                            $val["email_description"] = "Sent!";
                            unset($val["email_address"]);
                            $sent++;
                            array_push($sent_emails, $val);
                        } else { //failed emails
                            $val["email_number_of_send_attempt"] += 1;
                            $val["email_status"] = 0;
                            $val["email_description"] = "Failed!";
                            unset($val["email_address"]);
                            $failed++;
                            array_push($failed_emails, $val);
                        }
                    }
                    unset($processed_emails);
                    $emails = array();
                    $mjLog .="Email type : Push event, Sent : ".$sent.", Failed : ".$failed.", Event_id : ".$value["event"]->event_id."\n";
                } else {
                    $mjLog .="Email type : Push event, Mj E-Code : ".$response->getStatus()." Event_id : ".$value["event"]->event_id."\n";
                }
            } else {
                $mjLog .="Email type : Push event, Mj E-Code : ".$response->getStatus()." Event_id : ".$value["event"]->event_id."\n";
            }
            unset($response);
        } //end of main loop

        return array("success" => true, "sent_emails" => $sent_emails, "failed_emails" => $failed_emails, "logs" => $mjLog);
    }

    public function _call(){
        // use your saved credentials
        
        // Resources are all located in the Resources class
        $response = $this->mj->get(Resources::$Contact);

        /*
        Read the response
        */
        if ($response->success())
        var_dump($response->getData());
        else
        var_dump($response->getStatus());
    }

    protected function initialize_event_vars($vars){
        $CI =& get_instance();
        $Vars = array('subscriber','email_address','event_title','event_start_day_name','event_start_day','event_start_month', 'event_start_month_name','event_start_year','event_start_hour','seats_reserved','event_start_day_name', 'city', 'event_description', 'event_venue', 'event_place_name', 'event_address', 'event_postal_code', 'event_rate', 'day', 'addressee', 'start_day', 'start_month', 'start_year', 'start_date_hour', 'subscriber', 'event_url', 'new_tab_url', 'event_picture', 'email_address');

        //for translation
        $toFR = array('day', 'event_start_month_name', 'event_start_day_name');
       
        foreach ($vars as $key => $value) {

            if (in_array($key, $Vars)) {
                //translate to french
                if(in_array($key, $toFR)){
                    $value = $CI->lang->line($value);
                    $vars->{$key} = $value;
                }

                $this->search[] = "[[var:" . $key . "]]";
                $this->replacements[] = $value;
            }
        }

        return $vars;
    }
}