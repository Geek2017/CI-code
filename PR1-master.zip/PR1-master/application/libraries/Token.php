<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Token {

        public function generate()
        {
         	$CI =& get_instance();
         	$CI->load->library('session');

			 if( !empty( $CI->session->userdata('username') ) )
			 {
			     return sha1(uniqid( $CI->session->userdata('username') , true));
			 }
        }
        public function exist($token)
        {
        	if (!empty($token) && preg_match('/^[0-9A-F]{40}$/i', $token)) 
        	{
			    return true;
			}
			else 
			{
			   return false;
			}
        }
        public function url($token)
        {
        	return base_url()."index.php/main/token/".$token;
        }
        public function expires()
        {
        	
        }
}