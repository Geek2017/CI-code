<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Event extends MY_Controller {

    public function __construct()
    {
        //parent::__construct();
        $this->my_controller_parent_construct();
        $this->check_session_timed_out("bo");
        //load language files
        $this->load_language_backoffice();
        $this->lang->load('backoffice/events', 'fr');
        //load model
        $this->load->model("event_model");
        $this->load->model("user_activity_log_model");
        $this->load->helper('htmlpurifier');
    }

    public function add_event(){
        if($this->input->post()) {
            if($this->event_model->check_event_title($this->input->post('title'), "")){
                output_to_json($this, array(
                    "mtype" => "error",
                    "message" => $this->lang->line("event_title_exist"),
                    "mdetail" =>  array(array("field" => "title", "message" => $this->lang->line("event_title_exist")))
                ));
            } else {

                $new_event_data = array();
                $new_event_data = $this->input->post();

                UNSET($new_event_data["event_attachment"], $new_event_data["speaker"], $new_event_data["event_speaker"], $new_event_data["event_sponsor"], $new_event_data["event_schedule"], $new_event_data["event-file-attachment"]);
                
                //try to insert new event in event table
                $event_id = $this->event_model->add_event($this->data["logged_in"]["user_id"], $new_event_data);

                if($event_id) {

                    $act_log = $this->user_activity_log_model->add_activity_log(array(
                        "description" => $this->lang->line("added_new_event")." - ".$this->input->post('title'),
                        "user_id"   =>  $this->data["logged_in"]["user_id"],
                        "action"    =>  "ADD",
                        "table_origin" => "event",
                        "reference_id" => $event_id
                    ));

                    //try to insert event schedules by bulk
                    $this->add_event_schedule_by_bulk($event_id);

                    //try to insert event speakers by bulk
                    $this->add_event_speaker_by_bulk($event_id);

                    //try to uplaod/insert event attachments
                    $catch = $this->add_event_sponsor_by_bulk($event_id);

                    //try to upload/insert event sponsors
                    $catch = $this->add_event_attachment_by_bulk($event_id);

                    if($act_log){
                        output_to_json($this, array(
                            "mtype" => "success",
                            "message" => $this->lang->line("added_new_event")
                        ));
                    } else {
                        output_to_json($this, array(
                            "mtype" => "warning",
                            "message" => $this->lang->line("unknown_error")
                        ));
                    }
                } else {
                    output_to_json($this, array(
                        "mtype" => "error",
                        "message" =>  $this->lang->line("unknown_error_on_saving")
                    ));
                }
            }
        } else {
            show_404();
        }
    }

    //edit event information
    public function update_event($event_id=0){
        if($this->input->post() && $event_id) {
            if($this->event_model->check_event_title($this->input->post('title'), $event_id)){
                output_to_json($this, array(
                    "mtype" => "error",
                    "message" => $this->lang->line("event_title_exist"),
                    "mdetail" =>  array(array("field" => "title", "message" => $this->lang->line("event_title_exist")))
                ));
            } else {

                $new_event_data = array();

                $new_event_data = $this->input->post();
                $new_event_data["remaining_seat"]= $this->input->post("total_available_seat");

                UNSET($new_event_data["event_attachment"], $new_event_data["speaker"], $new_event_data["event_speaker"], $new_event_data["event_sponsor"], $new_event_data["event_schedule"], $new_event_data["event-file-attachment"]);

                $update_event = $this->event_model->update_event($this->data["logged_in"]["user_id"], $new_event_data, $event_id);

                if($update_event) {
                    $act_log = $this->user_activity_log_model->add_activity_log(array(
                        "description" => $this->lang->line("updated_event")." - ".$this->input->post('title'),
                        "user_id"   =>  $this->data["logged_in"]["user_id"],
                        "action"    =>  "EDIT",
                        "table_origin" => "event",
                        "reference_id" => $event_id
                    ));

                    if($act_log){
                        output_to_json($this, array(
                            "mtype" => "success",
                            "message" => $this->lang->line("updated_event")
                        ));
                    } else {
                        output_to_json($this, array(
                            "mtype" => "warning",
                            "message" => $this->lang->line("unknown_error")
                        ));
                    }
                } else {
                    output_to_json($this, array(
                        "mtype" => "error",
                        "message" =>  $this->lang->line("unknown_error_on_saving")
                    ));
                }
            }
        } else {
            show_404();
        }
    }

    //delete event information
    public function delete_event($event_id=0){
        if($this->input->post() && $event_id) {
            $delete_event = $this->event_model->delete_event($event_id);
            if($delete_event) {
                $act_log = $this->user_activity_log_model->add_activity_log(array(
                    "description" => $this->lang->line("event_deleted")." - ".$event_id,
                    "user_id" => $this->data["logged_in"]["user_id"],
                    "action" => "DELETE",
                    "table_origin" => "event",
                    "reference_id" => $event_id
                ));

                if ($act_log) {
                    output_to_json($this, array(
                        "mtype" => "success",
                        "message" => $this->lang->line("event_deleted")
                    ));
                } else {
                    output_to_json($this, array(
                        "mtype" => "warning",
                        "message" => $this->lang->line("unknown_error")
                    ));
                }
            }
        } else {
            show_404();
        }
    }

    //add event schedule
    private function add_event_schedule_by_bulk($event_id){

        if($this->input->post("event_schedule")){

            $event_schedule = json_decode($this->input->post("event_schedule"), true);

            if(sizeof($event_schedule) > 0){

                $this->load->model("event_schedule_model");
                $result = $this->event_schedule_model->add_new_event_schedule($this->data["logged_in"]["user_id"], $event_id, $event_schedule);
            } else {
                output_to_json($this, array(
                    "mtype" => "warning",
                    "message" => $this->lang->line("unknown_error")
                ));
            }
        }
    }

    //add event speaker
    private function add_event_speaker_by_bulk($event_id){

        if($this->input->post("event_speaker")){

            $event_speaker = json_decode($this->input->post("event_speaker"), true);

            if(sizeof($event_speaker) > 0){
                $this->load->model("event_speaker_model");
                $this->load->model("event_speaker_assignee_model");
                foreach ($event_speaker as $key=>$speaker) {
                    $speaker["added_by"] = $this->data["logged_in"]["user_id"];
                    $speaker["speaker_id"] = $this->event_speaker_model->add_event_speaker($speaker, $event_id);
                    $speaker["event_id"] = $event_id;
                    $check = $this->event_speaker_assignee_model->add_new_speaker_assignee($speaker);
                    if(!$check){
                       output_to_json($this, array(
                            "mtype" => "warning",
                            "message" => $this->lang->line("unknown_error")
                        ));
                    }
                }
            } else {
                output_to_json($this, array(
                    "mtype" => "warning",
                    "message" => $this->lang->line("unknown_error")
                ));
            }
        }
    }

    //add event sponsors
    private function add_event_sponsor_by_bulk($event_id=0){
        if($this->input->post("event_sponsor") && $_FILES['event_sponsor_files'] && !empty($event_id) && isset($this->data["logged_in"]["user_id"])) {

            //load models
            $this->load->model("event_sponsor_model");
            $this->load->model("event_sponsor_assignee_model");

            //files with errors
            $errors = array();
            
            foreach ($this->input->post("event_sponsor") as $key=>$value) {

                $data = json_decode($value, true);
                $uploaded = upload_event_files("sponsors", $_FILES['event_sponsor_files'], $key);

                if( sizeof($uploaded) > 0 ) {
                    
                    $sponsor_id = $this->event_sponsor_model->add_event_sponsor(array(
                        "file"         =>  $uploaded["file_name"],
                        "sponsor_name" =>  $data["file_setup"]["file_name"],
                        "file_size"    =>  $uploaded["file_size"],
                        "added_by"     =>  $this->data["logged_in"]["user_id"]
                    ));

                    if( !$sponsor_id ) {
                        array_push($errors, array(
                            "file" => $data["file_setup"]["file_name"]
                        ));
                    } else {
                        //assign sponsor to event
                        $sponsor_assignee_id = $this->event_sponsor_assignee_model->add_event_sponsor_assignee(
                            array(
                                "sponsor_id"    =>  $sponsor_id,
                                "event_id"      =>  $event_id,
                                "added_by"     =>  $this->data["logged_in"]["user_id"]
                            )
                        );

                        if(!$sponsor_assignee_id){
                            array_push($errors, array(
                                "file" => $data["file_setup"]["file_name"]
                            ));
                        }
                    }
                }
            } //end of loop

            if( sizeof($errors) <=0 ) {                        
               return true;                  
            }
            return true; //when errors encountered

        } else {
            show_404();
        }
    }

    //add event attachments
    private function add_event_attachment_by_bulk($event_id=0){
        if(!empty($_FILES['event_attachment_files']) && $event_id && $this->input->post("event_attachment") && isset($this->data["logged_in"]["user_id"])){

            //load models
            $this->load->model("event_sponsor_model");
            $this->load->model("event_sponsor_assignee_model");
            $this->load->model("event_file_attachment_model");

            //files with errors
            $errors = array();
            
            foreach ($this->input->post("event_attachment") as $key=>$value) {

                $data = json_decode($value, true);
                $uploaded = upload_event_files("events",$_FILES['event_attachment_files'], $key);

                if( sizeof($uploaded) > 0 ) {

                    $audio_video = array();

                    //check for autoplay settings : catch if there is one
                    if( isset($data["file_setup"]["autoplay_vaudio"]) ){

                        $audio_video = array(
                            "autoplay_vaudio"   => $data["file_setup"]["autoplay_vaudio"],
                            "preview_default_image"   => (isset($data["file_setup"]["preview_default_image"]))?$data["file_setup"]["preview_default_image"]:0
                        );
                    }
                    
                    $add_status = $this->event_file_attachment_model->add_event_attachment(array(
                        "file_name" =>  $uploaded["file_name"],
                        "event_id"  =>  $event_id,
                        "mime_type" =>  $data["file_setup"]["mime_type"],
                        "description" =>  $data["file_setup"]["file_name"],
                        "attachment_type"   =>  $data["attachment_type"],
                        "file_size"         =>  $uploaded["file_size"],
                        "added_by"          =>  $this->data["logged_in"]["user_id"]
                    ), $audio_video);

                    if( !$add_status ) {
                        array_push($errors, array(
                            "file" => $data["file_setup"]["file_name"]
                        ));
                    }
                }
            } //end of loop

            if( sizeof($errors) <=0 ) {                        
                return true;                  
            }
            return false; //if errors found
        } else {
            show_404();
        }
    }

    public function event_information($event_id){
        if($this->input->post() && $event_id) {
            $result = $this->event_model->event_information($event_id);
            output_to_json($this, array(
                "mtype" => "success",
                "message" => $this->lang->line("event_info_retvd"),
                "mdata" => $result
            ));
        } else {
            show_404();
        }
    }

    public function preview_event($event_id=0){
        $this->load->model("user_model");
        if($this->input->post() && $event_id) {
            $result = $this->event_model->preview_event($event_id);
            output_to_json($this, array(
                "mtype" => "success",
                "message" => $this->lang->line("event_info_retvd"),
                "mdata" => $result
            ));
        } else {
            show_404();
        }
    }

    public function list_event($export=0){
        if($this->input->post() && isset($this->data["logged_in"]["user_id"])){
            $list = $this->event_model->get_datatables($this->input->post(), $export, 0);
            $data = array();
            $row = array();
            $x = $this->input->post("start");
            
            foreach ($list as $event) {
                $row["event_order"] = ++$x;
                $row["event_title"] = $event->event_title;
                $row["event_type"] = $event->event_type;
                $row["city"] = $event->city;
                $row["author"] = $event->author;
                $row["date_created"] = $event->date_created;
                // $row["event_status"] = $event->event_status;
                $row["action"] = array(
                    "event_id" => $event->event_id,
                    "event_schedule"  => json_decode("[".$event->event_schedule."]",true)
                );
                // $row["bo_status"] = $event->bo_status;
                array_push($data, $row);
            }
            $output = array(
                "draw" => $_POST['draw'],
                "recordsTotal" => $this->event_model->count_all($this->input->post(), $export, 0),
                "recordsFiltered" => $this->event_model->count_filtered($this->input->post(), $export,0),
                "data" => $data,
            );
            //output to json format
            output_to_json($this, $output);
        } else {
            show_404();
        }
    }

    public function typeahead_event(){
        if($this->input->post("search")) {
            output_to_json($this, $this->event_model->list_events_for_typeahead($this->input->post("search")));
        }
    }
}