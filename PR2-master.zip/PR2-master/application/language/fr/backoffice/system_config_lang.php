<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/* USER ACCOUNTS MANAGEMENT */

//BUTTONS
$lang["add_new_user"] = "Ajouter un nouvel utilisateur";
$lang["update_profile"] = "Mettre à jour le profil";

//TABLE COLUMNS
$lang["employee"] = "Employé";
$lang["email_address"] = "Adresse e-mail";
$lang["role"] = "Fonction";
$lang["username"] = "Identifiant";
$lang["status"] = "Statut";

//LINKS
$lang["edit"] = "Modifier";
$lang["delete"] = "Supprimer";


//FIELDS
$lang["first_name"] = "Prénom";
$lang["last_name"] = "Nom de famille";
$lang["email_address"] = "Adresse e-mail";
$lang["username"] = "Identifiant";
$lang["pwd"] = "Mot de passe";
$lang["confirm_pwd"] = "Confirmez le mot de passe";

// CONFIRMATION ACTION MESSAGE ON MODAL
$lang["uam"]["title"]["add_new_user"] = "Nouveau compte utilisateur";
$lang["uam"]["title"]["edit_user_account"] = "Modifier compte d'utilisateur";
$lang["uam"]["cma_msg"]["add_new_user"] = "Voulez-vous ajouter cet utilisateur ?";
$lang["uam"]["cma_msg"]["deactivate_account"] = "Désactiver ce compte";
$lang["uam"]["cma_msg"]["activate_account"] = "Activer ce compte";
$lang["uam"]["cma_msg"]["save_changes"] = "Voulez-vous enregistrer les modifications sur ce compte utilisateur ?";
$lang["uam"]["cma_msg"]["delete_account"] = "Voulez-vous supprimer ce compte utilisateur de façon permanente";
$lang["uam"]["action"]["click_to_delete"] = "Cliquez pour supprimer définitivement ce compte.";
$lang["uam"]["action"]["click_to_edit"] = "Cliquez pour modifier ce compte.";
$lang["uam"]["action"]["click_to_activate"] = "Cliquez pour activer ce compte.";
$lang["uam"]["action"]["click_to_deactivate"] = "Cliquez pour désactiver ce compte.";
$lang["uam"]["btn"]["add_new_user"] = "Ajouter un nouvel utilisateur";

// SERVER-SIDE ERROR MESSAGE
$lang["new_user_added"] = "Nouvel utilisateur a été ajouté !";
$lang["updated_user_info"] = "Informations sur l'utilisateur a été mis à jour !";

//FORM VALIDATION MESSAGE
$lang["account_deleted"] = "Compte d'utilisateur a été définitivement supprimé";
$lang["cannot_delete_account"] = "Impossible de supprimer le compte.  Une erreur inconnue s'est produite.";
$lang["activated_account"] = "Votre compte a été désactivé.";
$lang["deactivated_account"] = "Compte d'utilisateur a été désactivé.";
$lang["unable_deactivate_account"] = "Nous ne pourrons pas désactiver votre compte. Une erreur s'est produite";
$lang["unable_activate_account"] = "Nous ne pourrons pas activer votre compte. Une erreur s'est produite";

/* END OF USER ACCOUNTS MANAGEMENT LANGUAGE CONVERSION */

//------------------------------------------------------------------------------------------------------------------------------

/* CITY LOCATION */

//BUTTONS
$lang["add_new_city"] = "Ajouter une nouvelle ville";

//FIELDS
$lang["city_name"] = "Nom de Ville";

// CONFIRMATION ACTION MESSAGE ON MODAL
$lang["cl"]["title"]["add_new_city"] = "Ajouter un nouveau nom de la ville";
$lang["cl"]["title"]["edit_city"] = "Nom Modifier Ville";
$lang["cl"]["cma_msg"]["add_new_city"] = "Voulez-vous ajouter cette nouvelle ville?";
$lang["cl"]["cma_msg"]["update_city"] = "Voulez-vous enregistrer les modifications sur cette entrée ?";
$lang["cl"]["cma_msg"]["delete_city"] = "Voulez-vous supprimer ce nom de la ville de façon permanente";
$lang["cl"]["btn"]["add_new_city"] = "Ajouter une nouvelle ville";

// SERVER-SIDE ERROR MESSAGE
$lang["city_name_exist"] = "Nom de la ville existe déjà!";
$lang["added_new_city_loc"] = "nouvel emplacement de la ville Ajouté";
$lang["new_city_added"] = "Nouveau nom de la ville a été ajouté";
$lang["update_city_name"] = "Nom de la ville a été mis à jour";
$lang["deleted_city_name"] = "nom de la ville définitivement supprimé";
$lang["unknown_error"] = "Quelque-chose s'est mal passé!";
$lang["unknown_error_on_saving"] = "Impossible d' ajouter une nouvelle ville . Quelque-chose s'est mal passé!";
$lang["unknown_error_on_updates"] = "Impossible de mettre à jour le nom de la ville . Quelque-chose s'est mal passé";
$lang["updated_city_logs"] = "Lieu de ville Mise à jour";

/* END OF CITY LOCATION */


//---------------------------------------------------------------------------------------------------------------------------------

/* EVENT PREFERENCE */

//BUTTONS

//TABLE COLUMNS
$lang["event_pref"] = "Préférence de l'événement";

// CONFIRMATION ACTION MESSAGE ON MODAL
$lang["ep"]["title"]["add_new_event_pref"] = "Ajouter une nouvelle préférence";
$lang["ep"]["title"]["edit_event_pref"] = "Préférence Modifier l'événement";
$lang["ep"]["cma_msg"]["add_event_pref"] = "Voulez-vous ajouter cette nouvelle préférence de l'événement ?";
$lang["ep"]["cma_msg"]["delete_event_pref"] = "Voulez-vous supprimer ce type d'événement de façon permanente";


// SERVER-SIDE ERROR MESSAGE
$lang["event_pref_exist"] = "la préférence de l'événement existe déjà!";
$lang["added_new_event_pref_log"] = "nouvelle préférence de l'événement Ajouté";
$lang["new_event_pref_added"] = "Nouvelle préférence de l'événement a été ajouté !";
$lang["unable_to_save_data"] = "Impossible d'ajouter une nouvelle préférence de l'événement. Quelque-chose s'est mal passé!";
$lang["updated_event_pref"] = "la préférence de l'événement Mise à jour";
$lang["unknown_error"] = "Quelque-chose s'est mal passé!";
$lang["event_updated"] = "la préférence de l'événement a été mis à jour !";
$lang["unable_to_update"] = "Impossible de mettre à jour la préférence de l'événement. Quelque-chose s'est mal passé!";
$lang["deleted_event_pref_log"] = "la préférence de l'événement Deleted";
$lang["deleted_event_pref"] = "la préférence de l'événement a été définitivement supprimé !";

/* END OF EVENT PREFERENCE */

//---------------------------------------------------------------------------------------------------------------------------------


/* End of file system_config_lang.php */
/* Location: ./application/language/fr/backoffice/system_config_lang.php */
