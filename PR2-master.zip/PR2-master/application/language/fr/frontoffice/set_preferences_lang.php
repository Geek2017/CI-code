<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/* SET PREFERENCE PAGE */

// Labels
$lang["civility"] = "Civilité";
$lang["first_name"] = "Prénom";
$lang["last_name"] = "Nom";
$lang["birthday"] = "Anniversaire";
$lang["location"] = "Localisation";
$lang["address"] = "Adresse";
$lang["additional_address"] = "Complément d'adresse";
$lang["postal_code"] = "Code postal";
$lang["email_address"] = "Adresse e-mail";
$lang["mobile"] = "Téléphone mobile";
$lang["phone"] = "Téléphone fixe";

//checkboxes
$lang["event_preferences"] = "Préférences d'événement";


// Buttons
$lang["save_changes"] = "Enregistrer les modifications";