<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class User_forgot_password_model extends CI_Model {

	public function __construct() {
		parent::__construct();
	}

	public function send_email($email, $code, $role_id)
	{
        $this->delete_previous_fo_history($role_id, $email);
		$request_time = date("Y-m-d H:i:s");
		$newdate = new DateTime($request_time);
		$newdate->modify('+ 5 hour');
		$expiration_date_time = date_format($newdate, 'Y-m-d H:i:s');
		$this->db->insert('user_forgot_password',
			array (
				'email_address' => $email,
				'role_id' => $role_id,
				'reset_code' => sha1($code),
				'request_time' => $request_time,
				'expiration' => $expiration_date_time,
				'status' => 1
			)
		);
	}

    private function delete_previous_fo_history($role_id, $email){
        $this->db->where("email_address", $email);
        $this->db->where("role_id", $role_id);
        $this->db->update('user_forgot_password', array("status" => 0));
    }

	public function check_code($email, $code)
	{
		$current_time = date("Y-m-d H:i:s");

		// Query for Email		
		$emailmatch = $this->db->query("SELECT * 
					FROM 
					    user_forgot_password
					WHERE
					    email_address = '".$email."'
					AND
					    role_id IN(1,2)
					ORDER BY
					    forgot_password_id DESC
					LIMIT 1
					");

		if($emailmatch->num_rows() == 1){

			$codematch = $this->db->query("SELECT 
					   * 
					FROM 
					    user_forgot_password
					WHERE
					    email_address = '".$email."'
					AND
					    reset_code = sha1('".$code."')
					AND
					    role_id IN(1,2)
					ORDER BY
					    forgot_password_id DESC
					LIMIT 1");

			if($codematch->num_rows()){
				$expire = $this->db->query("SELECT * FROM 
				    user_forgot_password
				WHERE
				    email_address = '".$email."'
				AND
				    reset_code = sha1('".$code."')
				AND
				    DATE_FORMAT(expiration, 'Y-m-d H:i:s') >= '".$current_time."'
				AND
                    role_id IN(1,2)
				AND
					status = 1
				ORDER BY
				    forgot_password_id DESC
				LIMIT 1");

				if($expire->num_rows()){
					//reset code
					$this->db->where('email_address', $email);
		    		$this->db->update('user_forgot_password', array('status' => 0));
					return 1; // Correct Code - Reset Password
				} else {
					$this->db->where('email_address', $email);
		    		$this->db->update('user_forgot_password', array('status' => 0));
		        	return 0; // Code has Expired
				}
			} else {				
				return 2; // Invalid reset code
			}
		} else {			
			return 3; // Invalid email
		}
	}

    public function get_data_by_reset_code($reset_code){

        $this->db->select("email_address, role_id");
        $this->db->where("reset_code", sha1($reset_code));
        $this->db->where("status", 1);
//        $this->db->where("expiration > CURRENT_TIMESTAMP");
        $this->db->limit(1);
        $result = $this->db->get("user_forgot_password");

        if($result->num_rows()){
            return $result->row();
        }
        return false;
    }

}