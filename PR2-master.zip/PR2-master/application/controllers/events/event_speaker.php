<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Event_speaker extends MY_Controller {

    public function __construct()
    {
        //parent::__construct();
        $this->my_controller_parent_construct();
        $this->check_session_timed_out("bo");
        //load language files
        $this->load_language_backoffice();
        $this->lang->load('backoffice/events', 'fr');
        //load model
        $this->load->model("user_activity_log_model");
    }

    public function delete_event_speaker($speaker_assignee_id){
        if($this->input->post() && isset($this->data["logged_in"]["user_id"])){
            $this->load->model("event_speaker_model");
            $delete_status = $this->event_speaker_model->delete_event_speaker($speaker_assignee_id, $this->input->post("speaker_id"));
            if($delete_status){
                output_to_json($this, array(
                    "mtype"  => "success",
                    "message" => $this->lang->line("espeaker_deleted")
                ));
            } else {
                output_to_json($this, array(
                    "mtype"  => "error",
                    "message" => $this->lang->line("cant_delete_espeaker")
                ));
            }
        } else {
            show_404();
        }
    }

    public function update_event_speaker($speaker_assignee_id){
        if($this->input->post() && isset($this->data["logged_in"]["user_id"])){
            $this->load->model("event_speaker_model");
            $update_status = $this->event_speaker_model->update_event_speaker($speaker_assignee_id, $this->input->post(), $this->data["logged_in"]["user_id"]);
            if($update_status){
                output_to_json($this, array(
                    "mtype"  => "success",
                    "message" => $this->lang->line("updated_espeaker")
                ));
            } else {
                output_to_json($this, array(
                    "mtype"  => "error",
                    "message" => $this->lang->line("cant_update_espeaker")
                ));
            }
        } else {
            show_404();
        }
    }

    public function add_event_speaker($event_id){
        if($this->input->post() && isset($this->data["logged_in"]["user_id"])){
            $this->load->model("event_speaker_model");
            $this->load->model("event_speaker_assignee_model");
            $event_speakers = $this->input->post("event_speaker");
            foreach ($event_speakers as $key=>$speaker) {
                if(!$this->event_speaker_assignee_model->check_for_duplication(array("event_id" => $event_id, "speaker" => $speaker["speaker"]))) {
                    $speaker["added_by"] = $this->data["logged_in"]["user_id"];
                    $speaker["speaker_id"] = $this->event_speaker_model->add_event_speaker($speaker, $event_id);
                    $speaker["event_id"] = $event_id;
                    $check = $this->event_speaker_assignee_model->add_new_speaker_assignee($speaker);

                    if(!$check){
                        output_to_json($this, array(
                            "mtype"  => "error",
                            "message" => "Something went wrong!"
                        ));
                    } else {
                        output_to_json($this, array(
                            "mtype"  => "success",
                            "message" => "New speaker has been added!"
                        ));
                    }
                }
                output_to_json($this, array(
                    "mtype"  => "warning",
                    "message" => "Speaker already added to this event. See on next page of the table."
                ));
            }
        } else {
            show_404();
        }
    }

    public function list_event_speaker($event_id){
        if($event_id && $this->input->post() && isset($this->data["logged_in"]["user_id"])){
            $this->load->model("event_speaker_model");
            $this->load->model("event_speaker_assignee_model");

            $list = $this->event_speaker_assignee_model->get_datatables($this->input->post(), $event_id);
            $data = array();
            $row = array();
            $x = $this->input->post("start");
            foreach ($list as $speaker) {
                $row["sort_order"] = ++$x;
                $row["speaker_id"] = $speaker->speaker_id;
                $row["speaker_assignee_id"] = $speaker->speaker_assignee_id;
                $row["speaker"] = $speaker->speaker;
                $row["action"] = array(
                    "speaker_assignee_id" => $speaker->speaker_assignee_id,
                    "action" => "editEvent"
                );
                array_push($data, $row);
            }
            $output = array(
                "draw" => $_POST['draw'],
                "recordsTotal" => $this->event_speaker_assignee_model->count_all($this->input->post(), $event_id),
                "recordsFiltered" => $this->event_speaker_assignee_model->count_filtered($this->input->post(), $event_id),
                "data" => $data,
            );
            //output to json format
            output_to_json($this, $output);
        } else {
            show_404();
        }
    }
}