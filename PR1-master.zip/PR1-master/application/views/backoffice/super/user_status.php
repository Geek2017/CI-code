<div id="main">
<div class="table-responsive">
 <table id="userstatus" class="table table-striped table-bordered" cellspacing="0" width="100%">
    <thead>
        <tr>
            <th>Nom Prénom</th>
            <th>date de création</th>
            <th>date de début </th>
            <th>Progression</th>
            <th>Statut</th>
        </tr>
    </thead>
</table>
</div> 
