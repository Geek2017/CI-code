<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pdfs extends CI_Model {

    function __construct()
    {
        parent::__construct();
        //include APPPATH . 'third_party/mpdf60/mpdf.php';
        //$this->mpdf = new mPDF();

    }
    public function generate_pdf($content)
    {
      //$this->mpdf->WriteHTML($content);
      //$this->mpdf->Output();   
      //exit;
    }

}
