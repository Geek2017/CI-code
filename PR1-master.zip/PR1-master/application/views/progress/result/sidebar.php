<?php
	$profile =  $this->uri->segment(2) != null ? $this->uri->segment(2) : "";

	$section_num = $this->uri->segment(3);

    $this->db->select('*');
    $this->db->from('section');
    $this->db->where('section_id',$section_num);
    $query = $this->db->get();
    $sec = $query->result();
    $sec = $sec[0];
?>
<div class="side-content">
	<h3 class="text-center"><?php echo $sec->section_title; ?></h3>
	<hr>
	<?php 
	if( $profile == 'view' )
	{ 
		 echo '<div class="number-q text-center"><div class="chart progress_bar ss" id="graph" data-percent="100"></div></div>';
	} 
	?>
</div>
