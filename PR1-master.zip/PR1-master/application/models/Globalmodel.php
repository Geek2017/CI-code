<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class GlobalModel extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }

    /** Test custom validator
    Ace -
     * SAMPLE
     * $input = array(
    'bankAccount'           =>  $bankAccountAmount,
    'baseAmount'            =>  $baseAmount,
    'bankAccountDetails'    =>  $BanksAccountDetails,
    'transferAmount'        =>  $transferAmount
    );
    $rules = array(
    'bankAccount'           =>  'required|LowerThan:'.$amountAndFee.'|Insufficient Balance',
    'baseAmount'            =>  'required|GreaterThan:500000|Maximum amount is 500,000',
    'bankAccountDetails'    =>  'required',
    'transferAmount'        =>  'required|NotEqual:'.$forexE.'|Something went wrong.'
    );
     * Last value in $rules array should be the error message that will be return.
     * why did I made this? IDK, nothing to do. lol
     * */
    public function akeenValidator($input, $rules)
    {
        $ArrayValidation = array();
        foreach($input as $i => $inp){  // get all the inputs
            // $i   = input name
            // $inp = input value
            foreach($rules as $x => $rule){ // get all the rules
                if($i == $x){ // if input base name is the same with rule base name
                    $split = explode("|", $rule); // seperate rules
                    foreach($split as $spl){ // get rules
                        $required       = in_array("required",$split);
                        $searchString   = strpos($spl,":");
                        $split2         = $searchString > 0 ? explode(":", $spl) : $spl;
                        $returnValue    = end($split);

                        $alpha          = preg_match('/[a-zA-Z]/',       $inp); // contains letter
                        $numeric        = preg_match('/\d/',             $inp); // contains digit
                        $space          = preg_match('/\s/',             $inp); // contains space
                        $special        = preg_match('/[^-_a-z0-9]+/i',    $inp); // contains special
                        $dash           = preg_match('/[-_]/',           $inp); // contains dash and underscore

                        $name = ucwords(str_replace("_"," ",$x));
                        if($searchString > 0){ // validate with operator ( e.g greater than, lower than )
                            switch($split2[0]){
                                case 'LowerThan':
                                {
                                    if($inp < $split2[1]){
                                        $error =  $returnValue;
                                    }
                                    break;
                                }
                                case 'GreaterThan':
                                {
                                    if($inp > $split2[1]){
                                        $error =  $returnValue;
                                    }
                                    break;
                                }
                                case 'LowerEqual':
                                {
                                    if($inp <= $split2[1]){
                                        $error =  $returnValue;
                                    }
                                    break;
                                }
                                case 'GreaterEqual':
                                {
                                    if($inp >= $split2[1]){
                                        $error =  $returnValue;
                                    }
                                    break;
                                }
                                case 'NotEqual':
                                {
                                    if($inp && $inp != $split2[1]){
                                        $error =  $returnValue;
                                    }
                                    break;
                                }
                                case 'Equal':
                                {
                                    if($inp == $split2[1]){
                                        $error =  $returnValue;
                                    }
                                    break;
                                }
                                case 'CompareString':
                                {
                                    // ONLY STRING SHOULD PASS TO THIS VALIDATION
                                    $compareString = strcmp($inp,$split2[1]);
                                    if($compareString == 1){
                                        $error =  $returnValue;
                                    }
                                    break;
                                }
                                case 'maxlength':
                                {
                                    if(strlen($inp) > $split2[1]){
                                        $error = 'Maximum '.$name.' must be '.$split2[1];
                                    }
                                    break;
                                }
                                case 'minlength':
                                {
                                    if($inp && strlen($inp) < $split2[1]){
                                        $error = 'Minimum '.$name.' must be '.$split2[1];
                                    }
                                    break;
                                }
                                // ADD  YOUR OWN VALIDATION HERE
                            }
                        }else{
                            switch($split2){
                                case 'none':
                                {
                                    $name = $error = "";
                                    break;
                                }
                                case 'required':
                                {
                                    if(empty($inp)){
                                        if( $i === "subsidiary" )
                                        {
                                            $error =  ucwords("Société ou Filiale"). ' obligatoire';
                                        }
                                        else
                                        {
                                            $error =  ucwords(str_replace("_"," ",$i)). ' obligatoire';
                                        }
                                    }
                                    break;
                                }
                                case 'alpha_num':
                                {
                                    $validate = $this->regExp('number & letter',$split, $inp);
                                    if($validate['cond'] == true){
                                        $error = $validate['error'] != "" ? $x.$validate['error'] : "";
                                    }else{
                                        if($special > 0 || $space > 0){
                                            $error =  $name.' must only contain text and number';
                                        }
                                    }
                                    break;
                                }
                                case 'numeric':
                                {
                                    $validate = $this->regExp('letter',$split, $inp);
                                    if($validate['cond'] == true){
                                        $error = $validate['error'] != "" ? $x.$validate['error'] : "";
                                    }else{
                                        if($inp && $alpha > 0 || $special > 0){
                                            $error =  $name.' must only contain number';
                                        }
                                    }
                                    break;
                                }
                                case 'alpha':
                                {
                                    $validate = $this->regExp('letter',$split, $inp);
                                    if($validate['cond'] == true){
                                        $error = $validate['error'] != "" ? $x.$validate['error'] : "";
                                    }else{
                                        if($inp && $numeric > 0 || $special > 0 || $dash > 0){
                                            $error =  $name.' must only contain text characters';
                                        }
                                    }
                                    break;
                                }
                                case 'valid_email':
                                {
                                    if($inp && filter_var($inp , FILTER_VALIDATE_EMAIL) === false){
                                        $error = $returnValue;
                                    }
                                    break;
                                }
                                case 'valid_url':
                                {
                                    if($inp && filter_var($inp , FILTER_VALIDATE_URL) === false){
                                        $error = $returnValue;
                                    }
                                    break;
                                }
                                // ADD YOUR OWN SINGLE VALIDATION HERE
                            }
                        }
                    }
                    if(!empty($error)){ array_push($ArrayValidation, array( 'name' => $name, 'error' => $error )); }
                }
            }
        }
        return array_filter(array_unique($ArrayValidation, SORT_REGULAR));
    }
    public function regExp($valid, $array, $inp)
    {
        $alpha          = preg_match('/[a-zA-Z]/',       $inp); // contains letter
        $numeric        = preg_match('/\d/',             $inp); // contains digit
        $space          = preg_match('/\s/',             $inp); // contains space
        $special        = preg_match('/[^-_a-z0-9\s]+/i',$inp); // contains special
        $dash           = preg_match('/[-_]/',           $inp); // contains dash and underscore
        $error          = '';
        $cond           = false;
        if(in_array("alpha_dash", $array) && in_array("alpha_space", $array)){
            $cond = true;
            if($special > 0){
                $error = ' must only contain '.$valid.', dash, underscore and space';
            }
        }else if(in_array("alpha_dash", $array)){
            $cond = true;
            if($special > 0 || $space > 0){
                $error = ' must only contain '.$valid.', dash and underscore';
            }
        }else if(in_array("alpha_space", $array)){
            $cond = true;
            if($special > 0 || $dash > 0){
                $error = ' must only contain '.$valid.' and space';
            }
        }
        return array('cond'=>$cond,'error'=>$error);
    }

    public function is_section_allow($id, $flag = null)
    {
//        $count_answered = $this->questions->countAnsweredQuestion(2, $this->session->userdata('id'));
//        $count_questions = $this->questions->count_this('question',2);
        if($this->get_setting('allow_skip_question') == 0 || $flag == 'referent') {
            if ($this->questions->count_this('allsection_byid', $id) == 0)
                redirect('main/progress');

            $prev_section = $this->questions->getPercentage_($id != 1 ? $id - 1 : $id);
            $this_section = $this->questions->getPercentage_($id);
            $count_all_section = $this->questions->count_this('allsection_floor');
            $lp = [];
            $all_q = [];
            $new_param = 0;
            for ($i = 1; $i <= $count_all_section; $i++)
                $lp[] = $this->questions->getPercentage_($i);
            if (count(array_filter($lp)) > 0 ) {
                $filter_lp = array_filter($lp);
                $rd = (array_keys($lp, min($filter_lp))[min($filter_lp) == 100 ? count($filter_lp) - 1 : 0]) + 1;
                $section_param = $rd;
                $redirect = false;
                $question_not_found = false;
                if (array_sum($lp) < $count_all_section * 100 && $fetch_last = $this->questions->fetch_last_answered($rd)) {
                    $last_answered = $fetch_last->question_id;
                    $next_section = $this->questions->get_next_section($fetch_last->q_section);
                    $rdd = $prev_section == 100 && $this_section == 0 ? floor($next_section) : $rd;
                    $count_next_section = $this->questions->getQuestionBySection($next_section)->num_rows();
                    if($count_next_section === 0)
                        $rdd = $prev_section == 100 && $this_section == 0 ? floor($this->questions->get_next_section($next_section)) : $rd;
                         if($this->users->with_referent() == 0 && floor($next_section) == 6)
                         {                    
                            return true;                
                         }
                    foreach ($this->questions->getAllQuestionsBySection($rdd) as $question)
                        $all_q[] = $question->q_id;
                    $page_param = in_array($last_answered, $all_q) ? array_search($last_answered, $all_q) : 0;
                    $page_param_f = $page_param == 0 && in_array($last_answered, $all_q) ? 1 : ( $page_param == 0 ? 0 : ( count($all_q) > $page_param + 1 ? $page_param + 1 : $page_param ) );
                    $question_data = $this->questions->getQuestionByID($all_q[$page_param_f])->row();
                    $section_param = $question_data->q_section;
                    $new_q = [];
                    foreach ($this->questions->get_all_question($section_param) as $question)
                        $new_q[] = $question->q_id;

                    $c_allowed = false;
                    $p_allowed = false;
                    $new_param = array_search($question_data->q_id, $new_q) + 1;
                    if (is_numeric($this->uri->segment(2)) && is_numeric($this->uri->segment(3))) {
                        $a_q = [];
                        foreach ($this->questions->get_all_question($this->uri->segment(2)) as $question)
                            $a_q[] = $question->q_id;
                        if (count($all_q) == $page_param_f) {
                            $question_data_ = $this->questions->getQuestionByID($a_q[0])->row();
                            $section_param = $question_data_->q_section;
                            $new_param = 1;
                        }
                        $prev_question = false;
                        if ($prev_question_q = $this->questions->get_prev_question($this->uri->segment(2), $this->uri->segment(3)))
                            $prev_question = $prev_question_q->q_id;
                        if (!$this->uri->segment(3) && count($a_q) < 1 && !array_key_exists($this->uri->segment(3) - 1, $a_q)
                            || $this->uri->segment(3) > count($a_q)
                            || $this->uri->segment(2) == $section_param && $new_param < $this->uri->segment(3)
                        ) {
                            $redirect = true;
                            $question_not_found = true;
                        } else {
                            $c_allowed = $this->is_question_allow($a_q[$this->uri->segment(3) - 1]);
                            $p_allowed = $prev_question ? $this->is_question_allow($prev_question) : true;
                        }
                    } else
                        $redirect = true;

                }
                $segment_2 = $this->uri->segment(2) == 'sections_profile' ? (int)$section_param : $this->uri->segment(2);
                $segment_3 = $this->uri->segment(3) ? $this->uri->segment(3) : (int)$new_param;
                if ($flag == 2 || $flag == 'referent')
                    return ['section_param' => $section_param, 'last_answered' => $new_param];
                if ($this_section >= 100 && is_numeric($segment_2))
                    redirect('sections/result/' . floor($id));
                if (
                    is_numeric($segment_2)
                    &&
                    (
                        $redirect && $question_not_found
                        || $redirect && !is_numeric($segment_3) && $segment_2 > $section_param
                        || $segment_2 > $section_param
                        ||
                        $id != 1 && $this_section == 0
                        &&
                        $prev_section < 100
                        ||
                        (
                            is_numeric($segment_2)
                            && is_numeric($segment_3) //() && $flag == null)
                            &&  ( $segment_2 > $section_param || $segment_2 == 1 && $segment_2 >= $section_param )
                            && (
                                $c_allowed && !$p_allowed
                                || !$c_allowed && !$p_allowed
                            )
                        )
                    )
                )
                    if (!$flag)
                        redirect('sections/' . $section_param . '/' . $new_param);
                    else return false;
                else
                    return $flag == null ? true : false;
            }
            else if ($id != 1)
                $flag == null ? redirect('sections/1') : false;
            else if($id == 1 && $this->uri->segment(3) > 1 )
                $flag == null ? redirect('sections/1/1') : false;
        }
    }
    public function is_question_allow($id)
    {
        if($question = $this->questions->getAnswer($id,$this->session->userdata('id'),1)->row())
            return true;
        else
            return false;

    }
    /**
     * This is where we query and set the datatable results
     * access public
     * @param $cQryObj
     * @param array $aColumns
     * @param string $sIndexColumn
     * @return array
     */
    public static function setDatatable($cQryObj, $aColumns = array(), $sIndexColumn = "")
    {
        $CI =& get_instance();
        $Sortdir = $CI->input->get('sSortDir_0');
        $iDisplayStart =  $CI->input->get('iDisplayStart');
        $iDisplayLength =  $CI->input->get('iDisplayLength');
        $iSortCol =  $CI->input->get('iSortCol_0');
        $iSortingCols =  $CI->input->get('iSortingCols');
        $sSearch =  $CI->input->get('sSearch');

        $sLimit = "";
        if (isset($iDisplayStart) && $iDisplayLength != '-1') {
            $sLimit = $iDisplayStart . ", " . $iDisplayLength;
        }

        $sOrder = "";
        if (isset($iSortCol)) {
            $field = $aColumns[$iSortCol];
        }

        $sWhere = "";
        if ($sSearch != "") {
            for ($i = 0; $i < count($aColumns); $i++) {
                $sWhere .= $aColumns[$i] . "*" . $sSearch . "|";
            }
        }

        for ($i = 0; $i < count($aColumns); $i++) {
            if ( $CI->input->get('bSearchable_' . $i) == "true" &&  $CI->input->get('sSearch_' . $i) != '') {
                if ($sWhere == "") {
                    $sWhere = "WHERE ";
                } else {
                    $sWhere = "AND ";
                }
                $sWhere .= $aColumns[$i] . ", " .  $CI->input->get('sSearch_' . $i);
            }
        }

        $order_by = explode(",", $sOrder);
        $limits = explode(",", $sLimit);
        $filter = explode("|", $sWhere);
        $cQryObjOrig = clone $cQryObj;
        $cQryObjTemp = clone $cQryObj;
        if($sLimit!="")
            $cQryObjTemp = $cQryObjTemp->limit($limits[1])->offset($limits[0]);

        if ($sWhere != "") {
            $cQryObjTemp->group_start();
            for ($i = 0; $i < count($filter) - 1; $i++) {
                $xFilter = explode("*", $filter[$i]);
                $cQryObjTemp = $cQryObjTemp->or_where($xFilter[0]. ' LIKE "%' . $xFilter[1] . '%"');
                $cQryObjOrig = $cQryObjOrig->or_where($xFilter[0]. ' LIKE "%' . $xFilter[1] . '%"');
            }
            $cQryObjTemp->group_end();
        }

        $cQryObjResult = $cQryObjTemp->order_by($field, $Sortdir)->get()->result();
        $count = $cQryObjOrig->get()->num_rows();
        $output = array(
            "sEcho" => intval( $CI->input->get('sEcho')),
            "iTotalRecords" => $count,
            "iTotalDisplayRecords" => $count,
            "aaData" => array(),
            'objResult' => $cQryObjResult,
        );

        return $output;
    }
    public function get_name($user_id, $coma = null)
    {
        $check = $this->db->query("SELECT * FROM users WHERE user_id='$user_id'; ");

        if($check->num_rows() > 0)
        {
            $row = $check->row();
            return $row->firstname. ($coma ? "," : "")." ".$row->lastname;
        }
        return null;
    }

    public function send_email($email_from, $email_to, $subject, $content)
    {
        $this->email->from($email_from, '')
                    ->to( $email_to )
                    ->subject($subject)
                    ->message($content);

        return $this->email->send() ? true : false;
    }
    public function get_setting($field_code)
    {
        $setting = $this->db
                    ->where('setting_fieldcode',$field_code)
                    ->where('setting_status','1')
                    ->get('system_settings');
        return $setting->num_rows() > 0 ? $setting->row()->setting_fieldvalue : 0;
    }
    public function get_setting_info($id)
    {
        $setting = $this->db
            ->where('id',$id)
            ->get('system_settings');
        return $setting;
    }
    public function akeen_mail()
    {
        return $this->get_setting('akeen_email');
    }
    public function session_timeout()
    {
        if($this->session->userdata('role') && $time_session = $this->session->userdata('time_session')){
            $set_session = $this->get_setting('time_out_session');
            $dateTime = new DateTime(date($time_session));
            $dateTime->modify('+'.$set_session.' minutes');
            if($set_session && $dateTime->format('Y-m-d H:i:s') <= date('Y-m-d H:i:s')){
                $this->session->sess_destroy();
                redirect('/main/?redirect='.current_url(), 'refresh');
            }
            $this->session->set_userdata('time_session',date('Y-m-d H:i:s'));
        }
    }
    public function account_deactivated()
    {
        if($user = $this->users->get_user_info(['active'=>"0",'visited'=>"1","id"=>$this->session->userdata('id')])->row()) {
            $this->session->sess_destroy();
            redirect('/main/?deactivated=true', 'refresh');
        }
    }
}
