<div class="container">

<?php
if( $job_info ){ 
	foreach ($job_info as $key => $value) {
			$job_id = $value->id;
			$user_id = $value->user_id ;
			$company = $value->company   ;
			$job_title= $value->job_title;
			$start_date = $value->start_date;
			$s_reasons = $value->s_reasons   ;
			$end_date = $value->end_date ;
			$e_reasons = $value->e_reasons;
	}
}
?>




<h1 class="text-center">Votre Histoire Professionnelle</h1>
<br><br>
	<form  method="POST" role="form" id="job">
		<div class="row">
			<div class="col-md-6 col-md-offset-3">
				<input type="hidden" id="user_id" value="<?php echo $this->session->userdata('id')?>" name="id">
				<div class="col-md-3">
					<p><strong>Poste occupé </strong></p>
				</div>
				<input type="hidden"  id="actions" class="form-control" value="<?php echo !empty($job_info)  ? "edit" : "add"; ?>">
				<input type="hidden"  id="job_id" class="form-control" value="<?php echo !empty($job_info[0]->id)  ? $job_info[0]->id : "null"; ?>" >

				<div class="col-md-9">
					<div class="form-group">		
						<input type="text" name="job_title" placeholder="Poste occupé" id="job_title" class="form-control" value="<?php echo !empty($job_info[0]->job_title)  ?  $job_info[0]->job_title: "" ?>"  title="" required="required">
					</div>
				</div>
				<div class="col-md-3">
					<p><strong>Entreprise</strong></p>
				</div>
				<div class="col-md-9">
					<div class="form-group">		
						<input type="text" name="company" placeholder="Entreprise" id="company" class="form-control" value="<?php echo !empty($job_info[0]->company)  ?  $job_info[0]->company: "" ?>" required="required">
					</div>
				</div>
				<div class="col-md-3">
					<p><strong>Date d'entrée</strong></p>
				</div>
				<div class="col-md-9">
					<div class="form-group">		
						<input required data-date-format="dd/mm/yyyy" readonly placeholder="jj/mm/aaaa"  type="text" name="start_date" id="start_date" class="form-control datepicker" value="<?php echo !empty($job_info[0]->start_date)  ?  $job_info[0]->start_date: "" ?>"  title="" required="required">
					</div>
				</div>
				<div class="col-md-3">
					<p><strong>Raison d'entrée</strong></p>
				</div>
				<div class="col-md-9">
					<div class="form-group">		
						<input type="text" name="s_reasons" placeholder="Raison d'entrée" id="s_reasons" class="form-control" value="<?php echo !empty($job_info[0]->s_reasons)  ?  $job_info[0]->s_reasons: "" ?>"  title="" required="required">
					</div>
				</div>
				<div class="col-md-3">
					<p><strong>Date de départ</strong></p>
				</div>
				<div class="col-md-9">
					<div class="form-group input-group">		
						<input data-date-format="dd/mm/yyyy" readonly placeholder="jj/mm/aaaa" type="text"  name="end_date" id="end_date" class="form-control datepicker" value="<?php echo !empty($job_info[0]->end_date)  ?  $job_info[0]->end_date: "" ?>"   title="">
						<span class="input-group-addon "><a id="clearButton" class="glyphicon glyphicon-remove"></a></span>
					</div>
				</div>
				<div class="col-md-3">
					<p><strong>Raison de sortie</strong></p>
				</div>
				<div class="col-md-9">
					<div class="form-group">		
						<input type="text" name="e_reasons" placeholder="Raison de sortie" id="e_reasons" class="form-control" value="<?php echo !empty($job_info[0]->e_reasons)  ?  $job_info[0]->e_reasons: "" ?>"   title="">
					</div>
				</div>
				<a  href="#prof_job" class="btn btn-primary pull-right" style="width:20%">Suivant</a>
				<!-- <center>
				<button type="submit" onclick="Profesional_jobs.retour(event);" class="btn btn-primary" style="width:20%">Retour</button></center> -->
			</div>
			
		</div>
		
	</form>
	<div class="col-md-8 col-md-offset-2 prof_job">

		<div class="row" id="prof_job">
			<br><br>
			<form id="form_activity">
				<input type="hidden"  id="job_id_act" name="job_id" class="form-control" value="<?php echo !empty($job_info[0]->id)  ? $job_info[0]->id : "null"; ?>" >
			<table class="table " id="activity_job">
				<thead>
					<tr>
						<th>Activités </th>
						<th style="width:100px">Satisfaction de 1 (--) à 4 (++)</th>
						<th style="width:70px">Action</th>
					</tr>
				</thead>
				<tbody id="activity_jobs">
					
				</tbody>

				
				
			</table>
				</form>
			<button type="submit" class="btn btn-primary glyphicon glyphicon-plus" id="btn-activity"></button>
		</div>
		<form id="satiscation_form">
			<input type="hidden"  id="job_id_sat" name="job_id" class="form-control" value="<?php echo !empty($job_info[0]->id)  ? $job_info[0]->id : "null"; ?>" >
		<div class="row">
			
			<table class="table " id="savoir_job">
				<thead>
					<tr>
						<th>Compétences métier (savoir)</th>
						<th style="width:100px">Maitrise de 1 (--) à 4 (++)</th>
						<th style="width:100px">Motivation de 1 (--) à 4 (++)</th>
						<th style="width:70px">Total</th>
						<th style="width:70px">Action</th>
					</tr>
				</thead>
				<tbody id="savoir_jobs">
					
				</tbody>
			</table>
			<button type="submit" class="btn btn-primary glyphicon glyphicon-plus" id="btn-savoir"></button>
			
		</div>
		<div class="row">
			
			<table class="table " id="faire_job">
				<thead>
					<tr>
						<th>Compétences métier (savoir faire)</th>
						<th style="width:100px">Maitrise de 1 (--) à 4 (++)</th>
						<th style="width:100px">Motivation de 1 (--) à 4 (++)</th>
						<th style="width:70px">Total</th>
						<th style="width:70px">Action</th>
					</tr>
				</thead>
				<tbody id="faire_jobs">
					
				</tbody>
					
			</table>
			<button type="submit" class="btn btn-primary glyphicon glyphicon-plus" id="btn-faire"></button>
			
		</div>
		<div class="row">
			
			<table class="table " id="etre_job">
				<thead>
					<tr>
						<th>Compétences comportementales (savoir être démontré) <a href="<?php echo site_url()?>/main/glosaire#lien" target="_blank">* Glossaire</a></th>
						<th style="width:100px">Maitrise de 1 (--) à 4 (++)</th>
						<th style="width:100px">Motivation de 1 (--) à 4 (++)</th>
						<th style="width:70px">Total</th>
						<th style="width:70px">Action</th>
					</tr>
				</thead>
				<tbody id="etre_jobs">
					
				</tbody>
				
			</table>
			<button type="submit" class="btn btn-primary glyphicon glyphicon-plus" id="btn-etre"></button>
		</div>
		</form>
		<div class="pull-right">
			<button type="button" id="to-job" class="btn btn-primary next">Enregistrer</button>	
		</div>
			</form>
	</div>

</div>
<style>
	.glyphicon-plus {
	    margin-left: -40px;
	    margin-top: -115px;
	}
</style>
<?php 
	$s_last = $this->uri->total_segments();
	$segment = $this->uri->segment($s_last);
?>

<?php if ($segment == "profesional_job"): ?>
	<script>
	$(document).ready(function() {
		var count1 = $('#activity_jobs').children('tr').length;
		var count2 = $('#savoir_jobs').children('tr').length;
		var count3 = $('#faire_jobs').children('tr').length;
		var count4 = $('#etre_jobs').children('tr').length;
		if (count1 < 1) {
			$("#btn-activity").trigger('click');
		};
		if (count2 < 1) {
			$("#btn-savoir").trigger('click');
		};
		if (count3 < 1) {
			$("#btn-faire").trigger('click');
		};
		if (count4 < 1) {
			$("#btn-etre").trigger('click');
		};
		;
	    var $input = $('.prof_job input'),
		    $register = $('#to-job');

		$register.attr('disabled', true);
		$input.change(function() {
		    var trigger = false;
		    $input.each(function() {
		        if (!$.trim( $(this).val() )) {
		            trigger = true;
		        }
		    });
		    trigger ? $register.attr('disabled', true) : $register.removeAttr('disabled');
		});
			   
	});

	</script>

	
<?php endif ?>

