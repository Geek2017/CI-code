<style type="text/css">
	@media print and (color) {
       * {
          -webkit-print-color-adjust: exact;
          print-color-adjust: exact;
       }
    }
</style>
<div class="container" id="viewjobs">
	<?php foreach ($jobs as $job): ?>
		<div class=" jobs_main">
			<table class="table" id="view-job" style="width:50% !important">
				<tbody>
					<tr>
						<td><p class="" >Poste occupé  </p></td>
						<td> : </td>
						<td><p class=""><?php echo $job->job_title; ?></p></td>
					</tr>
					<tr>
						<td><p class="">Entreprise  </p></td>
						<td> : </td>
						<td><p class=""><?php echo $job->company; ?></p></td>
					</tr>
					<tr>
						<td><p class="">Date d'entrée  </p></td>
						<td> : </td>
						<td><p class=""><?php echo $job->start_date; ?></p></td>
					</tr>
					<tr>
						<td><p class="">Raisons  </p></td>
						<td> : </td>
						<td><p class=""><?php echo $job->s_reasons; ?></p></td>
					</tr>
					<?php if ($job->end_date != '' ): ?>
					<tr>
						<td><p class="">Date de départ  </p></td>
						<td> : </td>
						<td><p class=""><?php echo $job->end_date; ?> &nbsp;</p></td>
					</tr>
					<tr>
						<td><p class="">Raisons  </p></td>
						<td> : </td>
						<td><p class=""><?php echo $job->e_reasons; ?> &nbsp;</p></td>
					</tr>
					<?php endif ?>
					
				</tbody>
			</table>
			
			
		</div>
		<div class="row job-tables" >
			<div class="col-md-8 ">
			<table class="table ">
				<thead style="background-color: #285a89; color: #fff; ">
					<tr>
						<th>Activités</th>
						<th style="width:100px; background-color: #285a89;">Satisfaction de 1 (--) à 4 (++)</th>
					</tr>
				</thead>
				<tbody id="">
					<?php foreach ($activity as $row_act): ?>
						<?php if ($row_act->job_id == $job->id): ?>
							<tr>
								<td><?php echo $row_act->activity?></td>
								<td><?php echo $row_act->satisfaction?></td>
							</tr>
						<?php endif ?>
					<?php endforeach ?>
					
				</tbody>
			</table>
			<br>
			<table class="table ">
				<thead style="background-color: #285a89; color: #fff; background-color: #285a89;">
					<tr>
						<th>Compétences métier (savoir)</th>
						<th style="width:100px">Maîtrise de 1 (--) à 4 (++)</th>
						<th style="width:100px">Motivation de 1 (--) à 4 (++)</th>
						<th style="width:100px">Total</th>
					</tr>
				</thead>
				<tbody id="">
					<?php foreach ($savoir as $row_savoir): ?>
						<?php if ($row_savoir->job_id == $job->id): ?>
							<tr>
								<td><?php echo $row_savoir->activity?></td>
								<td><?php echo $row_savoir->satisfaction1?></td>
								<td><?php echo $row_savoir->satisfaction2?></td>
								<td><?php echo $row_savoir->total?></td>
							</tr>
						<?php endif ?>
					<?php endforeach ?>
					
				</tbody>
			</table>
			<br>
			<table class="table ">
				<thead style="background-color: #285a89; color: #fff; background-color: #285a89; ">
					<tr>
						<th>Compétences métier (savoir faire)</th>
						<th style="width:100px">Maîtrise de 1 (--) à 4 (++)</th>
						<th style="width:100px">Motivation de 1 (--) à 4 (++)</th>
						<th style="width:100px">Total</th>
					</tr>
				</thead>
				<tbody id="">
					<?php foreach ($faire as $row_faire): ?>
						<?php if ($row_faire->job_id == $job->id): ?>
							<tr>
								<td><?php echo $row_faire->activity?></td>
								<td><?php echo $row_faire->satisfaction1?></td>
								<td><?php echo $row_faire->satisfaction2?></td>
								<td><?php echo $row_faire->total?></td>
							</tr>
						<?php endif ?>
					<?php endforeach ?>
					
				</tbody>
			</table>
			<table class="table ">
				<thead style="background-color: #285a89; color: #fff; background-color: #285a89;">
					<tr>
						<th>Compétences comportementales (savoir être démontré) *</th>
						<th style="width:100px">Maîtrise de 1 (--) à 4 (++)</th>
						<th style="width:100px">Motivation de 1 (--) à 4 (++)</th>
						<th style="width:100px">Total</th>
					</tr>
				</thead>
				<tbody id="">
					<?php foreach ($etre as $row_etre): ?>
						<?php if ($row_etre->job_id == $job->id): ?>
							<tr>
								<td><?php echo $row_etre->activity?></td>
								<td><?php echo $row_etre->satisfaction1?></td>
								<td><?php echo $row_etre->satisfaction2?></td>
								<td><?php echo $row_etre->total?></td>
							</tr>
						<?php endif ?>
					<?php endforeach ?>
					
				</tbody>
			</table>
			</div>
		</div>
		
	<?php endforeach ?>
</div>