<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| File and Directory Modes
|--------------------------------------------------------------------------
|
| These prefs are used when checking and setting modes when working
| with the file system.  The defaults are fine on servers with proper
| security, but you may wish (or even need) to change the values in
| certain environments (Apache running a separate process for each
| user, PHP under CGI with Apache suEXEC, etc.).  Octal values should
| always be used to set the mode correctly.
|
*/

/*
|--------------------------------------------------------------------------
| GOOGLE ANALYTICS CODES
|--------------------------------------------------------------------------
|
| These modes are used when working with Google Analytics
|
*/
define('LEMONDE_APP_ENV', strtoupper(getenv('LEMONDE_APP_ENV')));

if(LEMONDE_APP_ENV === "PREPROD" || LEMONDE_APP_ENV === "DEV" || LEMONDE_APP_ENV === "LOCAL"){

    //GOOGLE ANALYTICS
    define('GA_TRACKER_ID', "UA-88448558-1");
    define('GA_CLIENT_ID', "921069029216-78fc70b6g2hftup7di9mesn1v98hodm1.apps.googleusercontent.com");
    define('GA_CLIENT_SECRET', "pSu2NmCXP-WhPpqO1r-ezLaY");
    define('GA_CLIENT_ALLDATA_ID', "ga:135291658");
    define('GA_CLIENT_BYUSER_ID', "ga:135416523");

    //BACKGROUND SERVICE FOR CRON
    if(LEMONDE_APP_ENV === "DEV") {
        define('BASEURL', "http://dev.wylog.com/lemonde/");
        define('EVENTLOGOPATH', "/web/lemonde/resources/images/logo-lemonde.png");
        define('EVENTPICTPATH', "/web/lemonde/resources/images/frontoffice/events/");
    } else if(LEMONDE_APP_ENV === "PREPROD") {
        define('BASEURL', "http://dev.wylog.com/lemonde_pre_prod/");
        define('EVENTLOGOPATH', "/web/lemonde_pre_prod/resources/images/logo-lemonde.png");
        define('EVENTPICTPATH', "/web/lemonde_pre_prod/resources/images/frontoffice/events/");
    } else {
        define('BASEURL', "http://localhost/weblemonde_test/");
        define('EVENTLOGOPATH', "http://localhost/weblemonde_test/resources/images/logo-lemonde.png");
        define('EVENTPICTPATH', "http://localhost/weblemonde_test/resources/images/frontoffice/events/");
    }

} else if(LEMONDE_APP_ENV === "PROD") {

    //GOOGLE ANALYTICS
    define('GA_TRACKER_ID',  "UA-88698927-1");
    define('GA_CLIENT_ID',  "552689160713-dgpntph6ff5laqbl4452bnopvn47orfc.apps.googleusercontent.com");
    define('GA_CLIENT_SECRET',  "meRhY9sdYZ0dlxbNATQoT5lx");
    define('GA_CLIENT_ALLDATA_ID', "ga:135602717");
    define('GA_CLIENT_BYUSER_ID', "ga:135604008");

    //BACKGROUND SERVICE FOR CRON
    define('BASEURL', "http://evenements-abonnes.lemonde.fr/");
    define('EVENTLOGOPATH', "/var/www/lemonde/resources/images/logo-lemonde.png");
    define('EVENTPICTPATH', "/var/www/lemonde/resources/images/frontoffice/events/");
}
/* End of file constants.php */
/* Location: ./application/config/constants.php */