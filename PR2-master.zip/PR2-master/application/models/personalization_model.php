<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 
	
class Personalization_model extends MY_Model{

	function __construct() {
		parent::__construct();
		
		$this->user_subscriber_reg_form_table = "user_subscriber_reg_form";
		$this->banner = "frontoffice_banner";
		$this->all = "*";

		$this->footer = "frontoffice_footer";
		$this->description = "description";
		$this->status = 1;

		$this->logo = "frontoffice_logo";
	}

	public function get_user_subscriber_reg_form($active = null){
		$this->db->select($this->all); 
		$this->db->from($this->user_subscriber_reg_form_table);
		if($active){
		 $this->db->where('display_status', $active);
		 $this->db->order_by("sort", "asc");
		}
		$query = $this->db->get();
		return $query->result();
	}
	public function update_user_subscriber_reg_form()
	{
		$ids = 0;
		$req = "";
		foreach ($_POST as $key => $value) {
			  if( $key == 'req')
			  	$req = $value;
			  else if( $key == "ids")
			  	$ids = $value;

			  $this->db->where('id', $ids);
 					 $this->db->update($this->user_subscriber_reg_form_table, array(
		 	        'is_required' => $req
		 	    ));
		}
	}
	public function upload_new_banner($arr = array() )
	{
		$this->db->insert($this->banner, $arr);
	}
	public function upload_get_banner()
	{
		$this->db->limit(1);
		$this->db->order_by('id', 'DESC');
		$query  = $this->db->get($this->banner);
		return $query->row_array();
	}
	public function get_mentions_legales()
	{
		$this->db->select($this->description);
        $this->db->where('status', $this->status);
        $result = $this->db->get($this->footer);
        if($result->num_rows() > 0){
           $ret = $result->row();
           return $ret->description;
        }
        return false;
	}
	public function append_mentions_legales()
	{
		$this->db->select($this->all); 
		$this->db->from($this->footer);
		$query = $this->db->get();
		return $query->row();
	}
	public function update_mentions_legales($default = 1)
	{
	   $this->db->where('id', $default );
			$this->db->update($this->footer, array(
	 	        'status' => $_POST['status'],
	 	        'description' => $_POST['description']
	 	));

		return $this->db->affected_rows() ;	
	}
	public function insert_logo($arr = array())
	{
		 // $result = $this->db->get($this->logo);

   //       if($result->num_rows() > 0){
   //       	//$this->db->where('id', 1);
 		// 	// $this->db->update($this->logo, $arr);
 		// 	 $this->db->limit(1);
			//  $this->db->order_by('id', 'DESC');
			//  $query  = $this->db->get($this->logo);
			//  return $query->row_array();
   //       }

         $this->db->insert($this->logo, $arr);
	}
	public function get_logo()
	{
 			 $this->db->limit(1);
			 $this->db->order_by('id', 'DESC');
			 $query  = $this->db->get($this->logo);
			 return $query->row_array();
	}

	public function contact_email_update($email){
		$data = array(
			'contact_email' => $email
		);

		$this->db->update('contact_email_info', $data);

		if ($this->db->trans_status() === FALSE)
		{
			return false;
		}else{
			return true;
		}

	}
}

?>