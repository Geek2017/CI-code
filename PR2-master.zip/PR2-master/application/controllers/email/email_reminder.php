<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Email_reminder extends MY_Controller {

    public function __construct()
    {
        //parent::__construct();
        $this->my_controller_parent_construct();
        $this->check_session_timed_out("bo");
        //load language files
        $this->load_language_backoffice();
        $this->lang->load('backoffice/email', 'fr');
        //load model
        $this->load->model("event_model");
        $this->load->model("event_email_template_model");
        $this->load->model("event_email_schedule_model");
        $this->load->model("event_email_default_setting_model");
        $this->load->model("user_activity_log_model");
        $this->load->helper('htmlpurifier');
    }

    public function get_email_reminder_list($export=0){
        if($this->input->post() && isset($this->data["logged_in"]["user_id"])){
            $list = $this->event_email_schedule_model->get_datatables($this->input->post());
            $data = array();
            $row = array();
            $x = $this->input->post("start");
            foreach ($list as $event_reminder) {
                $row["event_order"] = ++$x;
                $row["event_title"] = $event_reminder->event_title;
                $row["start_date_time"] = $event_reminder->start_date_time;
                $row["email_schedule_date"] = $event_reminder->email_schedule_date;
                //$row["email_sched_overwrite_default"] = $event_reminder->email_sched_overwrite_default;
                $row["email_schedule_author"] = $event_reminder->email_schedule_author;
                $row["email_schedule_status"] = $event_reminder->email_schedule_status;
                $row["email_schedule_date_added"] = $event_reminder->email_schedule_date_added;
                $row["action"] = array(
                    "email_schedule_id" => $event_reminder->email_schedule_id,
                    "email_schedule_status" => $event_reminder->email_schedule_status,
                    "event_id" => $event_reminder->event_id,
                    "event_status" => $event_reminder->event_status,
                    "email_sched_overwrite_default" => ($event_reminder->email_sched_overwrite_default == "YES")?1:2,
                    "email_schedule_date" => $event_reminder->email_schedule_date_,
                    "reservation_start_date" => $event_reminder->reservation_start_date,
                    "start_date_time" => $event_reminder->start_date_time_
                );
                array_push($data, $row);
            }
            $output = array(
                "draw" => $_POST['draw'],
                "recordsTotal" => $this->event_email_schedule_model->count_all($this->input->post()),
                "recordsFiltered" => $this->event_email_schedule_model->count_filtered($this->input->post()),
                "data" => $data,
            );
            //output to json format
            output_to_json($this, $output);
        } else {
            show_404();
        }
    }

    public function add_email_reminder(){
        if($this->input->post() && isset($this->data["logged_in"]["user_id"])) {
            $email_tpl_setting = $this->event_email_default_setting_model->get_default_email_schedule(1);
            //insert data
            if ($email_tpl_setting) {
                $_POST["reference"] = $email_tpl_setting->email_tpl_setting_id;
            }
            $_POST["email_schedule_author"] = $this->data["logged_in"]["user_id"];
            $_POST["email_type_id"] = 1;
            $email_schedule_id = $this->event_email_schedule_model->add_email_reminder($this->input->post());
            if ($email_schedule_id) {
                //email reminder added
                output_to_json($this, array(
                    "mtype" => "success",
                    "message" => $this->lang->line("added_email_reminder")
                ));
            } else {
                output_to_json($this, array(
                    "mtype" => "error",
                    "message" => $this->lang->line("unknown_error")
                ));
            }
        } else {
            show_404();
        }
    }

    public function update_email_reminder(){
        if($this->input->post() && isset($this->data["logged_in"]["user_id"])) {
            $email_tpl_setting = $this->event_email_default_setting_model->get_default_email_schedule(1);
            //insert data
            if ($email_tpl_setting) {
                $_POST["reference"] = $email_tpl_setting->email_tpl_setting_id;
            }
            $_POST["email_schedule_author"] = $this->data["logged_in"]["user_id"];
            $_POST["email_type_id"] = 1;
            $email_schedule_id = $this->event_email_schedule_model->update_email_reminder($this->input->post());
            if ($email_schedule_id) {
                //email reminder added
                output_to_json($this, array(
                    "mtype" => "success",
                    "message" => $this->lang->line("updated_reminder_email")
                ));
            } else {
                output_to_json($this, array(
                    "mtype" => "error",
                    "message" => $this->lang->line("unknown_error")
                ));
            }
        } else {
            show_404();
        }
    }

    public function delete_email_reminder(){
        if($this->input->post("email_schedule_id") && isset($this->data["logged_in"]["user_id"])) {
            $delete_email_schedule = $this->event_email_schedule_model->delete_email_reminder($this->input->post("email_schedule_id"));

            if ($delete_email_schedule) {
                output_to_json($this, array(
                    "mtype" => "success",
                    "message" => $this->lang->line("deleted_reminder_email")
                ));
            } else {
                output_to_json($this, array(
                    "mtype" => "error",
                    "message" => $this->lang->line("unknown_error")
                ));
            }
        } else {
            show_404();
        }
    }

    public function typeahead_event(){
        if($this->input->post("search")) {
            output_to_json($this, $this->event_email_schedule_model->list_events_for_typeahead($this->input->post("search")));
        }
    }

    public function check_email_active_processes_1(){
        if($this->input->post("email_schedule_id") && isset($this->data["logged_in"]["user_id"])){
            output_to_json($this, array("processes" =>$this->event_email_schedule_model->check_email_active_processes($this->input->post("email_schedule_id"))));
        }
    }
}