<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Questions extends CI_Model
{

    /**
     * Model for question_answers & questionaires table
     */

    protected $table = 'question_answers';
    public $with_referent;
    function __construct()
    {
        parent::__construct();
        $this->with_referent = $this->users->with_referent() == 0 ? true : false;
    }

    /**
     * @param $limit = limit of fetching date
     * @param $start = where to start fetching
     * @param $section = section ID
     */
    public function fetch_data($limit, $start, $section) {
        $not_in = $this->get_q_id_org($section,"0", true);
        $this->db->limit($limit, $start - 1);
                $this->db->order_by("q_id", "asc");
                $this->db->where('q_section', $section);
                $this->db->where_not_in('q_id', $not_in);
                $this->db->where('status',"1");
                if($this->with_referent)
                    $this->db->where('referent_question','0');
        $query = $this->db->get("questionaires");;
        $data = [];
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                if($this->session->userdata('org') > 0 && $question = $this->get_question_org($row->q_id)->row()) {
                    if($question->status == '1')
                        $data[] = $question;
                }else
                    $data[] = $row;
            }
            return $data;
        }
        return false;
    }
    public function section_segments()
    {
        if( $this->uri->segment(3) == 1 ){ // sections/view/1
            return false;
        }else{
            return true;
        }
    }
    // FIXME: Can we have better query for getSection functions like Laravel Eloquent? [Ace]
    public function getAllQuestionsBySection($sectionID)
    {
        $not_in = $this->get_q_id_org($sectionID,"0",true);
        $this->db->order_by("q_section", "asc");
                 $this->db->where('status',"1");
                 $this->db->where('FLOOR(q_section)', $sectionID);
                 $this->db->where_not_in('q_id', $not_in);
                 $this->db->join('section', 'questionaires.sec_id = section.id');
                if($this->with_referent)
                    $this->db->where('referent_question','0');
                 $query = $this->db->get("questionaires");
        if ($query->num_rows() > 0)
            return $query->result();

    }
    public function get_all_question($sectionID)
    {
        $not_in = $this->get_q_id_org($sectionID,"0",false);
        $this->db->order_by("q_section", "asc");
            $this->db->where('status',"1");
            $this->db->where_not_in('q_id', $not_in);
            $this->db->where('q_section', $sectionID);
                if($this->with_referent)
                    $this->db->where('referent_question','0');
             $query = $this->db->get("questionaires");
        if ($query->num_rows() > 0)
            return $query->result();

    }
    public function getQuestion()
    {
        $query = $this->db->get("questionaires");
        return $query;
    }

    public function getQuestionByID($questionID)
    {
        $this->db->where('q_id', $questionID);
        $query = $this->db->get("questionaires");
        return $query;
    }
    public function get_single_question($q_id)
    {
        $this->db->order_by("q_section", "asc");
                 $this->db->where('status',"1");
                 $this->db->where('q_id', $q_id);
                 $this->db->join('section', 'questionaires.sec_id = section.id');
                if($this->with_referent)
                    $this->db->where('referent_question','0');
                 $query = $this->db->get("questionaires");
        if ($query->num_rows() > 0)
            return $query->result();
    }
    public function get_single_answers($q_id)
    {
        $this->db->select('*');
        $this->db->from('questionaires');
        $this->db->join('question_answers', 'questionaires.q_id = question_answers.question_id');
        $this->db->where('question_answers.question_id', $q_id);
        $this->db->where('answer_caption !=',null);
        $this->db->where('user_id', $this->session->userdata('id') );
        $this->db->order_by("question_answers.id", "asc");
        $query = $this->db->get();
        return $query->result();
    }
    public function getQuestionByAdmin($questionID)
    {
        $this->db->where('id', $questionID);
        $query = $this->db->get("questionaires_org");
        return $query;
    }
    public function getSections()
    {
        $query = $this->db->order_by('section_id','asc')->get("section");
        return $query;
    }

    public function getSectionByID($sectionID, $flag = null)
    {
        if($flag)
            $this->db->where('id',$sectionID);
        else
            $this->db->where('section_id',$sectionID);
        $query = $this->db->get("section");
        return $query;
    }

    public function getSection($sectionID)
    {
        $this->db->where('id',$sectionID);
        $query = $this->db->get("section");
        return $query;
    }
    public function getQuestionBySection($sectionID)
    {
        $not_in = $this->get_q_id_org($sectionID,"0", false);
        $this->db->where('q_section', $sectionID);
        $this->db->where('status',"1");
        $this->db->where_not_in('q_id', $not_in);
        if($this->with_referent)
            $this->db->where('referent_question','0');
        $query = $this->db->get("questionaires");
        return $query;
    }

    public function countQuestionBySection($sectionID)
    {
        $not_in = $this->get_q_id_org($sectionID,"0",false);
        $this->db->select('*');
        $this->db->from('questionaires');
        $this->db->where('q_section', $sectionID);
        $this->db->where_not_in('q_id', $not_in);
        if($this->with_referent)
            $this->db->where('referent_question','0');
        $query = $this->db->get();
        return $query->num_rows();
    }

    public function get_next_section($id)
    {
        try {
            $this->db->select('*');
            $this->db->from('section');
            $this->db->where('section_id >', $id);
            $this->db->order_by('section_id asc');
            $this->db->limit(1);
            $query = $this->db->get();
            $next_item = $query->num_rows() > 0 ? $query->row()->section_id : 0;

            return $next_item;
        }catch(Exception $ex){
            return false;
        }
    }
    public function get_prev_question($id,$order)
    {
        try {
            $not_in = $this->get_q_id_org($id,"0",true);
            $this->db->select('*');
            $this->db->from('questionaires');
            $this->db->where('q_section <=', $id);
            $this->db->where('q_order', $order - 1);
            $this->db->where_not_in('q_id', $not_in);
            if($this->with_referent)
                $this->db->where('referent_question','0');
            $this->db->order_by('q_section','desc');
            $this->db->order_by('q_order','desc');
            $this->db->limit(1);
            $query = $this->db->get();

            $next_item = $query->num_rows() > 0 ? $query->row() : 0;

            return $next_item;
        }catch(Exception $ex){
            return false;
        }

    }
    public function get_next_question($id)
    {
        try {
            $not_in = $this->get_q_id_org($id,"0",true);
            $this->db->select('*');
            $this->db->from('questionaires');
            $this->db->where('q_section >', $id);
            $this->db->where_not_in('q_id', $not_in);
            if($this->with_referent)
                $this->db->where('referent_question','0');
            $this->db->order_by('q_section asc');
            $this->db->limit(1);
            $query = $this->db->get();
            $next_item = $query->num_rows() > 0 ? $query->row() : 0;

            return $next_item;
        }catch(Exception $ex){
            return false;
        }

    }

    public function getNextItem($id)
    {
        try {
            $this->db->select('*');
            $this->db->from('section');
            $this->db->where('section_id >', $id);
            $this->db->order_by('section_id asc');
            $this->db->limit(1);
            $query = $this->db->get();
            $next_item = $query->num_rows() > 0 ? $query->row()->section_id : 0;
            if((int)$id != (int) $next_item)
                $next_item = 'result/'.(int)$id;

            return $next_item;
        }catch(Exception $ex){
            return false;
        }
    }

    public function countAnsweredQuestion($sectionID, $userID)
    {
        $not_in = $this->get_q_id_org($sectionID,"0",true);
        $this->db->select('*');
        $this->db->from('questionaires');
        $this->db->join('question_answers', 'questionaires.q_id = question_answers.question_id');
        $this->db->where('FLOOR(questionaires.q_section)',$sectionID);
        if($this->with_referent)
            $this->db->where('referent_question','0');
        $this->db->where_not_in('questionaires.q_id', $not_in);
        $this->db->where('user_id',$userID);
        $this->db->where('answer_caption !=',null);
        $this->db->group_by('question_answers.question_id');
        $query = $this->db->get();
        return $query->num_rows();
    }

    public function getAnswer($id, $userID, $option)
    {
        if($option == 1) {
            $this->db->select('*');
            $this->db->from('question_answers');
            $this->db->where('question_id', $id);
            $this->db->where('user_id', $userID);
            $this->db->where('answer_caption !=', null);
            $query = $this->db->get();
        }else{
            $not_in = $this->get_q_id_org($id,"0",true);
            $this->db->select('*');
            $this->db->from('question_answers');
            $this->db->join('questionaires', 'questionaires.q_id = question_answers.question_id');
            $this->db->where_not_in('q_id', $not_in);
            if($this->with_referent)
                $this->db->where('referent_question','0');
            if( $this->section_segments() == false )
            {
                $this->db->where('q_section', $id);

            }else{
                $this->db->like('q_section', $id , 'after'); 
            } 
            $this->db->where('user_id', $userID);
            $this->db->where('answer_caption !=', null);
            $query = $this->db->get();
        }
        return $query;
    }

    /**
     * @param $question_id = Question ID for question
     * @param $final_answer =  should be JSON format
     * @return string
     */
    // TODO: Put backend validation [Ace]
    public function postAnswers($question_id, $final_answer)
    {
        try {
            $this->db->where('question_id', $question_id);
            $this->db->where('user_id', $this->session->userdata('id'));
            $query = $this->db->get($this->table);
            if ($query->num_rows() > 0) {
                $this->db->where('question_id', $question_id);
                $this->db->where('user_id', $this->session->userdata('id'));
                $this->db->update($this->table, ["answer_caption" => $final_answer]);
            } else {
                $data = [
                    'question_id'       =>  $question_id,
                    'answer_caption'    =>  $final_answer,
                    'user_id'           =>  $this->session->userdata('id'),
                    'date_created'      =>  date('Y-m-d H:i:s'),
                    'session_id'        =>  $this->logs->last_activity()->id
                ];
                $this->db->insert($this->table, $data);
            }
            return ak_return('success','Answer Saved');
        }catch(Exception $ex){
            return ak_return('success','An error occur');
        }
    }

    // FIXME: Better insertion please? [Ace]
    /**
     * flag = 1 or 0
     * 1 = submit for referents page @ profile
     * 0 = for answering referent @ section
     */
    public function postReferents($answer, $i, $flag = null)
    {
        try {
            if($this->session->userdata('username') == $answer[7]){
                echo ak_return('error','Votre email ne peut pas être référent');
                return false;
            }
            if($ref = json_decode($this->referents->get_referents_by_email($answer[7], null, 1))){
                if($answer[8]){
                    if($ref_update = json_decode($this->referents->get_referents_by_id($answer[8], null, 1))){
                        if($ref_update->id != $ref->id){
                            echo ak_return('error','Référent existe déjà');
                            return false;
                        }
                    }
                }else {
                    echo ak_return('error', 'Référent existe déjà');
                    return false;
                }
            }
            if($flag) {
                $this->db->where('user_id', $this->session->userdata('id'));
                $this->db->where('id', $answer[8]);
                $this->db->update('referents',
                    [
                        "last_name" => $answer[4],
                        "first_name" => $answer[5],
                        "sector" => $answer[0],
                        "function" => $answer[3],
                        "email" => $answer[7],
                        "token_id" => $this->token->generate(),
                        "company" => $answer[1],
                        "job" => $answer[2],
                        "link" => $answer[6],
                        //'date_email' => date("Y-m-d H:i:s", strtotime('today GMT')),
//                        "validation" => 0
                    ]
                );
            }else{
                $this->db->where('user_id', $this->session->userdata('id'));
                $query = $this->db->get('referents');
                if ($query->num_rows() > 0 && $i == 0) {
                    $this->db->delete('referents', ['user_id' => $this->session->userdata('id')]); // I forgot why we need this query [Ace]
                }
                $data = [
                    "user_id" => $this->session->userdata('id'),
                    "last_name" => $answer[4],
                    "first_name" => $answer[5],
                    "sector" => $answer[0],
                    "function" => $answer[3],
                    "email" => $answer[7],
                    "token_id" => $this->token->generate(),
                    "company" => $answer[1],
                    "job" => $answer[2],
                    "link" => $answer[6],
                    'date_email' => date("Y-m-d H:i:s", strtotime('today GMT')),
                    "validation" => 0
                ];
                $this->db->insert('referents', $data);
            }
            echo ak_return('success','Référent enregistré');
        }catch(Exception $ex){
            echo ak_return('success','An error occur');
            return false;
        }
    }

    public function postDisapp($data)
    {
        $this->db->where('user_id', $this->session->userdata('id'));
        $query = $this->db->get('disappointments');
        if ($query->num_rows() > 0) {
            $this->db->delete('disappointments', ['user_id' => $this->session->userdata('id')]); // TOO LAZY TO CODE UPDATE LOL
        }

        unset($data["q_id"]);
        $content = [];
        foreach($data as $dt)
        {
            $content[] = $dt;
        }
        $insert_data = [
            'user_id'   =>  $this->session->userdata('id'),
            'content'   =>  json_encode($content)
        ];
        $this->db->insert('disappointments', $insert_data);
    }

    public function getDisapp()
    {
        $this->db->where('user_id', $this->session->userdata('id'));
        $query = $this->db->get('disappointments');
        if ($query->num_rows() > 0) {
            return json_decode($query->row()->content);
        }
    }
    /**
     * @param null $id
     * @param null $flag , 1 = referents list in profile
     * @return query
     */
    public function get_referents($id = null, $flag = null)
    {
        if($id){
            $this->db->select('*');
            $this->db->from('referents');
            $this->db->where('user_id',$this->session->userdata('id'));
            $this->db->where('id',$id);
            $query = $this->db->get();
        }else if($flag) {
            $query = $this->db->select('*')
                     ->from('referents')
                     ->where('user_id',$this->session->userdata('id'));
        }else{
            $this->db->select('*');
            $this->db->from('referents');
            $this->db->where('user_id',$this->session->userdata('id'));
            $query = $this->db->get();
        }
        return $query;
    }

    /**
     * @param $flag = allsection_floor / allquestion / question or answer provided section id
     * @param $section_id
     * @return mixed
     */
    public function count_this($flag, $section_id = null, $user_id = null)
    {
        $orig_section = $section_id;
        $section_id = floor($section_id);
        switch($flag){
            case 'allsection_byid':
            {
                $this->db->select('*')
                    ->from('section')
                    ->where('section_id !=',0.0)
                    ->where('FLOOR(section_id)',$section_id)
                ;
                break;
            }
            case 'allsection_floor':
            {
                $this->db->select('*')
                    ->from('section')
                    ->where('section_id !=',0.0)
                    ->group_by('FLOOR(section_id)')
                ;
                break;
            }
            case 'allquestion':
            {
                $not_in = $this->get_q_id_org(null,"0",false);
                $this->db->select('*');
                    $this->db->where('status',"1") ;
                if($this->with_referent)
                    $this->db->where('referent_question','0');
                    $this->db->where_not_in('q_id', $not_in);
                    $this->db->from('questionaires');
                break;
            }
            case 'question':
            {
                $not_in = $this->get_q_id_org($section_id,"0",true);
                $this->db->select('*');
                        $this->db->from('questionaires');
                        $this->db->where('status',"1");
                        $this->db->where_not_in('q_id', $not_in);
                if($this->with_referent)
                    $this->db->where('referent_question','0');
                        $this->db->where('FLOOR(q_section)', $section_id);
                break;
            }
            case 'question_by_section':
            {
                $not_in = $this->get_q_id_org($orig_section,"0",false);
                $this->db->select('*');
                    $this->db->from('questionaires');
                    $this->db->where('status',"1");
                    $this->db->where_not_in('q_id', $not_in);
                if($this->with_referent)
                    $this->db->where('referent_question','0');
                    $this->db->where('q_section', $orig_section);
                break;
            }
            case 'answer':
            {
                $user_id = $user_id ? $user_id : $this->session->userdata('id');
                $this->db->select('*')
                    ->from('questionaires')
                    ->where('status',"1")
                    ->join('question_answers', 'questionaires.q_id = question_answers.question_id')
                    ->where('FLOOR(q_section)', $section_id)
                    ->where('answer_caption !=', null)
//                    ->where('answer_caption !=', '[]')
                    ->where('user_id', $user_id)
                    ->order_by("question_answers.id", "asc");
                break;
            }
            case 'step_done':
            {
                $this->db->select('*')
                        ->from('step')
                        //->join('section','section.section_id = step.section_id')
                        ->where('user_id', $this->session->userdata('id'))
                        ->where('percentage', 100)
                        //->group_by('FLOOR(section_id)')
                ;
            }
        }
        $query = $this->db->get();
//        return ['result'=>$query->result()[0], 'count'=>$query->num_rows()];
        return $query->num_rows();
    }

    public function delete_referents()
    {
        $this->db->where('id', $this->input->get('id'));
        $this->db->delete('referents');

        return true;
    }
    public function get_answers($section_id = null, $user_id = null)
    {
        $user_id = $user_id ? $user_id : $this->session->userdata('id');
        $this->db->select('*');
        $this->db->from('questionaires');
        $this->db->join('question_answers', 'questionaires.q_id = question_answers.question_id');
        if($section_id) {
            $this->db->where('q_section', $section_id);
        }
        $this->db->where('answer_caption !=',null);
        $this->db->where('user_id',$user_id);
        $this->db->order_by("question_answers.id", "asc");
        $query = $this->db->get();
        return $query->result();
    }
    public function getFirstQ(){
        $this->db->count_all_results('question_answers');
        $this->db->where('question_id', '0');
        $this->db->where('user_id', $this->session->userdata('id'));
        $this->db->from('question_answers');
        return $this->db->count_all_results();
    }
    public function getPercentage($section){ // Why do we need to save it to db when we can query the answer? [Ace]
        $this->db->where('user_id', $this->session->userdata('id'));
        //$this->db->where('section_id', $section);
        $this->db->where('FLOOR(section_id)',$section);
        $query = $this->db->get('step');
//        dd($this->questions->count_this('allsection_byid',$section));
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                if( $row->percentage < 100 ){
                    $finished[] = false;
                }
            }
           
        }
    }

//    public function getPercentage_($section_id){ // New function. Dont wanna ruin getPercentage function [Ace]
//        $section_id = floor($section_id);
//        $this->db->where('user_id', $this->session->userdata('id'));
//        $this->db->where('FLOOR(section_id)',$section_id);
//        $query = $this->db->get('step');
//        $finished = [];
//        if ($query->num_rows() > 0) {
//            foreach ($query->result() as $row) {
//                    $finished[] = $row->percentage;
//            }
//        }
//        return $finished;
//    }

    /**
     * Get the currenct percentage of a section provided by section id
     * Count answered question instead fetching section table
     * @param $section_id
     * @return float
     */
    public function getPercentage_($section_id, $user_id = null) // New function. Don't wanna ruin getPercentage function [Ace]
    {
        $user_id = $user_id ? $user_id : $this->session->userdata('id');
        $percentage = $this->questions->count_this('answer', $section_id, $user_id);
        $c_q = $this->questions->count_this('question', $section_id); // $section_id == 4 ? $this->questions->count_this('question', $section_id) - 1 :
        $MAX_SECTION_PERCENTAGE = $c_q * 100;
        $ANSWER_DONE = $percentage * 100;
        $final_p = $ANSWER_DONE > 0 && $MAX_SECTION_PERCENTAGE > 0 ? ( ceil(($ANSWER_DONE / $MAX_SECTION_PERCENTAGE) * 100) > 100 ? 100 : ceil(($ANSWER_DONE / $MAX_SECTION_PERCENTAGE) * 100) ) : 0 ;
        return $final_p;
    }

    public function submit_serie($data)
    {
        if(is_array($data) && count($data) > 0 ){
            $this->db->where('user_id', $this->session->userdata('id'));
            $this->db->delete('serie');
            foreach($data as $aRow)
            {
                $exp = explode("_",$aRow);
                $data = [
                    'user_id'        =>  $this->session->userdata('id'),
                    'serie_id'       =>  $exp[1],
                    'serie_letter'   =>  $exp[0],
                    'serie_choice'   =>  $exp[2]
                ];
                try{
                    $this->db->insert('serie', $data);
                }catch(Exception $ex){
                    echo ak_return('error','Error saving');
                }
            }

            echo json_encode( array(
                'message' => 'Insertion réussie',
                'redirect' => 'true'
            ));
        }
    }
    public function fetch_serie()
    {
        $this->db->select('*');
        $this->db->from('serie');
        $this->db->where('user_id',$this->session->userdata('id'));
        $query = $this->db->get();
        return json_encode($query->result());
    }
    public function fetch_serie_result()
    {
        $query = $this->db->select('*')
                ->from('serie')
                ->where('user_id',$this->session->userdata('id'))
                ->get();
        if($query->num_rows() > 0 ){
            $letters = ["T","R","I","C","A","M"];
            $result = [];
            foreach($letters as $letter){
                $query = $this->db
                    ->select_sum('serie_choice')
                    ->from('serie')
                    ->where('user_id',$this->session->userdata('id'))
                    ->where('serie_letter',$letter)
                    ->get();
                $data = [
                    'serie_letter'  =>  $letter,
                    'serie_choice'  =>  $query->row()->serie_choice
                ];
                $result[] = $data;
            }
            usort($result, function($a, $b) {
                if($a['serie_choice'] == $b['serie_choice']) return 0;
                return $a['serie_choice'] < $b['serie_choice'] ? 1 : -1;
            });
            return json_encode($result); //array_slice($result,0,3));
        }
    }
    public function fetch_last_answered($section_id = null, $user_id = null, $flag = null)
    {
        $user_id = $user_id ? $user_id : $this->session->userdata('id');
        $this->db->join('questionaires', 'questionaires.q_id = question_answers.question_id');
        $this->db->where('question_answers.user_id', $user_id );
        if($section_id)
            $this->db->where('FLOOR(q_section)',$section_id);

        $this->db->order_by('question_answers.id','desc');
        
        if($flag == "true")//for BACKOFFICE
            $this->db->order_by('questionaires.q_section','desc');

        $query = $this->db->get('question_answers');
        return $query->row();
    }
    public function my_last_answered($section_id = null, $user_id = null)
    {
        $user_id = $user_id ? $user_id : $this->session->userdata('id');
        $this->db->join('questionaires', 'questionaires.q_id = question_answers.question_id');
        $this->db->where('question_answers.user_id', $user_id );
        if($section_id)
            $this->db->where('FLOOR(q_section)',$section_id);

        $this->db->order_by('questionaires.q_section','desc');

        $query = $this->db->get('question_answers');
        return $query->row();
    }
    public function my_last_answered_by_year($section_id = null, $user_id = null, $by_date = null)
    {
        $user_id = $user_id ? $user_id : $this->session->userdata('id');
        $this->db->join('questionaires', 'questionaires.q_id = question_answers.question_id');
        $this->db->where('question_answers.user_id', $user_id );

        if($section_id)
            $this->db->where('FLOOR(q_section)',$section_id);

        if( $by_date )
            $this->db->where("DATE_FORMAT(date_created,'%Y')" , date('Y'));
        
        $this->db->order_by('questionaires.q_section','desc');

        $query = $this->db->get('question_answers');
        return $query->row();
    }
    public function answer_left_questions()
    {
        $not_in = $this->get_q_id_org($this->input->get('section_id'),"0",true);
        $this->db->where('user_id',$this->session->userdata('id'));
            $this->db->join('question_answers','question_answers.question_id = questionaires.q_id');
            $this->db->where('FLOOR(questionaires.q_section)', floor($this->input->get('section_id')));
            $this->db->where_not_in('q_id', $not_in);
                if($this->with_referent)
                    $this->db->where('referent_question','0');
           $answered_question =  $this->db->get('questionaires');
            $this->db->select('*');
                        $this->db->from('questionaires');
                        $this->db->where('status',"1");
                        $this->db->where('floor(q_section)', floor($this->input->get('section_id')));
                        $this->db->where_not_in('q_id', $not_in);
                    if($this->with_referent)
                        $this->db->where('referent_question','0');
                        $this->db->order_by('q_section','asc');
                        $this->db->order_by('q_order','asc');
                         $question_section = $this->db->get();
        if($question_section->num_rows() != $answered_question->num_rows()){
            $unanswered = $question_section->num_rows() - $answered_question->num_rows();
            $q_id = [];
            foreach($question_section->result() as $data)
                $q_id[] = $data->q_id;
            foreach(array_slice($q_id, -$unanswered, $unanswered) as $question)
                $this->postAnswers($question, '[]');

        }
    }
    public function get_all_questions_org()
    {
        if($this->session->userdata('role') == ADMIN){
            return $this->db->from('questionaires')
                    ->where_in('q_id',[96,100])
                    ->order_by('q_section','asc');
        }
        return $this->db->from('questionaires')
//            ->join('questionaires_org','questionaires_org.question_id = questionaires.q_id','left')
            ->order_by('q_section','asc')
//            ->order_by('q_order','asc')
            ;
    }
    public function get_section_title($sec_id = null)
    {
        $this->db->select("section_title");
        $this->db->where('id', $sec_id);
        $query = $this->db->get("section");
        return $query->row_array();
    }
    public function get_question_org($id)
    {
        return $this->db
                    ->where('q_id',$id)
                    ->where('ord_id',$this->session->userdata('org'))
                    ->get('questionaires_org');
    }
    public function get_question_org_with_section($id)
    {
        return $this->db
            ->where('q_id',$id)
            ->where('ord_id',$this->session->userdata('org'))
            ->join('section', 'questionaires_org.sec_id = section.id')
            ->get('questionaires_org');
    }
    public function get_question_org_section($section_number, $status, $floor = null)
    {
        if($section_number) {
            if ($floor)
                $this->db->where('floor(questionaires_org.q_section)', floor($section_number));
            else
                $this->db->where('questionaires_org.q_section', $section_number);
        }
        $this->db->where('questionaires_org.ord_id',$this->session->userdata('org'));
        $this->db->where('questionaires_org.status',$status);
        return $this->db->get('questionaires_org');
    }
    public function get_q_id_org($section_number, $status, $floor = null)
    {
        $query = $this->get_question_org_section($section_number, $status, $floor)->result();
        $q_id = [0];
        foreach($query as $q){
           $q_id[] = $q->q_id;
        }
        return $q_id;
    }
    public function is_next_disabled($section_id, $status = null)
    {
        if(
//            floor($section_id) != 1 &&
            (
//            !$status ||
            $this->count_this('question_by_section',$section_id) == 0
            &&
            (
                $this->get_question_org_section($section_id,'1',false)->num_rows()
                < $this->get_question_org_section($section_id,'0',false)->num_rows()
                ||
                is_numeric($section_id) &&
                $this->get_question_org_section($section_id,'1',false)->num_rows() == 0 &&
                $this->get_question_org_section($section_id,'0',false)->num_rows() == 0
            )
            )
        ){
            return $this->is_next_disabled($this->getNextItem($section_id));
        }else{
            return $section_id;
        }
    }

    public function get_question_by_session($logid, $user_id = null)
    {
        $user_id = $user_id ? $user_id : $this->session->userdata('id');
        $this->db
            ->where('session_id',$logid)
            ->where('user_id',$user_id)
            ->order_by('question_answers.id','desc');
        $query = $this->db->get('question_answers');
        return $query;
    }
}