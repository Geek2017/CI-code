<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Event_email_template_mapping_by_event_schedule_model extends CI_Model {

    function __construct(){
        parent::__construct();
        $this->table_mapping_child = "event_email_template_mapping_child_event";
    }
   public function remove_template_event_schedules($email_mapping_id_sched)
   {
      $this->db->where("email_mapping_persched_id", $email_mapping_id_sched);
      $this->db->update($this->table_mapping_child, array("is_active" => '0'));
      return $this->db->affected_rows();
   }
   public function assign_template_events()
   {
        $this->db->insert($this->table_mapping_child, 
        array(
         'event_schedule_id' => $_POST['event-id-value'],
         'email_tpl_id' => $_POST['template-id-value'],
         'is_active' =>  1
        ));
   }
   public function search_by_template_ids($email_type_id)
   {
        $result = $this->db->query("
            SELECT email_tpl_id, email_tpl_name 
            FROM event_email_template 
            WHERE email_type_id = ".$email_type_id." 
            AND email_tpl_status = 2
        ");
        
        if ($result->num_rows() > 0) 
        {
            $arr = [];
             foreach ($result->result_array() as $key => $value) {
                array_push($arr, 
                    array(
                    "template_id" => $value['email_tpl_id'],
                    "template_name" => $value['email_tpl_name']
                )
                );
             }
             return $arr;
        }
    }
    public function get_table_event($event_schedule_id)
    {
        $result = $this->db->query("
           SELECT
            type.email_type_id,
            type.email_type as template_type,
            (SELECT
                GROUP_CONCAT(
                        CONCAT(
                            eetm.email_mapping_persched_id,'_',
                            eetm.email_tpl_id,'_',
                            eet.email_tpl_name
                        )
                        ORDER BY eetm.email_tpl_id SEPARATOR ';;') as assigned_tempalate
                FROM event_email_template_mapping_by_event_schedule eetm
                LEFT JOIN event_email_template eet ON eet.email_tpl_id =  eetm.email_tpl_id
                WHERE eet.email_type_id = type.email_type_id
                AND eetm.is_active = 1
                AND eetm.event_schedule_id = ".$event_schedule_id."
                LIMIT 1
            ) AS assigned_tempalate

            FROM event_email_template_type as type
            WHERE
                type.email_type_status = 1               
             ORDER BY 
                type.sort_order ASC
        ");
        
        if ($result->num_rows() > 0) 
        {
            $res = [];
            $x = 0;
            foreach ($result->result_array() as $key => $value) {
                 $splits =  explode('_',$value['assigned_tempalate'] );
                array_push($res, 
                    array(
                        'no' => ++$x,
                        'email_type_id' => $value['email_type_id'],
                        'template_type' => $value['template_type'],
                        'default' => "N/A" ,
                        'template_name' => (  isset($splits[2]) ? $splits[2] : "" ),
                        'template_id' => (  isset($splits[1]) ? $splits[1] : "" ) ,
                        'email_mapping_id' => (  isset($splits[0]) ? $splits[0] : "" ) 
                    )
                );
            }
            return array( 'data' => $res );
        }
    }
}

