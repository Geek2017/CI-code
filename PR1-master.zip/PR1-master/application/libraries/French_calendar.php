<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class French_calendar {

        public function month($month)
        {
         	return str_replace(
                array(
                    'January', 
                    'February', 
                    'March', 
                    'April', 
                    'May', 
                    'June', 
                    'July', 
                    'August', 
                    'September', 
                    'October', 
                    'November', 
                    'December'
                ),
                array(
                    'Janvier', 
                    'Février', 
                    'Mars', 
                    'Avril', 
                    'Mai', 
                    'Juin', 
                    'Juillet', 
                    'Août', 
                    'Septembre', 
                    'Octobre', 
                    'Novembre', 
                    'Décembre'
                ),
                
                ucfirst( $month )
            );
        }
}

