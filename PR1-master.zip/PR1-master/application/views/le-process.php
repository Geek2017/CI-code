<div class="container">
<div class="row">
    <div class="col-lg-12">
     	<h2>Le processus en dix étapes vous fait cheminer au travers :</h2><br>
        <ul class="dashed">
            <li> <b>D’une série d’exercices personnels</b>, certains demanderont de la réflexion et d’autres de la spontanéité, ce qui compte c’est le « parler vrai », dans tous les cas personne n’aura accès à votre dossier. Attention, une fois l’exercice validé, vous n’aurez plus l’occasion de revenir sur ces exercices, en revanche chaque synthèse d’étape se retrouvera sur votre profil et sera imprimable.</li><br>

            <li> Pour chaque exercice demandant réflexion, un exemple personnel vous sera donné, nous vous demandons de compléter votre réponse sur cet exemple.</li><br>

            <li> <b>Dans la partie Regards croisés</b>, nous vous proposons d’avoir un retour sur votre personnalité et d’ouvrir vos horizons professionnels auprès de votre réseau professionnel interne. Je vous propose donc d’ores et déjà de réfléchir à une liste de noms de collaborateurs (hiérarchique ou non) bienveillants, utiles et stratégiques qui pourraient répondre à un questionnaire de 15 minutes à votre sujet.<br><br>
			Le processus sera le suivant : vous compléterez et enverrez un premier mail, à partir de votre messagerie, à un salarié de l’entreprise expliquant votre démarche et lui demandant si il accepte de répondre à un questionnaire de 15 minutes (un exemple de mail vous sera donné), si tel est le cas, le salarié s’inscrira directement via le lien proposé. La plateforme AMPI se chargera par la suite d’envoyer un deuxième mail avec un lien vers le questionnaire à compléter. Le lien ci-dessous vous présente ce questionnaire.
			</li>
        </ul><br> 
         <h3>Si vous êtes accompagné, quelles sont vos attentes vis-à-vis de votre coach référent ?</h3>
         <textarea row="10" column="10" name="question_0" id="question_0"  class="form-control"  title="">
         </textarea>
         <h3 class="text-center">Nous vous souhaitons une agréable et fructueuse réflexion</h3>
        <div class="pull-right">
         <button id="btn-load" onclick="save_question_0();" data-loading-text="Démarrer ...."  type="button" class="btn btn-primary start">Démarrer </button>
        </div>
    </div>

</div>
</div>