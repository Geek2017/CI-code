<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/** DATATABLES FIELDS && TABLE COLUMNS **/

/*datatable columns*/
$lang["email_tpl_name"] = "Nom du Template";
$lang["email_tpl_type"] = "Type de Template";
$lang["email_tpl_status"] = "Statut de création";
$lang["email_assigned_status"] = "Statut";
$lang["email_tpl_setting_sched"] = "Nombre d'heures avant l'envoi";
$lang["email_tpl_number_of_recipients"] = "Nombre d'abonnés";
$lang["email_tpl_creation_status"] = "Définir comme template par défaut";
$lang["email_tpl_author"] = "Auteur";
$lang["email_tpl_date_created"] = "Date de création";
$lang["email_schedule_date_added"] = "Date de création";
$lang["schedule_date"] = "Date de rappel";
$lang["select"] = "Selectionnez";
$lang["email_assigned_events"] = "Événements assignés";
$lang["email_schedule_date"] = "Date de rappel";
$lang["email_sched_overwrite_default"] = "Overwrite default schedule?";
$lang["email_schedule_author"] = "Auteur";
$lang["event_title"] = "Nom d’événement";
$lang["start_date_time"] = "Événement date de début";
$lang["email_schedule_status"] = "Calendrier";
$lang["email_push_filters"] = "Filtres";
$lang["email_push_subscribers"] = "Les abonnés";
$lang["email_push_email_sent"] = "Emails envoyés";
$lang["email_push_email_onqueue"] = "Emails en file d'attente";
$lang["email_push_date_created"] = "Date de création";
$lang["actions"] = "Actions";
$lang["email_push_author"] = "Auteur";

/*Default Email Subject*/
$lang["subject_email_reminder"] = "Rappel d'événement pour ";
$lang["subject_waitlist_reinvitation"] = "Réinvitation sur liste d'attente";
$lang["subject_email_push"] = "Push : Evénement";

/*datatable buttons*/
$lang["event_preview"] = "Prévisualisez";
$lang["click_to_preview"] = "Cliquez pour afficher l'événement";

/*datatable filters*/
$lang["events"]["_filter"]["all"] = "Tous";
$lang["events"]["_filter"]["research"] = "Rechercher";

/** MODAL FORMS **/
$lang["email_status"] ="Statut d'email";
$lang["template_name"] ="Nom du Template";
$lang["email_subject"] = "Objet";
$lang["choose_event"] ="Choisissez un événement";
$lang["choose_email_template"] ="Sélectionner un Template";
$lang["use_as_creation_status"] =" Configurer un Template par défaut pour cette email?";
$lang["event_email_status"] ="Statut d'email";
$lang["email_tpl_setting_sched_unit"] = "Nombre d'heures avant l'envoi (Unit)";
$lang["email_tpl_setting_sched_minute"] = "Nombre de minutes avant l'envoi";
$lang["email_tpl_setting_sched_hour"] = "Nombre d'heures avant l'envoi";
$lang["email_tpl_setting_sched_day"] = "Nombre de jours avant l'envoi";
$lang["delay_before_dispatch"] = "Délai avant envoi";
$lang["delay_time_unit_before_dispatch"] = "Unité de temps du délai avant envoi";
$lang["choose"] = "Selectionnez";
$lang["filter_by"] = "Filtrer par:";
$lang["send_to"] = "Envoyer à:";
$lang["search_by_seniority"] = "Recherche par Ancienneté";
$lang["search_by_location"] = "Recherche par Localisation";
$lang["search_by_interest"] = "Recherche par Intérêt";
$lang["all_subscribers"] = "Tous les abonnés";
$lang["specific_subscribers"] = "Abonnés spécifiques";
$lang["search_subscriber"] = "Recherche Abonné";
$lang["warning"] = "Avertissement: cette action remplacera la planification par défaut des emails de rappel.";
$lang["select_all"] = "Tout sélectionner";
/** CONFIRMATION ACTION MESSAGE ON MODAL **/

/*modal titles*/
$lang["email"]["title"]["create_template"] = "Créer un Email Template";
$lang["email"]["title"]["edit_default_email_setting"] = "Paramètre de configuration d’édition";
$lang["email"]["title"]["set_default_email_setting"] = "Configurer un email";
$lang["email"]["title"]["set_default_email_setting"] = "Paramètre de configuration par défaut";
$lang["email"]["title"]["assign_template"] = "Assigner un Template";
$lang["email"]["title"]["add_email_reminder"] = "Créér un email de rappel";
$lang["email"]["title"]["edit_template"] = "Editer un Template";
$lang["email"]["title"]["edit_email_reminder"] = "Editer un email de rappel";
$lang["email"]["title"]["add_email_push"] = "Créér un email";
$lang["email"]["title"]["update_email_push"] = "Update push event email";

/*modal confirmation message*/
$lang["email"]["cmsg"]["create_new_template"] = "Créer un nouveau Template?";
$lang["email"]["cmsg"]["save_configuration"] = "Voulez-vous sauvegarder ce paramètre pour la configuration par défaut?";
$lang["email"]["cmsg"]["edit_template"] = "Sauvegarder les modifications du Template?";
$lang["email"]["cmsg"]["edit_configuration"] = "Etes-vous sure de vouloirs modifier la configuration par défaut?";
$lang["email"]["cmsg"]["delete_email_template"] = "Etes-vous sure de vouloirs supprimer l'email template ?";
$lang["email"]["cmsg"]["assign_template"] = "Voulez vous assigner l'email template a cette événement ?";
$lang["email"]["cmsg"]["update_assign_template"] = "Voulez-vous appliquer les modifications ?";
$lang["email"]["cmsg"]["delete_assign_template"] = "Etes-vous sure de vouloirs supprimer les modifications ?";
$lang["email"]["cmsg"]["add_email_reminder"] = "Voulez-vous enregistrer votre email de rappel?";
$lang["email"]["cmsg"]["delete_email_reminder"] = "Voulez-vous supprimer le planning pour l'email de rappel ?";
$lang["email"]["cmsg"]["save_changes"] = "Voulez-vous appliquer les modifications ?";
$lang["email"]["cmsg"]["add_email_push"] = "Créér un email";
$lang["email"]["cmsg"]["delete_email_push"] = "Supprimer un e-mail push événement?";
$lang["email"]["cmsg"]["empty_subject"] = "Attention: L'objet email est vide, voulez vous utiliser l'objet par défaut suivant ? ";
$lang["email"]["cmsg"]["event_is_full"] = "L'e-mail \"push\" ne peut pas être envoyé car l’événement est complet ";

/*modal buttons*/
$lang["email"]["btn"]["create_new_template"] = "Créer un Email Template";
$lang["email"]["btn"]["save_configuration"] = "Sauvegarder les modifications";
$lang["email"]["btn"]["assign_template"] = "Assigner un template";
$lang["email"]["btn"]["add_email_reminder"] = "Créér un email de rappel";
$lang["email"]["btn"]["add_email_push"] = "Créér un email";
$lang["email"]["btn"]["save_changes"] = "Voulez-vous appliquer les modifications ?";

/*modal validation message*/
$lang["email"]["val"]["description_req"] = "Un template email est requis!";
$lang["email"]["val"]["template_type_req"] = "Une erreur s'est produite, merci de recharger la page!";
$lang["email"]["val"]["email_tpl_req"] = "Veuillez choisir un template email à partir de la sélection !";
$lang["email"]["val"]["email_event_req"] = "Veuillez sélectionner un événement!";
$lang["email"]["val"]["email_template_req"] = "Merci de sélectionner un  template email!";
$lang["email"]["pub_email_tpl"]["publishing_email_template"] = "Publier le template email...";
$lang["email"]["val"]["invlaid_date"] = "L'intervalle entre les dates est invalide ! (JJ/MM/AAAA - JJ/MM/AAAA)";
$lang["email"]["val"]["event_first"] = "Selectionnez un événement";


/**  SERVER-SIDE ERROR MESSAGE **/

$lang["unknown_error"] = "Quelque-chose s'est mal passé!";
$lang["event_title_exist"] = "Le nom d'événement existe déjà";
$lang["email_template_created"] = "Le Template email a été créé !";
$lang["save_default_configuration"] = "Paramètre de configuration sauvegardé !";
$lang["default_configuration_updated"] = "Paramètre de configuration mis a jour !";
$lang["default_configuration_deleted"] = "Paramètre de configuration supprimé !";
$lang["email_template_updated"] = "Le Template Email a été mis a jours!";
$lang["email_template_name_duplicate"] = "Ce nom de Template a déjà été utilise !";
$lang["cant_delete_due_to_tpl_dependencies"] = " Ce template ne peut pas être supprimé car il est utilisé !";
$lang["email_template_deleted"] = "Le Template email a été supprimé ! ";
$lang["save_template_assignment"] = "Assignement du template sauvegardé ";
$lang["assign_template_updated"] = "L'assignement du template a été mis a jour";
$lang["assign_template_deleted"] = "L'assignement du template a été supprimé!";
$lang["added_email_reminder"] ="Un email a été créé.";
$lang["duplicate_email_reminder"] ="Attention, vous ne pouvez pas planifier avec la même date utilisée précédemment!";
$lang["updated_reminder_email"] ="L'email de rappel a été mis à jour.";
$lang["deleted_reminder_email"] ="L'email de rappel a été supprimé.";

//dynamic varaibles
$lang["email"]["dynamicVars"]=array(
    //array("text" => 'Surheader | Sortie: texte du Surheader', "code" => "[[var:surheader]]", "val" => "Vous faites partie des premiers inscrits"),
    array("text" => 'Adresse | sortie: Paris', "code" => "[[var:event_address]]", "val" => 'Paris'),
    array("text" => 'Année | sortie: aaaa', "code" => "[[var:event_start_year]]", "val" => 'yyyy'),
    array("text" => 'Code postal | sortie: 78720', "code" => "[[var:event_postal_code]]", "val" => '4500'),
    array("text" => 'Début de l’événement (heure) | sortie: hh:mm', "code" => "[[var:event_start_hour]]", "val" =>'00:00'),
    array("text" => 'Jour | sortie: jj', "code" => "[[var:event_start_day]]", "val" => 'dd'),
    array("text" => 'Jour de la semaine | sortie: Dimanche', "code" => "[[var:event_start_day_name]]", "val" => 'Dimanche'),
    array("text" => 'Mois | sortie: mm', "code" => "[[var:event_start_month]]", "val" => 'mm'),
    array("text" => 'Nombre de places réservées | sortie: 2 places', "code" => "[[var:seats_reserved]]", "val" =>'2 places'),
    array("text" => "Nom de l'abonné(e) | Sortie: Abonné(e)", "code" => "[[var:subscriber]]", "val" => 'Subscriber'),
    array("text" => 'Nom du lieu | sortie: Pigalle ', "code" => "[[var:event_place_name]]", "val" =>'TimeSquare'),
    array("text" => 'Nom du mois | sortie: Janvier', "code" => "[[var:event_start_month_name]]", "val" => 'Janvier'),
    array("text" => 'Photo de l’événement | sortie: Photo principale de l’événement', "code" => '<img class="img-responsive" style="border: none; clear: both; text-decoration: none; width:450px !important;" title="[[var:event_title]]" src="%5B%5Bvar%3Aevent_picture%5D%5D" alt="[[var:event_title]]"/>', "val" => 'Event primary picture'),    
    array("text" => 'Prix en euro | sortie: 100,00€', "code" => "[[var:event_rate]]", "val" => '$100'),
    array("text" => 'Titre de l’événement | sortie: titre événement', "code" => "[[var:event_title]]", "val" =>'Event name'),
    array("text" => 'Type d’événement | sortie: Concert', "code" => "[[var:event_type]]", "val" =>'Concert'),    
    array("text" => 'Ville | sortie: Paris ', "code" => "[[var:city]]", "val" => 'Paris'),
    array("text" => 'Ville de rattachement | sortie: Paris', "code" => "[[var:event_venue]]", "val" => 'Paris')
);

/* End of file events_lang.php */
/* Location: ./application/language/fr/backoffice/events_lang.php */
/**
EMAIL TEMPLATE
 * Setup tables
 * Add template
 * Edit
 * Delete ? Delete only if the template has no dependents
 * Change template (Check if there are dependents, if yes then insert new record.
    - Do not allow changing of template while sending process is in progress.
    - Allow editing of template 3hrs before the sending process
 **/