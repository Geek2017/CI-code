
<div class="home">
		<!-- TODO: WHY NOT LOOP THESE SECTION AND FETCH FROM DB INSTEAD ? -->
        <div class="row">
        	<div class="col-lg-12">
        		<a href="#" onclick="sections_profile(1);">
        			<div class="col-lg-2 w-chart">
		        		<div style="padding-top: 50px;padding-bottom: 50px;">
		        			<div class="<?php echo $this->mains->getProgressClass(1)['circle'] ?>"><p>1</p></div>
						    <div class="gray-chart">
								<div class="<?php echo $this->mains->getProgressClass(1)['title'] ?>">
									Point de départ <br> 15 min
								</div>
			        			<div class="<?php echo $this->mains->getProgressClass(1)['desc'] ?>"><b>Mise en action</b></div>
			        		</div>
		        		</div>
        			</div>
        		</a>
        		<a href="#" onclick="sections_profile(2);">
        		<div class="col-lg-2 w-chart">
	        		<div style="padding-top: 50px;padding-bottom: 50px;">	
	        		<div class="<?php echo $this->mains->getProgressClass(2)['circle'] ?>"><p>2</p></div>
					    <div class="green-chart">
							<div class="<?php echo $this->mains->getProgressClass(2)['title'] ?>">
								Capital Professionnel <br> 3h00
							</div>
		        			<div class="<?php echo $this->mains->getProgressClass(2)['desc'] ?>"><b>
									Carrière professionnelle, fil<br>d'Ariane, compétences<br> succès, échecs</b></div>
		        		</div>
	        		</div>
        		</div>
        		</a>
        		<a href="#" onclick="sections_profile(3);">
        		<div class="col-lg-2 w-chart">
	        		<div style="padding-top: 50px;padding-bottom: 50px;">	
	        		<div class="<?php echo $this->mains->getProgressClass(3)['circle'] ?>"><p>3</p></div>
					    <div class="blue-chart">
							<div class="<?php echo $this->mains->getProgressClass(3)['title'] ?>">
								Bilan Professionnel <br> 45 min
							</div>
		        			<div class="<?php echo $this->mains->getProgressClass(3)['desc'] ?>"><b>Bilan professionnel,<br>linguistique et technique</b></div>
		        		</div>
	        		</div>
        		</div>
        		</a>
        		<a href="#" onclick="sections_profile(4);">
        		<div class="col-lg-2 w-chart">
	        		<div style="padding-top: 50px;padding-bottom: 50px;">	
	        		<div class="<?php echo $this->mains->getProgressClass(4)['circle'] ?>"><p>4</p></div>
					    <div class="blue-chart">
							<div class="<?php echo $this->mains->getProgressClass(4)['title'] ?>">
								Portrait <br> 1h00
							</div>
		        			<div class="<?php echo $this->mains->getProgressClass(4)['desc'] ?>"><b>Portrait professionnel <br> (style de management)<br> et personnel</b></div>
		        		</div>
	        		</div>
        		</div>
        		</a>
        		<a href="#" onclick="sections_profile(5);">
        		<div class="col-lg-2 w-chart">
	        		<div style="padding-top: 50px;padding-bottom: 50px;">	
	        		<div class="<?php echo $this->mains->getProgressClass(5)['circle'] ?>"><p>5</p></div>
					    <div class="blue-chart">
							<div class="<?php echo $this->mains->getProgressClass(5)['title'] ?>">
								Priorités <br> 30 min
							</div>
		        			<div class="<?php echo $this->mains->getProgressClass(5)['desc'] ?>"><b>Valeurs et moteurs</b></div>
		        		</div>
	        		</div>
        		</div>
        		</a>
        	</div>
        	<div class="col-lg-12 progress-bottom">
        	<a href="#" onclick="sections_profile(6);">
        		<div class="col-lg-2 w-chart">
	        		<div style="padding-top: 50px;">
	        			<div class="<?php echo $this->mains->getProgressClass(6)['circle'] ?>"><p>6</p></div>
					    <div class="blue-chart">
							<div class="<?php echo $this->mains->getProgressClass(6)['title'] ?>">
								Regards croisés <br> internes 15 min
							</div>
		        			<div class="<?php echo $this->mains->getProgressClass(6)['desc'] ?>"><b>360- Retours personnalité, CV, pistes professionnelles</b></div>
		        		</div>
	        		</div>
        		</div>
        		</a>
        		<a href="#" onclick="sections_profile(7);">
        		<div class="col-lg-2 w-chart">
	        		<div style="padding-top: 50px;">
	        			<div class="<?php echo $this->mains->getProgressClass(7)['circle'] ?>"><p>7</p></div>
					    <div class="blue-chart">
							<div class="<?php echo $this->mains->getProgressClass(7)['title'] ?>">
								<span class="pistes">Pistes professionnelles</span> <br>  2h00
							</div>
		        			<div class="<?php echo $this->mains->getProgressClass(7)['desc'] ?>"><b>Trois pistes professionnelles internes explorées</b></div>
		        		</div>
	        		</div>
        		</div>
        		</a>
        		<a href="#" onclick="sections_profile(8);">
        		<div class="col-lg-2 w-chart">
	        		<div style="padding-top: 50px;">	
	        		<div class="<?php echo $this->mains->getProgressClass(8)['circle'] ?>"><p>8</p></div>
					    <div class="blue-chart">
							<div class="<?php echo $this->mains->getProgressClass(8)['title'] ?>">
								Projet Professionnel <br> 1h45
							</div>
		        			<div class="<?php echo $this->mains->getProgressClass(8)['desc'] ?> top1"><br><b>Un projet professionnel interne réaliste retenu. Un plan de développement détaillé construit</b></div>
		        		</div>
	        		</div>
        		</div>
        		</a>
        		<a href="#" onclick="sections_profile(9);">
        		<div class="col-lg-2 w-chart">
	        		<div style="padding-top: 50px;">	
	        		<div class="<?php echo $this->mains->getProgressClass(9)['circle'] ?>"><p>9</p></div>
					    <div class="blue-chart">
							<div class="<?php echo $this->mains->getProgressClass(9)['title'] ?>">
								Pitch <br> 1h30
							</div>
		        			<div class="<?php echo $this->mains->getProgressClass(9)['desc'] ?>"><b>Pitch rédigé et filmé</b></div>
		        		</div>
	        		</div>
        		</div>
        		</a>
        		<a href="#" onclick="sections_profile(10);">
        		<div class="col-lg-2 w-chart">
	        		<div style="padding-top: 50px;">	
	        		<div class="<?php echo $this->mains->getProgressClass(10)['circle'] ?>"><p>10</p></div>
					    <div class="blue-chart">
							<div class="<?php echo $this->mains->getProgressClass(10)['title'] ?>">
								Clôture de la<br> démarche
							</div>
		        			<div class="<?php echo $this->mains->getProgressClass(10)['desc'] ?> top1" style="padding-top:10px !important;"><b>
									Lien avec entretien d’évaluation. Ouverture de la plateforme. Évaluation de la plateforme et du coach référent.</b></div>
		        		</div>
	        		</div>
        		</div>
        		</a>
        		<br>
        		<div class="col-md-12">
        			<br>
		        	<p>Chaque étape propose :</p>
					<p>- <strong>une présentation vidéo de l’étape</strong>,<br>
					- <strong>une série d’exercices</strong> ; certains demanderont de la réflexion et d’autres de la spontanéité, l'important c'est d'être « sincère » dans les réponses. Attention, une fois l’exercice validé, vous n’aurez plus l’occasion de revenir sur celui-ci ; en revanche chaque synthèse d’étape se retrouvera sur votre profil et sera imprimable.<br>
					-	Pour chaque exercice demandant réflexion, un exemple personnel vous sera donné ; nous vous demandons de compléter votre réponse sur la base de cet exemple. <br>
					-	Un mail contact est disponible pour toute question que vous pourriez avoir. Nous nous engageons à y répondre dans les 72 heures.<br>
					-	<strong>Dans la partie « Regards croisés »</strong>, nous vous proposons d’avoir un retour sur votre personnalité et d’ouvrir vos horizons professionnels auprès de votre réseau professionnel interne. Je vous propose donc d’ores et déjà de réfléchir à une liste de noms de collaborateurs (hiérarchique ou non) bienveillants, utiles et stratégiques qui pourraient répondre à un questionnaire de 15 minutes à votre sujet.  <br>
					Le processus sera le suivant : vous appellerez la personne en question puis vous compléterez et enverrez un premier mail, à partir de votre messagerie, à un salarié de l’entreprise expliquant votre démarche et lui demandant si il accepte de répondre à un questionnaire de 15 minutes (un exemple de mail vous sera donné) ; si tel est le cas, le salarié s’inscrira directement via le lien proposé. 
					<br><br>
					La plateforme AkeeN se chargera par la suite d’envoyer un deuxième mail avec un lien vers le questionnaire à compléter.
					</p>
					<h3>Nous vous souhaitons une agréable et fructueuse réflexion</h3>
				</div>

				  <div class="pull-right">
		        	<?php if ($firstQ = 0): ?>
		        		<a href="leProcess" id="btn-load" data-loading-text="Démarrer ...."  type="button" class="btn btn-primary start">Démarrer </a>	
		        	<?php endif ?>
		        	
		        </div>
	</div>
</div>
	
        

