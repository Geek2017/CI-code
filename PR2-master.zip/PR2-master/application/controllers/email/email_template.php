<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Email_template extends MY_Controller {

    public function __construct()
    {
        $this->my_controller_parent_construct();
        $this->check_session_timed_out("bo");
        //load language files
        $this->load_language_backoffice();
        $this->lang->load('backoffice/email', 'fr');
        //load model
        $this->load->model("event_email_template_model");
        $this->load->model("user_activity_log_model");
        $this->load->helper('htmlpurifier');
    }

    public function get_email_template_list(){
        if($this->input->post() && isset($this->data["logged_in"]["user_id"])){
            $list = $this->event_email_template_model->get_datatables($this->input->post());
            $data = array();
            $row = array();
            $x = $this->input->post("start");

            foreach ($list as $email_template) {
                $row["email_tpl_order"] = ++$x;
                $row["email_tpl_name"] = $email_template->email_tpl_name;
                $row["email_tpl_subject"] = $email_template->email_tpl_subject;
                $row["email_type"] = $email_template->email_type;
                $row["email_tpl_creation_status"] = $email_template->email_tpl_creation_status;
                $row["email_tpl_status"] = $email_template->email_tpl_status;
                $row["email_tpl_author"] = $email_template->email_tpl_author;
                $row["email_tpl_date_created"] = $email_template->email_tpl_date_created;
                $row["action"] = array(
                    "email_tpl_id" => $email_template->email_tpl_id,
                    "email_type_id" => $email_template->email_type_id,
                    "email_type_subject" => $email_template->email_type_subject,
                    "email_tpl_status" => $email_template->email_tpl_status_
                );
                array_push($data, $row);
            }
            $output = array(
                "draw" => $_POST['draw'],
                "recordsTotal" => $this->event_email_template_model->count_all($this->input->post()),
                "recordsFiltered" => $this->event_email_template_model->count_filtered($this->input->post()),
                "data" => $data,
            );
            //output to json format
            output_to_json($this, $output);
        } else {
            show_404();
        }
    }

    public function create_email_template(){
        if($this->input->post() && isset($this->data["logged_in"]["user_id"])) {
            if(!$this->event_email_template_model->check_duplicate_template_name("", $this->input->post("email_tpl_name"))) {
                $this->load->helper('htmlpurifier');
                //filter wysiwyg inputs
                if (isset($_POST["email_tpl_detail"]) && !empty($_POST["email_tpl_detail"])) {
                    $_POST["email_tpl_detail"] = html_purify($this->input->post("email_tpl_detail"));
                }
                $_POST["email_tpl_author"] = $this->data["logged_in"]["user_id"];
                //insert data
                unset($_POST["preview_tpl_detail"]);
                $create_email_template = $this->event_email_template_model->create_email_template($this->input->post());
                if ($create_email_template) {
                    output_to_json($this, array(
                        "mtype" => "success",
                        "message" => $this->lang->line("email_template_created")
                    ));
                } else {
                    output_to_json($this, array(
                        "mtype" => "error",
                        "message" => $this->lang->line("unknown_error")
                    ));
                }
            } else {
                output_to_json($this, array(
                    "mtype" => "error",
                    "message" => $this->lang->line("email_template_name_duplicate")
                ));
            }
        } else {
            show_404();
        }
    }

    public function get_email_template_content($email_tpl_id) {
        if($email_tpl_id && isset($this->data["logged_in"]["user_id"])) {
            //insert data
            $create_email_template = $this->event_email_template_model->get_email_template_content($email_tpl_id);
            if($create_email_template) {
                output_to_json($this, array(
                    "mtype" => "success",
                    "mdetail" => $create_email_template
                ));
            } else {
                output_to_json($this, array(
                    "mtype" => "error",
                    "message" => $this->lang->line("unknown_error")
                ));
            }
        } else {
            show_404();
        }
    }

    public function update_email_template($email_tpl_id){
        if($this->input->post() && isset($this->data["logged_in"]["user_id"]) && $email_tpl_id > 0) {
            if(!$this->event_email_template_model->check_duplicate_template_name($email_tpl_id, $this->input->post("email_tpl_name"))) {

                $this->load->helper('htmlpurifier');
                //filter wysiwyg inputs
                if (isset($_POST["email_tpl_detail"]) && !empty($_POST["email_tpl_detail"])) {
                    $_POST["email_tpl_detail"] = html_purify($this->input->post("email_tpl_detail"));
                }
                $_POST["email_tpl_author"] = $this->data["logged_in"]["user_id"];
                unset($_POST["preview_tpl_detail"]);
                //udpate data
                // print_r($this->input->post());
                $update_email_template = $this->event_email_template_model->update_email_template($email_tpl_id, $this->input->post());
                if ($update_email_template) {
                    output_to_json($this, array(
                        "mtype" => "success",
                        "message" => $this->lang->line("email_template_updated")
                    ));
                } else {
                    output_to_json($this, array(
                        "mtype" => "error",
                        "message" => $this->lang->line("unknown_error")
                    ));
                }
            } else {
                output_to_json($this, array(
                    "mtype" => "error",
                    "message" => $this->lang->line("email_template_name_duplicate")
                ));
            }
        } else {
            show_404();
        }
    }
    //check dependencies before deleting
    public function check_template_dependencies($email_tpl_id){
        if(isset($this->data["logged_in"]["user_id"]) && $email_tpl_id > 0) {
            //check dependencies
            $check_dependencies = $this->event_email_template_model->check_template_dependencies($email_tpl_id);
            if(!$check_dependencies) {
                $deleted_template = $this->event_email_template_model->delete_email_tempalate($email_tpl_id);
                if ($deleted_template) {
                    output_to_json($this, array(
                        "mtype" => "success",
                        "message" => $this->lang->line("email_template_deleted")
                    ));
                } else {
                    output_to_json($this, array(
                        "mtype" => "error",
                        "message" => $this->lang->line("unknown_error")
                    ));
                }
            } else {
                output_to_json($this, array(
                    "mtype" => "error",
                    "message" => $this->lang->line("cant_delete_due_to_tpl_dependencies")
                ));
            }
        } else {
            show_404();
        }
    }

    public function get_tpl_form($tpl,$data=array()){
        if($tpl && isset($this->data["logged_in"]["user_id"])) {
            if(!$data) {$data = array();}
            switch($tpl){
                case "reminder" :
                    $this->load->view("backoffice/email/form/reminder", $data);
                    break;
                case "tpl_list" :
                    output_to_json($this, $this->event_email_template_model->list_email_type());
                    break;
                case "tpl_email_default_setting_list" :
                    output_to_json($this, $this->event_email_template_model->list_email_type_with_default_setting());
                    break;
                default : echo "No template found.";
                    break;
            }
        }
    }

    public function typeahead_email_template(){
        if($this->input->post("search") && $this->input->post("email_type_id")) {
            output_to_json($this, $this->event_email_template_model->typeahead_email_template($this->input->post()));
        }
    }

    public function typeahead_event(){  //$event_id)
        if($this->input->post("search") && $this->input->post("email_type_id")) {
            output_to_json($this, $this->event_email_template_model->typeahead_event($this->input->post()));
        }
    }
    
    public function get_default_template(){

        $email_type_id = $this->input->post('email_type_id');

        $default_template = $this->event_email_template_model->get_default_template($email_type_id);

        if($default_template){
            $result = array(
                "mtype" => "success",
                "message" => "Got Default Template",
                "mdata" => $default_template
            );
        } else {
            $result = array(
                "mtype" => "error",
                "message" => "No Default Template Found",
                "mdata" => ''
            );            
        }
        output_to_json($this, $result);

    }
}