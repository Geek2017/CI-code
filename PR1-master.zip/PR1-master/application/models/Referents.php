<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Referents extends CI_Model {

	private $akeen_mail;

	function __construct() 
	{
        parent::__construct();
		$this->akeen_mail = $this->globalmodel->akeen_mail();
    }
    public function count_referents($validated = null)
    {
        $this->db->where('user_id', $this->session->userdata('id') );
		if($validated)
			$this->db->where('validation', "0");
        $query = $this->db->get("referents");
		if($validated)
			return $query->num_rows();
		else
        	echo json_encode( array( 'total_referents' => $query->num_rows() ));
    }
	public function count_referents_use_token($token, $validated = null)
	{
		if($user_id = $this->users->get_user_info(['token_id'=>$token])->row()) {
			$user_id = $user_id->id;
			$this->db->where('user_id', $user_id);
			if ($validated)
				$this->db->where('validation', "0");
			$query = $this->db->get("referents");
			if ($validated)
				return $query->num_rows();
			else
				echo json_encode(array('total_referents' => $query->num_rows()));
		}
		if ($validated)
			return 0;
		else
			echo json_encode(array('total_referents' => 0));
	}
    public function get_tokens()
    {
    	$user_id = $this->session->userdata('id');
    	$results = $this->db->query("SELECT token_id FROM referents WHERE user_id='$user_id' ")->result_array();
        echo json_encode($results);
    }
    public function get_referents_list($user_id = null, $flag = null)
    {
    	$user_id = $user_id ? $user_id : $this->session->userdata('id');
    	$results = $this->db->query("SELECT * FROM referents WHERE user_id='$user_id' ")->result_array();
		if($flag)
			return json_encode($results);
		else
        	echo json_encode($results);
    }
	public function get_referents_by_email($email, $user_id){
		$user_id = $user_id ? $user_id : $this->session->userdata('id');
		$results =  $this->db->where([ 'email'	=>	$email, 'user_id'	=>	$user_id ])
					->get('referents')
					->row();
		return json_encode($results);
	}
	public function get_referents_by_id($id, $user_id){
		$user_id = $user_id ? $user_id : $this->session->userdata('id');
		$results =  $this->db->where([ 'id'	=>	$id, 'user_id'	=>	$user_id ])
			->get('referents')
			->row();
		return json_encode($results);
	}
    public function get_referent_answers($ref_id = null, $flag = null)
    {
    	$data = array();
        $query = $this->db->get_where('referents_answers', array('ref_id' =>  $ref_id ? $ref_id : $_POST['ref_id'] ));
        if ($query->num_rows() > 0) 
        {
            foreach ($query->result() as $row) 
            {
                //foreach(json_decode($row,true) as $key=> $ans)
               // {
                       $data[] = $row->answer;
               // }
            }
        }
		if($flag)
			return $data;
		else
        	echo $data[0];
    }
	public function get_ref_answer($user_id = null)
	{
		$user_id = $user_id ? $user_id : $this->session->userdata('id');
		$query = $this->db
				->join('referents', 'referents_answers.ref_id = referents.id')
				->where('user_id',$user_id)
				->get('referents_answers');
		return $query;
	}
    public function get_referents()
    {
    	$user_id = $this->session->userdata('id');
    	$results = $this->db->query("SELECT * FROM referents WHERE user_id='$user_id' ")->result_array();
        return $results;
    }
    public function get_referents_active_list()
    {
    	$user_id = $this->session->userdata('id');
		$results = $this->db
			->join('referents', 'referents_answers.ref_id = referents.id')
			->where('user_id',$user_id)
			->where('validation >=',1)
			->get('referents_answers')->result_array();
        	echo json_encode($results);
    }
	public function get_referents_validated_list()
	{
		$user_id = $this->session->userdata('id');
		$results = $this->db
			->where('user_id',$user_id)
			->where('validation >=',1)
			->get('referents')->result_array();
		return $results;
	}
	public function fetch_token($token_id)
	{
		return json_encode(
			$this->db
			->where('token_id', $token_id)
			->get('referents')
			->row()
		);
	}
	public function update_validation($id, $value)
	{
		$this->db->where('id', $id)
				->update('referents', ["validation" => $value]);
		return true;
	}
	public function sends()
	{
		$last = count($this->get_referents_validated_list()) ;
    	$counter = 1;
		$user_info = $this->users->get_table_user(['user_id'=>$this->session->userdata('id')])->row();
		foreach ($this->get_referents_validated_list() as $key => $value)
		{
			if($value['validation'] == 1 || ($this->input->get('prompt') === "1" && $value['validation'] == 2)) {
				$name = ucwords($value['first_name'] . ' ' . $value['last_name']);
				$email = $value['email'];
				$token = $this->token->url($value['token_id']);

				$this->email->clear();
				$this->email->from($this->akeen_mail, '');
				$this->email->to($email);
				$this->email->subject("Akeen Referent");

				$temp = "
					Bonjour " . $name . ",<br/>
					<p>
					Je vous remercie d’avoir répondu de façon positive à ma demande concernant mon bilan de mobilité professionnel interne. Remplir le questionnaire ne vous prendra que 15 minutes. Il est structuré en 3 temps :
					retour sur la forme de mon curriculum vitae, retour sur ma personnalité et idées de postes en interne pour l’avenir.
					Je joins mon curriculum vitae. N’hésitez pas à m’appeler si vous avez besoin de plus d’informations.
					<br>
					Merci de votre aide précieuse.
					Je suis persuadé que votre point de vue me permettra de mieux aborder mon nouveau challenge.
					 <div id='emails'><a target='_blank' href='" . $token . "'>" . $token . "</a></div>
					 <br><br>
					 " . $this->users->get_full_name($this->session->userdata('id'), true) . "
					 <br>
					 " . $user_info->contact . "
					</p>
			";

				$this->email->message($temp);
				$this->update_validation($value['id'], 2);
				if ($counter != $last) {// multiple emails
					$this->email->send();
					$counter++;
				} else if ($counter == $last) { //one email only
					$this->email->send();
					$counter++;
					echo json_encode(array("send" => "true", "message" => "Vos e-mails ont bien été envoyés à votre réseau interne "));
				}
			}
		}
	}
	public function update_my_referents()
	{
		$user_contact_id = $this->input->post("uid_id") ;
		$query = $this->db->query("SELECT * FROM users WHERE user_id='$user_contact_id' ")->result_array(); 
		$email_ref = $this->db->query("SELECT username FROM accounts WHERE id='$user_contact_id' ")->result_array();

		 $data =  array(
			"last_name"     =>  $this->input->post("nom"),
			"first_name"    => $this->input->post("prenom"),
			"sector"        =>  $this->input->post("secteur"),
			"function"      => $this->input->post("fonction"),
			"email"         =>  $this->input->post("email"),
			"company"       =>  $this->input->post("enterprise"),
			"job"           =>  $this->input->post("metier"),
			'date_email2'    => date("Y-m-d H:i:s", strtotime('today GMT')),
			"validation"    =>  1
		 );
//        $this->db->where('token_id', $this->input->post("token_id"));
        $this->db->where(['email' => $this->input->post("email_orig"), 'user_id'	=>	$user_contact_id]);

        if( $this->db->update('referents', $data) && $this->send_refent_mail( $this->input->post("email") , $email_ref[0]['username'] , ucfirst( $query[0]['lastname'] ).", ". $query[0]['firstname'] ) )
        {
        	return true;
        }
	}
	
	
	public function send_refent_mail( $email , $email_c , $contact )
	{

 			$this->email->from($this->akeen_mail, '');
            $this->email->to( $email );
            $this->email->subject("Akeen Confirmation");
            $this->email->message("
            	<p>Bravo, vous êtes bien inscrit sur notre plateforme.<p><p>Vous recevrez bientôt 
            	un e-mail pour répondre à un court questionnaire.
            	Vous pouvez dès maintenant envoyer un e-mail à votre correspondant pour 
            	lui signifier votre inscription en tant que référent.</p>
            	Contact : ".$contact."<br>
            	Email : ".$email_c."

            	");

            if($this->email->send())
            {
            	return true;
            }
            else
            {
            	return false;
            }
	}

	public function submit_referent_answer($ref_data, $form_data)
	{
		$data = [];
		foreach($form_data as $key => $fd){
			$data[] = [
				'field_name'	=>	$key,
				'field_answer'	=>	$fd
			];
		}
		$referent = json_decode($ref_data);
		$insert_data = [
			'ref_id'	=>	$referent->id,
			'answer'	=>	json_encode($data)
		];
		if($this->db->insert('referents_answers', $insert_data) && $this->update_validation($referent->id, 3)) {
			$this->globalmodel->send_email($this->akeen_mail, $referent->email, "Akeen","Nous vous remercions d’avoir répondu à ce questionnaire toutes vos réponses ont bien été prises en compte");
			return true;
		}else
			return false;
	}
}


