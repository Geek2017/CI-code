<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

//modal titles and headings
$lang["event_modal_title"] = "Email Template";
$lang["event_modal_type"] = "Template type";
$lang["event_modal_name"] = "Template name";
$lang["event_modal_status"] = "Status";
$lang["event_modal_default"] = "Default";
$lang["event_modal_action"] = "Action";


//buttons
$lang["event_modal_close"] = "Close";
$lang["event_modal_save"] = "Save";
$lang["event_modal_apply"] = "Apply";

//search title
$lang["event_modal_search_template"] = "Search Template";

//send
$lang["send_email"] = "Send Email";
$lang["send"] = "Send";

