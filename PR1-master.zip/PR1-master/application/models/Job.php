<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class job extends CI_Model {

	private $akeen_mail = 'akeen.email@gmail.com';

	function __construct() 
	{
        parent::__construct();
    }
     public function get_job_list($id = null)
    {
    	$user_id = $this->session->userdata('id');
    	$results = $this->db->query("SELECT * FROM profesional_job WHERE user_id='$user_id' ")->result_array();
//        if($id)
//            $results = $this->db->query("SELECT * FROM profesional_job WHERE user_id='$user_id' AND id='$id'")->result_array();
        echo json_encode($results);
    }
    public function add_job(){
    	$data = array(
    		'user_id' => $this->input->post('user_id'),
			'job_title' => $this->input->post('job_title'),
			'company' => $this->input->post('company'),
			'start_date' => $this->input->post('start_date'),
			's_reasons' => $this->input->post('s_reasons'),
			'end_date' => $this->input->post('end_date'),
			'e_reasons' => $this->input->post('e_reasons'),
			);
         if( trim($this->input->post('job_title')) == null )
        {
            echo json_encode( array(
                    'message' => 'Champ de saisie obligatoire',
                    'focus' => 'job_title',
                    'redirect' => 'false'
                ) );
        }else if( trim($this->input->post('company')) == null )
        {
            echo json_encode( array(
                    'message' => 'Champ de saisie obligatoire',
                    'focus' => 'company',
                    'redirect' => 'false'
                ) );
        }
        else if( $this->input->post('start_date') != null && $this->input->post('s_reasons') == null )
        {
            echo json_encode( array(
                    'message' => 'Champ de saisie obligatoire',
                    'focus' => 's_reasons',
                    'redirect' => 'false'
                ) );
        }
        else if( $this->input->post('end_date') != null && $this->input->post('e_reasons') == null )
        {
            echo json_encode( array(
                    'message' => 'Champ de saisie obligatoire',
                    'focus' => 'e_reasons',
                    'redirect' => 'false'
                ) );
        }
        else if( $this->input->post('end_date') == null && $this->input->post('e_reasons') != null )
        {
            echo json_encode( array(
                    'message' => 'Champ de saisie obligatoire',
                    'focus' => 'end_date',
                    'redirect' => 'false'
                ) );
        }
        else if( $this->input->post('start_date') == null && $this->input->post('s_reasons') != null )
        {
            echo json_encode( array(
                    'message' => 'Champ de saisie obligatoire',
                    'focus' => 'start_date',
                    'redirect' => 'false'
                ) );
        }
        // else if( $this->input->post('start_date') != null && $this->input->post('s_reasons') == null )
        // {
        //     echo json_encode( array(
        //             'message' => 'Champ de saisie obligatoire',
        //             'focus' => 's_reasons',
        //             'redirect' => 'false'
        //         ) );
        // }
        // else if(  $this->input->post('end_date') != null && $this->input->post('e_reasons') == null )
        // {
        //     echo json_encode( array(
        //             'message' => 'Champ de saisie obligatoire',
        //             'focus' => 'e_reasons',
        //             'redirect' => 'false'
        //         ) );
        // }
        else{
            $insert = $this->db->insert('profesional_job', $data);
            $last_id = $this->db->insert_id();
            if($insert){
                echo json_encode( array(
                    'message' => 'Enregistré avec succès',
                    'redirect' => 'true',
                    'last_id' => $last_id,
                    ) );
            }
        }
		
		
    }
    public function delete_job(){
        
        if( $this->db->delete('profesional_job', ['id' => $this->input->post('job_id')]) ){
            echo json_encode( array(
                'message' => 'Suppression réussie',
                'redirect' => 'true'
                ) );
        }
        
    }
    public function update_job(){
        $data = array(
            'job_title' => $this->input->post('job_title'),
            'company' => $this->input->post('company'),
            'start_date' => $this->input->post('start_date'),
            's_reasons' => $this->input->post('s_reasons'),
            'end_date' => $this->input->post('end_date'),
            'e_reasons' => $this->input->post('e_reasons'),
            );
         if( trim($this->input->post('job_title')) == null )
        {
            echo json_encode( array(
                    'message' => 'Champ de saisie obligatoire',
                    'focus' => 'job_title',
                    'redirect' => 'false'
                ) );
        }else if( trim($this->input->post('company')) == null )
        {
            echo json_encode( array(
                    'message' => 'Champ de saisie obligatoire',
                    'focus' => 'company',
                    'redirect' => 'false'
                ) );
        }
        else if( $this->input->post('start_date') != null && $this->input->post('s_reasons') == null )
        {
            echo json_encode( array(
                    'message' => 'Champ de saisie obligatoire',
                    'focus' => 's_reasons',
                    'redirect' => 'false'
                ) );
        }
        else if( $this->input->post('end_date') != null && $this->input->post('e_reasons') == null )
        {
            echo json_encode( array(
                    'message' => 'Champ de saisie obligatoire',
                    'focus' => 'e_reasons',
                    'redirect' => 'false'
                ) );
        }
        else if( $this->input->post('end_date') == null && $this->input->post('e_reasons') != null )
        {
            echo json_encode( array(
                    'message' => 'Champ de saisie obligatoire',
                    'focus' => 'end_date',
                    'redirect' => 'false'
                ) );
        }
        else if( $this->input->post('start_date') == null && $this->input->post('s_reasons') != null )
        {
            echo json_encode( array(
                    'message' => 'Champ de saisie obligatoire',
                    'focus' => 'start_date',
                    'redirect' => 'false'
                ) );
        }
        // else if( $this->input->post('start_date') != null && $this->input->post('s_reasons') == null )
        // {
        //     echo json_encode( array(
        //             'message' => 'Champ de saisie obligatoire',
        //             'focus' => 's_reasons',
        //             'redirect' => 'false'
        //         ) );
        // }
        // else if(  $this->input->post('end_date') != null && $this->input->post('e_reasons') == null )
        // {
        //     echo json_encode( array(
        //             'message' => 'Champ de saisie obligatoire',
        //             'focus' => 'e_reasons',
        //             'redirect' => 'false'
        //         ) );
        // }
        else{
             $this->db->where('id', $this->input->post('job_id') );
            
            if( $this->db->update('profesional_job', $data ) ){
                echo json_encode( array(
                    'message' => 'Enregistrement des modifications',
                    'redirect' => 'true'
                    ) );
            }
        }
        
    }
    public function get_activity_list($job_id = null)
    {
    	// $job_id = $this->session->userdata('job_id');
    	$results = $this->db->query("SELECT * FROM activity WHERE job_id='$job_id' ")->result_array();
        echo json_encode($results);
    }
    public function add_activity(){
        $satisfaction = $this->input->post('satisfaction');
        foreach($this->input->post('activity') as $i => $act){
            if($this->input->post('activity_id')[$i]){
                $data = array(
                    'activity' => $act,
                    'satisfaction' => $satisfaction[$i],
                );
                $query = $this->db // TODO:: Add validation if user own this job_id
                        ->where('job_id',(int)$this->input->post('job_id'))
                        ->where('id',$this->input->post('activity_id')[$i])
                        ->update('activity', $data);
            }else {
                $data = array(
                    'job_id' => (int)$this->input->post('job_id'),
                    'activity' => $act,
                    'satisfaction' => $satisfaction[$i],
                );
                $query = $this->db->insert('activity', $data);
            }
        }
		return $query;
    }
    public function get_savoir($job_id = null)
    {
    	// $job_id = $this->session->userdata('job_id');
    	$results = $this->db->query("SELECT * FROM satisfaction WHERE job_id='$job_id' && place='savoir' ")->result_array();
        echo json_encode($results);
    }
    public function add_savoir(){
        foreach($this->input->post('activity') as $i => $act){
            $sat_id = $this->input->post('satisfaction_id');
            if($sat_id[$i] != "null"){
                $data = array(
                    'activity' => $this->input->post('activity')[$i],
                    'satisfaction1' => $this->input->post('satisfaction1')[$i],
                    'satisfaction2' => $this->input->post('satisfaction2')[$i],
                    'total' => $this->input->post('satisfaction1')[$i] + $this->input->post('satisfaction2')[$i],
                );
                $query = $this->db // TODO:: Add validation if user own this job_id
                    ->where('job_id',(int)$this->input->post('job_id'))
                    ->where('id',$this->input->post('satisfaction_id')[$i])
                    ->update('satisfaction', $data);
            }else {
                $data = array(
                    'place' => $this->input->post('place')[$i],
                    'job_id' => (int)$this->input->post('job_id'),
                    'activity' => $this->input->post('activity')[$i],
                    'satisfaction1' => $this->input->post('satisfaction1')[$i],
                    'satisfaction2' => $this->input->post('satisfaction2')[$i],
                    'total' => $this->input->post('satisfaction1')[$i] + $this->input->post('satisfaction2')[$i],
                );
                $query = $this->db->insert('satisfaction', $data);
            }
        }
		return $query;
    }
    public function get_faire($job_id = null)
    {
    	// $job_id = $this->session->userdata('job_id');
    	$results = $this->db->query("SELECT * FROM satisfaction WHERE job_id='$job_id' && place='faire' ")->result_array();
        echo json_encode($results);
    }
    public function add_faire(){
    	$data = array(
    		'place' => 'faire',
    		'job_id' => $this->session->userdata('job_id'),
			'activity' => $this->input->post('activity'),
			'satisfaction1' => $this->input->post('satisfaction1'),
			'satisfaction2' => $this->input->post('satisfaction2'),
			'total' => $this->input->post('satisfaction1') + $this->input->post('satisfaction2'),
			);
		
		$query = $this->db->insert('satisfaction', $data);
		return $query;
    }
    public function get_etre($job_id = null)
    {
    	// $job_id = $this->session->userdata('job_id');
    	$results = $this->db->query("SELECT * FROM satisfaction WHERE job_id='$job_id' && place='etre' ")->result_array();
        echo json_encode($results);
    }
    public function add_etre(){
    	$data = array(
    		'place' => 'etre',
    		'job_id' => $this->session->userdata('job_id'),
			'activity' => $this->input->post('activity'),
			'satisfaction1' => $this->input->post('satisfaction1'),
			'satisfaction2' => $this->input->post('satisfaction2'),
			'total' => $this->input->post('satisfaction1') + $this->input->post('satisfaction2'),
			);
		
		$query = $this->db->insert('satisfaction', $data);
		return $query;
    }
    public function get_my_job()
    {
    	$id = $this->session->userdata('id');
    	$results = $this->db->query("SELECT * FROM profesional_job WHERE user_id='$id' ")->result();
        // echo json_encode($results);
       	return $results;
    }
    public function get_my_activity()
    {
    	$results = $this->db->query("SELECT * FROM activity  ")->result();
        // echo json_encode($results);
       	return $results;
    }
    public function get_my_savoir()
    {
    	$results = $this->db->query("SELECT * FROM satisfaction WHERE place='savoir' ")->result();
        // echo json_encode($results);
       	return $results;
    }
    public function get_my_faire()
    {
    	$results = $this->db->query("SELECT * FROM satisfaction WHERE place='faire' ")->result();
        // echo json_encode($results);
       	return $results;
    }
    public function get_my_etre()
    {
    	$results = $this->db->query("SELECT * FROM satisfaction WHERE place='etre' ")->result();
        // echo json_encode($results);
       	return $results;
    }
    public function delete_satisfactions()
    {
        $id = $this->input->post('id');
        $table = $this->input->post('table');
        $this->db->delete($table, array( 'id' => $id ) ); 
        return true;
    }   
    public function job_information($id){
        $this->db->where('id', $id);
        $query = $this->db->get("profesional_job");
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
    }
    public function count_jobs()
    {
        $this->db->where('user_id', $this->session->userdata('id'));
        $query = $this->db->get("profesional_job");
       
        echo json_encode( array(
             'count' => $query->num_rows()
            ) );
    }
}	


