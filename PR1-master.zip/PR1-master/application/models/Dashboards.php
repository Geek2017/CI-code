<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboards extends CI_Model
{

    function __construct()
    {
        parent::__construct();
    }

    public function profileInfo(){
    	
    }

}