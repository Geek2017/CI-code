<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Referent extends CI_Controller {

	function __construct() {
        parent::__construct();
    }
    
    public function ajax()
    {
    	$type = $this->input->get("type");

        switch($type)
        {
            case 'send_email':
            {
                $this->referents->sends();
                break;
            }
            case 'count_referents':
            {
                $this->referents->count_referents();
            }
        }
    }
    public function get_referent_answer()
    {
        $this->referents->get_referent_answers();
    }
    public function get_token()
    {
    	$this->referents->get_tokens();
    }
    public function get_referents_list()
    {
        $this->referents->get_referents_list();
    }
     public function get_referents_active()
    {
        $this->referents->get_referents_active_list();
    }
    public function get_ref_answer($flag = null)
    {
        $answers = $this->referents->get_ref_answer();
        $data = [];
        if ($answers->num_rows() > 0)
        {
            foreach ($answers->result() as $row)
            {
                $data[] = json_decode($row->answer);
            }
        }
        if($flag)
            return json_encode($data);
        else
            echo json_encode($data);
    }
    public function get_regards_cv()
    {
        $ref_answer = json_decode($this->get_ref_answer(1));
        $values = [];
        foreach($ref_answer as $key => $refs){
            foreach($refs as $ref) {
                if (strpos($ref->field_name,"input_") !== false) {
                    $values[] = $ref->field_answer;
                }
            }
        }
        $chunk_val = array_chunk($values, ceil(count($values) / count($ref_answer)));
        $final_val = [];
        $f_v = [];
        array_walk_recursive($chunk_val, function($item, $key) use (&$final_val){
            $final_val[$key] = isset($final_val[$key]) ?  $item + $final_val[$key] : $item;
        });
        foreach($final_val as $key => $fv){
            $f_v[$key] = number_format($fv / count($ref_answer), 2);
        }
        echo json_encode($f_v);

    }
    public function get_referents_emails($data){
        $emails = [];
        foreach(json_decode($data) as $dt){
            $emails[] = $dt->email;
        }
        return $emails;
    }
    public function confirm_referent()
    {
        $token_id = $this->input->post("token_id");
        $type = $this->input->get('type');
        if(! $user_info = $this->users->get_user_info(['token_id' => $token_id])->row()){
            echo json_encode(
                array(
                    'msg' => "Token invalide",
                    "type" => "error",
                    "id" => "nom"
                )
            );
            exit;
        }

        $get_user = $this->globalmodel->get_name($user_info->id);
        if( $validate_email = in_array($this->input->post("email"),$this->get_referents_emails($this->referents->get_referents_list($user_info->id,1))))
            $referent = json_decode($this->referents->get_referents_by_email($this->input->post("email"),$user_info->id));

         if( $validate_email && $referent->validation == 1){
             echo json_encode(
                 array(
                     'msg' => "Email déjà enregistré",
                     "type" => "error",
                     "id" => "email"
                 )
             );
         }
         else if( $this->input->post("nom") == null )
         {
             echo json_encode(
               array(
                'msg' => "Le nom est obligatoire",
                "type" => "error",
                "id" => "nom"
                )
            );
         }
         else if( $this->input->post("prenom") == null )
         {
             echo json_encode(
               array(
                 'msg' => "Le Prénom est obligatoire",
                "type" => "error",
                "id" => "prenom"
                )
            );

         }
         else if( $type == 0 && !$validate_email )
         {
             echo json_encode(
                 array(
                     'msg' => "L'adresse email utilisée n'est pas répertoriée en tant que \"référent\" de l'utilisateur ".$get_user.". Merci d'utiliser l'adresse email où vous avez reçu l'invitation Akeen",
                     "type" => "error",
                     "id" => "email_"
                 )
             );

         }
          else if( $this->input->post("email") == null || !filter_var( $this->input->post("email") , FILTER_VALIDATE_EMAIL))
         {
             echo json_encode(
               array(
                 'msg' => "S'il vous plaît entrez une adresse e-mail valide",
                "type" => "error",
                "id" => "email"
                )
            );
         }
          else if( $this->input->post("secteur") == null && $type == 1 )
         {
             echo json_encode(
               array(
                 'msg' => "Secteur est nécessaire",
                "type" => "error",
                "id" => "secteur"
                )
            );

         }
          else if( $this->input->post("enterprise") == null  && $type == 1)
         {
            echo json_encode(
               array(
                 'msg' => "Société est tenue",
                "type" => "error",
                "id" => "enterprise"
                )
            );

         }
          else if( $this->input->post("metier") == null && $type == 1 )
         {
            echo json_encode(
               array(
                 'msg' => "Job est nécessaire",
                "type" => "error",
                "id" => "metier"
                )
            );

         }
          else if( $this->input->post("fonction") == null  && $type == 1 )
         {
            echo json_encode(
               array(
                 'msg' => "La fonction est nécessaire",
                "type" => "error",
                "id" => "fonction"
                )
            );

         }
//          else if( $this->input->post("lien_avec_vous") == null  && $type == 1 )
//         {
//            echo json_encode(
//               array(
//                 'msg' => "Link est nécessaire",
//                "type" => "error",
//                "id" => "lien_avec_vous"
//                )
//            );
//         }
         else
         {
             if( $type == 1 ){
                 if( $this->referents->update_my_referents() )
                 {
                     $access = array(
                         'name'   => 'validated',
                         'value'  => true,
                         'expire' => '999999',
                     );
                     $this->input->set_cookie($access);
                     echo json_encode(
                         array(
                             'msg' => "Confirmation avec succès",
                             "type" => "success",
                             "id" => ""
                         )
                     );
                 }
             }else{
                 echo json_encode(
                     array(
                         'msg' => "Email valide",
                         "type" => "success",
                         "id" => "",
                         'referent_data' => $referent
                     )
                 );
             }
         }
    }
    public function lists()
    {
       $this->session_checker->session_filled();
       $this->session_checker->is_user();

        if( $this->session->userdata('lastname') != null )
        {
            $data = array(
                'content' => 'referent_list',
                'nav_menu' => 'page-nav',
                'user_role' => $this->session->userdata('role'),
                'lists' => $this->referents->get_referents()
                );
            $this->load->view('template-sidebar', $data);
        }else{
            redirect('/main/welcome', 'refresh');
        }
    }
    public function submit_referent_answer()
    {
        $data = $this->input->post();
        $token_id = $data["token_id"];
        unset($data["token_id"]);
        unset($data["uid_id"]);
        if($orig_token = $this->referents->fetch_token($token_id)){
            if($this->referents->submit_referent_answer($orig_token, $data)) {
                echo json_encode(
                    array(
                        'msg' => "Confirmation avec succès",
                        "type" => "success",
                        "id" => ""
                    )
                );
            }else if(json_decode($orig_token)->validation == 3){
                echo json_encode(
                    array(
                        'msg' => "Token expiré",
                        "type" => "error",
                        "id" => ""
                    )
                );
            }else{
                echo json_encode(
                    array(
                        'msg' => "Une erreur s'est produite",
                        "type" => "error",
                        "id" => ""
                    )
                );
            }
        }else{
            echo json_encode(
                array(
                    'msg' => "Token invalide",
                    "type" => "error",
                    "id" => ""
                )
            );
        }
    }
    public function regards_answer()
    {
        $datas = $this->input->post('item');
        $total_value = [];
        foreach($datas as $data)
            $total_value[] = $data[6][1];
        uasort($total_value, function($a, $b) {
            return $b - $a;
        });
        $f_data = [];
        foreach($total_value as $key => $tv){
            $item = $datas[$key];
            $f_data[] = [
                'experience'    =>  $item[3][1],
                'competence'    =>  $item[4][1],
                'interest'      =>  $item[5][1],
                'activity'      =>  $item[0][1],
                'ref_name'      =>  $item[7][1]
            ];
        }
        echo json_encode(array_slice($f_data, 0, 5));
    }
}
