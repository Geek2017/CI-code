<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Email_default_setting extends MY_Controller {

    public function __construct()
    {
        $this->my_controller_parent_construct();
        $this->check_session_timed_out("bo");
        //load language files
        $this->load_language_backoffice();
        $this->lang->load('backoffice/email', 'fr');
        //load model
        $this->load->model("event_email_default_setting_model");
        $this->load->model("user_activity_log_model");
        $this->load->helper('htmlpurifier');
    }

    public function get_email_default_setting_list(){
        if($this->input->post() && isset($this->data["logged_in"]["user_id"])){
            $list = $this->event_email_default_setting_model->get_datatables($this->input->post());
            $data = array();
            $row = array();
            $x = $this->input->post("start");
            foreach ($list as $default_setting) {
                $row["email_tpl_order"] = ++$x;
                $row["email_type"] = $default_setting->email_type;
                $row["email_tpl_setting_sched"] = $default_setting->email_tpl_setting_sched;
                $row["email_tpl_number_of_recipients"] = $default_setting->email_tpl_number_of_recipients;
                $row["email_tpl_sched_author"] = $default_setting->email_tpl_sched_author;
                $row["email_tpl_sched_date_added"] = $default_setting->email_tpl_sched_date_added;
                $row["action"] = array(
                    "email_tpl_setting_id" => $default_setting->email_tpl_setting_id,
                    "email_type_id" => $default_setting->email_type_id,
                    "email_tpl_setting_sched_by" => $default_setting->email_tpl_setting_sched_by,
                    "email_tpl_setting_sched" => $default_setting->email_tpl_setting_sched_q
                );
                array_push($data, $row);
            }
            $output = array(
                "draw" => $_POST['draw'],
                "recordsTotal" => $this->event_email_default_setting_model->count_all($this->input->post()),
                "recordsFiltered" => $this->event_email_default_setting_model->count_filtered($this->input->post()),
                "data" => $data,
            );
            //output to json format
            output_to_json($this, $output);
        } else {
            show_404();
        }
    }

    public function save_default_configuration($email_type_id){
        if($this->input->post() && isset($this->data["logged_in"]["user_id"])) {

            if($this->input->post("email_type_id") == 1){
                unset($_POST["email_tpl_number_of_recipients"]);
            }
            $_POST["email_tpl_sched_author"] = $this->data["logged_in"]["user_id"];
            //insert data
            $default_configuration = $this->event_email_default_setting_model->save_default_configuration($this->input->post());
            if ($default_configuration) {
                output_to_json($this, array(
                    "mtype" => "success",
                    "message" => $this->lang->line("save_default_configuration")
                ));
            } else {
                output_to_json($this, array(
                    "mtype" => "error",
                    "message" => $this->lang->line("unknown_error")
                ));
            }
        } else {
            show_404();
        }
    }

    public function update_default_configuration($email_tpl_setting_id){
        if($this->input->post() && isset($this->data["logged_in"]["user_id"]) && $email_tpl_setting_id > 0) {
            $_POST["email_tpl_sched_author"] = $this->data["logged_in"]["user_id"];
            //udpate data
            $update_email_template = $this->event_email_default_setting_model->update_default_configuration($email_tpl_setting_id, $this->input->post());
            if ($update_email_template) {
                output_to_json($this, array(
                    "mtype" => "success",
                    "message" => $this->lang->line("default_configuration_updated")
                ));
            } else {
                output_to_json($this, array(
                    "mtype" => "error",
                    "message" => $this->lang->line("unknown_error")
                ));
            }
        } else {
            show_404();
        }
    }
    //check dependencies before deleting
    public function delete_configuration_setting($email_tpl_setting_id){
        if(isset($this->data["logged_in"]["user_id"]) && $email_tpl_setting_id > 0) {
            $deleted_default_conf = $this->event_email_default_setting_model->delete_configuration_setting($email_tpl_setting_id);
            if ($deleted_default_conf) {
                output_to_json($this, array(
                    "mtype" => "success",
                    "message" => $this->lang->line("default_configuration_deleted")
                ));
            } else {
                output_to_json($this, array(
                    "mtype" => "error",
                    "message" => $this->lang->line("unknown_error")
                ));
            }
        } else {
            show_404();
        }
    }
}