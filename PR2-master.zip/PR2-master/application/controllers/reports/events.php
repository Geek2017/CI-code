<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Events extends MY_Controller {
    
    public function __construct()
    {
        //parent::__construct();
        $this->my_controller_parent_construct();
        $this->check_session_timedout_admin();
        //load language files
        $this->load_language_backoffice();
        $this->lang->load('backoffice/reports', 'fr');
        $this->lang->load('backoffice/events', 'fr');
        //load model
        $this->load->model("user_model");
        $this->load->model("event_model");
        $this->load->model("event_registration_model");
    }

    public function export_events_list($event_id)
    {
        ini_set('memory_limit', '1024M');
        ini_set('max_execution_time', (60*3));

        $reports = array("event", "client");

        /** Include PHPExcel */
        require_once APPPATH  . 'libraries/Classes/PHPExcel.php';

        // Create new PHPExcel object
        $objPHPExcel = new PHPExcel();

        // Set document properties
        $objPHPExcel->getProperties()->setCreator("Le Monde Event Management System")
            ->setLastModifiedBy("Le Monde Event Management System")
            ->setTitle("Office 2007 XLSX Document")
            ->setSubject("Office 2007 XLSX  Document")
            ->setDescription("Test document for Office 2007 XLSX, generated using PHP classes.")
            ->setKeywords("office 2007 openxml php")
            ->setCategory("Export file");

        foreach($reports as $sheet=>$value) {

            $options = $this->get_report($value, $event_id);

            if($sheet > 0){
                $objPHPExcel->createSheet();
                $objPHPExcel->setActiveSheetIndex($sheet)->setTitle(ucwords($this->lang->line("reports")[$value][$value."_file_name"]));
            }else{
                $objPHPExcel->setActiveSheetIndex(0)->setTitle(ucwords($this->lang->line("reports")[$value][$value."_file_name"]));
            }

            $col = 0;

            if (count($options["column_names"]) > 0) {
                foreach ($options["column_names"] as $colKey => $name) {
                    $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col, 1, $this->lang->line($name));
                    $objPHPExcel->getActiveSheet()->getStyleByColumnAndRow($col++, 1)->applyFromArray(
                        array
                        (
                            'fill' => array
                            (
                                'type' => PHPExcel_Style_Fill::FILL_SOLID,
                                'color' => array('rgb' => '428bca')
                            )
                        )
                    )->getBorders()->getAllBorders()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
                }
            }

            $col = 0;
            $row = 2;

            if (count($options["data"]) > 0) {
                foreach ($options["data"] as $data) {
                    foreach ($options["column_names"] as $colKey => $name) {
                        if (trim($name) != "" && isset($data->{$name}) && !empty($data->{$name})) {
                            $value = $data->{$name};
                            if ($name == "price_rate") {
                                $value = str_replace(",00", "", number_format($data->{$name}, 2, ",", " ")) . " €";
                            }
                            $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col++, $row, $value);
                        } else {
                            $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col++, $row, "");
                        }
                    }
                    $col = 0;
                    $row++;
                }
            }
        } //end of for loop

        // Auto size columns for each worksheet
        foreach ($objPHPExcel->getWorksheetIterator() as $worksheet) {

            $objPHPExcel->setActiveSheetIndex($objPHPExcel->getIndex($worksheet));

            $sheet = $objPHPExcel->getActiveSheet();
            $cellIterator = $sheet->getRowIterator()->current()->getCellIterator();
            $cellIterator->setIterateOnlyExistingCells(true);
            /** @var PHPExcel_Cell $cell */
            foreach ($cellIterator as $cell) {
                $sheet->getColumnDimension($cell->getColumn())->setAutoSize(true);
            }
        }

        $filename = "Les données de l'événement";

        // Set active sheet index to the first sheet, so Excel opens this as the first sheet
        $objPHPExcel->setActiveSheetIndex(0);

        // Redirect output to a client’s web browser (Excel2007)
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename='.$filename.'.xlsx');
        header('Cache-Control: max-age=0');

        // If you're serving to IE 9, then the following may be needed
        header('Cache-Control: max-age=1');

        // If you're serving to IE over SSL, then the following may be needed
        header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
        header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
        header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
        header ('Pragma: public'); // HTTP/1.0

        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        $objWriter->save('php://output');
        exit();
    }

    private function get_report($type, $event_id){
        switch($type){

            case "event" : return $this->event_data($event_id);
            break;

            case "client" : return $this->export_subscribers_list($event_id);
            break;

            default : return array();
            break;
        };
    }

    public function export_subscribers_list($event_id)
    {
        /*BASIC SUBCRIBERS LIST EXPORT TEMPLATE*/
        $column_names = array("genre", "last_name", "first_name", "address_1", "address_2", "address_3", "code_postal",
            "city", "telephone_number", "mobile_number", "email_address", "subscriber_number", "subscription_date_op", "birth_date",
            "event_preference", "status");

        $subscribers = $this->event_registration_model->get_event_subscribers($event_id);
        foreach($subscribers as $row=>$key){
            $event_pref = $this->user_model->subscriber_event_preference($key->subscriber_id);
            $subscribers[$row]->{"event_preference"} = $event_pref;
        }

        return array(
            "column_names" => $column_names,
            "data" => $subscribers
        );
    }


    public function event_data($event_id){
        /*BASIC SUBCRIBERS LIST EXPORT TEMPLATE*/
        $column_names = array("event_title", "event_type", "place_town", "date_month", "hour",
            "total_places_avl", "num_remaining_places", "price_rate","event_statuses");

        $events = $this->event_model->get_events_list_export($this->input->get(), 1, $event_id);

        return array(
            "column_names" => $column_names,
            "data" => $events
        );
    }

    public function get_events_list($export=0)
    {
        $list = $this->event_model->get_datatables($this->input->post(), $export, 0);
        $data = array();
        $row = array();

        $x = $this->input->post("start");
        foreach ($list as $events) {
            $row["event_order"] = ++$x;
            $row["event_title"] = $events->event_title;
            $row["event_type"] = $events->event_type;
            $row["city"] = $events->city;
            $row["author"] = $events->author;
            $row["date_created"] = $events->date_created;
            $row["event_status"] = $events->event_status;
            $row["action"] = $events->event_id;
            $row["bo_status"] = $events->bo_status;
            array_push($data, $row);
        }
        $output = array(
            "draw" => $this->input->post('draw'),
            "recordsTotal" => $this->event_model->count_all($this->input->post(), $export, 0),
            "recordsFiltered" => $this->event_model->count_filtered($this->input->post(), $export,0),
            "data" => $data,
        );
        //output to json format
        output_to_json($this, $output);
    }
}