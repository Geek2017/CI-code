<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profiles extends CI_Model {

	function __construct() 
	{
        parent::__construct();
    }
	public function save_profile()
	{
		$data = array
		(
			'user_id' =>  $this->session->userdata('id'),
			'lastname' => $this->input->post("lname"),
            'firstname' => $this->input->post("fname"),
            'bday' => $this->input->post("bday"),
            'contact' => $this->input->post("contact"),
            'address' => $this->input->post("address"),
            'zip' => $this->input->post("zip"),
            'city' => $this->input->post("city"),
            'country' => ($this->input->post("country")),
            'position' => $this->input->post("current_position"),
            'number_year' => $this->input->post("number_years_position"),
            'started_date' => $this->input->post("started_date") 
            
		);
		if(count($this->getUserDetails($this->session->userdata('id'))))
		{
			$this->db->where('user_id',$this->session->userdata('id'));
			$this->db->update('users', $data);
			$this->update_email_pass($this->input->post("email"),$this->input->post("password"));
			$this->users->update_user_info(['active'=>'1','visited'=>1]);
			 echo json_encode(array(
					'mcontent' => 'success', 
					'message' => "Votre compte a été mis à jour" ,
				));

			 $this->session->set_userdata('lastname', $this->input->post("lname"));
		}
		else
		{
			$this->db->insert('users', $data);
			$this->update_email_pass($this->input->post("email"),$this->input->post("password"));
			$token = $this->token->generate();
			$this->users->update_user_info(['token_id' => $token, 'active'=>'1', 'visited'=>1]);
			 echo json_encode(array( 
					'mcontent' => 'success', 
					'message' => "Profil enregistré avec succès." ,
				));

			 $this->session->set_userdata(['lastname' => $this->input->post("lname"),'token_id'=>$token]);
		}

	}
	public function update_email_pass($email,$password)
	{
			$this->db->where('id',$this->session->userdata('id'));

			if( $email != null && $password != null )
			{
				$this->db->update('accounts', array(
					'username'	=>	$email,
					'password'	=>	sha1($password)
				));
			}
			else if( $email != null )
			{
				$this->db->update('accounts', array(
					'username'	=>	$email
				));
			}
			else if( $password != null )
			{
				$this->db->update('accounts', array(
					'password'	=>	sha1($password)
				));
			}

		    
	}

	public function check_unique_email()
	{
		$username = $this->input->post("email");
		
		$check = $this->db->query("SELECT * FROM accounts WHERE username='$username' ");
      
		if($check->num_rows() > 0)
		{

			return true;
		}
		else
		{
			return false;	
		}
	}

	public function getUserDetails($userID)
	{
		$this->db->select('*');
		$this->db->from('users');
		$this->db->where('user_id',$userID);
		$query = $this->db->get();
		return $query->result();
	}

	public function email_required($email)
	{
		if( $email != null )
		{
			if( !filter_var($email, FILTER_VALIDATE_EMAIL) )
			{
				return true;
			}
		}
	}
	 
	
}
