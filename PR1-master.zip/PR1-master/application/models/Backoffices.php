<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Backoffices extends CI_Model
{

    protected $table = 'questionaires';
    protected $table_org = 'organization';
    protected $table_acc = 'accounts';
    protected $table_sec = 'section';
    protected $table_users = "users";

    function __construct()
    {
        parent::__construct();
    }

    public function postquestion($section, $question, $editQuestion = null)
    {
        if($editQuestion){
            $this->db->where('q_id', $editQuestion['question_id']);
            $this->db->update($this->table,
                [   "q_section" => $editQuestion['section'],
                    "q_content" => $editQuestion['question'],
                ]);
        }else {
            $data = [
                'q_section' => $section,
                'q_content' => $question
            ];
            $this->db->insert($this->table, $data);
        }
    }

    public function getquestion($question_id)
    {
        $gQ = $this->db->query("SELECT * FROM questionaires WHERE q_id='$question_id' ");
        $gQ = $gQ->row();
        return $gQ->q_content;
    }

    public function fetch_data($limit, $start) {
        $this->db->limit($limit, $start - 1);
        $this->db->order_by("q_id", "asc");
        $query = $this->db->get("questionaires");
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
    }
    public function guest_accounts()
    {
        return $this->db
                    ->from('accounts')
                    ->where('role_id', 3)
                    ->join('users','users.user_id = accounts.id','left')
                    ->join('roles','roles.id = accounts.role_id')
                    ->order_by("accounts.id", "DESC");
    }
    public function guest_account_by_org($org_id)
    {
        return $this->db
                    ->from($this->table_acc)
                    ->where('role_id',3)
                    ->where('ord_id',$org_id)
                    ->join('users','users.user_id = accounts.id','left')
                    ->join('roles','roles.id = accounts.role_id')
                    ->order_by("accounts.id", "DESC")
        ;
    }
    public function update_super_profile()
    {
        $confirm_pass = $this->input->post("npass");

        if( $this->input->post("email") == null ){
              echo json_encode(  array( 'focus' =>  'email' , 'types' => 'error' , 'msg' => 'E-mail obligatoire!') );
        }else if(filter_var($this->input->post("email") , FILTER_VALIDATE_EMAIL) === false){
            echo json_encode(  array( 'focus' =>  'email' , 'types' => 'error' , 'msg' => 'Adresse e-mail invalide!') );
        }else if( $this->input->post("username") == null ){
              echo json_encode(  array(  'focus' =>  "username" , 'types' => 'error' , 'msg' => "Nom d'utilisateur nécessaire!") );
        }else{
            if( $this->input->post("password") == null   ){
                echo json_encode(  array(  'focus' =>  "password" , 'types' => 'error' , 'msg' => 'Mot de passe obligatoire!') );
            }else if( $this->input->post("npass") != null && $this->input->post("cpass") == null  ){
                echo json_encode(  array(  'focus' =>  "cpass" , 'types' => 'error' , 'msg' => 'Le mot de passe de confirmation est obligatoire!') );
            }else if( $this->input->post("npass") != null && $this->input->post("cpass") != null && ( $this->input->post("npass")  != $this->input->post("cpass")  ) ){
                echo json_encode(  array('focus' =>  "cpass" ,  'types' => 'error' , 'msg' => 'les mots de passe ne correspondent pas!') );
            }else{
                    echo json_encode(  array( 'types' => 'success' , 'msg' => 'Enregistrement des modifications') );

                    $accounts_table = array
                    (
                        'username' => $this->input->post("username"),
                        'password' => sha1( $this->input->post("npass") )
                    );

                    $users_table = array
                    (
                        'lastname' => $this->input->post("lastname"),
                        'firstname' => $this->input->post("firstname"),
                        'email' => $this->input->post("email")
                    );

                    if( $this->input->post("npass") != null ){
                        $this->db->where('id',$this->session->userdata('id'));
                        $this->db->update($this->table_acc, $accounts_table );
                    }
                    

                    $this->db->where('user_id',$this->session->userdata('id'));
                    $this->db->update($this->table_users, $users_table );
            }
        }

    }
    public function get_user_status()
    {
         $where = "(date_add(loginlog.date_time,interval 15 day) <= '".date('Y-m-d H:i:s')."' OR date_add(loginlog.date_time,interval 30 day) <= '".date('Y-m-d H:i:s')."')";
         $query = $this->db
             ->select('*, date_add(loginlog.date_time,interval 15 day) as test_date')
             ->join('users', 'accounts.id = users.user_id')
             ->join('loginlog', 'accounts.id = loginlog.user_id')
             ->where('accounts.role_id',USERS)
             ->where('accounts.ord_id', ( $this->session->userdata('org') > 0 ? $this->session->userdata('org') : 0 ))
             ->where($where)
             ->group_by("loginlog.user_id")
             ->get('accounts')
            ;
        return $query;
    }
    public function get_super_profile()
    {
        $this->db->select('*');
        $this->db->from('accounts');
        $this->db->join('users', 'accounts.id = users.user_id');
        $this->db->order_by("users.user_id", "ASC");
        $this->db->where('accounts.role_id', SUPERADMIN);
        $this->db->where('users.user_id', $this->session->userdata('id'));

        $query = $this->db->get();
        foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
    }
    public function get_organizations()
    {
        $data = [];
        
        $this->db->select('*');
        $this->db->from('accounts');
        $this->db->join('organization', 'accounts.ord_id = organization.id');
        $this->db->order_by("organization.id", "DESC");
        $this->db->where('accounts.role_id', ADMIN);
//        $this->db->where('accounts.active', 1);

        $query = $this->db->get();
        foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
    }
    public function get_organization_by_id($id)
    {
        return $this->db->where('id',$id)->get($this->table_org)->row();
    }
    public function get_company($id)
    {
        if($id){
            $query = $this->db->select('*')
                        ->from('accounts')
                        ->join('users', 'accounts.id = users.user_id')
                        ->join($this->table_org, 'accounts.ord_id = organization.id')
                        ->where('accounts.role_id',ADMIN)
                        ->where('organization.id',$id)
                        ->order_by("organization.id", "ASC");
        }else{
            $query = $this->db->select('*')
                ->from($this->table_org)
                ->order_by("id", "ASC");
        }
        return $query;
    }

    public function submit_company( $input )
    {
        if($input){
            try{
                $id = $this->input->post('id');
                $admin_org = $this->get_admin_org($id);
                $data1 = array(
                    'name'          => $_POST['name'],
                    'subsidiary'    => $_POST['subsidiary'],
                    'sector'        => $_POST['sector'],
                    'num_staff'     => $_POST['num_staff'],
                    'address_line1' => $_POST['address_line1'],
                    'zip_code'      => $_POST['zip_code'],
                    'org_city'      => $_POST['org_city'],
                    'org_country'   => $_POST['org_country']
                );
                $this->db->where('id',$id)
                    ->update($this->table_org, $data1);

                $data2 = array(
                    'username' => $_POST['username']
                );
                if(isset($_POST['new_password']) && $_POST['new_password'] != null) {
                    $data2['password'] = sha1($_POST['new_password']);
                }
                $this->db->where('id',$admin_org->user_id)
                    ->update($this->table_acc, $data2);

                $data3 = array(
                    'firstname'     => $_POST['firstname'],
                    'lastname'      => $_POST['lastname'],
                    'civility'      => $_POST['civility'],
                    'function'      => $_POST['function'],
                    'contact'       => $_POST['contact']
                );
                $this->db->where('user_id',$admin_org->user_id)
                    ->update('users', $data3);

                return ak_return('Success', "Succès de l'enregistrement");
            }catch(Exception $ex) {
                return ak_return('Error', 'An error occurred');
            }
        }
        return ak_return('Error','An error occurred');
    }

    public function get_company_users($userId = null, $orgId = null)
    {
        if($userId){

        }else if($orgId){
            $query = $this->db->select('*')
                    ->from($this->table_acc)
                    ->join('users', 'accounts.id = users.user_id', 'left')
                    ->where('ord_id', $orgId)
                    ->where('role_id >',ADMIN)
                    ->order_by("users.id", "ASC");
            return $query;
        }
        return false;

    }
    /*sadmin -> admin*/
    public function get_admin_org($id)
    {
        $this->db->select('*');
        $this->db->from('organization');
        $this->db->join('accounts', 'accounts.ord_id = organization.id');
        $this->db->join('users', 'accounts.id = users.user_id');
        $this->db->order_by("organization.id", "ASC");
        $this->db->where('organization.id', $id);
        $this->db->where('accounts.role_id',ADMIN);
        $query = $this->db->get();
        return $query->row();
    }
    public function get_admins()
    {
        $this->db->select('*');
        $this->db->from('accounts');
        $this->db->join('organization', 'accounts.ord_id = organization.id');
        $this->db->order_by("organization.id", "ASC");
        $this->db->where('accounts.ord_id', $_POST['id']);
        $query = $this->db->get();
        foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
    }
    public function delete_admins()
    {
        $data = array( 'active' => $this->input->post('status') == 1 ? "0" : "1" );

       $this->db->where('ord_id',$_POST['id']);
       $this->db->update($this->table_acc, $data);
    }
    public function add_update_admins()
    {
        $id = $this->input->post('id');
        $admin_org = $this->get_admin_org($id);
        $user_email = $id ? $this->users->get_user_info(['id'=>$admin_org->user_id])->row()->username : null;
        if( $_POST['username'] == null )
        {
            echo json_encode( array(  'errors' => 'yes' , 'focus' => 'username' ,'msg' => 'Adresse e-mail obligatoire' ) );
        }
        else if(filter_var($_POST['username'] , FILTER_VALIDATE_EMAIL) === false){
            echo json_encode( array(  'errors' => 'yes' , 'focus' => 'username' ,'msg' => 'Adresse e-mail invalide' ) );
        }
        else if($this->users->check_email_existing($_POST['username'], $user_email)){
            echo json_encode( array(  'errors' => 'yes' , 'focus' => 'username' ,'msg' => 'Adresse e-mail déjà existant' ) );
        }
//        else if( $_POST['website_url'] != null && filter_var($_POST['website_url'] , FILTER_VALIDATE_URL) === false )
//        {
//            echo json_encode( array(  'errors' => 'yes' , 'focus' => 'website_url' ,'msg' => 'Format d\'URL incorrect' ) );
//        }
        else if( $_POST['subsidiary'] == null )
        {
            echo json_encode( array(  'errors' => 'yes' , 'focus' => 'subsidiary' ,'msg' => 'Société / Filiale obligatoire' ) );
        }
        else if( !$id && $_POST['password'] == null )//!$id && $_POST['password'] == null
        {
            echo json_encode( array(  'errors' => 'yes' , 'focus' => 'password' ,'msg' => 'Mot de passe obligatoire' ) );
        }
        else if( !$id && $_POST['cpassword'] == null )//!$id && $_POST['cpassword'] == null
        {
            echo json_encode( array(  'errors' => 'yes' , 'focus' => 'cpassword' ,'msg' => 'Confirmation du mot de passe obligatoire' ) );
        }
        else if(  $_POST['password'] != $_POST['cpassword']  )
        {
            echo json_encode( array(  'errors' => 'yes' , 'focus' => 'cpassword' ,'msg' => 'Les deux mots de passe ne correspondent pas!' ) );
        }
        else if( $_POST['max_users'] == null )
        {
            echo json_encode( array(  'errors' => 'yes' , 'focus' => 'max_users' ,'msg' => 'Nombre d\'utilisateur max obligatoire' ) );
        }
        else if( isset($_POST['max_users']) && !is_numeric($_POST['max_users']) )
        {
            echo json_encode( array(  'errors' => 'yes' , 'focus' => 'max_users' ,'msg' => 'Nombre d\'utilisateur max should be numeric' ) );
        }
        else
        {
            if($id){
                $data1 = array(
                    'name'          => $_POST['name'],
                    'subsidiary'    => $_POST['subsidiary'],
                    'sector'        => $_POST['sector'],
                    'num_staff'     => $_POST['num_staff'],
                    'address_line1' => $_POST['address_line1'],
                    'zip_code'      => $_POST['zip_code'],
                    'org_city'      => $_POST['org_city'],
                    'org_country'   => $_POST['org_country'],
                    'max_users'     => $_POST['max_users']
                );
                $this->db->where('id',$id)
                        ->update($this->table_org, $data1);

                $data2 = array(
                    'username' => $_POST['username']
                );
                if(isset($_POST['password']) && $_POST['password'] != null) {
                    $data2['password'] = sha1($_POST['password']);
                }
                $this->db->where('id',$admin_org->user_id)
                        ->update($this->table_acc, $data2);

                $data3 = array(
                    'firstname'     => $_POST['firstname'],
                    'lastname'      => $_POST['lastname'],
                    'civility'      => $_POST['civility'],
                    'function'      => $_POST['function'],
                    'contact'       => $_POST['contact']
                );
                $this->db->where('user_id',$admin_org->user_id)
                    ->update('users', $data3);
                $msg = 'Mise à jour effectuée';
            }else {
                $data1 = array(
                    'name'          => $_POST['name'],
                    'subsidiary'    => $_POST['subsidiary'],
                    'sector'        => $_POST['sector'],
                    'num_staff'     => $_POST['num_staff'],
                    'address_line1' => $_POST['address_line1'],
                    'zip_code'      => $_POST['zip_code'],
                    'org_city'      => $_POST['org_city'],
                    'org_country'   => $_POST['org_country'],
                    'max_users'     => $_POST['max_users']
                );
                $this->db->insert($this->table_org, $data1);
                $last_id = $this->db->insert_id();


                $data2 = array(
                    'username' => $_POST['username'],
                    'password' => sha1($_POST['password']),
                    'ord_id' => $last_id,
                    'role_id' => ADMIN,
                    'date_created' => date("Y-m-d H:i:s", strtotime('today GMT')),
                    'active' => 1
                );
                $this->db->insert($this->table_acc, $data2);
                $last_account = $this->db->insert_id();
                $data3 = array(
                    'user_id' => $last_account,
                    'firstname' => $_POST['firstname'],
                    'lastname' => $_POST['lastname'],
                    'civility'      => $_POST['civility'],
                    'function'      => $_POST['function'],
                    'contact'       => $_POST['contact']
                );
                $this->db->insert('users', $data3);
                $msg = "Succès de l'enregistrement";
            }
            echo json_encode( array(  'errors' => 'no' , 'msg' => $msg ) );
        }


    }
    public function update_admins()
    {
        $data1 = array(
                'name' => $_POST['name'],
                'address_line1' => $_POST['address_line1'],
                'zip_code' => $_POST['zip_code'],
                'org_city' => $_POST['org_city'],
                'website_url' => $_POST['website_url']
        );
        $this->db->where('id',$_POST['id']);
        $this->db->update($this->table_org, $data1);


        $data2 = array(
                'username' => $_POST['username']
        );
        if(isset($_POST['password']) && $_POST['password'] != null) {
            $data2['password'] = sha1($_POST['password']);
        }
        $this->db->where('ord_id',$_POST['id']);
        $this->db->update($this->table_acc, $data2);
    }

    public function update_section()
    {
        $data = [
            'section_id'            => $this->input->post('section_number'),
            'section_title'         => $this->input->post('section_title'),
            'section_description'   => $this->input->post('section_description'),
            'objectives'            => $this->input->post('section_obj'),
            'instructions_start'    => $this->input->post('section_ins'),
            'duration_time'         => $this->input->post('section_duration'),
            'sec_status'            => $this->input->post('section_status'),
        ];
        $this->db->where('id', $this->input->post('section_id'));
        if ($this->db->update($this->table_sec, $data)) {
            if($_FILES['video_file']['name']){
                $upload = $this->uploads->save_video($this->input->post('section_id'), 'section_video');
                $upload = json_decode($upload);
                if($upload->type == 'error'){
                    return ak_return('Error', $upload->msg);
                }
            }
            return ak_return('Success', "Succès de l'enregistrement");
        }
        return ak_return('Error', 'An error occurred');
    }
    public function update_question()
    {
        $section = $this->questions->getSectionByID($this->input->post('section_id'),1)->row();
        $section_num = $section ? $section->section_id : 0;
        $data = [
            'sec_id'                => $this->input->post('section_id'),
            'q_section'             => $section_num,
            'q_order'               => $this->input->post('q_order'),
            'q_content'             => $this->input->post('q_content'),
            'fetch_description'     => $this->input->post('fetch_description'),
            'status'                => $this->input->post('status'),
        ];
        if($this->session->userdata('role') == ADMIN){
            if($question_admin = $this->questions->get_question_org($this->input->post('question_id'))->row()){
                $this->db->where('q_id', $this->input->post('question_id'))
                         ->where('ord_id',$this->session->userdata('org'));
                if ($this->db->update('questionaires_org', $data))
                    return ak_return('Success', "Succès de l'enregistrement");
            }else{
                $data['ord_id'] = $this->session->userdata('org');
                $data['q_id'] = $this->input->post('question_id');
                if ($this->db->insert('questionaires_org', $data))
                    return ak_return('Success', "Succès de l'enregistrement");
            }
        }else{
            $this->db->where('q_id', $this->input->post('question_id'));
            if ($this->db->update('questionaires', $data))
                return ak_return('Success', "Succès de l'enregistrement");
        }
        return ak_return('Error', 'An error occurred');
    }
    public function update_setting()
    {
        $data = [
            'setting_fieldvalue'    => $this->input->post('setting_value'),
            'setting_description'   => $this->input->post('setting_description'),
            'setting_status'        => $this->input->post('setting_status')
        ];
        $this->db->where('id', $this->input->post('setting_id'));
        if ($this->db->update('system_settings', $data)) {
            return ak_return('Success', "Succès de l'enregistrement");
        }
        return ak_return('Error', 'An error occurred');
    }
    /*Sadmin Guest*/
    public function delete_guests()
    {
       $data = array(
           'active'  => $this->input->post('status_guest') == "1" ? "0" : "1"
       );
        if($this->input->post('status_guest') == "0"){
            $data['warning'] = "0";
        }
       $this->db->where('id',$_POST['id']);
       if($this->db->update($this->table_acc, $data))
           return true;
       return false;
    }
    public function edit_guests(){
         $this->db->select('*');
         $this->db->from($this->table_acc);
         $this->db->join('users', 'accounts.id = users.user_id', 'left');
         $this->db->where('users.user_id', $_POST['id']);

        $query = $this->db->get();
        foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
    }
    public function update_guests()
    {
        $data = array
        (
            'user_id' =>  $this->input->post('id'),
            'lastname' => $this->input->post("lname"),
            'firstname' => $this->input->post("fname"),
            'bday' => $this->input->post("bday"),
            'contact' => $this->input->post("contact"),
            'address' => $this->input->post("address"),
            'zip' => $this->input->post("zip"),
            'city' => $this->input->post("city"),
            'country' => ($this->input->post("country")),
            'position' => $this->input->post("current_position"),
            'number_year' => $this->input->post("number_years_position"),
            'started_date' => $this->input->post("started_date") 
            
        );
        if(count($this->getUserDetails($this->input->post('id'))) > 0)
        {
            $this->db->where('user_id',$this->input->post('id'));
            $this->db->update('users', $data);
            $this->update_email_pass($this->input->post('id'),$this->input->post("email"),$this->input->post("passwords"));

             echo json_encode(array( 
                    'mcontent' => 'success', 
                    'msg' => "Votre compte a été mis à jour" ,
                ));
        }
        else
        {
            $this->db->insert('users', $data);
            $this->update_email_pass($this->input->post('id'),$this->input->post("email"),$this->input->post("passwords"));

             echo json_encode(array( 
                    'mcontent' => 'success', 
                    'msg' => "Profil enregistré avec succès." ,
                ));
        }

    }
    public function update_email_pass($id,$email,$password)
    {
            $this->db->where('id',$id);

            if( $email != null && $password != null )
            {
                $this->db->update('accounts', array(
                    'username'  =>  $email,
                    'password'  =>  sha1($password)
                ));
            }
            else if( $email != null )
            {
                $this->db->update('accounts', array(
                    'username'  =>  $email
                ));
            }
            else if( $password != null )
            {
                $this->db->update('accounts', array(
                    'password'  =>  sha1($password)
                ));
            }   
    }
    public function getUserDetails($userID)
    {
        $this->db->select('*');
        $this->db->from('users');
        $this->db->where('user_id',$userID);
        $query = $this->db->get();
        return $query->result();
    }
    
    public function get_section_stat()
    {
        $count_all_section = $this->questions->count_this('allsection_floor');
        $label = [];
        for($i = 1; $i <= $count_all_section; $i++){
            $label[] = $i;
        }
        
        $all_users_registered_not_registered = $this->session->userdata('role') == SUPERADMIN ? $this->users->get_user_info(["role_id" => USERS]) : $this->users->get_user_info(["role_id" => USERS, "ord_id"=>$this->session->userdata('org')]);
        $all_users_registered_not_registered_count = $all_users_registered_not_registered->num_rows();

        $all_users = $this->session->userdata('role') == SUPERADMIN ? $this->users->get_user_info(["active" => "1", "role_id" => USERS]) : $this->users->get_user_info(["active" => "1", "role_id" => USERS, "ord_id"=>$this->session->userdata('org')]);
        $all_users_count = $all_users->num_rows();
        if($all_users_count > 0){
            $done = []; $in_progress = []; $not_started = [];
            $done_g = []; $in_progress_g = []; $not_started_g = [];
            $user_done = 0; $user_in_prog = 0;
            foreach($all_users->result() as $user){
                $user_prog = 0;
                for($i = 1; $i <= $count_all_section; $i++){
                    $percentage = $this->questions->getPercentage_($i, $user->id);
                    $user_prog += $percentage;
                    $percent_done = $percentage >= 100 ;
                    $done[$i] = isset($done[$i]) ? ($percent_done ? 1 : 0 ) + $done[$i] : ($percent_done ? 1 : 0);
                    $in_progress[$i] = isset($in_progress[$i]) ? ($percent_done || $percentage == 0 ? 0 : 1) + $in_progress[$i] : ($percent_done || $percentage == 0 ? 0 : 1 );
                    $not_started[$i] = isset($not_started[$i]) ? ($percentage == 0 ? 1 : 0) + $not_started[$i] : ($percentage == 0 ? 1 : 0 );
                    $done_g[$i] = ceil(($done[$i] * 100) / $all_users_count);
                    $in_progress_g[$i] = ceil(($in_progress[$i] * 100) / $all_users_count);
                    $not_started_g[$i] = ceil(($not_started[$i] * 100) / $all_users_count);
                }
                $user_prog >= ($count_all_section * 100) ? $user_done++ : ( $user_prog != 0 ? $user_in_prog++ : null); //* $count_all_section

                array_walk_recursive($done, function($item, $key) use (&$done, $user_prog, $count_all_section, $user){
                    $done[$key] = $user_prog >= ($count_all_section * 100) ?  $item - 1  : $done[$key];
                });
            }
            return json_encode([ 'all_users'=>$all_users_registered_not_registered_count /*$all_users_count*/,
                'user_done' => $user_done, 'user_in_prog' => $user_in_prog,
                'not_started' => $not_started, 'done' => $done, 'in_progress' => $in_progress,
                'not_started_g' => $not_started_g, 'done_g' => $done_g, 'in_progress_g' => $in_progress_g,
                'label' => $label ]);
        }
        return json_encode([ 'all_users'=>0, 'user_done' => 0, 'user_in_prog' => 0, 'not_started' => 0, 'done' => 0, 'in_progress' => 0, 'not_started_g' => 0, 'done_g' => 0, 'in_progress_g' => 0,'label' => $label ]);
    }
    public function get_org_logo($id)
    {
        return $this->db->order_by('id','DESC')->get_where('admin_personalize', array('ord_id' => $id));
    }
    public function has_logo($id)
    {
        $query = $this->get_org_logo($id);

        if( $query->num_rows() > 0)
        {
            return $query->row();

        }else{
            return null;
        }
    }
    public function  users_progresions_and_dones($orgid = null, $by_date = null)
    {

        if( $orgid != null)// by table
            $dtQuery = $this->guest_account_by_org( $orgid );
        else // by admin or superadmin
            $dtQuery = $this->session->userdata('role') == SUPERADMIN ? $this->guest_accounts() : $this->guest_account_by_org(  $this->session->userdata('org') );

        
        $dtResult = $dtQuery->get()->result();
        $dtHtml = '';
        $all_users = 0 ; $done = 0; $all_users = 0; $not_started = 0; $in_progress = 0; $not_done = 0; 
        $users = 1; $inprog = 1;
        $counta = 1; $countb = 1;  $countc = 1;
        $list = [];

        //$count_all_section = $this->questions->count_this('allsection_floor');

        foreach ($dtResult as $aRow) {

            if($by_date)
                $users_progressions =  ( $this->questions->my_last_answered_by_year("",$aRow->user_id,"true") ? $this->questions->my_last_answered_by_year("",$aRow->user_id,"true")->q_section : null);
            else
                $users_progressions =  ( $this->questions->my_last_answered("",$aRow->user_id) ? $this->questions->my_last_answered("",$aRow->user_id)->q_section : null);
            
            $all_users = $users++;
            
            //$list[] = $aRow->username . ": ". $users_progressions;

            if( $this->session->userdata('role') == SUPERADMIN ){

                if(  $users_progressions  == 10.4 ){
                    $done = $counta++ ;                      
                }else if( $users_progressions  < 10.4  &&  $aRow->started_date == 0 &&  $users_progressions =="" ){
                    $not_started = $countb++; 
                }else if( $users_progressions  < 10.4 &&  $users_progressions !="" ) {
                    $in_progress = $countc++; 
                    //$list[] = $aRow->username . ": ". $users_progressions;
                }

            }else{

                if(  $users_progressions  == 10.4 ){
                    $done = $counta++ ;                      
                }else if( $users_progressions  < 10.4   &&  $aRow->started_date == 0 &&  $users_progressions ==""  ){
                    $not_started = $countb++; 
                }else if( $users_progressions  < 10.4 &&  $users_progressions !="" ){
                    $in_progress = $countc++;  
                }
            }
        }

        //echo "<pre>";
        //asort($list);
        //print_r( $list );

        $not_done = ( $all_users - $done );

        if( $orgid != null ) // by table
        {
            return  array(
                'all_users' => $all_users,
                'users_done' => $done,
                'users_not_done' => $not_done,
                'users_not_started' => $not_started,
                'users_in_progress' => $in_progress   
            );
        }
        else // by admin or superadmin
        {
            return  array
            (
                'all_users' => $all_users,
                'users_done' => $done,
                'users_not_done' => $not_done,
                'users_not_started' => $not_started,
                'users_in_progress' => $in_progress   
            );
        }
        

    }
    public function  get_section_stat_superadmin()
    {
        // $section = 1;
        // $data = [];

        // $dtQuery = $this->session->userdata('role') == SUPERADMIN ? $this->guest_accounts() : $this->guest_account_by_org(  $this->session->userdata('org') );

        // $dtResult = $dtQuery->get()->result();
        // $done = 0; $in_progress = 0; $not_started = 0;
        // $arr = [];

        // $count_all_section = $this->questions->count_this('allsection_floor');

        // for($i = 1; $i <= $count_all_section; $i++)
        // {   
        //     //echo $max = $this->get_max_section( $i ) ;

        //     foreach ($dtResult as $aRow) 
        //     {
        //      $percent =  ( $this->questions->my_last_answered("",$aRow->user_id) ? ( $this->questions->my_last_answered("",$aRow->user_id)->q_section ).','.$aRow->started_date : null);  
        //      $percentages = explode(',', $percent);
        //      $percentage = isset( $percentages[0] ) ? $percentages[0] : "";
        //      $date = isset( $percentages[1]) ? $percentages[1] : "";

            

        //      echo $percentage . ' '. $this->get_max_section( round($percentage,0) ) ;
        //      // if( $max == $percentage ){
        //      //     echo "<pre>";
        //      //    print_r( $data );
        //      // }
             
        //     }

           
        //      // if( $i == $section )
        //      // {
        //      //    array_push($arr, array( "not_started" => $not_started ) );
        //      //    array_push($arr, array( "in_progress" => $in_progress));
        //      //    array_push($arr, array( "done" => $done ) ); 
        //      // }
        // }
        // echo "<pre>";
        // print_r( $arr );
    }
    public function get_max_section( $section )
    {
         $query = $this->db->query("
            SELECT q_section as max_x FROM questionaires
            WHERE TRUNCATE(q_section, 0) = ".$section."
            ORDER BY q_section DESC LIMIT 1
        ");

        if($query->num_rows() > 0)
        {
           $ret = $query->row();
           return $ret->max_x;
        }

    }
    public function most_user_graphs()
    {
        $query = $this->db->query("
            SELECT o.id, o.name , o.subsidiary, o.max_users, 
            (
                 SELECT COUNT(*)
                 FROM accounts accnt 
                 LEFT JOIN users u 
                 ON accnt.id = u.user_id
                 WHERE accnt.ord_id = o.id
                 AND accnt.role_id = 3
            ) as max_u

            FROM organization o 
            JOIN accounts a 
            ON o.id = a.ord_id
            JOIN users u 
            ON a.id = u.user_id
            WHERE a.role_id = 3
            GROUP BY o.id
            ORDER by max_u DESC 
            LIMIT 10
        ");

        return $query->result_array() ;

    }
    public function section_graphs()
    {
        $computations = $this->users_progresions_and_dones();

        $all_users = $computations['all_users'];
        $users_done = $computations['users_done'];
        $users_not_done = $computations['users_not_done'];
        $users_not_started = $computations['users_not_started'];
        $users_in_progress = $computations['users_in_progress'];
        

        echo json_encode([ 
            'all_users' => $all_users,
            'users_done' => $users_done,
            'users_not_done' => $users_not_done,
            'users_not_started' => $users_not_started,
            'users_in_progress' => $users_in_progress
        ]);

    }
    public function get_profiles()
    {
          $this->db->select('*');
            $this->db->from('users');
            $this->db->join('accounts', 'accounts.id = users.user_id');
            $this->db->where('user_id', $_POST['id']);
            $query = $this->db->get();
            return $query->result_array();
    }
    public function get_sadmin_profiles()
    {
          $this->db->select('*');
            $this->db->from('users');
            $this->db->join('accounts', 'accounts.id = users.user_id');
            $this->db->where('user_id', $this->session->userdata('id') );
            $query = $this->db->get();
            return $query->result_array();
    }
    public function post_sadmin_profiles()
    {

         $accounts_array = $this->input->post('npass') != null ? [
                'username' => $this->input->post('username'),
                'password' => sha1( $this->input->post('npass') )
            ] : [
                'username' => $this->input->post('username')
            ];

         $this->db->where('user_id',$this->session->userdata('id') )
        ->update('users',
            [
                'firstname' => $this->input->post('firstname'),
                'lastname' => $this->input->post('lastname'),
                'email'   => $this->input->post('email'),
                'function'  => "SUPERADMIN"
            ]);

         $this->db->where('id',$this->session->userdata('id') )
        ->update('accounts', $accounts_array);

        return $this->db->affected_rows();
    }

    public function get_sadmin_personalizes( $type )
    {

        $org_id = $this->session->userdata('role') == SUPERADMIN ? 0 : $this->session->userdata('org');

        $this->db->select("content");
        $this->db->where('type', $type );
        $this->db->where('org_id', $org_id );
        $result = $this->db->get("sadmin_personalize");
        if($result->num_rows() > 0)
        {
           $ret = $result->row();
           return $ret->content;
        }
        else if( $result->num_rows() == 0 )
        {
            $this->db->select("content");
            $this->db->where('type', $type );
            $this->db->where('org_id', null);
            $result = $this->db->get("sadmin_personalize");
            $ret = $result->row();
           return $ret->content;
        }
    }
    public function post_sadmin_personalizes($type, $arr = array() )
    {
       
        $org_id = $this->session->userdata('role') == SUPERADMIN ? 0 : $this->session->userdata('org');

        $this->db->select("content");
        $this->db->where('type', $type );
        $this->db->where('org_id', $org_id );
        $result = $this->db->get("sadmin_personalize");
        if($result->num_rows() > 0)
        {
            $this->db->where('type', $type );
            $this->db->where('org_id', $org_id );
            $this->db->update('sadmin_personalize', $arr );
        }
        else if( $result->num_rows() == 0 )
        {
            $this->db->insert('sadmin_personalize',
            [
              'type' => $type,
              'content' => $this->input->post('content'),
              'org_id' => $org_id
            ]
            );
        }

    }
}
