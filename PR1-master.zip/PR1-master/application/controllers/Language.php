<?php
class Language extends CI_Controller
{
    public function __construct() 
    {
        parent::__construct();   	 
    }

    function french($msg) 
    {
      echo json_encode( array(
      	'lang' => $this->languages->lang($msg)
      	) );
    }

    public function populate_language()
    {
      $this->languages->populate_languages();
    }
    public function check_empty()
    {
      $this->languages->check_empties();
    }
    public function add_language()
    {
      $this->languages->add_languages();
    }
    public function delete_language()
    {
      $this->languages->delete_languages();
    }
    public function get_data_id()
    {
      $this->languages->get_data_ids();
    }
    public function update_language()
    {
      $this->languages->update_languages();
    }
    public function get_highest_point()
    {
        $this->languages->get_highest($this->input->get('type'));
    }
}