<?php /**  <link href="<?php echo base_url();?>assets/css/admin/company_users.css" rel="stylesheet"> **/ ?>
<div id="main">
    <div class="admin_header">
        <div class="admin_title"><h2><?php echo $this->languages->lang('users') ?></h2></div>
    </div>
    <div class="table-responsive">
        <br><br>
        <table id="company_users_dt" class="table table-striped table-bordered" cellspacing="0" width="100%">
            <thead>
            <tr>
                <th>Username</th>
                <th>First name</th>
                <th>Last name</th>
                <th>Email</th>
                <th>Contact</th>
                <th>Address</th>
            </tr>
            </thead>
        </table>
    </div>
</div>