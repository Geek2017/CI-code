<div class="container">
	<?php
if( $job_info ){ 
	foreach ($job_info as $key => $value) {
			$job_id = $value->id;
			$user_id = $value->user_id ;
			$company = $value->company   ;
			$job_title= $value->job_title;
			$start_date = $value->start_date;
			$s_reasons = $value->s_reasons   ;
			$end_date = $value->end_date ;
			$e_reasons = $value->e_reasons;
	}
}

?>
	<h1 class="text-center">Votre Histoire Professionnelle</h1>

<br><br>
<form  method="POST" role="form" id="job">
		<div class="row">
			<div class="col-md-6 col-md-offset-3">
				<input type="hidden" id="user_id" value="<?php echo $this->session->userdata('id')?>" name="id">
				<div class="col-md-3">
					<p><strong>Poste occupé </strong></p>
				</div>
				<input type="hidden"  id="actions" class="form-control" value="<?php echo !empty($job_info)  ? "edit" : "add"; ?>">
				<input type="hidden"  id="job_id" class="form-control" value="<?php echo !empty($job_info[0]->id)  ? $job_info[0]->id : "null"; ?>" >

				<div class="col-md-9">
					<div class="form-group">		
						<input type="text" name="job_title" id="job_title" class="form-control" value="<?php echo !empty($job_info[0]->job_title)  ?  $job_info[0]->job_title: "" ?>"  title="" required="required">
					</div>
				</div>
				<div class="col-md-3">
					<p><strong>Entreprise</strong></p>
				</div>
				<div class="col-md-9">
					<div class="form-group">		
						<input type="text" name="company" id="company" class="form-control" value="<?php echo !empty($job_info[0]->company)  ?  $job_info[0]->company: "" ?>" required="required">
					</div>
				</div>
				<div class="col-md-3">
					<p><strong>Entrée date</strong></p>
				</div>
				<div class="col-md-9">
					<div class="form-group">		
						<input readonly type="text" name="start_date" id="start_date" class="form-control datepicker" value="<?php echo !empty($job_info[0]->start_date)  ?  $job_info[0]->start_date: "" ?>"  title="" required="required">
					</div>
				</div>
				<div class="col-md-3">
					<p><strong>Raisons</strong></p>
				</div>
				<div class="col-md-9">
					<div class="form-group">		
						<input type="text" name="s_reasons" id="s_reasons" class="form-control" value="<?php echo !empty($job_info[0]->s_reasons)  ?  $job_info[0]->s_reasons: "" ?>"  title="" required="required">
					</div>
				</div>
				<div class="col-md-3">
					<p><strong>Sortie date</strong></p>
				</div>
				<div class="col-md-9">
					<div class="form-group">		
						<input readonly type="text"  name="end_date" id="end_date" class="form-control datepicker" value="<?php echo !empty($job_info[0]->end_date)  ?  $job_info[0]->end_date: "" ?>"   title="">
					</div>
				</div>
				<div class="col-md-3">
					<p><strong>Raisons</strong></p>
				</div>
				<div class="col-md-9">
					<div class="form-group">		
						<input type="text" name="e_reasons" id="e_reasons" class="form-control" value="<?php echo !empty($job_info[0]->e_reasons)  ?  $job_info[0]->e_reasons: "" ?>"   title="">
					</div>
				</div>
				<center>
				<button type="submit" onclick="Profesional_jobs.job_form(event);" class="btn btn-primary" style="width:20%"><?php echo !empty($job_info)  ?  "Mettre à jour" : "Enregistrer" ?></button>
				<button type="submit" onclick="Profesional_jobs.retour(event);" class="btn btn-primary" style="width:20%">Retour</button></center>
			</div>
			
		</div>
		
	</form>
	<div class="col-md-8 col-md-offset-2">	
		<div class="row">
			<br><br>
			<form id="form_activity">
			<table class="table " id="activity_job">
				<thead>
					<tr>
						<th>Activités </th>
						<th>Satisfaction de 1 (--) à 4 (++)</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody id="activity_jobs">
					
				</tbody>
				
				
				
			</table>
			</form>
			<button type="submit" class="btn btn-primary glyphicon-plus" id="btn-activity"></button>
		</div>

		<form id="satiscation_form">
		<div class="row">
			
			<table class="table " id="savoir_job">
				<thead>
					<tr>
						<th>Compétences métier (savoir)</th>
						<th>Maitrise de 1 (--) à 4 (++)</th>
						<th>Motivation de 1 (--) à 4 (++)</th>
						<th>Total</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody id="savoir_jobs">
					
				</tbody>
				<tfoot>
					<tr>
						<td><input type="hidden" name="place[]" class="form-control" id="" placeholder="" required="required" value="savior">
							<input type="text" name="activity[]" class="form-control" id="" placeholder="" required="required"></td>
						<td><input type="number" name="satisfaction1[]" class="form-control" id="" max="4" min="1" required="required"></td>
						<td><input type="number" name="satisfaction2[]" class="form-control" id="" max="4" min="1" required="required"></td>
						<td><input type="number" name="total[]" class="form-control" id="" ></td>
						<td><button type="submit" class="btn btn-primary glyphicon-plus" id="btn-savoir"></button></td>
					</tr>
				</tfoot>

			</table>
			
		</div>
		<div class="row">
			
			<table class="table " id="faire_job">
				<thead>
					<tr>
						<th>Compétences métier (savoir faire)</th>
						<th>Maitrise de 1 (--) à 4 (++)</th>
						<th>Motivation de 1 (--) à 4 (++)</th>
						<th>Total</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody id="faire_jobs">
					
				</tbody>
					<tfoot>
						<tr>
							<td><input type="hidden" name="place[]" class="form-control" id="" placeholder="" required="required" value="faire">
								<input type="text" name="activity[]" class="form-control" id="" placeholder="" required="required"></td>
							<td><input type="number" name="satisfaction1[]" class="form-control" id="" max="4" min="1" required="required"></td>
							<td><input type="number" name="satisfaction2[]" class="form-control" id="" max="4" min="1" required="required"></td>
							<td><input type="number" name="total[]" class="form-control" id="" ></td>
							<td><button type="submit" class="btn btn-primary glyphicon glyphicon-plus" id="btn-faire"></button></td>
						</tr>
					</tfoot>
			</table>
			
		</div>
		<div class="row">
			
			<table class="table " id="etre_job">
				<thead>
					<tr>
						<th>Compétences comportementales (savoir être démontré) *</th>
						<th>Maitrise de 1 (--) à 4 (++)</th>
						<th>Motivation de 1 (--) à 4 (++)</th>
						<th>Total</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody id="etre_jobs">
					
				</tbody>
				<tfoot>
					<tr>
						<td><input type="hidden" name="place[]" class="form-control" id="" placeholder="" required="required" value="etre">
							<input type="text" name="activity[]" class="form-control" id="" placeholder="" required="required"></td>
						<td><input type="number" name="satisfaction1[]" class="form-control" id="" max="4" min="1" required="required"></td>
						<td><input type="number" name="satisfaction2[]" class="form-control" id="" max="4" min="1" required="required"></td>
						<td><input type="number" name="total[]" class="form-control" id="" ></td>
						<td><button type="submit" class="btn btn-primary glyphicon glyphicon-plus" id="btn-etre"></button></td>
					</tr>
				</tfoot>
			</table>
		</div>
		</form>
		<div class="pull-right">
			<button type="button" id="to-job" class="btn btn-primary next">Enregistrer</button>	
		</div>
	</div>
	
</div>