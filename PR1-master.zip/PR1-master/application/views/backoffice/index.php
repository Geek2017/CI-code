<div id="main">
  <h2>Tableau de bord</h2>
  <div class="row dashboard_graph">
    <div class="col-sm-12">

        <div class="col-sm-4 pie_chart">
          <canvas id="done_pie" style="padding-left:0px; padding-right:0px;"></canvas>
           <center><label for = "done_pie">
              Nombre total d’utilisateur sur la plateforme.<br />
           </label></center>
        </div>
     
        <div class="col-sm-4 pie_chart">
          <canvas id="in_progress_pie" style="padding-left:0px; padding-right:0px;"></canvas>
          <center><label for = "in_progress_pie">
                Nombre d’utilisateur en direct.<br />
            </label></center>
        </div>
      
        <div class="col-sm-4 pie_chart">
          <canvas id="user_pie" style="padding-left:0px; padding-right:0px;"></canvas>
           <center><label for = "user_pie">
            Nombre d’adminsitrateur/entreprise.<br />
            </label></center>
        </div>

<!--      <div class="col-sm-4 pie_chart">-->
<!--        <canvas id="user_graph" style="padding-left:0px; padding-right:30px;"></canvas>-->
<!--        <div class="graph_info_cont">-->
<!--          <div>No. of Admin active user : <span class="active_admin"></span></div>-->
<!--          <div>No. of Admin deactivated user : <span class="inactive_admin"></div>-->
<!--          <div>No. of Guest active user : <span class="active_user"></div>-->
<!--          <div>No. of Guest deactivated user : <span class="inactive_user"></div>-->
<!--        </div>-->
<!--      </div>-->
    </div>
    <div class="col-sm-12 second_con_dashboard">
       <label for = "table_section_stat">
             Utilisateurs de superadmin et admin.<br />
        </label>
<!--      <div class="col-sm-4">-->
<!--        <canvas id="section_donut" style="padding-left:0px; padding-right:30px;"></canvas>-->
<!--        <div class="graph_info_cont bar_graph">-->
<!--          <div>OVERALL SECTION (1-10)</div>-->
<!--          <div>No. of all NOT STARTED guest : <span class="not_started_label"></div>-->
<!--          <div>No. of all IN PROGRESS guest : <span class="in_progress_label"></div>-->
<!--          <div>No. of all DONE guest : <span class="all_done_label"></div>-->
<!--        </div>-->
<!--      </div>-->
<!--      <div class="col-sm-8">-->
        <?php
          // $label = ["Guests who DIDN'T START per section","Guests whose IN PROGRESS per section","Guests whose DONE per section"];
          $label = ["Nombre d'invités n'ayant pas commencé","Nombre d'invités en cours de progression","Nombre d'invités ayant terminé le parcours"];
          $label_class = ["not_started","in_progress","done"];
          $table = "<table class='table_section_stat' border='1'><thead><tr><td></td>";
          for($i = 1; $i <= $this->questions->count_this('allsection_floor'); $i++){
                $table .= "<td>Section ".$i."</td>";
          }
          $table .= "</tr></thead>";
          $table .= "";
          foreach($label as $x => $l){
            $table .= "<tr><td>".$l."</td>";
            for($i = 1; $i <= $this->questions->count_this('allsection_floor'); $i++){
              $table .= "<td class='value_label ".$label_class[$x]."_".$i."'></td>";
            }
            $table .= "</tr>";
          }
          echo $table."</table>";
        ?>
<!--      </div>-->
    </div>

    <div class="col-sm-12 second_con_dashboard">
       <label for = "table_section_stat">
             Utilisateurs de superadmin.<br />
        </label>
        <?php
          $label = ["Nombre d'invités n'ayant pas commencé","Nombre d'invités en cours de progression","Nombre d'invités ayant terminé le parcours"];
          $label_class = ["not_started","in_progress","done"];
          $table = "<table class='table_section_stat' border='1'><thead><tr><td></td>";
          for($i = 1; $i <= $this->questions->count_this('allsection_floor'); $i++){
                $table .= "<td>Section ".$i."</td>";
          }
          $table .= "</tr></thead>";
          $table .= "";
          foreach($label as $x => $l){
            $table .= "<tr><td>".$l."</td>";
            for($i = 1; $i <= $this->questions->count_this('allsection_floor'); $i++){
              $table .= "<td class='value_label ".$label_class[$x]."_".$i."'></td>";
            }
            $table .= "</tr>";
          }
          echo $table."</table>";
        ?>
    </div>

    <div class="col-sm-12">
       <label for = "section_graph">
             <br /><br />Utilisateurs de superadmin et admin.<br />
        </label>
      <canvas id="section_graph" style="padding-left:0px; padding-right:30px;"></canvas>
    </div>


     <div class="col-sm-12">
       <label for = "most_users_graph">
             <br />Top 10 des compagnies avec le plus d’utilisateurs<br /> <br />
        </label>
      <canvas id="most_users_graph" style="padding-left:0px; padding-right:30px;"></canvas>
    </div>
     <div class="col-sm-12">
                <div><h2>Par année</h2></div>
                <table class='table_section_stat' border='1'>
                    <?php $per_year  = $this->backoffices->users_progresions_and_dones("","true");?>
                    <tr><td></td><td><?=date('Y')?></td></tr>
                    <tr><td>N’ayant pas commencé</td><td><?=$per_year['users_not_started']?></td></tr>
                    <tr><td>En progression</td><td><?=$per_year['users_in_progress']?></td></tr>
                    <tr><td>Ceux qui ont terminé</td><td><?=$per_year['users_done']?></td></tr>
                </table>
        </div>

  </div>
</div>