<html>
<head>
	<head>
		<title><?php echo $title; ?></title>
	</head>
	<body>
		<section>
			<div>
				<div align="center" style="margin-top:50px; margin-bottom:50px;">
					<img src="<?php echo base_url();?>assets/img/404.png" /> <br>
					<?php 
					echo $message; 
					
					$retour = "";

					if( $this->session->userdata('role') < 3)

						$retour = base_url('index.php/admin/dashboard');

					else
						
						$retour = base_url('index.php/main');

					?>
					<a href="<?php echo $retour;?>">retour</a>
				</div>
			</div>
		</section>
	</body>
</html>