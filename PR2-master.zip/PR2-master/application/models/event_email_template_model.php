<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Event_email_template_model extends CI_Model {

    var $column_order = array(null, 'eet.email_tpl_name', 'eett.email_type','eet.email_tpl_creation_status','eet.email_tpl_status', 'u.first_name', null, 'eet.email_tpl_date_created'); //set column field database for datatable orderable
    var $column_search = array('CONCAT(u.first_name, " ", u.last_name)','eet.email_tpl_name'); //set column field database for datatable searchable just firstname , lastname , address are searchable
    var $order = array('eet.email_tpl_id' => 'desc'); // default order

    public function __construct() {
        parent::__construct();
    }
    private function _get_datatables_query($data_source){

        $this->db->select("
            eet.email_tpl_id,
            eett.email_type,
            eett.email_type_subject,
            eet.email_type_id,
            eet.email_tpl_name,
            eet.email_tpl_subject,
            eet.email_tpl_surheader,
            eet.email_tpl_creation_status AS email_tpl_creation_status,
            eet.email_tpl_status AS email_tpl_status_,
            (CASE
              WHEN eet.email_tpl_status = 1 THEN 'En cours de création'
              WHEN eet.email_tpl_status = 2 THEN 'Publié'
              ELSE 'Email n\'est pas encore créé'
            END) AS email_tpl_status")
            ->select("CONCAT(u.first_name, ' ', u.last_name) as email_tpl_author", FALSE)
            ->select("DATE_FORMAT(eet.email_tpl_date_created, '%d/%m/%Y %Hh%i') AS email_tpl_date_created", FALSE)
            ->from("event_email_template eet")
            ->join('event_email_template_type eett', 'eett.email_type_id = eet.email_type_id', 'left')
            ->join('user u', 'u.user_id = eet.email_tpl_author', 'left')
            ->where_in("eet.email_tpl_status", array(1,2));

        $i = 0;
        foreach ($this->column_search as $item) {// loop column
            if ($data_source['search']['value']) {  // if datatable send POST for search
                if ($i === 0) { // first loop
                    $this->db->like($item, $data_source['search']['value']);
                } else {
                    $this->db->or_like($item, $data_source['search']['value']);
                }
            }
            $i++;
        }

        if(isset($data_source['order'])) { // here order processing
            if(isset($data_source['order']['0']['dir'])) {
                $this->db->order_by($this->column_order[$data_source['order']['0']['column']], $data_source['order']['0']['dir']);
            }
        } else if(isset($this->order)) {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    public function get_events_list_export($data_source){
        $this->_get_datatables_query($data_source);
        $query = $this->db->get();
        $res = $query->result();
        return $res;
    }

    public function get_datatables($data_source){
        $this->_get_datatables_query($data_source);
        if($data_source['length'] != -1)
            $this->db->limit($data_source['length'], $data_source['start']);
        $query = $this->db->get();
        return $query->result();
    }

    public function count_filtered($data_source){
        $this->_get_datatables_query($data_source);
        $query = $this->db->get();
        return $query->num_rows();
    }

    public function count_all($data_source){
        $this->_get_datatables_query($data_source);
        return $this->db->count_all_results();
    }

    public function create_email_template($data){
        //unset default template if the template to be added is also a default one
        if($data["email_tpl_creation_status"] === "DEFAULT" && $data["email_tpl_status"] == 2) {
            $this->db->where("email_tpl_creation_status", $data["email_tpl_creation_status"]);
            $this->db->where("email_tpl_status", $data["email_tpl_status"]);
            $this->db->where("email_type_id", $data["email_type_id"]);
            $this->db->update("event_email_template", array("email_tpl_creation_status" => "CUSTOMIZED"));
        }
        $this->db->insert("event_email_template", $data);
        if($this->db->affected_rows()){
            return $this->db->insert_id();
        }
        return false;
    }

    public function update_email_template($email_tpl_id, $data){
        //unset default template if the template to be replaced is also a default one
        if($data["email_tpl_creation_status"] === "DEFAULT" && $data["email_tpl_status"] == 2) {
            $this->db->where("email_tpl_creation_status", $data["email_tpl_creation_status"]);
            $this->db->where("email_tpl_status", $data["email_tpl_status"]);
            $this->db->where("email_type_id", $data["email_type_id"]);
            $this->db->update("event_email_template", array("email_tpl_creation_status" => "CUSTOMIZED"));
        }
        $this->db->where("email_tpl_id", $email_tpl_id);
        $update = $this->db->update("event_email_template", $data);
        if($update){
            return true;
        }
        return false;
    }

    public function check_template_dependencies($email_tpl_id){
        // //check dependencies
        // $this->db->select("email_tpl_id");
        // $this->db->where("email_tpl_id", $email_tpl_id);
        // $this->db->where("email_map_status", 1);
        // $check = $this->db->get("event_email_template_map")->num_rows();
        // if($check){
        //     return true;
        // }
        // return false;
    }

    public function delete_email_tempalate($email_tpl_id){
        $this->db->where("email_tpl_id", $email_tpl_id);
        $this->db->update("event_email_template", array("email_tpl_status" => 0));
        if($this->db->affected_rows()){
            return true;
        }
        return false;
    }

    public function get_email_template_content($email_tpl_id){
        $this->db->select("email_tpl_detail");
        $this->db->where("email_tpl_id",$email_tpl_id);
        $result = $this->db->get("event_email_template")->result();
        if($result){
            return $result;
        }
        return false;
    }

    public function check_duplicate_template_name($email_tpl_id="", $email_tpl_name){
        $this->db->select("email_tpl_id");
        if($email_tpl_id !="") {
            $this->db->where("email_tpl_id !=", $email_tpl_id);
        }
        $this->db->where("email_tpl_name", $email_tpl_name);
        $this->db->where("email_tpl_status !=", 0);
        $result = $this->db->get("event_email_template")->num_rows();

        if($result > 0){
            return true;
        }
        return false;
    }

    public function get_subscribers_data($subscriber){
        $result = $this->db->query("SELECT
            u.user_id as subscriber_id,
            u.email_address,
            CONCAT(u.first_name, ' ', u.last_name) AS subscriber
          FROM
            user u
          WHERE
            user_id = ".$subscriber."
            LIMIT 1");

        if ($result->num_rows() > 0) {
            return $result->result_array()[0];
        }
        return false;
    }

    public function list_email_type(){
        $result = $this->db->select("email_type_id, email_type")
            ->where("email_type_status",1)
            ->order_by("sort_order", "asc")
            ->get("event_email_template_type")->result();
        return $result;
    }

    public function list_email_type_with_default_setting(){
        $result = $this->db->select("email_type_id, email_type")
            ->where("email_type_status",1)
            ->where_not_in("email_type_id", array(3, 4, 5, 6))
            ->get("event_email_template_type")->result();
        return $result;
    }

    public function typeahead_email_template($data){
        $this->db->select("email_tpl_id, email_tpl_name AS name");
        $this->db->where("email_tpl_status", 2);
        $this->db->where("email_type_id", $data["email_type_id"]);
        $this->db->like("email_tpl_name", $data["search"]);
        $this->db->limit(10);
        $this->db->order_by("email_tpl_id", "desc");
        return $this->db->get("event_email_template")->result();
    }

    public function typeahead_event($data){
        $where = (isset($data["events_ids"]) && !empty($data["events_ids"]))?" AND eetmp.event_id != ".$data["events_ids"]:"";
        return $this->db->query("
            SELECT event_id, title AS name,
                DATE_FORMAT(reservation_start_date, '%d/%m/%Y %Hh%m') AS reservation
            FROM
                event
            WHERE
                back_office_status IN(1,2,3)
              AND
                  title LIKE '%".$data["search"]."%'
              AND
                 event_id NOT IN(
                 SELECT eetmp.event_id
                 FROM event_email_template_mapping eetmp, event_email_template eet
                 WHERE eet.email_type_id = '".$data["email_type_id"]."' AND eetmp.email_mapping_status = 1 ".$where."
                 )
             ORDER BY event_id desc
             LIMIT 10
        ")->result();
    }

    public function check_reset_time($email_schedule_id){
        return $this->db->select("email_schedule_id")
            ->where("email_schedule_date <= NOW()")
            ->where("email_schedule_status", 1)
            ->where("email_schedule_id", $email_schedule_id)
            ->order_by("email_schedule_id", "desc")
            ->limit(1)
            ->get("event_email_schedule")->num_rows();
    }

    public function get_current_event_email_template($event_id, $event_schedule_id, $email_type_id, $withcontent=false){
        $select = ""; 
        if($withcontent){
            $select = ", 
                (CASE 
                    WHEN (eet.email_tpl_surheader IS NULL OR eet.email_tpl_surheader = '') THEN eet.email_tpl_detail
                    ELSE CONCAT(eet.email_tpl_surheader,' ', eet.email_tpl_detail)
                END) AS email_tpl_detail, eet.email_tpl_subject ";
        }
        //check if there is an assigned template to this event
        $checkTpl = $this->db->query("
            SELECT 
                eet.email_tpl_id
                ".$select."
            FROM event_email_template_mapping_by_event_schedule emap
            LEFT JOIN event_schedule es
                ON es.event_id = ".$event_id."
            LEFT JOIN event e
                ON e.event_id = es.event_id
            LEFT JOIN event_email_template eet 
                ON emap.email_tpl_id = eet.email_tpl_id
            WHERE 
                emap.event_schedule_id = ".$event_schedule_id." 
                AND emap.is_active = 1
                AND eet.email_type_id = ".$email_type_id." 
                AND eet.email_tpl_status = 2
            LIMIT 1
        ");

        if($checkTpl->num_rows()){
            return $checkTpl->row();
        } else {

            $result = $this->db->query("
                SELECT 
                    eet.email_tpl_id
                    ".$select."
                FROM event_email_template eet
                WHERE 
                    eet.email_tpl_status = 1
                    AND eet.email_type_id = ".$email_type_id." 
                    AND eet.email_tpl_creation_status = 'DEFAULT'
                LIMIT 1
                ");

            if($result->num_rows()){
                return $result->row();
            } else {
                return array();
            }

        }
    }

    public function get_default_template($email_template_id){
        $default_template = $this->db->select("email_type_subject, email_type_template")
            ->from('event_email_template_type')
            ->where('email_type_id', $email_template_id)
            ->where('email_type_status', 1)
            ->limit(1)
            ->get()
            ->row();

        if($default_template){
            return $default_template;
        } else return false;
    }

    public function upload_default_email_template($email_template){
       $this->db->where('email_type_status',1);
       $this->db->update_batch('event_email_template_type', $email_template, 'email_type_id');
       $this->db->trans_complete();        
       return ($this->db->trans_status() === FALSE)? FALSE:TRUE;
    }
}