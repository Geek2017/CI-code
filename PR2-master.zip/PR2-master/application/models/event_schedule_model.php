<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 
	
class Event_schedule_model extends CI_Model {

    function __construct(){
        parent::__construct();
    }

    public function get_all_event_schedule($event_id){
        $this->db->select("*");
        $this->db->select("total_available_seat AS avl_seats", FALSE);
        $this->db->select("DATE_FORMAT(reservation_start_date, '%e/%m/%Y %Hh%i') AS reservation_start_date", FALSE);
        $this->db->select("(CASE 
                WHEN DATE_FORMAT(reservation_end_date, '%e/%m/%Y %Hh%i') IS NULL
                    THEN \"\"
                    ELSE DATE_FORMAT(reservation_end_date, '%e/%m/%Y %Hh%i')
                END)", FALSE);
        $this->db->select("DATE_FORMAT(start_date_time, '%e/%m/%Y %Hh%i') AS start_date_time", FALSE);
        $this->db->select("DATE_FORMAT(end_date_time, '%e/%m/%Y %Hh%i') AS end_date_time", FALSE);
        $this->db->select("remaining_seat AS rem_seats", FALSE);
        $this->db->where("back_office_status NOT IN(5,6)");
        $this->db->where("event_id", $event_id);
        return $this->db->get("event_schedule")->result();
    }

    public function add_new_event_schedule($user_id, $event_id, $event_schedules){
        //lets insert them one by one..
        foreach ($event_schedules as $index => $event_sched) {

            $event_sched = $this->filter_form_inputs($event_sched);
            //add event_id 
            $event_sched["event_id"] = $event_id;
            //add author
            $event_sched["author"] = $user_id;

            //set the total available seats as remaining seats
            $event_sched["remaining_seat"]= $event_sched["total_available_seat"]; 

             // status: being created
            if($event_sched["back_office_status"] == 0 || !isset($event_sched["back_office_status"])) {
                $event_sched["back_office_status"] = 0;
                $event_sched["event_status"] = "AVAILABLE";
            }

            //checking for past event
            $event_sched["back_office_status"] = $this->recheck_bo_status($event_sched);
            if($event_sched["back_office_status"] == 4) $event_sched["display_status"] = 0;

            $this->db->insert("event_schedule", $event_sched);
        }
    }

    private function recheck_bo_status($event_data){
        //checking for past event
        if($event_data["start_date_time"] != "") {
            if (strtotime(date("Y-m-d H:i:s")) > strtotime(date($event_data["start_date_time"]))) {
                if(!in_array($event_data["back_office_status"], array(5,0))) { //not yet archived/encours
                    return 4; //closed event
                }
            }
        }else if($event_data["end_date_time"] != ""){
            if (strtotime(date("Y-m-d H:i:s")) > strtotime(date($event_data["end_date_time"]))) {
                if(!in_array($event_data["back_office_status"], array(5,0))) { //not yet archived/encours
                    return 4; //closed event
                }
            }
        }

        return $event_data["back_office_status"];
    }

    //filter event dates input
    private function filter_form_inputs($event_sched){

        if($event_sched["start_date_time"] && $event_sched["start_date_time"]!= "") {
            $start_date_time = date_create($event_sched["start_date_time"]);
            $event_sched["start_date_time"] = date_format($start_date_time, 'Y-m-d H:i:s');
        }
        if($event_sched["end_date_time"]) {
            $end_date_time= date_create($event_sched["end_date_time"]);
            $event_sched["end_date_time"] = date_format($end_date_time, 'Y-m-d H:i:s');
        }
        if($event_sched["reservation_start_date"]) {
            $reservation_start_date= date_create($event_sched["reservation_start_date"]);
            $event_sched["reservation_start_date"] = date_format($reservation_start_date, 'Y-m-d H:i:s');
        }

        return $event_sched;
    }
}