<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['protocol'] = "smtp";
$config['smtp_host'] = "ex.mail.ovh.net";
$config['smtp_port'] = "587";
$config['smtp_user'] = "lemonde@wylog.com";
$config['smtp_pass'] = "HeL10R2d2";
$config['mailtype'] = "html";
$config['charset'] = "UTF-8";
$config['smtp_crypto'] = "tls";

//$config['protocol'] = "smtp";
//$config['smtp_host'] = "ssl://smtp.gmail.com";
//$config['smtp_port'] = "465";
//$config['smtp_user'] = "lemondeforgotpass@gmail.com";
//$config['smtp_pass'] = "lemonde2016";
//$config['mailtype'] = "html";
//$config['charset'] = "UTF-8";